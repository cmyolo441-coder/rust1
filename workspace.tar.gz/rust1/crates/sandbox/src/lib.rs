//! OS isolation: bwrap/Landlock/seccomp, Seatbelt, AppContainer, egress.
#![warn(missing_docs)]
