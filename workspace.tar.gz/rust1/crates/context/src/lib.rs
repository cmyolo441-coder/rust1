//! Context economy: assembly, compaction ladder, memory, ledger, pressure.
#![warn(missing_docs)]
