//! Enterprise managed policy (`rustplan.txt` §6.4, §9.5 `src/managed.rs`).
//!
//! A managed policy is a file the *administrator* owns and the user cannot edit.
//! It is merged over the user's config with **most-restrictive-wins**: the merge
//! can only ever take privileges away, never add them. That single property is
//! what makes "we rolled out a deny rule to 400 engineers" safe to say out loud.
//!
//! Locations searched, first existing file wins (§3):
//!
//! | OS      | path                                              |
//! |---------|---------------------------------------------------|
//! | Linux   | `/etc/agent/policy.toml`                          |
//! | macOS   | `/Library/Application Support/agent/policy.toml`  |
//! | Windows | `C:\ProgramData\agent\policy.toml`                |
//! | any     | `$AGENT_MANAGED_POLICY` (explicit override, testing) |
//!
//! On unix the file must be owned by uid 0 and not group/world-writable,
//! otherwise it is **ignored with a loud warning**: an attacker who can write
//! `/etc/agent/policy.toml` already owns the box, but a user-writable copy in a
//! home directory should not be able to *grant* itself anything.

use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use agent_protocol::permission::Mode;

use crate::modes::{clamp, rank};
use crate::network::{NetworkDefault, NetworkPolicy, PortRange};

/// The managed policy file. Every field is optional; absence means "no
/// opinion", not "permit".
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ManagedPolicy {
    /// Highest mode a user may select.
    #[serde(default)]
    pub max_mode: Option<Mode>,
    /// Deny patterns. Unioned with the user's; cannot be removed.
    #[serde(default)]
    pub deny: Vec<String>,
    /// Ask patterns. Unioned; a managed `ask` beats a user `allow`.
    #[serde(default)]
    pub ask: Vec<String>,
    /// Allow patterns. Applied **only** where no managed deny/ask matches, so a
    /// managed allow can open a path the user config left closed but can never
    /// punch through a managed deny.
    #[serde(default)]
    pub allow: Vec<String>,
    /// Network constraints.
    #[serde(default)]
    pub network: Option<ManagedNetwork>,
    /// Force the sandbox on; the user's `--no-sandbox` is refused.
    #[serde(default)]
    pub force_sandbox: bool,
    /// Refuse to let the user turn redaction off.
    #[serde(default)]
    pub require_redaction: bool,
    /// Require audit logging to a path the user cannot disable.
    #[serde(default)]
    pub require_audit: bool,
    /// Refuse `bypass` entirely, even with the CLI flag.
    #[serde(default)]
    pub forbid_bypass: bool,
    /// Maximum worker fan-out.
    #[serde(default)]
    pub max_workers: Option<u8>,
    /// Maximum model tier (cost control). `1` = small only.
    #[serde(default)]
    pub max_model_tier: Option<u8>,
    /// Providers the user may talk to.
    #[serde(default)]
    pub allowed_providers: Vec<String>,
    /// Models the user may talk to (takes precedence over providers).
    #[serde(default)]
    pub allowed_models: Vec<String>,
    /// Message shown to the user when a managed rule fires.
    #[serde(default)]
    pub contact: Option<String>,
    /// Policy version, for `agent config explain` output.
    #[serde(default)]
    pub version: Option<String>,
}

/// Managed network constraints.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ManagedNetwork {
    /// Ceiling on the network default.
    #[serde(default)]
    pub max_default: Option<NetworkDefault>,
    /// Hosts denied for everyone.
    #[serde(default)]
    pub deny_hosts: Vec<String>,
    /// The only hosts anyone may reach. Empty = no restriction.
    #[serde(default)]
    pub allow_hosts: Vec<String>,
    /// Ports denied for everyone.
    #[serde(default)]
    pub deny_ports: Vec<PortRange>,
    /// Force private-range blocking even if the user disabled it.
    #[serde(default)]
    pub block_private_ranges: Option<bool>,
    /// Force TLS.
    #[serde(default)]
    pub require_tls: Option<bool>,
}

/// What the user asked for, in the subset that managed policy can constrain.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct UserPolicy {
    /// Requested mode.
    pub mode: Mode,
    /// User allow patterns.
    #[serde(default)]
    pub allow: Vec<String>,
    /// User ask patterns.
    #[serde(default)]
    pub ask: Vec<String>,
    /// User deny patterns.
    #[serde(default)]
    pub deny: Vec<String>,
    /// User network policy.
    #[serde(default)]
    pub network: NetworkPolicy,
    /// User asked for no sandbox.
    #[serde(default)]
    pub no_sandbox: bool,
    /// User turned redaction off.
    #[serde(default)]
    pub redaction_disabled: bool,
    /// User turned the audit log off.
    #[serde(default)]
    pub audit_disabled: bool,
    /// Bypass flag present on the command line.
    #[serde(default)]
    pub bypass_flag: bool,
    /// Requested worker fan-out.
    #[serde(default)]
    pub max_workers: Option<u8>,
    /// Requested model tier ceiling.
    #[serde(default)]
    pub max_model_tier: Option<u8>,
    /// Provider the user configured.
    #[serde(default)]
    pub provider: Option<String>,
    /// Model the user configured.
    #[serde(default)]
    pub model: Option<String>,
}

impl Default for UserPolicy {
    fn default() -> Self {
        Self {
            mode: Mode::default(),
            allow: Vec::new(),
            ask: Vec::new(),
            deny: Vec::new(),
            network: NetworkPolicy::default(),
            no_sandbox: false,
            redaction_disabled: false,
            audit_disabled: false,
            bypass_flag: false,
            max_workers: None,
            max_model_tier: None,
            provider: None,
            model: None,
        }
    }
}

/// The merged result.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EffectivePolicy {
    /// Mode in force.
    pub mode: Mode,
    /// Deny patterns, most restrictive first (managed before user).
    pub deny: Vec<String>,
    /// Ask patterns.
    pub ask: Vec<String>,
    /// Allow patterns, after removing anything a managed deny/ask shadows.
    pub allow: Vec<String>,
    /// Network policy in force.
    pub network: NetworkPolicy,
    /// Sandbox must be on.
    pub sandbox_required: bool,
    /// Redaction must be on.
    pub redaction_required: bool,
    /// Audit must be on.
    pub audit_required: bool,
    /// Bypass is unavailable even with the flag.
    pub bypass_forbidden: bool,
    /// Worker fan-out ceiling.
    pub max_workers: Option<u8>,
    /// Model tier ceiling.
    pub max_model_tier: Option<u8>,
    /// Every override the merge applied, for `agent config explain`.
    pub overrides: Vec<Override>,
}

/// One place where managed policy changed the user's request.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Override {
    /// What was constrained.
    pub field: String,
    /// What the user asked for.
    pub requested: String,
    /// What they get.
    pub effective: String,
    /// Why, in one sentence.
    pub reason: String,
}

impl Override {
    /// Rendered line for `agent config explain`.
    #[must_use]
    pub fn render(&self) -> String {
        format!("{}: requested `{}` → effective `{}` ({})", self.field, self.requested, self.effective, self.reason)
    }
}

/// Errors while loading a managed policy.
#[derive(Debug, thiserror::Error)]
pub enum ManagedError {
    /// I/O failure.
    #[error("cannot read managed policy {path}: {source}")]
    Io {
        /// Path.
        path: PathBuf,
        /// Underlying error.
        #[source]
        source: std::io::Error,
    },
    /// Parse failure. A malformed managed policy is **fatal**: silently
    /// ignoring it would silently drop every enterprise control.
    #[error("managed policy {path} is not valid TOML: {message}")]
    Parse {
        /// Path.
        path: PathBuf,
        /// Message.
        message: String,
    },
    /// The file is not owned/permissioned as required.
    #[error("managed policy {path} is not trustworthy: {reason}")]
    Untrusted {
        /// Path.
        path: PathBuf,
        /// Why.
        reason: String,
    },
}

/// Candidate managed policy paths for this platform, plus the env override.
/// The env value is passed in rather than read, so tests stay hermetic (§2.6:
/// no hidden global state).
#[must_use]
pub fn managed_policy_paths(env_override: Option<&str>) -> Vec<PathBuf> {
    let mut out = Vec::new();
    if let Some(p) = env_override {
        if !p.trim().is_empty() {
            out.push(PathBuf::from(p));
        }
    }
    if cfg!(target_os = "macos") {
        out.push(PathBuf::from("/Library/Application Support/agent/policy.toml"));
    } else if cfg!(target_os = "windows") {
        out.push(PathBuf::from(r"C:\ProgramData\agent\policy.toml"));
    } else {
        out.push(PathBuf::from("/etc/agent/policy.toml"));
    }
    // XDG fallback for systems where /etc is not writable by the fleet tooling.
    if let Some(dir) = std::env::var_os("XDG_CONFIG_DIRS") {
        for d in std::env::split_paths(&dir) {
            out.push(d.join("agent").join("policy.toml"));
        }
    }
    out
}

/// Load the first existing, trustworthy managed policy.
///
/// Returns `(policy, path, warnings)`. `Ok(None)` means "no managed policy" —
/// which is the normal case on a developer laptop.
///
/// # Errors
/// [`ManagedError::Parse`] on malformed TOML (fatal, never ignored),
/// [`ManagedError::Io`] when a file exists but cannot be read.
pub fn load(
    env_override: Option<&str>,
    require_root_owner: bool,
) -> Result<Option<(ManagedPolicy, PathBuf, Vec<String>)>, ManagedError> {
    let mut warnings = Vec::new();
    for path in managed_policy_paths(env_override) {
        if !path.exists() {
            continue;
        }
        if require_root_owner {
            if let Err(e) = check_ownership(&path, env_override.is_some()) {
                warnings.push(e.to_string());
                continue;
            }
        }
        let text = std::fs::read_to_string(&path).map_err(|source| ManagedError::Io { path: path.clone(), source })?;
        let policy = parse(&text).map_err(|e| ManagedError::Parse { path: path.clone(), message: e.to_string() })?;
        return Ok(Some((policy, path, warnings)));
    }
    if warnings.is_empty() {
        Ok(None)
    } else {
        Ok(None)
    }
}

/// Parse managed policy TOML.
///
/// # Errors
/// A TOML error message, or a complaint about unknown keys — a typo'd key in a
/// managed policy means a control that silently does not exist.
pub fn parse(text: &str) -> Result<ManagedPolicy, String> {
    toml::from_str::<ManagedPolicy>(text).map_err(|e| e.to_string())
}

/// Verify ownership/permissions on unix. Ignored elsewhere.
///
/// # Errors
/// [`ManagedError::Untrusted`] when the file is not root-owned or is writable by
/// anyone other than root.
pub fn check_ownership(path: &Path, allow_env_override: bool) -> Result<(), ManagedError> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        let md = std::fs::metadata(path)
            .map_err(|source| ManagedError::Io { path: path.to_path_buf(), source })?;
        if !allow_env_override && md.uid() != 0 {
            return Err(ManagedError::Untrusted {
                path: path.to_path_buf(),
                reason: format!("owned by uid {} (expected 0)", md.uid()),
            });
        }
        let mode = md.mode();
        if mode & 0o022 != 0 {
            return Err(ManagedError::Untrusted {
                path: path.to_path_buf(),
                reason: format!("mode {:o} is group- or world-writable", mode & 0o777),
            });
        }
        Ok(())
    }
    #[cfg(not(unix))]
    {
        let _ = (path, allow_env_override);
        Ok(())
    }
}

/// Merge a user policy with a managed policy. Most restrictive wins, always.
#[must_use]
pub fn merge(user: &UserPolicy, managed: Option<&ManagedPolicy>) -> EffectivePolicy {
    let mut overrides = Vec::new();
    let Some(m) = managed else {
        return EffectivePolicy {
            mode: user.mode,
            deny: user.deny.clone(),
            ask: user.ask.clone(),
            allow: user.allow.clone(),
            network: user.network.clone(),
            sandbox_required: false,
            redaction_required: false,
            audit_required: false,
            bypass_forbidden: false,
            max_workers: user.max_workers,
            max_model_tier: user.max_model_tier,
            overrides,
        };
    };

    // --- mode -------------------------------------------------------------
    let mut mode = user.mode;
    if let Some(ceiling) = m.max_mode {
        if rank(mode) > rank(ceiling) {
            overrides.push(Override {
                field: "mode".into(),
                requested: mode.to_string(),
                effective: ceiling.to_string(),
                reason: format!("managed policy pins max_mode = {}", ceiling),
            });
            mode = clamp(mode, ceiling);
        }
    }
    let mut bypass_forbidden = m.forbid_bypass;
    if m.forbid_bypass && user.bypass_flag {
        overrides.push(Override {
            field: "bypass".into(),
            requested: "bypass".into(),
            effective: mode.to_string(),
            reason: "managed policy forbids bypass; the CLI flag was ignored".into(),
        });
    }
    if bypass_forbidden && mode == Mode::Bypass {
        mode = Mode::AutoEdit;
    }

    // --- rules ------------------------------------------------------------
    let mut deny: Vec<String> = m.deny.clone();
    deny.extend(user.deny.iter().cloned());
    deny.dedup();
    let mut ask: Vec<String> = m.ask.clone();
    ask.extend(user.ask.iter().cloned());
    ask.dedup();

    // A user allow is dropped when a managed deny or ask shadows it. Shadowing
    // is decided by *pattern equality or containment of the literal part*; the
    // engine still re-evaluates at call time, this is only about not showing the
    // user an allow that can never fire.
    let mut allow: Vec<String> = Vec::new();
    for a in &user.allow {
        if shadows(&m.deny, a) || shadows(&m.ask, a) {
            overrides.push(Override {
                field: "allow".into(),
                requested: a.clone(),
                effective: "(dropped)".into(),
                reason: "a managed deny/ask rule covers this pattern".into(),
            });
            continue;
        }
        allow.push(a.clone());
    }
    // Managed allows are appended last: they can open something the user closed,
    // but the engine's deny→ask→allow order means they still lose to any deny.
    allow.extend(m.allow.iter().cloned());
    allow.dedup();

    // --- network ----------------------------------------------------------
    let mut network = user.network.clone();
    if let Some(mn) = &m.network {
        if let Some(max) = mn.max_default {
            if default_rank(network.default) > default_rank(max) {
                overrides.push(Override {
                    field: "network.default".into(),
                    requested: network.default.as_str().into(),
                    effective: max.as_str().into(),
                    reason: "managed policy caps the network default".into(),
                });
                network.default = max;
            }
        }
        for h in &mn.deny_hosts {
            if !network.deny_hosts.contains(h) {
                network.deny_hosts.push(h.clone());
            }
        }
        if !mn.allow_hosts.is_empty() {
            // Intersection semantics: a managed allowlist narrows the user's.
            let effective = if network.allow_hosts.is_empty() {
                mn.allow_hosts.clone()
            } else {
                network
                    .allow_hosts
                    .iter()
                    .filter(|h| mn.allow_hosts.iter().any(|m| m == *h))
                    .cloned()
                    .collect::<Vec<_>>()
            };
            if effective != network.allow_hosts {
                overrides.push(Override {
                    field: "network.allow_hosts".into(),
                    requested: format!("{} entries", network.allow_hosts.len()),
                    effective: format!("{} entries", effective.len()),
                    reason: "managed allow_hosts narrows the list".into(),
                });
            }
            network.allow_hosts = effective;
        }
        for p in &mn.deny_ports {
            if !network.deny_ports.contains(p) {
                network.deny_ports.push(*p);
            }
        }
        if mn.block_private_ranges == Some(true) && !network.block_private_ranges {
            overrides.push(Override {
                field: "network.block_private_ranges".into(),
                requested: "false".into(),
                effective: "true".into(),
                reason: "managed policy forces private-range blocking".into(),
            });
            network.block_private_ranges = true;
        }
        if mn.require_tls == Some(true) && !network.require_tls {
            overrides.push(Override {
                field: "network.require_tls".into(),
                requested: "false".into(),
                effective: "true".into(),
                reason: "managed policy forces TLS".into(),
            });
            network.require_tls = true;
        }
    }

    // --- hard switches ----------------------------------------------------
    let mut sandbox_required = m.force_sandbox;
    if m.force_sandbox && user.no_sandbox {
        overrides.push(Override {
            field: "sandbox".into(),
            requested: "off (--no-sandbox)".into(),
            effective: "on".into(),
            reason: "managed policy forces the sandbox; the flag was ignored".into(),
        });
    }
    let mut redaction_required = m.require_redaction;
    if m.require_redaction && user.redaction_disabled {
        overrides.push(Override {
            field: "redaction".into(),
            requested: "off".into(),
            effective: "on".into(),
            reason: "managed policy requires secret redaction".into(),
        });
    }
    let mut audit_required = m.require_audit;
    if m.require_audit && user.audit_disabled {
        overrides.push(Override {
            field: "audit".into(),
            requested: "off".into(),
            effective: "on".into(),
            reason: "managed policy requires the audit log".into(),
        });
    }

    // --- numeric ceilings -------------------------------------------------
    let max_workers = lower_of(user.max_workers, m.max_workers, "max_workers", &mut overrides);
    let max_model_tier = lower_of(user.max_model_tier, m.max_model_tier, "max_model_tier", &mut overrides);

    // --- provider/model ---------------------------------------------------
    if !m.allowed_providers.is_empty() {
        if let Some(p) = &user.provider {
            if !m.allowed_providers.iter().any(|a| a.eq_ignore_ascii_case(p)) {
                overrides.push(Override {
                    field: "provider".into(),
                    requested: p.clone(),
                    effective: m.allowed_providers.first().cloned().unwrap_or_default(),
                    reason: format!("managed policy allows only [{}]", m.allowed_providers.join(", ")),
                });
            }
        }
    }
    if !m.allowed_models.is_empty() {
        if let Some(md) = &user.model {
            if !m.allowed_models.iter().any(|a| a == md) {
                overrides.push(Override {
                    field: "model".into(),
                    requested: md.clone(),
                    effective: m.allowed_models.first().cloned().unwrap_or_default(),
                    reason: format!("managed policy allows only [{}]", m.allowed_models.join(", ")),
                });
            }
        }
    }

    let _ = &mut sandbox_required;
    let _ = &mut redaction_required;
    let _ = &mut audit_required;
    let _ = &mut bypass_forbidden;

    EffectivePolicy {
        mode,
        deny,
        ask,
        allow,
        network,
        sandbox_required,
        redaction_required,
        audit_required,
        bypass_forbidden,
        max_workers,
        max_model_tier,
        overrides,
    }
}

fn lower_of(user: Option<u8>, managed: Option<u8>, field: &str, overrides: &mut Vec<Override>) -> Option<u8> {
    match (user, managed) {
        (Some(u), Some(m)) => {
            if u > m {
                overrides.push(Override {
                    field: field.into(),
                    requested: u.to_string(),
                    effective: m.to_string(),
                    reason: "managed policy sets a lower ceiling".into(),
                });
                Some(m)
            } else {
                Some(u)
            }
        }
        (None, Some(m)) => Some(m),
        (Some(u), None) => Some(u),
        (None, None) => None,
    }
}

const fn default_rank(d: NetworkDefault) -> u8 {
    match d {
        NetworkDefault::LocalhostOnly => 0,
        NetworkDefault::Allowlisted => 1,
        NetworkDefault::Open => 2,
    }
}

/// True when any pattern in `managed` would shadow `user_pattern`.
///
/// Shadowing is exact-match or tool-match with a wildcard managed selector:
/// `shell(*)` shadows every `shell(…)`. Anything subtler is left to the engine's
/// specificity rules at call time.
fn shadows(managed: &[String], user_pattern: &str) -> bool {
    let (utool, usel) = split_pattern(user_pattern);
    managed.iter().any(|m| {
        let (mtool, msel) = split_pattern(m);
        (mtool == "*" || mtool == utool) && (msel == "*" || msel == usel)
    })
}

fn split_pattern(p: &str) -> (&str, &str) {
    match p.split_once('(') {
        Some((tool, rest)) => (tool, rest.trim_end_matches(')')),
        None => (p, ""),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn user() -> UserPolicy {
        UserPolicy {
            mode: Mode::Bypass,
            allow: vec!["shell(git status)".into(), "read(src/**)".into()],
            ask: vec!["shell(cargo publish*)".into()],
            deny: vec!["write(secret/**)".into()],
            network: NetworkPolicy { default: NetworkDefault::Open, deny_ports: Vec::new(), ..Default::default() },
            no_sandbox: true,
            redaction_disabled: true,
            audit_disabled: true,
            bypass_flag: true,
            max_workers: Some(8),
            max_model_tier: Some(3),
            provider: Some("openai".into()),
            model: Some("gpt-5".into()),
            ..Default::default()
        }
    }

    fn managed() -> ManagedPolicy {
        ManagedPolicy {
            max_mode: Some(Mode::Ask),
            deny: vec!["shell(git push*)".into()],
            ask: vec!["shell(git status)".into()],
            allow: vec!["read(docs/**)".into()],
            network: Some(ManagedNetwork {
                max_default: Some(NetworkDefault::Allowlisted),
                deny_hosts: vec!["*.evil.test".into()],
                allow_hosts: vec!["api.openai.com".into()],
                deny_ports: vec![PortRange::one(22)],
                block_private_ranges: Some(true),
                require_tls: Some(true),
            }),
            force_sandbox: true,
            require_redaction: true,
            require_audit: true,
            forbid_bypass: true,
            max_workers: Some(2),
            max_model_tier: Some(1),
            allowed_providers: vec!["anthropic".into()],
            allowed_models: vec!["claude-opus-4-6".into()],
            contact: Some("security@example.com".into()),
            version: Some("2026.10".into()),
        }
    }

    #[test]
    fn no_managed_policy_means_the_user_wins() {
        let e = merge(&user(), None);
        assert_eq!(e.mode, Mode::Bypass);
        assert!(e.overrides.is_empty());
        assert!(e.allow.contains(&"shell(git status)".to_string()));
        assert!(!e.sandbox_required);
    }

    #[test]
    fn mode_is_clamped_to_the_managed_ceiling() {
        let e = merge(&user(), Some(&managed()));
        assert_eq!(e.mode, Mode::Ask);
        assert!(e.overrides.iter().any(|o| o.field == "mode"), "{:?}", e.overrides);
    }

    #[test]
    fn bypass_is_refused_when_forbidden() {
        let e = merge(&user(), Some(&managed()));
        assert!(e.bypass_forbidden);
        assert_ne!(e.mode, Mode::Bypass);
        assert!(e.overrides.iter().any(|o| o.field == "bypass"));
    }

    #[test]
    fn rules_are_unioned_and_deny_still_wins() {
        let e = merge(&user(), Some(&managed()));
        assert!(e.deny.contains(&"shell(git push*)".to_string()));
        assert!(e.deny.contains(&"write(secret/**)".to_string()));
        assert_eq!(e.deny[0], "shell(git push*)", "managed rules come first");
        assert!(e.ask.contains(&"shell(cargo publish*)".to_string()));
    }

    #[test]
    fn a_user_allow_shadowed_by_a_managed_ask_is_dropped() {
        let e = merge(&user(), Some(&managed()));
        assert!(!e.allow.contains(&"shell(git status)".to_string()), "{:?}", e.allow);
        assert!(e.allow.contains(&"read(src/**)".to_string()));
        assert!(e.allow.contains(&"read(docs/**)".to_string()), "managed allows are added");
        assert!(e.overrides.iter().any(|o| o.field == "allow"));
    }

    #[test]
    fn network_is_narrowed_to_the_managed_ceiling() {
        let e = merge(&user(), Some(&managed()));
        assert_eq!(e.network.default, NetworkDefault::Allowlisted);
        assert!(e.network.deny_hosts.contains(&"*.evil.test".to_string()));
        assert_eq!(e.network.allow_hosts, vec!["api.openai.com".to_string()]);
        assert!(e.network.deny_ports.contains(&PortRange::one(22)));
        assert!(e.network.block_private_ranges);
        assert!(e.network.require_tls);
    }

    #[test]
    fn hard_switches_are_forced_on() {
        let e = merge(&user(), Some(&managed()));
        assert!(e.sandbox_required);
        assert!(e.redaction_required);
        assert!(e.audit_required);
        for f in ["sandbox", "redaction", "audit"] {
            assert!(e.overrides.iter().any(|o| o.field == f), "missing override for {f}");
        }
    }

    #[test]
    fn numeric_ceilings_only_go_down() {
        let e = merge(&user(), Some(&managed()));
        assert_eq!(e.max_workers, Some(2));
        assert_eq!(e.max_model_tier, Some(1));
        // A user asking for less keeps their lower number.
        let u = UserPolicy { max_workers: Some(1), max_model_tier: Some(1), ..user() };
        let m = ManagedPolicy { max_workers: Some(4), max_model_tier: Some(3), ..Default::default() };
        let e2 = merge(&u, Some(&m));
        assert_eq!(e2.max_workers, Some(1));
        assert_eq!(e2.max_model_tier, Some(1));
    }

    #[test]
    fn provider_and_model_restrictions_are_reported() {
        let e = merge(&user(), Some(&managed()));
        let p = e.overrides.iter().find(|o| o.field == "provider").unwrap();
        assert_eq!(p.requested, "openai");
        assert_eq!(p.effective, "anthropic");
        let m = e.overrides.iter().find(|o| o.field == "model").unwrap();
        assert_eq!(m.effective, "claude-opus-4-6");
    }

    #[test]
    fn an_allowed_provider_produces_no_override() {
        let u = UserPolicy { provider: Some("anthropic".into()), model: Some("claude-opus-4-6".into()), ..user() };
        let e = merge(&u, Some(&managed()));
        assert!(!e.overrides.iter().any(|o| o.field == "provider"), "{:?}", e.overrides);
        assert!(!e.overrides.iter().any(|o| o.field == "model"));
    }

    #[test]
    fn overrides_render_for_config_explain() {
        let e = merge(&user(), Some(&managed()));
        let text = e.overrides.iter().map(Override::render).collect::<Vec<_>>().join("\n");
        assert!(text.contains("mode: requested `bypass` → effective `ask`"), "{text}");
        assert!(text.contains("managed policy"), "{text}");
    }

    #[test]
    fn shadowing_is_pattern_aware() {
        assert!(shadows(&["shell(*)".into()], "shell(git status)"));
        assert!(shadows(&["shell(git status)".into()], "shell(git status)"));
        assert!(!shadows(&["shell(git push*)".into()], "shell(git status)"));
        assert!(shadows(&["*(*)".into()], "read(src/**)"));
        assert!(!shadows(&["read(*)".into()], "write(src/**)"));
    }

    #[test]
    fn managed_toml_parses() {
        let text = r#"
version = "2026.10"
max_mode = "read-only"
force_sandbox = true
require_redaction = true
forbid_bypass = true
max_workers = 2
deny = ["shell(git push*)", "write(.github/**)"]
ask  = ["shell(cargo publish*)"]
contact = "security@example.com"

[network]
max_default = "allowlisted"
deny_hosts = ["*.evil.test"]
allow_hosts = ["api.anthropic.com"]
require_tls = true
"#;
        let p = parse(text).unwrap();
        assert_eq!(p.max_mode, Some(Mode::ReadOnly));
        assert!(p.force_sandbox);
        assert!(p.forbid_bypass);
        assert_eq!(p.deny.len(), 2);
        assert_eq!(p.network.as_ref().unwrap().max_default, Some(NetworkDefault::Allowlisted));
        assert_eq!(p.contact.as_deref(), Some("security@example.com"));
    }

    #[test]
    fn unknown_keys_in_a_managed_policy_are_fatal() {
        let err = parse("max_mode = \"ask\"\ndneay = [\"x\"]\n").unwrap_err();
        assert!(err.contains("unknown field") || err.contains("dneay"), "{err}");
    }

    #[test]
    fn a_bad_mode_string_is_fatal() {
        assert!(parse("max_mode = \"yolo\"").is_err());
    }

    #[test]
    fn paths_include_the_platform_default_and_the_env_override() {
        let p = managed_policy_paths(Some("/tmp/custom/policy.toml"));
        assert_eq!(p[0], PathBuf::from("/tmp/custom/policy.toml"));
        assert!(p.len() >= 2, "{p:?}");
        let none = managed_policy_paths(None);
        assert!(!none.iter().any(|x| x.to_string_lossy().contains("custom")));
    }

    #[test]
    fn ownership_check_rejects_a_world_writable_file() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("policy.toml");
        std::fs::write(&path, "max_mode = \"ask\"\n").unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o666)).unwrap();
            let err = check_ownership(&path, false).unwrap_err();
            assert!(matches!(err, ManagedError::Untrusted { .. }), "{err}");
            // The env override relaxes the uid check but never the mode check.
            assert!(check_ownership(&path, true).is_err());
            std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
            assert!(check_ownership(&path, true).is_ok());
            // Without the override, a non-root owner is still refused.
            if std::process::id() != 0 {
                assert!(check_ownership(&path, false).is_err());
            }
        }
        #[cfg(not(unix))]
        assert!(check_ownership(&path, false).is_ok());
    }

    #[test]
    fn loading_a_file_from_an_explicit_path_works() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("policy.toml");
        std::fs::write(&path, "max_mode = \"plan\"\nrequire_audit = true\n").unwrap();
        let loaded = load(Some(path.to_str().unwrap()), false).unwrap().expect("policy present");
        assert_eq!(loaded.0.max_mode, Some(Mode::Plan));
        assert!(loaded.0.require_audit);
        assert_eq!(loaded.1, path);
    }

    #[test]
    fn a_malformed_managed_policy_is_an_error_not_a_warning() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("policy.toml");
        std::fs::write(&path, "max_mode = \n").unwrap();
        let err = load(Some(path.to_str().unwrap()), false).unwrap_err();
        assert!(matches!(err, ManagedError::Parse { .. }), "{err}");
    }

    #[test]
    fn effective_policy_serialises_for_the_audit_record() {
        let e = merge(&user(), Some(&managed()));
        let json = serde_json::to_string(&e).unwrap();
        assert!(json.contains("overrides"));
        assert!(json.contains("sandbox_required"));
        let back: EffectivePolicy = serde_json::from_str(&json).unwrap();
        assert_eq!(back, e);
    }
}
