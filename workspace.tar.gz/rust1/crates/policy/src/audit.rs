//! Hash-chained audit log (`rustplan.txt` §6.4, §9.5 `src/audit.rs`).
//!
//! Format: **JSONL**, one canonical-JSON record per line, each carrying
//!
//! * `prev_hash` — blake3 hex of the previous record's canonical JSON, and
//! * `hash` — blake3 hex of this record's canonical JSON with `hash` removed.
//!
//! That is a Merkle-style chain: editing, deleting or reordering any line
//! invalidates every line after it, and `agent audit verify` says exactly where
//! the break is. Every [`ANCHOR_INTERVAL`] records the chain also emits an
//! **anchor** record containing the running root and the record count, so an
//! operator can pin that number somewhere else (SIEM, printed report, git
//! commit) and later prove a log was not truncated from the top.
//!
//! Canonical JSON here means: keys sorted (a [`BTreeMap`]), no insignificant
//! whitespace, numbers as integers where possible. Anything else makes hashes
//! non-reproducible across versions, which would be worse than no chain.

use std::collections::BTreeMap;
use std::io::{self, BufRead, Write};
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use agent_protocol::ids::{ThreadId, TurnId};
use agent_protocol::event::EVENT_SCHEMA_VERSION;

/// Records between anchors. §6.4 fixes this at 1000.
pub const ANCHOR_INTERVAL: u64 = 1000;
/// Genesis `prev_hash` for the first record in a chain.
pub const GENESIS_HASH: &str = "0000000000000000000000000000000000000000000000000000000000000000";

/// Who did the thing being audited.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Actor {
    /// A human at the terminal.
    User {
        /// OS username or configured identity.
        id: String,
    },
    /// The model, acting through a tool call.
    Model {
        /// Model id.
        id: String,
        /// Provider.
        provider: String,
    },
    /// A sub-agent worker.
    Worker {
        /// Worker id.
        id: String,
        /// The thread that spawned it.
        parent_thread: String,
    },
    /// Enterprise policy pushed by an admin.
    Admin {
        /// Admin identity.
        id: String,
        /// Managed policy source.
        source: String,
    },
    /// The agent itself (startup, compaction, GC, anchoring).
    System {
        /// Subsystem name.
        component: String,
    },
}

impl Actor {
    /// Stable rendering for reports.
    #[must_use]
    pub fn label(&self) -> String {
        match self {
            Self::User { id } => format!("user:{id}"),
            Self::Model { id, provider } => format!("model:{provider}/{id}"),
            Self::Worker { id, .. } => format!("worker:{id}"),
            Self::Admin { id, .. } => format!("admin:{id}"),
            Self::System { component } => format!("system:{component}"),
        }
    }
}

/// What happened. Additive-only: new variants are fine, renaming breaks every
/// existing log.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AuditAction {
    /// Session started.
    SessionStart,
    /// Session ended.
    SessionEnd,
    /// A tool call was executed.
    ToolInvoked,
    /// A tool call was refused by policy.
    ToolDenied,
    /// A tool call was approved by a human.
    ToolApproved,
    /// A tool call was refused by a human.
    ToolRefused,
    /// An approval was remembered as a grant.
    GrantRemembered,
    /// A grant was revoked.
    GrantRevoked,
    /// Permission mode changed.
    ModeChanged,
    /// Config (re)loaded, with the layer that won.
    ConfigLoaded,
    /// Managed/admin policy merged in.
    ManagedPolicyApplied,
    /// Sandbox refused an operation.
    SandboxViolation,
    /// Network egress blocked.
    NetworkBlocked,
    /// A secret was redacted before leaving the process.
    SecretRedacted,
    /// A worker was spawned.
    WorkerSpawned,
    /// A worker finished and its diff was merged.
    WorkerMerged,
    /// A merge-queue verify gate ran.
    VerifyGate,
    /// `git push` was attempted (never automatic — §7).
    PushAttempted,
    /// An `/undo` restored a snapshot.
    UndoApplied,
    /// Audit chain anchored.
    ChainAnchor,
    /// Audit log exported to SIEM.
    AuditExport,
    /// An incident report was generated.
    IncidentReport,
}

impl AuditAction {
    /// Wire name.
    #[must_use]
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::SessionStart => "session_start",
            Self::SessionEnd => "session_end",
            Self::ToolInvoked => "tool_invoked",
            Self::ToolDenied => "tool_denied",
            Self::ToolApproved => "tool_approved",
            Self::ToolRefused => "tool_refused",
            Self::GrantRemembered => "grant_remembered",
            Self::GrantRevoked => "grant_revoked",
            Self::ModeChanged => "mode_changed",
            Self::ConfigLoaded => "config_loaded",
            Self::ManagedPolicyApplied => "managed_policy_applied",
            Self::SandboxViolation => "sandbox_violation",
            Self::NetworkBlocked => "network_blocked",
            Self::SecretRedacted => "secret_redacted",
            Self::WorkerSpawned => "worker_spawned",
            Self::WorkerMerged => "worker_merged",
            Self::VerifyGate => "verify_gate",
            Self::PushAttempted => "push_attempted",
            Self::UndoApplied => "undo_applied",
            Self::ChainAnchor => "chain_anchor",
            Self::AuditExport => "audit_export",
            Self::IncidentReport => "incident_report",
        }
    }

    /// True for actions that a compliance reviewer must see (SOC2 evidence).
    #[must_use]
    pub fn is_compliance_relevant(&self) -> bool {
        matches!(
            self,
            Self::ToolDenied
                | Self::ToolApproved
                | Self::ToolRefused
                | Self::GrantRemembered
                | Self::GrantRevoked
                | Self::ModeChanged
                | Self::ManagedPolicyApplied
                | Self::SandboxViolation
                | Self::NetworkBlocked
                | Self::SecretRedacted
                | Self::PushAttempted
                | Self::UndoApplied
        )
    }
}

/// How it turned out.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Outcome {
    /// Permitted and completed.
    Allowed,
    /// Refused.
    Denied,
    /// A human was asked.
    Prompted,
    /// Failed after being permitted.
    Failed,
    /// Informational only.
    Info,
}

/// One audit record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AuditRecord {
    /// Record id (`aud_` + ULID).
    pub id: String,
    /// Wall clock, ms since epoch.
    pub ts_ms: u64,
    /// Schema version of the record format.
    pub schema_version: u32,
    /// Thread.
    pub thread_id: ThreadId,
    /// Turn, when the action belongs to one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Actor.
    pub actor: Actor,
    /// Action.
    pub action: AuditAction,
    /// Outcome.
    pub outcome: Outcome,
    /// Structured details. Keys sorted for canonical hashing.
    #[serde(default)]
    pub detail: BTreeMap<String, String>,
    /// Rule pattern / origin that decided this, when policy was involved.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub policy_ref: Option<String>,
    /// Hash of the previous record (genesis for the first).
    pub prev_hash: String,
    /// Hash of this record.
    pub hash: String,
    /// Position in the chain, 0-based.
    pub index: u64,
}

impl AuditRecord {
    /// Canonical JSON of this record with `hash` elided — the bytes that get
    /// hashed.
    ///
    /// # Errors
    /// Only on a serialisation failure of the record itself.
    pub fn canonical_for_hash(&self) -> Result<String, serde_json::Error> {
        let mut v = serde_json::to_value(self)?;
        if let Some(obj) = v.as_object_mut() {
            obj.remove("hash");
        }
        // serde_json::Map preserves insertion order unless the
        // `preserve_order` feature is on; re-encode through a BTreeMap to be
        // certain keys are sorted regardless of feature flags.
        let sorted = sort_value(&v);
        serde_json::to_string(&sorted)
    }

    /// Recompute this record's hash from its own contents.
    ///
    /// # Errors
    /// Propagates a canonicalisation failure.
    pub fn compute_hash(&self) -> Result<String, serde_json::Error> {
        Ok(blake3_hex(&self.canonical_for_hash()?))
    }

    /// True when the stored `hash` matches the recomputed one.
    ///
    /// # Errors
    /// Propagates a canonicalisation failure.
    pub fn hash_is_valid(&self) -> Result<bool, serde_json::Error> {
        Ok(self.compute_hash()? == self.hash)
    }

    /// True when `prev_hash` matches the given predecessor's `hash`.
    #[must_use]
    pub fn links_to(&self, prev: Option<&AuditRecord>) -> bool {
        match prev {
            None => self.prev_hash == GENESIS_HASH,
            Some(p) => self.prev_hash == p.hash && self.index == p.index + 1,
        }
    }

    /// One-line JSONL encoding.
    ///
    /// # Errors
    /// On serialisation failure.
    pub fn to_line(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string(self)
    }
}

/// Fresh `aud_`-prefixed record id.
#[must_use]
pub fn new_audit_id() -> String {
    format!("aud_{}", ulid::Ulid::new())
}

fn blake3_hex(s: &str) -> String {
    blake3::hash(s.as_bytes()).to_hex().to_string()
}

/// Recursively sort object keys so hashes do not depend on feature flags.
fn sort_value(v: &serde_json::Value) -> serde_json::Value {
    use serde_json::Value;
    match v {
        Value::Object(map) => {
            let mut out = BTreeMap::new();
            for (k, val) in map {
                out.insert(k.clone(), sort_value(val));
            }
            Value::Object(out.into_iter().collect::<serde_json::Map<_, _>>())
        }
        Value::Array(items) => Value::Array(items.iter().map(sort_value).collect()),
        other => other.clone(),
    }
}

/// Builder for records; keeps the field soup out of call sites.
#[derive(Debug, Clone)]
pub struct AuditBuilder {
    thread_id: ThreadId,
    turn_id: Option<TurnId>,
    actor: Actor,
    action: AuditAction,
    outcome: Outcome,
    detail: BTreeMap<String, String>,
    policy_ref: Option<String>,
    ts_ms: u64,
}

impl AuditBuilder {
    /// Start a builder.
    #[must_use]
    pub fn new(thread_id: ThreadId, actor: Actor, action: AuditAction) -> Self {
        Self {
            thread_id,
            turn_id: None,
            actor,
            action,
            outcome: Outcome::Info,
            detail: BTreeMap::new(),
            policy_ref: None,
            ts_ms: agent_protocol::now_ms(),
        }
    }

    /// Attach a turn.
    #[must_use]
    pub fn turn(mut self, turn_id: TurnId) -> Self {
        self.turn_id = Some(turn_id);
        self
    }

    /// Set the outcome.
    #[must_use]
    pub const fn outcome(mut self, outcome: Outcome) -> Self {
        self.outcome = outcome;
        self
    }

    /// Add a detail key/value.
    #[must_use]
    pub fn detail(mut self, k: impl Into<String>, v: impl ToString) -> Self {
        self.detail.insert(k.into(), v.to_string());
        self
    }

    /// Record the deciding rule.
    #[must_use]
    pub fn policy_ref(mut self, r: impl Into<String>) -> Self {
        self.policy_ref = Some(r.into());
        self
    }

    /// Override the timestamp (used by tests and by imports).
    #[must_use]
    pub const fn at(mut self, ts_ms: u64) -> Self {
        self.ts_ms = ts_ms;
        self
    }

    /// Finish into a record, given the chain position and previous hash.
    #[must_use]
    pub fn build(self, index: u64, prev_hash: &str) -> AuditRecord {
        let mut rec = AuditRecord {
            id: new_audit_id(),
            ts_ms: self.ts_ms,
            schema_version: EVENT_SCHEMA_VERSION,
            thread_id: self.thread_id,
            turn_id: self.turn_id,
            actor: self.actor,
            action: self.action,
            outcome: self.outcome,
            detail: self.detail,
            policy_ref: self.policy_ref,
            prev_hash: prev_hash.to_string(),
            hash: String::new(),
            index,
        };
        rec.hash = rec.compute_hash().unwrap_or_else(|_| GENESIS_HASH.to_string());
        rec
    }
}

/// The in-memory chain state plus an optional file sink.
pub struct AuditChain {
    path: Option<PathBuf>,
    last_hash: String,
    index: u64,
    anchors: Vec<Anchor>,
    buffer: Vec<String>,
}

/// An anchor: a pinnable statement about the chain so far.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Anchor {
    /// Number of records covered.
    pub count: u64,
    /// Hash of the last covered record.
    pub root_hash: String,
    /// When the anchor was written.
    pub ts_ms: u64,
    /// Index of the anchoring record in the chain.
    pub index: u64,
}

impl Anchor {
    /// One-line encoding for external pinning.
    ///
    /// # Errors
    /// On serialisation failure.
    pub fn to_line(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string(self)
    }
}

/// Errors from the audit subsystem.
#[derive(Debug, thiserror::Error)]
pub enum AuditError {
    /// I/O failure.
    #[error("audit I/O failed: {0}")]
    Io(#[from] io::Error),
    /// Serialisation failure.
    #[error("audit serialisation failed: {0}")]
    Serde(#[from] serde_json::Error),
    /// A malformed line was read back.
    #[error("audit line {line} is not valid JSON: {source}")]
    Malformed {
        /// 1-based line number.
        line: usize,
        /// Parse error.
        source: serde_json::Error,
    },
    /// The chain does not verify.
    #[error("audit chain broken at line {line} ({reason})")]
    Broken {
        /// 1-based line number.
        line: usize,
        /// Why.
        reason: String,
    },
}

impl AuditChain {
    /// An in-memory chain (used by tests and by the incident reporter).
    #[must_use]
    pub fn in_memory() -> Self {
        Self {
            path: None,
            last_hash: GENESIS_HASH.to_string(),
            index: 0,
            anchors: Vec::new(),
            buffer: Vec::new(),
        }
    }

    /// Open (creating if needed) a JSONL audit file and continue its chain.
    ///
    /// The existing tail is read so a restarted process extends the chain
    /// instead of forking it. If the existing chain does not verify, this
    /// returns [`AuditError::Broken`] — the agent refuses to append to a log it
    /// cannot vouch for.
    ///
    /// # Errors
    /// On I/O failure, malformed lines, or a broken chain.
    pub fn open(path: impl AsRef<Path>) -> Result<Self, AuditError> {
        let path = path.as_ref().to_path_buf();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let (last_hash, index, anchors) = if path.exists() {
            let report = AuditReader::verify_file(&path)?;
            if !report.ok {
                let p = report.problem.unwrap_or(ChainProblem { line: 0, reason: "unknown".into() });
                return Err(AuditError::Broken { line: p.line, reason: p.reason });
            }
            // `count` excludes anchor records; the chain position is the total
            // number of lines, so recover it from the last record's index.
            let total = report.last_index.map(|i| i + 1).unwrap_or(0);
            (report.last_hash.clone(), total, report.anchors)
        } else {
            (GENESIS_HASH.to_string(), 0, Vec::new())
        };
        Ok(Self { path: Some(path), last_hash, index, anchors, buffer: Vec::new() })
    }

    /// Records written so far.
    #[must_use]
    pub const fn len(&self) -> u64 {
        self.index
    }

    /// True when nothing has been written.
    #[must_use]
    pub const fn is_empty(&self) -> bool {
        self.index == 0
    }

    /// Hash of the chain head.
    #[must_use]
    pub fn head(&self) -> &str {
        &self.last_hash
    }

    /// Anchors written so far.
    #[must_use]
    pub fn anchors(&self) -> &[Anchor] {
        &self.anchors
    }

    /// Buffered lines not yet flushed.
    #[must_use]
    pub fn buffered(&self) -> usize {
        self.buffer.len()
    }

    /// Append a record built from a builder. Returns the record (with its hash
    /// and index filled in), plus any anchor record the append triggered.
    ///
    /// # Errors
    /// On serialisation or I/O failure.
    pub fn append(
        &mut self,
        builder: AuditBuilder,
    ) -> Result<(AuditRecord, Option<AuditRecord>), AuditError> {
        let rec = builder.build(self.index, &self.last_hash);
        let rec = self.push(rec)?;
        // Anchor *after* the record that completed the interval, so the anchor's
        // `count` includes it.
        let anchor =
            if self.index > 0 && self.index % ANCHOR_INTERVAL == 0 { Some(self.write_anchor()?) } else { None };
        Ok((rec, anchor))
    }

    /// Append a finished record. Its `prev_hash`/`index`/`hash` are recomputed
    /// from the chain state so callers cannot fork the log by accident.
    ///
    /// # Errors
    /// On serialisation or I/O failure.
    pub fn push(&mut self, mut rec: AuditRecord) -> Result<AuditRecord, AuditError> {
        rec.index = self.index;
        rec.prev_hash = self.last_hash.clone();
        rec.hash = rec.compute_hash()?;
        let line = rec.to_line()?;
        self.buffer.push(line);
        self.last_hash = rec.hash.clone();
        self.index += 1;
        if self.buffer.len() >= 64 {
            self.flush()?;
        }
        Ok(rec)
    }

    /// Write an anchor record now (also called automatically every
    /// [`ANCHOR_INTERVAL`] records).
    ///
    /// # Errors
    /// On serialisation or I/O failure.
    pub fn write_anchor(&mut self) -> Result<AuditRecord, AuditError> {
        let anchor = Anchor {
            count: self.index,
            root_hash: self.last_hash.clone(),
            ts_ms: agent_protocol::now_ms(),
            index: self.index,
        };
        self.anchors.push(anchor.clone());
        let mut rec = AuditRecord {
            id: new_audit_id(),
            ts_ms: anchor.ts_ms,
            schema_version: EVENT_SCHEMA_VERSION,
            thread_id: ThreadId::new(),
            turn_id: None,
            actor: Actor::System { component: "audit".into() },
            action: AuditAction::ChainAnchor,
            outcome: Outcome::Info,
            detail: BTreeMap::from([
                ("count".to_string(), anchor.count.to_string()),
                ("root_hash".to_string(), anchor.root_hash.clone()),
            ]),
            policy_ref: None,
            prev_hash: self.last_hash.clone(),
            hash: String::new(),
            index: self.index,
        };
        rec.hash = rec.compute_hash()?;
        let line = rec.to_line()?;
        self.buffer.push(line);
        self.last_hash = rec.hash.clone();
        self.index += 1;
        Ok(rec)
    }

    /// Flush buffered lines to disk with an `fsync`, per §6.5 (durability at
    /// meaningful boundaries).
    ///
    /// # Errors
    /// On I/O failure.
    pub fn flush(&mut self) -> Result<(), AuditError> {
        if self.buffer.is_empty() {
            return Ok(());
        }
        let Some(path) = self.path.clone() else {
            self.buffer.clear();
            return Ok(());
        };
        let mut f = std::fs::OpenOptions::new().create(true).append(true).open(&path)?;
        let payload = self.buffer.join("\n") + "\n";
        f.write_all(payload.as_bytes())?;
        f.sync_all()?;
        self.buffer.clear();
        Ok(())
    }

    /// Everything buffered, for in-memory chains and tests.
    #[must_use]
    pub fn drain_buffer(&mut self) -> Vec<String> {
        std::mem::take(&mut self.buffer)
    }
}

impl std::fmt::Debug for AuditChain {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("AuditChain")
            .field("path", &self.path)
            .field("index", &self.index)
            .field("last_hash", &self.last_hash)
            .field("anchors", &self.anchors.len())
            .field("buffered", &self.buffer.len())
            .finish()
    }
}

/// Read and verify audit logs.
pub struct AuditReader;

/// Verification result.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct VerifyReport {
    /// Records checked (excluding anchors, which are counted separately).
    pub count: u64,
    /// True when every hash and link verified.
    pub ok: bool,
    /// Hash of the last record.
    pub last_hash: String,
    /// Index of the last record, when the log was non-empty.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_index: Option<u64>,
    /// Anchors found.
    pub anchors: Vec<Anchor>,
    /// The first problem, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub problem: Option<ChainProblem>,
}

/// A single chain defect.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChainProblem {
    /// 1-based line number.
    pub line: usize,
    /// What is wrong.
    pub reason: String,
}

impl AuditReader {
    /// Parse one JSONL line.
    ///
    /// # Errors
    /// When the line is not a record.
    pub fn parse_line(line: &str) -> Result<AuditRecord, serde_json::Error> {
        serde_json::from_str(line)
    }

    /// Verify a file.
    ///
    /// # Errors
    /// On I/O failure or a malformed line. A *broken chain* is reported in the
    /// returned [`VerifyReport`], not as an error, so callers can render it.
    pub fn verify_file(path: impl AsRef<Path>) -> Result<VerifyReport, AuditError> {
        let f = std::fs::File::open(path)?;
        Self::verify_reader(io::BufReader::new(f))
    }

    /// Verify an in-memory JSONL string.
    ///
    /// # Errors
    /// On a malformed line.
    pub fn verify_str(text: &str) -> Result<VerifyReport, AuditError> {
        Self::verify_reader(text.as_bytes())
    }

    /// Verify any `BufRead`.
    ///
    /// # Errors
    /// On I/O failure or a malformed line.
    pub fn verify_reader<R: BufRead>(r: R) -> Result<VerifyReport, AuditError> {
        let mut prev: Option<AuditRecord> = None;
        let mut count = 0u64;
        let mut anchors = Vec::new();
        let mut last_hash = GENESIS_HASH.to_string();
        for (i, line) in r.lines().enumerate() {
            let line = line?;
            if line.trim().is_empty() {
                continue;
            }
            let rec: AuditRecord = Self::parse_line(&line)
                .map_err(|e| AuditError::Malformed { line: i + 1, source: e })?;
            if !rec.hash_is_valid().unwrap_or(false) {
                return Ok(VerifyReport {
                    count,
                    ok: false,
                    last_hash,
                    last_index: prev.as_ref().map(|p| p.index),
                    anchors,
                    problem: Some(ChainProblem {
                        line: i + 1,
                        reason: format!("stored hash {} != recomputed {}", rec.hash, rec.compute_hash().unwrap_or_default()),
                    }),
                });
            }
            if !rec.links_to(prev.as_ref()) {
                let expected = prev.as_ref().map(|p| p.hash.clone()).unwrap_or_else(|| GENESIS_HASH.to_string());
                return Ok(VerifyReport {
                    count,
                    ok: false,
                    last_hash,
                    last_index: prev.as_ref().map(|p| p.index),
                    anchors,
                    problem: Some(ChainProblem {
                        line: i + 1,
                        reason: format!("prev_hash {} != expected {}", rec.prev_hash, expected),
                    }),
                });
            }
            if rec.action == AuditAction::ChainAnchor {
                let count_val = rec.detail.get("count").and_then(|s| s.parse::<u64>().ok()).unwrap_or(0);
                let root = rec.detail.get("root_hash").cloned().unwrap_or_default();
                anchors.push(Anchor { count: count_val, root_hash: root, ts_ms: rec.ts_ms, index: rec.index });
            } else {
                count += 1;
            }
            last_hash = rec.hash.clone();
            prev = Some(rec);
        }
        Ok(VerifyReport {
            count,
            ok: true,
            last_hash,
            last_index: prev.as_ref().map(|p| p.index),
            anchors,
            problem: None,
        })
    }

    /// Stream every record from a file, in order.
    ///
    /// # Errors
    /// On I/O failure. Malformed lines are skipped but counted in the returned
    /// tuple's second element so a damaged log is never silently truncated.
    pub fn iter_file(path: impl AsRef<Path>) -> io::Result<(Vec<AuditRecord>, usize)> {
        let f = std::fs::File::open(path)?;
        let mut out = Vec::new();
        let mut bad = 0usize;
        for line in io::BufReader::new(f).lines() {
            let line = line?;
            if line.trim().is_empty() {
                continue;
            }
            match Self::parse_line(&line) {
                Ok(r) => out.push(r),
                Err(_) => bad += 1,
            }
        }
        Ok((out, bad))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn builder(thread: ThreadId, action: AuditAction) -> AuditBuilder {
        AuditBuilder::new(thread, Actor::User { id: "dev".into() }, action)
            .outcome(Outcome::Denied)
            .detail("tool", "shell")
            .detail("command", "rm -rf /")
            .policy_ref("shell(rm -rf **) at .agent/config.toml:12")
    }

    #[test]
    fn first_record_links_to_genesis() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        let rec = c.push(builder(t, AuditAction::ToolDenied).build(999, "ignored")).unwrap();
        assert_eq!(rec.index, 0, "index is assigned by the chain, not the caller");
        assert_eq!(rec.prev_hash, GENESIS_HASH);
        assert_eq!(rec.hash.len(), 64);
        assert!(rec.hash_is_valid().unwrap());
        assert!(rec.links_to(None));
    }

    #[test]
    fn consecutive_records_form_a_chain() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        let a = c.push(builder(t, AuditAction::ToolDenied).build(0, GENESIS_HASH)).unwrap();
        let b = c.push(builder(t, AuditAction::GrantRemembered).build(0, GENESIS_HASH)).unwrap();
        assert_eq!(b.prev_hash, a.hash);
        assert_eq!(b.index, 1);
        assert!(b.links_to(Some(&a)));
        assert_eq!(c.len(), 2);
        assert_eq!(c.head(), b.hash);
    }

    #[test]
    fn hashes_are_order_sensitive() {
        let mut c1 = AuditChain::in_memory();
        let mut c2 = AuditChain::in_memory();
        let t = ThreadId::new();
        let _ = c1.push(builder(t, AuditAction::ToolDenied).at(1).build(0, GENESIS_HASH)).unwrap();
        let _ = c1.push(builder(t, AuditAction::ToolApproved).at(2).build(0, GENESIS_HASH)).unwrap();
        let _ = c2.push(builder(t, AuditAction::ToolApproved).at(2).build(0, GENESIS_HASH)).unwrap();
        let _ = c2.push(builder(t, AuditAction::ToolDenied).at(1).build(0, GENESIS_HASH)).unwrap();
        assert_ne!(c1.head(), c2.head(), "reordering must change the chain head");
    }

    #[test]
    fn canonical_hash_ignores_detail_insertion_order() {
        let t = ThreadId::new();
        let mut a = builder(t, AuditAction::ToolInvoked).at(5).build(0, GENESIS_HASH);
        let mut b = AuditBuilder::new(t, Actor::User { id: "dev".into() }, AuditAction::ToolInvoked)
            .outcome(Outcome::Denied)
            .detail("command", "rm -rf /")
            .detail("tool", "shell")
            .policy_ref("shell(rm -rf **) at .agent/config.toml:12")
            .at(5)
            .build(0, GENESIS_HASH);
        // Different ids => different hashes; force them equal to test the map.
        b.id = a.id.clone();
        a.hash = String::new();
        a.hash = a.compute_hash().unwrap();
        assert_eq!(a.hash, b.compute_hash().unwrap(), "detail ordering must not matter");
    }

    #[test]
    fn verify_accepts_an_untouched_chain() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        for i in 0..5 {
            c.push(builder(t, AuditAction::ToolInvoked).at(i).build(0, GENESIS_HASH)).unwrap();
        }
        let text = c.drain_buffer().join("\n");
        let report = AuditReader::verify_str(&text).unwrap();
        assert!(report.ok, "{report:?}");
        assert_eq!(report.count, 5);
        assert_eq!(report.last_hash, c.head());
        assert!(report.problem.is_none());
    }

    #[test]
    fn verify_detects_a_tampered_detail_field() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        for i in 0..3 {
            c.push(builder(t, AuditAction::ToolDenied).at(i).build(0, GENESIS_HASH)).unwrap();
        }
        let mut lines = c.drain_buffer();
        // Someone rewrites history: make the denial look like an approval.
        lines[1] = lines[1].replace("\"tool_denied\"", "\"tool_approved\"");
        let report = AuditReader::verify_str(&lines.join("\n")).unwrap();
        assert!(!report.ok);
        let p = report.problem.unwrap();
        assert_eq!(p.line, 2);
        assert!(p.reason.contains("recomputed"), "{p:?}");
    }

    #[test]
    fn verify_detects_a_deleted_line() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        for i in 0..4 {
            c.push(builder(t, AuditAction::ToolInvoked).at(i).build(0, GENESIS_HASH)).unwrap();
        }
        let mut lines = c.drain_buffer();
        lines.remove(1);
        let report = AuditReader::verify_str(&lines.join("\n")).unwrap();
        assert!(!report.ok);
        let problem = report.problem.as_ref().unwrap();
        assert_eq!(problem.line, 2);
        assert!(problem.reason.contains("prev_hash"), "{problem:?}");
    }

    #[test]
    fn verify_detects_a_reordered_chain() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        for i in 0..3 {
            c.push(builder(t, AuditAction::ToolInvoked).at(i).build(0, GENESIS_HASH)).unwrap();
        }
        let mut lines = c.drain_buffer();
        lines.swap(0, 1);
        assert!(!AuditReader::verify_str(&lines.join("\n")).unwrap().ok);
    }

    #[test]
    fn malformed_json_is_reported_with_its_line_number() {
        let err = AuditReader::verify_str("{\"id\":\"aud_1\"}\nnot json\n").unwrap_err();
        match err {
            AuditError::Malformed { line, .. } => assert_eq!(line, 2),
            other => panic!("expected Malformed, got {other:?}"),
        }
    }

    #[test]
    fn anchors_are_written_every_interval() {
        let mut c = AuditChain::in_memory();
        let t = ThreadId::new();
        for i in 0..(2 * ANCHOR_INTERVAL + 1) {
            c.push(builder(t, AuditAction::ToolInvoked).at(i).build(0, GENESIS_HASH)).unwrap();
        }
        let a = c.write_anchor().unwrap();
        assert_eq!(a.action, AuditAction::ChainAnchor);
        assert!(c.anchors().len() >= 1);
        assert!(a.detail.contains_key("root_hash"));
        // The anchor record itself is part of the chain.
        assert!(a.hash_is_valid().unwrap());
    }

    #[test]
    fn file_backed_chain_round_trips_and_resumes() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("audit.jsonl");
        let t = ThreadId::new();
        let head_after_first;
        {
            let mut c = AuditChain::open(&path).unwrap();
            assert!(c.is_empty());
            c.push(builder(t, AuditAction::SessionStart).build(0, GENESIS_HASH)).unwrap();
            c.push(builder(t, AuditAction::ToolDenied).build(0, GENESIS_HASH)).unwrap();
            c.flush().unwrap();
            head_after_first = c.head().to_string();
        }
        // Reopen: the chain must continue, not fork.
        let mut c2 = AuditChain::open(&path).unwrap();
        assert_eq!(c2.len(), 2);
        assert_eq!(c2.head(), head_after_first);
        let rec = c2.push(builder(t, AuditAction::SessionEnd).build(0, GENESIS_HASH)).unwrap();
        c2.flush().unwrap();
        assert_eq!(rec.index, 2);

        let report = AuditReader::verify_file(&path).unwrap();
        assert!(report.ok, "{report:?}");
        assert_eq!(report.count, 3);
        assert_eq!(report.last_hash, c2.head());

        let (records, bad) = AuditReader::iter_file(&path).unwrap();
        assert_eq!(records.len(), 3);
        assert_eq!(bad, 0);
        assert_eq!(records[0].action, AuditAction::SessionStart);
    }

    #[test]
    fn opening_a_tampered_file_refuses_to_append() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("audit.jsonl");
        let t = ThreadId::new();
        {
            let mut c = AuditChain::open(&path).unwrap();
            c.push(builder(t, AuditAction::ToolDenied).build(0, GENESIS_HASH)).unwrap();
            c.push(builder(t, AuditAction::ToolDenied).build(0, GENESIS_HASH)).unwrap();
            c.flush().unwrap();
        }
        let text = std::fs::read_to_string(&path).unwrap();
        std::fs::write(&path, text.replace("\"tool_denied\"", "\"tool_approved\"")).unwrap();
        let err = AuditChain::open(&path).unwrap_err();
        assert!(matches!(err, AuditError::Broken { .. }), "{err:?}");
    }

    #[test]
    fn actor_labels_are_stable() {
        assert_eq!(Actor::User { id: "dev".into() }.label(), "user:dev");
        assert_eq!(
            Actor::Model { id: "gpt-5".into(), provider: "openai".into() }.label(),
            "model:openai/gpt-5"
        );
        assert_eq!(Actor::System { component: "audit".into() }.label(), "system:audit");
    }

    #[test]
    fn compliance_relevant_actions_are_flagged() {
        assert!(AuditAction::ToolDenied.is_compliance_relevant());
        assert!(AuditAction::SecretRedacted.is_compliance_relevant());
        assert!(!AuditAction::SessionStart.is_compliance_relevant());
        assert_eq!(AuditAction::ManagedPolicyApplied.as_str(), "managed_policy_applied");
    }

    #[test]
    fn records_survive_a_json_round_trip() {
        let t = ThreadId::new();
        let rec = builder(t, AuditAction::SandboxViolation)
            .detail("syscall", "ptrace")
            .build(0, GENESIS_HASH);
        let json = rec.to_line().unwrap();
        let back = AuditReader::parse_line(&json).unwrap();
        assert_eq!(back, rec);
        assert!(back.hash_is_valid().unwrap());
    }
}
