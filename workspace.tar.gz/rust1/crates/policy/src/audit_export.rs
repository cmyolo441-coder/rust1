//! Audit export (`rustplan.txt` §6.4, §9.5 `src/audit_export.rs`).
//!
//! Enterprises do not read JSONL; their SIEM does. Three sinks are supported
//! out of the box, all fed from the same chain so nothing is re-derived:
//!
//! * **RFC 5424 syslog** — facility `log audit` (13), one line per record,
//!   structured data carrying the policy fields. This is what `logger`/`rsyslog`
//!   and most agents on the box already speak.
//! * **OTLP JSON** — the OpenTelemetry logs data model, POSTable straight at a
//!   collector's `/v1/logs`.
//! * **Rotating JSONL** — a size-capped mirror of the chain, so a long-running
//!   session cannot fill a disk. The canonical chain file is *not* rotated:
//!   rotating the thing you verify would break verification.
//!
//! Every export is redacted on the way out and carries the chain anchor, so an
//! operator can prove the export covers the same records as the local log.

use std::io::{self, Write};
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::audit::{Anchor, AuditRecord};
use crate::incident::Severity;
use crate::redaction::{RedactionConfig, Redactor};

/// RFC5424 facility for audit/log records.
pub const SYSLOG_FACILITY: u8 = 13;
/// PRI = facility * 8 + severity.
#[must_use]
pub const fn syslog_pri(severity: Severity) -> u16 {
    SYSLOG_FACILITY as u16 * 8 + severity.syslog() as u16
}

/// Which sink to write to.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExportFormat {
    /// RFC5424 syslog lines.
    Rfc5424,
    /// OTLP `/v1/logs` JSON body.
    OtlpJson,
    /// Newline-delimited JSON, redacted.
    Ndjson,
    /// Comma-separated, one row per record, for spreadsheet review.
    Csv,
}

impl ExportFormat {
    /// File extension for a bulk export.
    #[must_use]
    pub const fn extension(&self) -> &'static str {
        match self {
            Self::Rfc5424 => "log",
            Self::OtlpJson => "otlp.json",
            Self::Ndjson => "ndjson",
            Self::Csv => "csv",
        }
    }
}

/// Export options.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExportOptions {
    /// Format.
    pub format: ExportFormat,
    /// Hostname for syslog `HOSTNAME` / OTLP `host.name`.
    pub hostname: String,
    /// Application name for syslog `APP-NAME`.
    pub app_name: String,
    /// PROCID for syslog; the OS pid by default.
    pub procid: String,
    /// OTLP resource attributes.
    #[serde(default)]
    pub resource: Vec<(String, String)>,
    /// Redact before export. On by default; turning it off is itself audited.
    #[serde(default = "on")]
    pub redact: bool,
    /// Include anchor records.
    #[serde(default = "on")]
    pub include_anchors: bool,
}

const fn on() -> bool {
    true
}

impl Default for ExportOptions {
    fn default() -> Self {
        Self {
            format: ExportFormat::Ndjson,
            hostname: "localhost".into(),
            app_name: agent_protocol::PRODUCT.into(),
            procid: std::process::id().to_string(),
            resource: Vec::new(),
            redact: true,
            include_anchors: true,
        }
    }
}

/// An exported batch plus the metadata needed to prove it is complete.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExportBatch {
    /// Serialised payload.
    pub payload: String,
    /// Records included.
    pub count: usize,
    /// Anchor covering them, when the chain supplied one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub anchor: Option<Anchor>,
    /// blake3 of the payload, so a receiver can verify the transfer.
    pub checksum: String,
    /// Format used.
    pub format: ExportFormat,
}

/// Render records into a payload.
///
/// # Errors
/// On serialisation failure (OTLP/NDJSON only).
pub fn render(
    records: &[AuditRecord],
    opts: &ExportOptions,
    anchor: Option<Anchor>,
) -> Result<ExportBatch, serde_json::Error> {
    let redactor = if opts.redact {
        Redactor::new(RedactionConfig::for_telemetry())
    } else {
        Redactor::new(RedactionConfig::disabled())
    };
    let selected: Vec<&AuditRecord> = records
        .iter()
        .filter(|r| opts.include_anchors || r.action != crate::audit::AuditAction::ChainAnchor)
        .collect();

    let payload = match opts.format {
        ExportFormat::Rfc5424 => selected
            .iter()
            .map(|r| to_rfc5424(r, opts, &redactor))
            .collect::<Vec<_>>()
            .join("\n")
            + "\n",
        ExportFormat::Ndjson => selected
            .iter()
            .map(|r| redact_record_json(r, &redactor))
            .collect::<Result<Vec<_>, _>>()?
            .join("\n")
            + "\n",
        ExportFormat::Csv => to_csv(&selected, &redactor),
        ExportFormat::OtlpJson => serde_json::to_string_pretty(&to_otlp(&selected, opts, &redactor))?,
    };
    let checksum = blake3::hash(payload.as_bytes()).to_hex().to_string();
    Ok(ExportBatch { payload, count: selected.len(), anchor, checksum, format: opts.format })
}

/// One RFC5424 line.
///
/// `<PRI>1 TIMESTAMP HOSTNAME APP-NAME PROCID MSGID [SD] MSG`
#[must_use]
pub fn to_rfc5424(r: &AuditRecord, opts: &ExportOptions, redactor: &Redactor) -> String {
    let sev = severity_for(r);
    let pri = syslog_pri(sev);
    let ts = agent_protocol::iso_from_ms(r.ts_ms);

    let mut sd = String::from("[agent");
    sd.push_str(&format!(" thread=\"{}\"", r.thread_id));
    if let Some(t) = r.turn_id {
        sd.push_str(&format!(" turn=\"{t}\""));
    }
    sd.push_str(&format!(" actor=\"{}\"", escape_sd(&redactor.redact_str(&r.actor.label()))));
    sd.push_str(&format!(" outcome=\"{:?}\"", r.outcome));
    sd.push_str(&format!(" index=\"{}\"", r.index));
    if let Some(p) = &r.policy_ref {
        sd.push_str(&format!(" policy=\"{}\"", escape_sd(&redactor.redact_str(p))));
    }
    for (k, v) in &r.detail {
        sd.push_str(&format!(" {}=\"{}\"", escape_sd(k), escape_sd(&redactor.redact_str(v))));
    }
    sd.push(']');

    // MSG carries the short hash pair so an operator can line the syslog line up
    // against the local chain without a second lookup.
    let detail = r
        .detail
        .iter()
        .map(|(k, v)| format!("{k}={v}"))
        .collect::<Vec<_>>()
        .join(" ");
    let msg = redactor.redact_str(&format!(
        "{} {} hash={} prev={}",
        r.action.as_str(),
        detail,
        &r.hash,
        &r.prev_hash[..r.prev_hash.len().min(16)]
    ));

    // RFC5424 forbids raw newlines in MSG; fold them so one record is one line.
    let msg = msg.replace(['\n', '\r'], " ");
    format!(
        "<{pri}>1 {ts} {host} {app} {pid} {msgid} {sd} {msg}",
        host = opts.hostname,
        app = opts.app_name,
        pid = opts.procid,
        msgid = r.action.as_str()
    )
}

fn escape_sd(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace(']', "\\]").replace('\n', " ")
}

/// Map an audit record onto a syslog severity.
#[must_use]
pub fn severity_for(r: &AuditRecord) -> Severity {
    use crate::audit::{AuditAction, Outcome};
    match r.action {
        AuditAction::SandboxViolation => Severity::Critical,
        AuditAction::NetworkBlocked | AuditAction::SecretRedacted => Severity::High,
        AuditAction::ToolDenied | AuditAction::ToolRefused => Severity::Medium,
        AuditAction::PushAttempted => Severity::Medium,
        _ => match r.outcome {
            Outcome::Failed => Severity::Medium,
            Outcome::Denied => Severity::Medium,
            Outcome::Prompted => Severity::Low,
            Outcome::Allowed | Outcome::Info => Severity::Info,
        },
    }
}

/// OTLP severity number (log record severity, 1–24).
#[must_use]
pub const fn otlp_severity_number(s: Severity) -> u8 {
    match s {
        Severity::Info => 9,
        Severity::Low => 13,
        Severity::Medium => 17,
        Severity::High => 21,
        Severity::Critical => 23,
    }
}

/// Build the OTLP `/v1/logs` request body.
#[must_use]
pub fn to_otlp(records: &[&AuditRecord], opts: &ExportOptions, redactor: &Redactor) -> serde_json::Value {
    use serde_json::{json, Value};
    let mut attrs: Vec<Value> = vec![
        json!({"key": "service.name", "value": {"stringValue": opts.app_name}}),
        json!({"key": "host.name", "value": {"stringValue": opts.hostname}}),
    ];
    for (k, v) in &opts.resource {
        attrs.push(json!({"key": k, "value": {"stringValue": v}}));
    }
    let log_records: Vec<Value> = records
        .iter()
        .map(|r| {
            let sev = severity_for(r);
            let mut a = vec![
                json!({"key": "agent.record.id", "value": {"stringValue": r.id}}),
                json!({"key": "agent.action", "value": {"stringValue": r.action.as_str()}}),
                json!({"key": "agent.outcome", "value": {"stringValue": format!("{:?}", r.outcome)}}),
                json!({"key": "agent.thread", "value": {"stringValue": r.thread_id.to_string()}}),
                json!({"key": "agent.actor", "value": {"stringValue": redactor.redact_str(&r.actor.label())}}),
                json!({"key": "agent.chain.index", "value": {"intValue": r.index.to_string()}}),
                json!({"key": "agent.chain.hash", "value": {"stringValue": r.hash}}),
                json!({"key": "agent.chain.prev_hash", "value": {"stringValue": r.prev_hash}}),
            ];
            if let Some(t) = r.turn_id {
                a.push(json!({"key": "agent.turn", "value": {"stringValue": t.to_string()}}));
            }
            if let Some(p) = &r.policy_ref {
                a.push(json!({"key": "agent.policy_ref", "value": {"stringValue": redactor.redact_str(p)}}));
            }
            for (k, v) in &r.detail {
                a.push(json!({"key": format!("agent.detail.{k}"), "value": {"stringValue": redactor.redact_str(v)}}));
            }
            json!({
                "timeUnixNano": (r.ts_ms as u64).saturating_mul(1_000_000).to_string(),
                "observedTimeUnixNano": (r.ts_ms as u64).saturating_mul(1_000_000).to_string(),
                "severityNumber": otlp_severity_number(sev),
                "severityText": sev.as_str().to_uppercase(),
                "body": {"stringValue": redactor.redact_str(&r.detail.iter().map(|(k, v)| format!("{k}={v}")).collect::<Vec<_>>().join(" "))},
                "attributes": a,
            })
        })
        .collect();
    json!({
        "resourceLogs": [{
            "resource": {"attributes": attrs},
            "scopeLogs": [{
                "scope": {"name": "agent.policy.audit", "version": agent_protocol::BUILD_VERSION},
                "logRecords": log_records,
            }],
        }],
    })
}

/// CSV export: header plus one row per record. Values are quoted and any
/// embedded quote doubled, per RFC4180.
#[must_use]
pub fn to_csv(records: &[&AuditRecord], redactor: &Redactor) -> String {
    let mut out = String::from("id,ts_utc,thread_id,turn_id,actor,action,outcome,policy_ref,hash,prev_hash,index,detail\n");
    for r in records {
        let detail: Vec<String> = r.detail.iter().map(|(k, v)| format!("{k}={v}")).collect();
        let row = [
            r.id.clone(),
            agent_protocol::iso_from_ms(r.ts_ms),
            r.thread_id.to_string(),
            r.turn_id.map(|t| t.to_string()).unwrap_or_default(),
            r.actor.label(),
            r.action.as_str().to_string(),
            format!("{:?}", r.outcome),
            r.policy_ref.clone().unwrap_or_default(),
            r.hash.clone(),
            r.prev_hash.clone(),
            r.index.to_string(),
            detail.join(" "),
        ];
        let cells: Vec<String> = row
            .iter()
            .map(|c| format!("\"{}\"", redactor.redact_str(c).replace('"', "\"\"")))
            .collect();
        out.push_str(&cells.join(","));
        out.push('\n');
    }
    out
}

/// Redact a record and re-encode it as one JSON line.
///
/// # Errors
/// On serialisation failure.
pub fn redact_record_json(r: &AuditRecord, redactor: &Redactor) -> Result<String, serde_json::Error> {
    let mut v = serde_json::to_value(r)?;
    if let Some(obj) = v.as_object_mut() {
        if let Some(detail) = obj.get_mut("detail").and_then(|d| d.as_object_mut()) {
            for val in detail.values_mut() {
                if let Some(s) = val.as_str() {
                    *val = serde_json::Value::String(redactor.redact_str(s));
                }
            }
        }
        if let Some(p) = obj.get_mut("policy_ref").and_then(|p| p.as_str().map(str::to_string)) {
            obj.insert("policy_ref".into(), serde_json::Value::String(redactor.redact_str(&p)));
        }
    }
    serde_json::to_string(&v)
}

/// A size-capped JSONL mirror.
///
/// Rotation is `audit.jsonl` → `audit.1.jsonl` → … → `audit.{n}.jsonl`, with the
/// oldest dropped. `max_bytes` is checked *before* each write so a single huge
/// record cannot overshoot by more than its own length.
pub struct RotatingJsonl {
    path: PathBuf,
    max_bytes: u64,
    max_files: u32,
    written: u64,
}

/// Rotation errors.
#[derive(Debug, thiserror::Error)]
pub enum RotateError {
    /// I/O failure.
    #[error("rotation failed for {path}: {source}")]
    Io {
        /// Path involved.
        path: PathBuf,
        /// Underlying error.
        #[source]
        source: io::Error,
    },
}

impl From<io::Error> for RotateError {
    fn from(source: io::Error) -> Self {
        Self::Io { path: PathBuf::new(), source }
    }
}

impl RotatingJsonl {
    /// Open a rotating sink, picking up the existing file's size.
    ///
    /// # Errors
    /// When the parent directory cannot be created or the file cannot be stat'd.
    pub fn open(path: impl AsRef<Path>, max_bytes: u64, max_files: u32) -> Result<Self, RotateError> {
        let path = path.as_ref().to_path_buf();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).map_err(|source| RotateError::Io { path: parent.to_path_buf(), source })?;
        }
        let written = std::fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
        Ok(Self { path, max_bytes: max_bytes.max(1), max_files: max_files.max(1), written })
    }

    /// Current file path.
    #[must_use]
    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Bytes written to the current file.
    #[must_use]
    pub const fn bytes_written(&self) -> u64 {
        self.written
    }

    /// Write one line (a trailing newline is added if missing), rotating first
    /// when the line would exceed the cap.
    ///
    /// # Errors
    /// On I/O failure.
    pub fn write_line(&mut self, line: &str) -> Result<(), RotateError> {
        let bytes = line.len() as u64 + 1;
        if self.written.saturating_add(bytes) > self.max_bytes && self.written > 0 {
            self.rotate()?;
        }
        let mut f = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.path)
            .map_err(|source| RotateError::Io { path: self.path.clone(), source })?;
        f.write_all(line.as_bytes()).map_err(|source| RotateError::Io { path: self.path.clone(), source })?;
        if !line.ends_with('\n') {
            f.write_all(b"\n").map_err(|source| RotateError::Io { path: self.path.clone(), source })?;
        }
        f.flush().map_err(|source| RotateError::Io { path: self.path.clone(), source })?;
        self.written += bytes;
        Ok(())
    }

    /// Rotate now: `path` → `path.1`, `path.1` → `path.2`, oldest dropped.
    ///
    /// # Errors
    /// On I/O failure.
    pub fn rotate(&mut self) -> Result<(), RotateError> {
        let stem = self.path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "audit".into());
        let ext = self.path.extension().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "jsonl".into());
        let parent = self.path.parent().map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from("."));
        let at = |n: u32| parent.join(if n == 0 { format!("{stem}.{ext}") } else { format!("{stem}.{n}.{ext}") });

        // Drop the oldest.
        let oldest = at(self.max_files);
        if oldest.exists() {
            std::fs::remove_file(&oldest).map_err(|source| RotateError::Io { path: oldest.clone(), source })?;
        }
        for n in (1..self.max_files).rev() {
            let from = at(n - 1);
            if from.exists() {
                std::fs::rename(&from, at(n))
                    .map_err(|source| RotateError::Io { path: from.clone(), source })?;
            }
        }
        self.written = 0;
        Ok(())
    }

    /// All live files, newest first.
    #[must_use]
    pub fn files(&self) -> Vec<PathBuf> {
        let stem = self.path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "audit".into());
        let ext = self.path.extension().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "jsonl".into());
        let parent = self.path.parent().map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from("."));
        let mut out = Vec::new();
        for n in 0..self.max_files {
            let p = parent.join(if n == 0 { format!("{stem}.{ext}") } else { format!("{stem}.{n}.{ext}") });
            if p.exists() {
                out.push(p);
            }
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::audit::{Actor, AuditBuilder, GENESIS_HASH};
    use agent_protocol::ids::ThreadId;

    fn rec(action: crate::audit::AuditAction, detail: &[(&str, &str)]) -> AuditRecord {
        let mut b = AuditBuilder::new(ThreadId::new(), Actor::User { id: "dev".into() }, action).at(1_700_000_000_000);
        for (k, v) in detail {
            b = b.detail(*k, *v);
        }
        b.build(0, GENESIS_HASH)
    }

    #[test]
    fn rfc5424_line_has_the_right_shape() {
        let r = rec(crate::audit::AuditAction::ToolDenied, &[("tool", "shell"), ("command", "rm -rf build")]);
        let opts = ExportOptions { hostname: "dev-box".into(), procid: "4242".into(), ..Default::default() };
        let line = to_rfc5424(&r, &opts, &Redactor::default());
        assert!(line.starts_with("<108>1 "), "{line}");
        assert!(line.contains(" dev-box agent 4242 tool_denied "), "{line}");
        assert!(line.contains("[agent "), "{line}");
        assert!(line.contains("thread=\""), "{line}");
        assert!(line.contains("tool=\"shell\""), "{line}");
        assert!(!line.contains('\n'), "a syslog line must not contain newlines: {line:?}");
        assert_eq!(line.matches(']').count(), line.matches('[').count());
    }

    #[test]
    fn syslog_pri_follows_facility_and_severity() {
        assert_eq!(syslog_pri(Severity::Info), 13 * 8 + 6);
        assert_eq!(syslog_pri(Severity::Critical), 13 * 8 + 2);
        assert_eq!(syslog_pri(Severity::High), 13 * 8 + 3);
    }

    #[test]
    fn severity_mapping_is_action_driven() {
        assert_eq!(severity_for(&rec(crate::audit::AuditAction::SandboxViolation, &[])), Severity::Critical);
        assert_eq!(severity_for(&rec(crate::audit::AuditAction::NetworkBlocked, &[])), Severity::High);
        assert_eq!(severity_for(&rec(crate::audit::AuditAction::ToolDenied, &[])), Severity::Medium);
        assert_eq!(severity_for(&rec(crate::audit::AuditAction::SessionStart, &[])), Severity::Info);
    }

    #[test]
    fn sd_values_are_escaped() {
        let r = rec(crate::audit::AuditAction::ToolDenied, &[("command", "echo \"hi\"] \\ x")]);
        let line = to_rfc5424(&r, &ExportOptions::default(), &Redactor::default());
        assert!(line.contains("\\\"hi\\\""), "{line}");
        assert!(line.contains("\\]"), "{line}");
        // Still exactly one SD block.
        assert_eq!(line.matches("[agent ").count(), 1);
    }

    #[test]
    fn secrets_are_redacted_in_every_format() {
        let r = rec(crate::audit::AuditAction::ToolDenied, &[("command", "aws --key AKIAIOSFODNN7EXAMPLE")]);
        let secret = "AKIAIOSFODNN7EXAMPLE";
        for fmt in [ExportFormat::Rfc5424, ExportFormat::Ndjson, ExportFormat::Csv, ExportFormat::OtlpJson] {
            let opts = ExportOptions { format: fmt, ..Default::default() };
            let batch = render(std::slice::from_ref(&r), &opts, None).unwrap();
            assert!(!batch.payload.contains(secret), "{fmt:?} leaked: {}", batch.payload);
            assert!(batch.payload.contains("[redacted:"), "{fmt:?}: {}", batch.payload);
        }
    }

    #[test]
    fn redaction_can_be_disabled_explicitly() {
        let r = rec(crate::audit::AuditAction::ToolDenied, &[("command", "aws --key AKIAIOSFODNN7EXAMPLE")]);
        let opts = ExportOptions { redact: false, ..Default::default() };
        let batch = render(std::slice::from_ref(&r), &opts, None).unwrap();
        assert!(batch.payload.contains("AKIAIOSFODNN7EXAMPLE"));
    }

    #[test]
    fn ndjson_is_one_valid_json_object_per_line() {
        let records = vec![
            rec(crate::audit::AuditAction::SessionStart, &[]),
            rec(crate::audit::AuditAction::ToolInvoked, &[("tool", "read_file")]),
        ];
        let opts = ExportOptions { format: ExportFormat::Ndjson, ..Default::default() };
        let batch = render(&records, &opts, None).unwrap();
        assert_eq!(batch.count, 2);
        let lines: Vec<&str> = batch.payload.lines().collect();
        assert_eq!(lines.len(), 2);
        for l in lines {
            let v: serde_json::Value = serde_json::from_str(l).unwrap();
            assert!(v.get("hash").is_some());
            assert!(v.get("detail").is_some());
        }
    }

    #[test]
    fn csv_is_rfc4180_quoted() {
        let records = vec![rec(crate::audit::AuditAction::ToolDenied, &[("command", "echo \"hi\", there")])];
        let opts = ExportOptions { format: ExportFormat::Csv, ..Default::default() };
        let batch = render(&records, &opts, None).unwrap();
        let lines: Vec<&str> = batch.payload.lines().collect();
        assert!(lines[0].starts_with("id,ts_utc,thread_id,"), "{}", lines[0]);
        assert_eq!(lines.len(), 2);
        assert!(lines[1].contains("\"\"hi\"\""), "{}", lines[1]);
        // Every row has the same number of top-level fields.
        let header_fields = lines[0].split(',').count();
        let row = parse_csv_row(lines[1]);
        assert_eq!(row.len(), header_fields, "{row:?}");
    }

    fn parse_csv_row(row: &str) -> Vec<String> {
        let mut out = Vec::new();
        let mut cur = String::new();
        let mut in_q = false;
        let mut chars = row.chars().peekable();
        while let Some(c) = chars.next() {
            match c {
                '"' if in_q && chars.peek() == Some(&'"') => {
                    cur.push('"');
                    chars.next();
                }
                '"' => in_q = !in_q,
                ',' if !in_q => {
                    out.push(std::mem::take(&mut cur));
                }
                _ => cur.push(c),
            }
        }
        out.push(cur);
        out
    }

    #[test]
    fn otlp_body_follows_the_data_model() {
        let records = vec![rec(crate::audit::AuditAction::ToolDenied, &[("tool", "shell")])];
        let opts = ExportOptions { format: ExportFormat::OtlpJson, ..Default::default() };
        let batch = render(&records, &opts, None).unwrap();
        let v: serde_json::Value = serde_json::from_str(&batch.payload).unwrap();
        let rl = &v["resourceLogs"][0];
        assert!(rl["resource"]["attributes"].is_array());
        assert_eq!(rl["scopeLogs"][0]["scope"]["name"], "agent.policy.audit");
        let lr = &rl["scopeLogs"][0]["logRecords"][0];
        assert_eq!(lr["severityNumber"], otlp_severity_number(Severity::Medium));
        assert_eq!(lr["severityText"], "MEDIUM");
        assert!(lr["timeUnixNano"].as_str().unwrap().len() >= 13);
        let keys: Vec<&str> = lr["attributes"].as_array().unwrap().iter().map(|a| a["key"].as_str().unwrap()).collect();
        assert!(keys.contains(&"agent.action"), "{keys:?}");
        assert!(keys.contains(&"agent.chain.hash"), "{keys:?}");
        assert!(keys.contains(&"agent.detail.tool"), "{keys:?}");
    }

    #[test]
    fn resource_attributes_are_merged_in() {
        let opts = ExportOptions {
            format: ExportFormat::OtlpJson,
            resource: vec![("deployment.environment".into(), "prod".into())],
            ..Default::default()
        };
        let batch = render(&[rec(crate::audit::AuditAction::SessionStart, &[])], &opts, None).unwrap();
        assert!(batch.payload.contains("deployment.environment"));
        assert!(batch.payload.contains("prod"));
    }

    #[test]
    fn the_checksum_covers_the_payload() {
        let records = vec![rec(crate::audit::AuditAction::SessionStart, &[])];
        let batch = render(&records, &ExportOptions::default(), None).unwrap();
        assert_eq!(batch.checksum, blake3::hash(batch.payload.as_bytes()).to_hex().to_string());
        assert_eq!(batch.checksum.len(), 64);
    }

    #[test]
    fn anchors_can_be_excluded() {
        let mut anchor = rec(crate::audit::AuditAction::ChainAnchor, &[("count", "10")]);
        anchor.id = "aud_anchor".into();
        let records = vec![rec(crate::audit::AuditAction::SessionStart, &[]), anchor];
        let with = render(&records, &ExportOptions::default(), None).unwrap();
        assert_eq!(with.count, 2);
        let opts = ExportOptions { include_anchors: false, ..Default::default() };
        let without = render(&records, &opts, None).unwrap();
        assert_eq!(without.count, 1);
        assert!(!without.payload.contains("aud_anchor"));
    }

    #[test]
    fn the_anchor_is_carried_into_the_batch() {
        let a = Anchor { count: 3, root_hash: "ab".repeat(32), ts_ms: 1, index: 3 };
        let batch = render(&[rec(crate::audit::AuditAction::SessionStart, &[])], &ExportOptions::default(), Some(a.clone())).unwrap();
        assert_eq!(batch.anchor, Some(a));
    }

    #[test]
    fn extensions_match_the_format() {
        assert_eq!(ExportFormat::Rfc5424.extension(), "log");
        assert_eq!(ExportFormat::OtlpJson.extension(), "otlp.json");
        assert_eq!(ExportFormat::Ndjson.extension(), "ndjson");
        assert_eq!(ExportFormat::Csv.extension(), "csv");
    }

    #[test]
    fn rotating_sink_caps_total_size() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("audit.jsonl");
        let mut w = RotatingJsonl::open(&path, 200, 3).unwrap();
        for i in 0..20 {
            w.write_line(&format!("{{\"i\":{i},\"pad\":\"{}\"}}", "x".repeat(40))).unwrap();
        }
        let files = w.files();
        assert!(files.len() <= 3, "{files:?}");
        let total: u64 = files.iter().map(|f| std::fs::metadata(f).unwrap().len()).sum();
        assert!(total <= 200 * 3 + 100, "total {total} exceeded the cap");
        // The newest file is the live one.
        assert_eq!(files[0], path);
        let content = std::fs::read_to_string(&path).unwrap();
        assert!(content.contains("\"i\":19"), "{content}");
    }

    #[test]
    fn rotation_renames_in_order() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("a.jsonl");
        let mut w = RotatingJsonl::open(&path, 50, 3).unwrap();
        w.write_line("first").unwrap();
        w.rotate().unwrap();
        assert!(dir.path().join("a.1.jsonl").exists());
        w.write_line("second").unwrap();
        w.rotate().unwrap();
        assert!(dir.path().join("a.2.jsonl").exists());
        assert_eq!(std::fs::read_to_string(dir.path().join("a.1.jsonl")).unwrap(), "second\n");
        w.write_line("third").unwrap();
        w.rotate().unwrap();
        // Oldest is dropped once max_files is exceeded.
        assert_eq!(w.files().len(), 3);
    }

    #[test]
    fn a_newline_is_added_when_missing() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("a.jsonl");
        let mut w = RotatingJsonl::open(&path, 1000, 2).unwrap();
        w.write_line("no-newline").unwrap();
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "no-newline\n");
        assert_eq!(w.bytes_written(), 11);
    }

    #[test]
    fn reopening_picks_up_the_existing_size() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("a.jsonl");
        std::fs::write(&path, "x".repeat(300)).unwrap();
        let w = RotatingJsonl::open(&path, 200, 2).unwrap();
        assert_eq!(w.bytes_written(), 300);
    }

    #[test]
    fn export_options_round_trip() {
        let o = ExportOptions::default();
        let json = serde_json::to_string(&o).unwrap();
        let back: ExportOptions = serde_json::from_str(&json).unwrap();
        assert_eq!(back.format, o.format);
        assert!(back.redact);
        // A sparse config keeps the safe defaults.
        let sparse: ExportOptions = serde_json::from_str("{}").unwrap();
        assert!(sparse.redact);
        assert!(sparse.include_anchors);
    }

    #[test]
    fn an_empty_export_is_still_well_formed() {
        for fmt in [ExportFormat::Rfc5424, ExportFormat::Ndjson, ExportFormat::Csv, ExportFormat::OtlpJson] {
            let opts = ExportOptions { format: fmt, ..Default::default() };
            let batch = render(&[], &opts, None).unwrap();
            assert_eq!(batch.count, 0);
            if fmt == ExportFormat::OtlpJson {
                let v: serde_json::Value = serde_json::from_str(&batch.payload).unwrap();
                assert_eq!(v["resourceLogs"][0]["scopeLogs"][0]["logRecords"].as_array().unwrap().len(), 0);
            }
            if fmt == ExportFormat::Csv {
                assert!(batch.payload.starts_with("id,ts_utc,"));
            }
        }
    }
}
