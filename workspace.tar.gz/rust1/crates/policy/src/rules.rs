//! Rule model and matchers (`rustplan.txt` §9.5 `src/rules.rs`, §10.4).
//!
//! Pattern grammar:
//!
//! ```text
//! pattern   := tool "(" selector ")"
//! tool      := "shell" | "read" | "write" | "net" | "mcp" | "*"
//! selector  := path-glob | argv-pattern | host | tool-name
//! argv-pattern := token (" " token)*    # token: literal, "*" = one, "**" = rest
//! ```
//!
//! Evaluation order is **deny → ask → allow**, and ties break on specificity
//! (longer literal prefix wins). Every rule remembers where it came from so
//! `explain()` can print `.agent/config.toml:12`.

use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Serialize};

use agent_protocol::glob_match::{argv_match, glob_match, glob_specificity, shell_words};
use agent_protocol::tool::RiskClass;

/// Which capability family a rule constrains.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RuleTool {
    /// Process execution.
    Shell,
    /// File reads.
    Read,
    /// File writes/edits/patches/deletes.
    Write,
    /// Network egress.
    Net,
    /// An MCP server tool.
    Mcp,
    /// Any tool.
    Any,
}

impl RuleTool {
    /// Parse the leading identifier of a pattern.
    #[must_use]
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "shell" | "exec" | "bash" => Some(Self::Shell),
            "read" => Some(Self::Read),
            "write" | "edit" | "mutate" => Some(Self::Write),
            "net" | "network" | "web" => Some(Self::Net),
            "mcp" => Some(Self::Mcp),
            "*" | "any" | "all" => Some(Self::Any),
            _ => None,
        }
    }

    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Shell => "shell",
            Self::Read => "read",
            Self::Write => "write",
            Self::Net => "net",
            Self::Mcp => "mcp",
            Self::Any => "*",
        }
    }

    /// Does this rule family apply to a concrete tool name + risk class?
    #[must_use]
    pub fn applies_to(self, tool: &str, risk: RiskClass) -> bool {
        match self {
            Self::Any => true,
            Self::Shell => risk == RiskClass::Exec || tool == "shell",
            Self::Read => risk == RiskClass::Read || tool.starts_with("read") || tool == "grep" || tool == "glob" || tool == "list_dir",
            Self::Write => matches!(risk, RiskClass::Mutate | RiskClass::Destructive) || tool == "apply_patch",
            Self::Net => risk == RiskClass::Network || tool.starts_with("web_"),
            Self::Mcp => tool.starts_with("mcp__"),
        }
    }
}

impl fmt::Display for RuleTool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// What a rule matched against.
///
/// Serialised with external tagging (`{"argv":"git status"}`) because serde
/// cannot encode a tagged newtype variant that holds a plain string.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Selector {
    /// A path glob (`src/**`, `*.rs`).
    Path(String),
    /// An argv pattern (`git status`, `rm -rf **`).
    Argv(String),
    /// A host or host glob (`api.anthropic.com`, `*.internal`).
    Host(String),
    /// A tool name or name glob (`mcp(github.*)`).
    ToolName(String),
    /// Matches everything (`*`).
    Everything,
}

impl Selector {
    /// Specificity score; higher wins a tie-break.
    #[must_use]
    pub fn specificity(&self) -> u32 {
        match self {
            Selector::Everything => 0,
            Selector::Path(p) => glob_specificity(p),
            Selector::Argv(a) => {
                let toks = shell_words(a);
                let literals = toks.iter().filter(|t| !t.contains(['*', '?'])).count() as u32;
                literals.saturating_mul(10).saturating_add(toks.len() as u32)
            }
            Selector::Host(h) => {
                if h == "*" { 0 } else { (h.len() as u32).saturating_add(h.matches('.').count() as u32 * 5) }
            }
            Selector::ToolName(t) => glob_specificity(t),
        }
    }

    /// True when the selector contains no wildcard at all.
    #[must_use]
    pub fn is_exact(&self) -> bool {
        match self {
            Selector::Everything => false,
            Selector::Path(p) | Selector::Argv(p) | Selector::Host(p) | Selector::ToolName(p) => {
                !p.contains(['*', '?', '[', '{'])
            }
        }
    }
}

impl fmt::Display for Selector {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Selector::Path(p)
            | Selector::Argv(p)
            | Selector::Host(p)
            | Selector::ToolName(p) => f.write_str(p),
            Selector::Everything => f.write_str("*"),
        }
    }
}

/// A parse error for a rule pattern.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum RuleParseError {
    /// The pattern was empty or only whitespace.
    #[error("empty rule pattern")]
    Empty,
    /// The leading tool name is not one of shell/read/write/net/mcp/*.
    #[error("unknown rule tool `{0}`; expected shell, read, write, net, mcp or *")]
    UnknownTool(String),
    /// Missing parentheses or a trailing `)`.
    #[error("rule `{0}` must look like `tool(selector)`, e.g. `shell(git status)`")]
    BadShape(String),
    /// The selector was empty.
    #[error("rule `{0}` has an empty selector")]
    EmptySelector(String),
}

/// A single policy rule.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Rule {
    /// Capability family.
    pub tool: RuleTool,
    /// What to match against.
    pub selector: Selector,
    /// What happens when it matches.
    pub effect: Effect,
    /// Where the rule came from, for `explain()`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub origin: Option<RuleOrigin>,
    /// True when the rule came from the admin-managed layer and cannot be
    /// weakened by a developer config (§9.5 `managed.rs`).
    #[serde(default)]
    pub managed: bool,
    /// Free-text note shown in `/permissions`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub note: Option<String>,
}

/// Allow / deny / force a prompt.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Effect {
    /// Permit without prompting.
    Allow,
    /// Refuse, and tell the model why.
    Deny,
    /// Always prompt, even in `auto-edit`/`bypass`.
    Ask,
}

impl Effect {
    /// Evaluation rank: deny first, then ask, then allow (§10.4).
    #[must_use]
    pub const fn rank(self) -> u8 {
        match self {
            Effect::Deny => 2,
            Effect::Ask => 1,
            Effect::Allow => 0,
        }
    }
}

/// Where a rule was loaded from.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RuleOrigin {
    /// Layer name (`managed`, `user`, `project`, `local`, `session-grant`, `builtin`).
    pub layer: String,
    /// File path, when the rule came from a file.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    /// 1-based line number in that file.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub line: Option<usize>,
}

impl RuleOrigin {
    /// `at .agent/config.toml:12` style suffix for `explain()`.
    #[must_use]
    pub fn render(&self) -> String {
        match (&self.path, self.line) {
            (Some(p), Some(l)) => format!("at {p}:{l}"),
            (Some(p), None) => format!("at {p}"),
            (None, _) => format!("from the {} layer", self.layer),
        }
    }
}

impl Rule {
    /// Parse a pattern string plus an effect, e.g. `("shell(rm -rf **)", Deny)`.
    ///
    /// # Errors
    /// [`RuleParseError`] when the pattern is malformed. The message always
    /// contains the offending text and the expected shape.
    pub fn parse(pattern: &str, effect: Effect) -> Result<Self, RuleParseError> {
        Self::parse_with_origin(pattern, effect, None)
    }

    /// Like [`Rule::parse`] but records provenance.
    ///
    /// # Errors
    /// [`RuleParseError`] when the pattern is malformed.
    pub fn parse_with_origin(
        pattern: &str,
        effect: Effect,
        origin: Option<RuleOrigin>,
    ) -> Result<Self, RuleParseError> {
        let p = pattern.trim();
        if p.is_empty() {
            return Err(RuleParseError::Empty);
        }
        let open = p.find('(').ok_or_else(|| RuleParseError::BadShape(p.to_owned()))?;
        if !p.ends_with(')') {
            return Err(RuleParseError::BadShape(p.to_owned()));
        }
        let (tool_raw, rest) = p.split_at(open);
        let inner = &rest[1..rest.len() - 1];
        let tool_raw = tool_raw.trim();
        let tool = RuleTool::parse(tool_raw).ok_or_else(|| RuleParseError::UnknownTool(tool_raw.to_owned()))?;
        let selector = parse_selector(tool, inner.trim()).ok_or_else(|| RuleParseError::EmptySelector(p.to_owned()))?;
        Ok(Self { tool, selector, effect, origin, managed: false, note: None })
    }

    /// Render back to pattern syntax (round-trips through [`Rule::parse`]).
    #[must_use]
    pub fn pattern(&self) -> String {
        format!("{}({})", self.tool, self.selector)
    }

    /// Mark the rule as coming from the admin-managed layer.
    #[must_use]
    pub fn managed(mut self) -> Self {
        self.managed = true;
        self
    }

    /// Attach a human note.
    #[must_use]
    pub fn with_note(mut self, note: impl Into<String>) -> Self {
        self.note = Some(note.into());
        self
    }

    /// Specificity, combining the selector score and the tool family.
    ///
    /// `*` (any tool) is the least specific; a named tool beats it; a longer
    /// literal selector beats a shorter one (§10.4 tie-break).
    #[must_use]
    pub fn specificity(&self) -> u32 {
        let tool_bonus = match self.tool {
            RuleTool::Any => 0,
            RuleTool::Shell | RuleTool::Read | RuleTool::Write | RuleTool::Net => 20,
            RuleTool::Mcp => 25,
        };
        self.selector.specificity().saturating_add(tool_bonus)
    }
}

/// Choose the selector kind from the rule family.
/// Every spelling of a tool name a `mcp(...)` selector may match against.
#[must_use]
pub fn tool_name_candidates(tool: &str) -> Vec<String> {
    let mut out = vec![tool.to_string()];
    if let Some(rest) = tool.strip_prefix("mcp__") {
        // `mcp__github__list_prs` -> `github.list_prs`
        match rest.split_once("__") {
            Some((server, name)) => out.push(format!("{server}.{name}")),
            None => out.push(rest.to_string()),
        }
    }
    out
}

fn parse_selector(tool: RuleTool, inner: &str) -> Option<Selector> {
    if inner.is_empty() {
        return None;
    }
    if inner == "*" {
        return Some(Selector::Everything);
    }
    Some(match tool {
        RuleTool::Shell => Selector::Argv(inner.to_owned()),
        RuleTool::Read | RuleTool::Write => Selector::Path(inner.to_owned()),
        RuleTool::Net => Selector::Host(inner.to_owned()),
        RuleTool::Mcp => Selector::ToolName(inner.to_owned()),
        // `*` family: guess from the shape. A selector containing a space is a
        // command line; otherwise it is a path.
        RuleTool::Any => {
            if inner.contains(' ') || inner.contains("**") && !inner.contains('/') {
                Selector::Argv(inner.to_owned())
            } else {
                Selector::Path(inner.to_owned())
            }
        }
    })
}

/// The concrete thing a rule is tested against.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Subject<'a> {
    /// Tool name as registered.
    pub tool: &'a str,
    /// Risk class resolved from the registry.
    pub risk: RiskClass,
    /// Workspace-relative paths the call touches (may be empty).
    pub paths: &'a [String],
    /// The shell command line, when the tool executes a process.
    pub command: Option<&'a str>,
    /// The argv, when the caller already tokenised it.
    pub argv: Option<&'a [String]>,
    /// Host(s) the call would contact.
    pub hosts: &'a [String],
}

impl<'a> Subject<'a> {
    /// Build a subject for a path-touching tool.
    #[must_use]
    pub fn paths(tool: &'a str, risk: RiskClass, paths: &'a [String]) -> Self {
        Self { tool, risk, paths, command: None, argv: None, hosts: &[] }
    }

    /// Build a subject for a shell call.
    #[must_use]
    pub fn shell(tool: &'a str, command: &'a str) -> Self {
        Self { tool, risk: RiskClass::Exec, paths: &[], command: Some(command), argv: None, hosts: &[] }
    }

    /// Build a subject for a network call.
    #[must_use]
    pub fn net(tool: &'a str, hosts: &'a [String]) -> Self {
        Self { tool, risk: RiskClass::Network, paths: &[], command: None, argv: None, hosts }
    }

    /// Does this rule match the subject? Returns the match strength
    /// (`None` = no match) so the engine can pick the most specific rule.
    #[must_use]
    pub fn matches(&self, rule: &Rule) -> Option<u32> {
        if !rule.tool.applies_to(self.tool, self.risk) {
            return None;
        }
        match &rule.selector {
            Selector::Everything => Some(rule.specificity()),
            Selector::Path(g) => self.paths.iter().any(|p| glob_match(g, p)).then(|| rule.specificity()),
            Selector::Host(h) => {
                if h == "*" {
                    return Some(0);
                }
                self.hosts.iter().any(|host| glob_match(h, host)).then(|| rule.specificity())
            }
            Selector::ToolName(g) => {
                // An MCP rule selects on `server.tool`; the registered name is
                // `mcp__server__tool`, so both spellings are offered to the glob.
                tool_name_candidates(self.tool)
                    .iter()
                    .any(|c| glob_match(g, c))
                    .then(|| rule.specificity())
            }
            Selector::Argv(pat) => self.match_argv(pat).map(|m| rule.specificity().saturating_add(m)),
        }
    }

    fn match_argv(&self, pat: &str) -> Option<u32> {
        if let Some(cmd) = self.command {
            return argv_match(pat, cmd).map(|m| m.specificity());
        }
        if let Some(argv) = self.argv {
            let ptoks = shell_words(pat);
            return agent_protocol::glob_match::argv_match_tokens(&ptoks, argv)
                .map(|m| m.specificity());
        }
        None
    }
}

impl FromStr for Rule {
    type Err = RuleParseError;
    /// Parses `deny:shell(rm -rf **)` / `allow:read(src/**)` / bare
    /// `shell(rm -rf **)` (defaults to deny, the safe reading).
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let (effect, rest) = match s.split_once(':') {
            Some((head, tail)) => match head.trim().to_ascii_lowercase().as_str() {
                "allow" => (Effect::Allow, tail),
                "ask" => (Effect::Ask, tail),
                "deny" => (Effect::Deny, tail),
                _ => (Effect::Deny, s),
            },
            None => (Effect::Deny, s),
        };
        Rule::parse(rest.trim(), effect)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_every_documented_example() {
        // §10.4 examples, verbatim.
        for (p, tool, sel) in [
            ("shell(git status)", RuleTool::Shell, "git status"),
            ("shell(cargo test *)", RuleTool::Shell, "cargo test *"),
            ("shell(rm -rf **)", RuleTool::Shell, "rm -rf **"),
            ("read(src/**)", RuleTool::Read, "src/**"),
            ("net(api.anthropic.com)", RuleTool::Net, "api.anthropic.com"),
            ("mcp(github.*)", RuleTool::Mcp, "github.*"),
            ("*(*)", RuleTool::Any, "*"),
        ] {
            let r = Rule::parse(p, Effect::Deny).unwrap_or_else(|e| panic!("{p}: {e}"));
            assert_eq!(r.tool, tool, "{p}");
            assert_eq!(r.selector.to_string(), sel, "{p}");
            assert_eq!(r.pattern(), p, "pattern must round-trip");
        }
    }

    #[test]
    fn malformed_patterns_are_rejected_with_useful_messages() {
        let cases = [
            ("", RuleParseError::Empty),
            ("shell", RuleParseError::BadShape("shell".into())),
            ("shell(git status", RuleParseError::BadShape("shell(git status".into())),
            ("frobnicate(x)", RuleParseError::UnknownTool("frobnicate".into())),
            ("shell()", RuleParseError::EmptySelector("shell()".into())),
        ];
        for (input, want) in cases {
            let got = Rule::parse(input, Effect::Deny).unwrap_err();
            assert_eq!(got, want, "{input}");
        }
        assert!(RuleParseError::UnknownTool("x".into()).to_string().contains("expected shell"));
    }

    #[test]
    fn from_str_reads_the_effect_prefix() {
        assert_eq!("allow:read(src/**)".parse::<Rule>().unwrap().effect, Effect::Allow);
        assert_eq!("ask:shell(cargo build)".parse::<Rule>().unwrap().effect, Effect::Ask);
        assert_eq!("deny:shell(rm -rf **)".parse::<Rule>().unwrap().effect, Effect::Deny);
        // No prefix defaults to deny: the safe reading of a bare pattern.
        assert_eq!("shell(rm -rf **)".parse::<Rule>().unwrap().effect, Effect::Deny);
    }

    #[test]
    fn argv_rules_are_token_aware_not_string_globs() {
        let rule = Rule::parse("shell(rm -rf **)", Effect::Deny).unwrap();
        assert!(Subject::shell("shell", "rm -rf /").matches(&rule).is_some());
        assert!(Subject::shell("shell", "rm    -rf    /tmp").matches(&rule).is_some());
        assert!(Subject::shell("shell", "rm -r /").matches(&rule).is_none());
        assert!(Subject::shell("shell", "echo rm -rf /").matches(&rule).is_none());
    }

    #[test]
    fn path_rules_respect_glob_semantics() {
        let rule = Rule::parse("read(src/**)", Effect::Allow).unwrap();
        let paths = vec!["src/main.rs".to_string()];
        assert!(Subject::paths("read_file", RiskClass::Read, &paths).matches(&rule).is_some());
        let outside = vec!["../etc/passwd".to_string()];
        assert!(Subject::paths("read_file", RiskClass::Read, &outside).matches(&rule).is_none());
    }

    #[test]
    fn a_rule_matches_if_any_path_matches() {
        let rule = Rule::parse("write(secret/**)", Effect::Deny).unwrap();
        let paths = vec!["src/a.rs".to_string(), "secret/key.pem".to_string()];
        assert!(Subject::paths("write_file", RiskClass::Mutate, &paths).matches(&rule).is_some());
    }

    #[test]
    fn host_rules_match_exact_and_wildcard() {
        let exact = Rule::parse("net(api.anthropic.com)", Effect::Allow).unwrap();
        let wild = Rule::parse("net(*.internal)", Effect::Allow).unwrap();
        let hosts = vec!["api.anthropic.com".to_string()];
        assert!(Subject::net("web_fetch", &hosts).matches(&exact).is_some());
        let internal = vec!["git.corp.internal".to_string()];
        assert!(Subject::net("web_fetch", &internal).matches(&wild).is_some());
        assert!(Subject::net("web_fetch", &internal).matches(&exact).is_none());
    }

    #[test]
    fn tool_family_gating_is_correct() {
        let shell = Rule::parse("shell(git status)", Effect::Allow).unwrap();
        // A read of a file named "git status" must not match a shell rule.
        let paths = vec!["git status".to_string()];
        assert!(Subject::paths("read_file", RiskClass::Read, &paths).matches(&shell).is_none());

        let mcp = Rule::parse("mcp(github.*)", Effect::Allow).unwrap();
        assert!(Subject { tool: "mcp__github__list_prs", risk: RiskClass::Read, paths: &[], command: None, argv: None, hosts: &[] }
            .matches(&mcp)
            .is_some());
        assert!(Subject { tool: "read_file", risk: RiskClass::Read, paths: &[], command: None, argv: None, hosts: &[] }
            .matches(&mcp)
            .is_none());
    }

    #[test]
    fn specificity_prefers_literal_over_wild() {
        let exact = Rule::parse("shell(git status)", Effect::Deny).unwrap();
        let prefix = Rule::parse("shell(git *)", Effect::Allow).unwrap();
        let any = Rule::parse("shell(**)", Effect::Allow).unwrap();
        let all = Rule::parse("*(*)", Effect::Allow).unwrap();
        assert!(exact.specificity() > prefix.specificity(), "{} vs {}", exact.specificity(), prefix.specificity());
        assert!(prefix.specificity() > any.specificity());
        assert!(any.specificity() > all.specificity());
    }

    #[test]
    fn effect_rank_puts_deny_first() {
        assert!(Effect::Deny.rank() > Effect::Ask.rank());
        assert!(Effect::Ask.rank() > Effect::Allow.rank());
    }

    #[test]
    fn origin_renders_a_locatable_suffix() {
        let o = RuleOrigin { layer: "project".into(), path: Some(".agent/config.toml".into()), line: Some(12) };
        assert_eq!(o.render(), "at .agent/config.toml:12");
        let o2 = RuleOrigin { layer: "session-grant".into(), path: None, line: None };
        assert_eq!(o2.render(), "from the session-grant layer");
    }

    #[test]
    fn argv_subject_accepts_pre_tokenised_input() {
        let rule = Rule::parse("shell(cargo test *)", Effect::Allow).unwrap();
        let argv = vec!["cargo".to_string(), "test".to_string(), "api".to_string()];
        let s = Subject { tool: "shell", risk: RiskClass::Exec, paths: &[], command: None, argv: Some(&argv), hosts: &[] };
        assert!(s.matches(&rule).is_some());
    }

    #[test]
    fn selectors_report_exactness() {
        assert!(Rule::parse("shell(git status)", Effect::Allow).unwrap().selector.is_exact());
        assert!(!Rule::parse("shell(git *)", Effect::Allow).unwrap().selector.is_exact());
        assert!(!Selector::Everything.is_exact());
    }

    #[test]
    fn rules_survive_serde() {
        let r = Rule::parse("shell(rm -rf **)", Effect::Deny).unwrap().managed().with_note("never");
        let v = serde_json::to_value(&r).unwrap();
        let back: Rule = serde_json::from_value(v).unwrap();
        assert_eq!(back, r);
        assert!(back.managed);
    }
}

impl std::fmt::Display for Effect {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Allow => "allow",
            Self::Ask => "ask",
            Self::Deny => "deny",
        })
    }
}
