//! Network egress policy (`rustplan.txt` §6.4 layer 4, §9.5 `src/network.rs`).
//!
//! Default is **localhost-only** (§3 safe-by-default): the agent may talk to a
//! dev server on `127.0.0.1` and nothing else. Opening egress is an explicit
//! config act, and it is recorded in the audit log because it changes the
//! blast radius of every subsequent tool call.
//!
//! Two things make this more than a domain allowlist:
//!
//! * **SSRF defence.** A hostname is not a destination. `http://foo.example/`
//!   can resolve to `169.254.169.254` and hand an attacker the instance
//!   credentials, so the policy is evaluated *twice*: once on the literal
//!   (before connecting, so the user sees a prompt) and once on every resolved
//!   address (after DNS, before the socket is used). [`NetworkPolicy::check_ip`]
//!   is the second gate and is what `sandbox` calls from its resolver hook.
//! * **Redirects are re-checked.** `web_fetch` follows up to N redirects; each
//!   hop goes back through [`NetworkPolicy::check_url`], so an allowlisted host
//!   cannot be used as a trampoline into a private range.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};

/// What egress is permitted when no rule says otherwise.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NetworkDefault {
    /// Loopback only. The default.
    #[default]
    LocalhostOnly,
    /// Loopback plus explicitly allowlisted hosts.
    Allowlisted,
    /// Anything except the deny list and link-local metadata. Never the default;
    /// the CLI prints a warning whenever it is in force.
    Open,
}

impl NetworkDefault {
    /// Stable config spelling.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::LocalhostOnly => "localhost-only",
            Self::Allowlisted => "allowlisted",
            Self::Open => "open",
        }
    }
}

impl std::str::FromStr for NetworkDefault {
    type Err = String;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim().to_ascii_lowercase().as_str() {
            "localhost-only" | "localhost" | "loopback" => Ok(Self::LocalhostOnly),
            "allowlisted" | "allowlist" | "allow-list" => Ok(Self::Allowlisted),
            "open" | "any" | "*" => Ok(Self::Open),
            other => Err(format!("unknown network default `{other}` (expected localhost-only|allowlisted|open)")),
        }
    }
}

/// An inclusive port range.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct PortRange {
    /// First port.
    pub start: u16,
    /// Last port.
    pub end: u16,
}

impl PortRange {
    /// A single port.
    #[must_use]
    pub const fn one(port: u16) -> Self {
        Self { start: port, end: port }
    }

    /// A range; swapped if given backwards.
    #[must_use]
    pub const fn span(start: u16, end: u16) -> Self {
        if start <= end { Self { start, end } } else { Self { start: end, end: start } }
    }

    /// Contains a port.
    #[must_use]
    pub const fn contains(&self, port: u16) -> bool {
        port >= self.start && port <= self.end
    }
}

/// A parsed URL. Deliberately minimal and dependency-free: policy must not pull
/// in a full URL stack, and it must never *guess* a component.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ParsedUrl {
    /// Scheme, lowercased.
    pub scheme: String,
    /// Host, lowercased, brackets stripped for IPv6.
    pub host: String,
    /// Port, explicit or scheme default.
    pub port: u16,
    /// True when the port came from the scheme rather than the URL text.
    pub port_is_default: bool,
    /// Path (may be empty).
    pub path: String,
    /// Query (without `?`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub query: Option<String>,
    /// Userinfo, when present. Never logged in full — see [`ParsedUrl::safe_user`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub userinfo: Option<String>,
}

/// URL parse failure.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error, Serialize, Deserialize)]
pub enum UrlError {
    /// No scheme.
    #[error("`{0}` has no scheme; expected http:// or https://")]
    NoScheme(String),
    /// Unsupported scheme.
    #[error("scheme `{0}` is not permitted (allowed: http, https, git, ssh, ftp, ftps)")]
    BadScheme(String),
    /// Empty host.
    #[error("`{0}` has no host")]
    NoHost(String),
    /// Invalid port.
    #[error("invalid port `{0}`")]
    BadPort(String),
}

impl ParsedUrl {
    /// Parse. Accepts only the schemes a coding agent has any business using;
    /// `file://` and `javascript:` are refused here rather than somewhere
    /// further down the stack.
    ///
    /// # Errors
    /// [`UrlError`] describing exactly what was wrong.
    pub fn parse(input: &str) -> Result<Self, UrlError> {
        let s = input.trim();
        let Some((scheme, rest)) = s.split_once("://") else {
            return Err(UrlError::NoScheme(s.to_string()));
        };
        let scheme = scheme.to_ascii_lowercase();
        const OK: &[&str] = &["http", "https", "git", "ssh", "ftp", "ftps"];
        if !OK.contains(&scheme.as_str()) {
            return Err(UrlError::BadScheme(scheme));
        }
        // Split off path/query/fragment.
        let (authority, tail) = match rest.find(['/', '?', '#']) {
            Some(i) => (&rest[..i], &rest[i..]),
            None => (rest, ""),
        };
        let (userinfo, hostport) = match authority.rsplit_once('@') {
            Some((u, h)) => (Some(u.to_string()), h),
            None => (None, authority),
        };
        // IPv6 literal: [::1]:8080
        let (host, port_text) = if let Some(stripped) = hostport.strip_prefix('[') {
            match stripped.find(']') {
                Some(i) => {
                    let h = stripped[..i].to_string();
                    let after = &stripped[i + 1..];
                    (h, after.strip_prefix(':').map(str::to_string))
                }
                None => return Err(UrlError::NoHost(s.to_string())),
            }
        } else {
            match hostport.rsplit_once(':') {
                Some((h, p)) => (h.to_string(), Some(p.to_string())),
                None => (hostport.to_string(), None),
            }
        };
        let host = host.to_ascii_lowercase();
        if host.is_empty() {
            return Err(UrlError::NoHost(s.to_string()));
        }
        let (port, port_is_default) = match &port_text {
            Some(p) if !p.is_empty() => {
                let n: u16 = p.parse().map_err(|_| UrlError::BadPort(p.clone()))?;
                (n, false)
            }
            _ => (Self::default_port(&scheme), true),
        };
        let (path, query) = match tail.split_once('?') {
            Some((p, q)) => (p.to_string(), Some(q.split('#').next().unwrap_or(q).to_string())),
            None => (tail.split('#').next().unwrap_or(tail).to_string(), None),
        };
        Ok(Self { scheme, host, port, port_is_default, path, query, userinfo })
    }

    /// Default port per scheme.
    #[must_use]
    pub fn default_port(scheme: &str) -> u16 {
        match scheme {
            "https" | "ftps" => 443,
            "ssh" | "git" => 22,
            "ftp" => 21,
            _ => 80,
        }
    }

    /// True when the host is a loopback name or address.
    #[must_use]
    pub fn host_is_loopback(&self) -> bool {
        is_loopback(&self.host)
    }

    /// Userinfo safe to log: the password half is dropped.
    #[must_use]
    pub fn safe_user(&self) -> Option<String> {
        self.userinfo.as_ref().map(|u| match u.split_once(':') {
            Some((name, _)) => format!("{name}:***"),
            None => u.clone(),
        })
    }

    /// Re-render without userinfo, for logs and the audit trail.
    #[must_use]
    pub fn redacted(&self) -> String {
        let q = self.query.as_ref().map(|q| format!("?{q}")).unwrap_or_default();
        format!("{}://{}:{}{}{q}", self.scheme, self.host, self.port, self.path)
    }
}

/// True for loopback names/addresses.
#[must_use]
pub fn is_loopback(host: &str) -> bool {
    let h = host.to_ascii_lowercase();
    h == "localhost" || h == "::1" || h.starts_with("127.")
}

/// Classify a literal IP (v4 or v6, brackets optional).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum IpClass {
    /// Loopback.
    Loopback,
    /// RFC1918 / ULA.
    Private,
    /// Link-local, including the cloud metadata service.
    LinkLocal,
    /// The instance metadata address specifically.
    CloudMetadata,
    /// Publicly routable.
    Public,
    /// Not an IP literal at all.
    NotAnIp,
}

/// Classify a host or IP literal.
#[must_use]
pub fn classify_ip(host: &str) -> IpClass {
    let h = host.trim().trim_matches(|c| c == '[' || c == ']').to_ascii_lowercase();
    if h == "169.254.169.254" || h == "metadata.google.internal" || h == "fd00:ec2::254" {
        return IpClass::CloudMetadata;
    }
    if is_loopback(&h) {
        return IpClass::Loopback;
    }
    let parts: Vec<&str> = h.split('.').collect();
    if parts.len() == 4 && parts.iter().all(|p| p.parse::<u8>().is_ok()) {
        let a: u8 = parts[0].parse().unwrap_or(0);
        let b: u8 = parts[1].parse().unwrap_or(0);
        if a == 10 {
            return IpClass::Private;
        }
        if a == 172 && (16..=31).contains(&b) {
            return IpClass::Private;
        }
        if a == 192 && b == 168 {
            return IpClass::Private;
        }
        if a == 169 && b == 254 {
            return IpClass::LinkLocal;
        }
        if a == 0 || a == 255 {
            return IpClass::LinkLocal;
        }
        return IpClass::Public;
    }
    if h.contains(':') {
        // Very small IPv6 classifier: fc00::/7 ULA, fe80::/10 link-local.
        let head = h.split(':').next().unwrap_or("");
        let first = u16::from_str_radix(head, 16).unwrap_or(0);
        if (0xfc00..=0xfdff).contains(&first) {
            return IpClass::Private;
        }
        if (0xfe80..=0xfebf).contains(&first) {
            return IpClass::LinkLocal;
        }
        return IpClass::Public;
    }
    IpClass::NotAnIp
}

/// The egress policy.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NetworkPolicy {
    /// Behaviour when nothing matches.
    pub default: NetworkDefault,
    /// Host globs that are always allowed (`*.internal.example.com`).
    #[serde(default)]
    pub allow_hosts: Vec<String>,
    /// Host globs that are always denied — deny wins, as everywhere else.
    #[serde(default)]
    pub deny_hosts: Vec<String>,
    /// Allowed ports; empty means "ports implied by the scheme".
    #[serde(default)]
    pub allow_ports: Vec<PortRange>,
    /// Denied ports. Always applied, even in `open`.
    #[serde(default)]
    pub deny_ports: Vec<PortRange>,
    /// Refuse private ranges even when a host is allowlisted. Default true: an
    /// allowlisted name resolving into the LAN is an SSRF, not a feature.
    #[serde(default = "yes")]
    pub block_private_ranges: bool,
    /// Refuse link-local. Always effectively true; kept explicit for audits.
    #[serde(default = "yes")]
    pub block_link_local: bool,
    /// Refuse non-HTTP(S) schemes. Default true.
    #[serde(default = "yes")]
    pub require_tls: bool,
    /// Maximum response body, bytes. Enforced by the fetch tool.
    #[serde(default = "default_max_bytes")]
    pub max_response_bytes: u64,
    /// Per-request timeout, ms.
    #[serde(default = "default_timeout_ms")]
    pub timeout_ms: u64,
    /// Redirect budget. Each hop is re-checked.
    #[serde(default = "default_max_redirects")]
    pub max_redirects: u8,
}

const fn yes() -> bool {
    true
}
const fn default_max_bytes() -> u64 {
    16 * 1024 * 1024
}
const fn default_timeout_ms() -> u64 {
    30_000
}
const fn default_max_redirects() -> u8 {
    5
}

impl Default for NetworkPolicy {
    fn default() -> Self {
        Self {
            default: NetworkDefault::LocalhostOnly,
            allow_hosts: Vec::new(),
            deny_hosts: Vec::new(),
            allow_ports: Vec::new(),
            deny_ports: vec![PortRange::span(0, 1023), PortRange::span(6000, 6063)],
            block_private_ranges: true,
            block_link_local: true,
            require_tls: true,
            max_response_bytes: default_max_bytes(),
            timeout_ms: default_timeout_ms(),
            max_redirects: default_max_redirects(),
        }
    }
}

/// The answer to an egress question.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "verdict", rename_all = "snake_case")]
pub enum NetworkVerdict {
    /// Connect.
    Allow {
        /// Why, for the audit line.
        reason: String,
    },
    /// Ask the human first.
    Ask {
        /// Why.
        reason: String,
    },
    /// Refuse.
    Deny {
        /// Why. Shown to the model so it can pick a different approach.
        reason: String,
    },
}

impl NetworkVerdict {
    /// True when the connection may proceed.
    #[must_use]
    pub const fn allows(&self) -> bool {
        matches!(self, Self::Allow { .. })
    }

    /// True when the connection is refused.
    #[must_use]
    pub const fn denies(&self) -> bool {
        matches!(self, Self::Deny { .. })
    }

    /// The reason string.
    #[must_use]
    pub fn reason(&self) -> String {
        match self {
            Self::Allow { reason } | Self::Ask { reason } | Self::Deny { reason } => reason.clone(),
        }
    }
}

impl NetworkPolicy {
    /// A policy for local development: loopback plus common dev-server ports.
    #[must_use]
    pub fn localhost_dev() -> Self {
        Self {
            allow_ports: vec![PortRange::span(3000, 9999)],
            deny_ports: Vec::new(),
            ..Self::default()
        }
    }

    /// Check a URL string.
    #[must_use]
    pub fn check_url_str(&self, url: &str) -> NetworkVerdict {
        match ParsedUrl::parse(url) {
            Ok(u) => self.check_url(&u),
            Err(e) => NetworkVerdict::Deny { reason: e.to_string() },
        }
    }

    /// Check a parsed URL. Pure: no DNS, no I/O.
    #[must_use]
    pub fn check_url(&self, url: &ParsedUrl) -> NetworkVerdict {
        // 1. Deny list wins over everything.
        if self.matches_any(&self.deny_hosts, &url.host) {
            return NetworkVerdict::Deny { reason: format!("{} is on the network deny list", url.host) };
        }
        // 2. Scheme.
        if self.require_tls && !matches!(url.scheme.as_str(), "https" | "http") {
            return NetworkVerdict::Deny {
                reason: format!("scheme `{}` is not permitted (require_tls is on)", url.scheme),
            };
        }
        if url.scheme == "http" && !url.host_is_loopback() && self.require_tls {
            return NetworkVerdict::Ask { reason: format!("plaintext http to a non-loopback host ({})", url.host) };
        }
        // 3. Ports.
        if self.matches_port(&self.deny_ports, url.port) {
            // Loopback dev servers legitimately use low ports in some setups, but
            // only when the operator said so via allow_ports.
            if !self.matches_port(&self.allow_ports, url.port) {
                return NetworkVerdict::Deny { reason: format!("port {} is on the deny list", url.port) };
            }
        }
        if !self.allow_ports.is_empty() && !self.matches_port(&self.allow_ports, url.port) {
            return NetworkVerdict::Ask { reason: format!("port {} is not in the configured allow_ports", url.port) };
        }
        // 4. IP literals get the address checks immediately.
        let cls = classify_ip(&url.host);
        if cls != IpClass::NotAnIp {
            if let Some(v) = self.check_ip_class(cls, &url.host) {
                return v;
            }
        }
        // 5. Host lists.
        if self.matches_any(&self.allow_hosts, &url.host) {
            return NetworkVerdict::Allow { reason: format!("{} matches an allow_hosts entry", url.host) };
        }
        match self.default {
            NetworkDefault::LocalhostOnly => {
                if url.host_is_loopback() {
                    NetworkVerdict::Allow { reason: format!("{} is loopback (localhost-only policy)", url.host) }
                } else {
                    NetworkVerdict::Deny {
                        reason: format!(
                            "network default is localhost-only; {} is not loopback. Add it to network.allow_hosts or change the default",
                            url.host
                        ),
                    }
                }
            }
            NetworkDefault::Allowlisted => NetworkVerdict::Ask {
                reason: format!("{} is not allowlisted (network default is allowlisted)", url.host),
            },
            NetworkDefault::Open => {
                if url.host_is_loopback() {
                    NetworkVerdict::Allow { reason: format!("{} is loopback", url.host) }
                } else {
                    NetworkVerdict::Allow { reason: format!("network default is open; {} permitted", url.host) }
                }
            }
        }
    }

    /// The post-DNS gate. Called by `sandbox`/`exec` with every address the
    /// resolver returned, *before* the socket is connected.
    #[must_use]
    pub fn check_ip(&self, ip: &str) -> NetworkVerdict {
        let cls = classify_ip(ip);
        self.check_ip_class(cls, ip).unwrap_or(NetworkVerdict::Allow { reason: format!("{ip} is publicly routable") })
    }

    fn check_ip_class(&self, cls: IpClass, host: &str) -> Option<NetworkVerdict> {
        match cls {
            IpClass::CloudMetadata => Some(NetworkVerdict::Deny {
                reason: format!("{host} is a cloud metadata endpoint; refusing (credential theft vector)"),
            }),
            IpClass::LinkLocal => self.block_link_local.then(|| NetworkVerdict::Deny {
                reason: format!("{host} is link-local; refusing"),
            }),
            IpClass::Private => self.block_private_ranges.then(|| NetworkVerdict::Deny {
                reason: format!(
                    "{host} resolves into a private range; refusing (set network.block_private_ranges=false only if you understand SSRF)"
                ),
            }),
            IpClass::Loopback | IpClass::Public | IpClass::NotAnIp => None,
        }
    }

    fn matches_any(&self, patterns: &[String], host: &str) -> bool {
        patterns.iter().any(|p| host_glob(p, host))
    }

    fn matches_port(&self, ranges: &[PortRange], port: u16) -> bool {
        ranges.iter().any(|r| r.contains(port))
    }
}

/// Host glob matching with a leading-dot rule: `*.example.com` matches
/// `a.example.com` and `example.com` (the common expectation) but not
/// `evil-example.com`.
#[must_use]
pub fn host_glob(pattern: &str, host: &str) -> bool {
    let p = pattern.to_ascii_lowercase();
    let h = host.to_ascii_lowercase();
    if p == h || p == "*" {
        return true;
    }
    if let Some(suffix) = p.strip_prefix("*.") {
        if h == suffix {
            return true;
        }
        return h.ends_with(&format!(".{suffix}"));
    }
    if let Some(prefix) = p.strip_suffix(".*") {
        return h.starts_with(&format!("{prefix}."));
    }
    if p.contains('*') {
        return agent_protocol::glob_match::glob_match(&p, &h);
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_a_full_url() {
        let u = ParsedUrl::parse("https://user:pw@api.example.com:8443/v1/models?x=1#frag").unwrap();
        assert_eq!(u.scheme, "https");
        assert_eq!(u.host, "api.example.com");
        assert_eq!(u.port, 8443);
        assert!(!u.port_is_default);
        assert_eq!(u.path, "/v1/models");
        assert_eq!(u.query.as_deref(), Some("x=1"));
        assert_eq!(u.safe_user().as_deref(), Some("user:***"));
        assert_eq!(u.redacted(), "https://api.example.com:8443/v1/models?x=1");
        assert!(!u.redacted().contains("pw"));
    }

    #[test]
    fn applies_default_ports() {
        assert_eq!(ParsedUrl::parse("https://a.example/x").unwrap().port, 443);
        assert_eq!(ParsedUrl::parse("http://a.example/x").unwrap().port, 80);
        assert_eq!(ParsedUrl::parse("ssh://git@a.example").unwrap().port, 22);
        assert!(ParsedUrl::parse("https://a.example/x").unwrap().port_is_default);
    }

    #[test]
    fn parses_ipv6_literals() {
        let u = ParsedUrl::parse("http://[::1]:8080/health").unwrap();
        assert_eq!(u.host, "::1");
        assert_eq!(u.port, 8080);
        assert!(u.host_is_loopback());
    }

    #[test]
    fn rejects_bad_urls() {
        assert!(matches!(ParsedUrl::parse("api.example.com/v1"), Err(UrlError::NoScheme(_))));
        assert!(matches!(ParsedUrl::parse("file:///etc/passwd"), Err(UrlError::BadScheme(_))));
        assert!(matches!(ParsedUrl::parse("javascript:alert(1)"), Err(UrlError::BadScheme(_))));
        assert!(matches!(ParsedUrl::parse("https://"), Err(UrlError::NoHost(_))));
        assert!(matches!(ParsedUrl::parse("https://a.example:notaport/"), Err(UrlError::BadPort(_))));
    }

    #[test]
    fn default_policy_is_localhost_only() {
        let p = NetworkPolicy::default();
        assert_eq!(p.default, NetworkDefault::LocalhostOnly);
        assert!(p.check_url_str("http://127.0.0.1:3000/api").allows());
        assert!(p.check_url_str("http://localhost:8080/").allows());
        assert!(p.check_url_str("https://api.example.com/v1").denies());
        assert!(!p.check_url_str("https://api.example.com/v1").allows());
    }

    #[test]
    fn metadata_endpoint_is_always_denied_even_when_open() {
        let p = NetworkPolicy { default: NetworkDefault::Open, deny_ports: Vec::new(), ..Default::default() };
        for url in [
            "http://169.254.169.254/latest/meta-data/",
            "http://metadata.google.internal/computeMetadata/v1/",
        ] {
            let v = p.check_url_str(url);
            assert!(v.denies(), "{url} => {v:?}");
            assert!(v.reason().contains("metadata"), "{}", v.reason());
        }
        assert!(p.check_ip("169.254.169.254").denies());
    }

    #[test]
    fn private_ranges_are_blocked_by_default() {
        let p = NetworkPolicy { default: NetworkDefault::Open, deny_ports: Vec::new(), ..Default::default() };
        for h in ["10.1.2.3", "192.168.1.1", "172.16.0.5", "fd12::1", "fe80::1"] {
            assert!(p.check_ip(h).denies(), "{h}");
        }
        assert!(p.check_ip("8.8.8.8").allows());
    }

    #[test]
    fn an_allowlisted_host_does_not_unlock_a_private_ip() {
        let mut p = NetworkPolicy::default();
        p.default = NetworkDefault::Allowlisted;
        p.allow_hosts = vec!["*.example.com".into()];
        // The literal check passes on the name, but the post-DNS gate must not.
        assert_eq!(p.check_ip("10.0.0.9").reason().contains("private range"), true);
    }

    #[test]
    fn allow_hosts_glob_respects_dot_boundaries() {
        assert!(host_glob("*.example.com", "api.example.com"));
        assert!(host_glob("*.example.com", "example.com"));
        assert!(host_glob("*.example.com", "deep.api.example.com"));
        assert!(!host_glob("*.example.com", "evil-example.com"));
        assert!(!host_glob("*.example.com", "example.com.evil.net"));
        assert!(host_glob("api.*", "api.example.com"));
        assert!(host_glob("*", "anything"));
        assert!(host_glob("exact.test", "exact.test"));
        assert!(!host_glob("exact.test", "EXACT.TEST2"));
    }

    #[test]
    fn deny_hosts_beats_allow_hosts() {
        let p = NetworkPolicy {
            default: NetworkDefault::Open,
            allow_hosts: vec!["*.example.com".into()],
            deny_hosts: vec!["secret.example.com".into()],
            deny_ports: Vec::new(),
            ..Default::default()
        };
        assert!(p.check_url_str("https://api.example.com/").allows());
        assert!(p.check_url_str("https://secret.example.com/").denies());
    }

    #[test]
    fn ports_are_enforced() {
        let p = NetworkPolicy::localhost_dev();
        assert!(p.check_url_str("http://127.0.0.1:3000/").allows());
        assert!(p.check_url_str("http://127.0.0.1:22/").allows(), "deny_ports is empty in the dev profile");

        let strict = NetworkPolicy::default();
        // Loopback is allowed but port 22 is in the default deny list.
        assert!(strict.check_url_str("http://127.0.0.1:22/").denies());
        assert!(strict.check_url_str("http://127.0.0.1:3000/").allows());
    }

    #[test]
    fn allow_ports_narrows_further_and_asks_outside() {
        let p = NetworkPolicy {
            default: NetworkDefault::Open,
            allow_ports: vec![PortRange::one(443)],
            deny_ports: Vec::new(),
            ..Default::default()
        };
        assert!(p.check_url_str("https://example.com/").allows());
        assert!(p.check_url_str("https://example.com:8443/").allows() == false);
        match p.check_url_str("https://example.com:8443/") {
            NetworkVerdict::Ask { reason } => assert!(reason.contains("8443"), "{reason}"),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn plaintext_http_to_a_public_host_asks() {
        let p = NetworkPolicy { default: NetworkDefault::Open, deny_ports: Vec::new(), ..Default::default() };
        match p.check_url_str("http://example.com/x") {
            NetworkVerdict::Ask { reason } => assert!(reason.contains("plaintext"), "{reason}"),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn require_tls_blocks_other_schemes() {
        let p = NetworkPolicy::default();
        assert!(p.check_url_str("ssh://git@github.com/x/y.git").denies());
        let relaxed = NetworkPolicy { require_tls: false, default: NetworkDefault::Open, deny_ports: Vec::new(), ..Default::default() };
        assert!(relaxed.check_url_str("ssh://git@github.com/x/y.git").allows());
    }

    #[test]
    fn malformed_urls_are_denied_not_crashed() {
        let p = NetworkPolicy::default();
        for bad in ["", "   ", "not a url", "://x", "https://", "ftp://a:b@:99999/"] {
            assert!(p.check_url_str(bad).denies(), "{bad:?}");
        }
    }

    #[test]
    fn ip_classification_covers_the_ranges() {
        assert_eq!(classify_ip("127.0.0.1"), IpClass::Loopback);
        assert_eq!(classify_ip("localhost"), IpClass::Loopback);
        assert_eq!(classify_ip("::1"), IpClass::Loopback);
        assert_eq!(classify_ip("10.0.0.1"), IpClass::Private);
        assert_eq!(classify_ip("172.31.255.255"), IpClass::Private);
        assert_eq!(classify_ip("172.32.0.1"), IpClass::Public);
        assert_eq!(classify_ip("192.168.0.1"), IpClass::Private);
        assert_eq!(classify_ip("169.254.1.1"), IpClass::LinkLocal);
        assert_eq!(classify_ip("169.254.169.254"), IpClass::CloudMetadata);
        assert_eq!(classify_ip("8.8.8.8"), IpClass::Public);
        assert_eq!(classify_ip("[fd00::1]"), IpClass::Private);
        assert_eq!(classify_ip("fe80::1"), IpClass::LinkLocal);
        assert_eq!(classify_ip("example.com"), IpClass::NotAnIp);
    }

    #[test]
    fn network_default_parses_from_config_text() {
        assert_eq!("localhost-only".parse::<NetworkDefault>().unwrap(), NetworkDefault::LocalhostOnly);
        assert_eq!("allowlisted".parse::<NetworkDefault>().unwrap(), NetworkDefault::Allowlisted);
        assert_eq!("open".parse::<NetworkDefault>().unwrap(), NetworkDefault::Open);
        assert!("yolo".parse::<NetworkDefault>().is_err());
        assert_eq!(NetworkDefault::LocalhostOnly.as_str(), "localhost-only");
    }

    #[test]
    fn port_ranges_normalise_backwards_input() {
        assert!(PortRange::span(9000, 3000).contains(5000));
        assert!(PortRange::one(443).contains(443));
        assert!(!PortRange::one(443).contains(444));
    }

    #[test]
    fn policy_round_trips_through_json() {
        let p = NetworkPolicy::localhost_dev();
        let json = serde_json::to_string(&p).unwrap();
        let back: NetworkPolicy = serde_json::from_str(&json).unwrap();
        assert_eq!(back, p);
        // Defaults must be applied when keys are absent (safe-by-default).
        let sparse: NetworkPolicy = serde_json::from_str("{}").unwrap();
        assert_eq!(sparse.default, NetworkDefault::LocalhostOnly);
        assert!(sparse.block_private_ranges);
        assert!(sparse.require_tls);
        assert_eq!(sparse.max_redirects, 5);
    }

    #[test]
    fn verdicts_serialise_with_a_tag() {
        let v = NetworkVerdict::Deny { reason: "nope".into() };
        assert_eq!(serde_json::to_value(&v).unwrap()["verdict"], "deny");
        assert_eq!(v.reason(), "nope");
    }

    #[test]
    fn redirect_budget_is_configurable() {
        assert_eq!(NetworkPolicy::default().max_redirects, 5);
        assert_eq!(NetworkPolicy::default().max_response_bytes, 16 * 1024 * 1024);
        assert_eq!(NetworkPolicy::default().timeout_ms, 30_000);
    }
}

// ---------------------------------------------------------------------------
// DNS rebinding guard + proxy configuration (§9.5 network.rs acceptance)
// ---------------------------------------------------------------------------

/// A pinned resolution.
///
/// The rebinding attack is: resolve `evil.example` to a public IP (passes the
/// policy check), then, on the second lookup the client performs, return
/// `127.0.0.1`. The defence is to resolve **once**, check the addresses, and
/// then connect to the *pinned* address — never to the name again.
///
/// [`DnsGuard`] is that pin store. It is deliberately tiny and synchronous: the
/// resolver hook in `sandbox` calls [`DnsGuard::pin`] with the addresses it got
/// and receives back either a pinned address it is allowed to connect to, or a
/// refusal.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DnsGuard {
    /// Pinned host → addresses, with the time they were pinned.
    pins: BTreeMap<String, Pin>,
    /// How long a pin is honoured, ms. Longer than a request, shorter than a
    /// session: a stale pin is a correctness bug, not a safety bug.
    pub ttl_ms: u64,
    /// Refusals, for `network_rebinding_blocked_total`.
    pub blocked: u64,
}

/// One host's pin.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
struct Pin {
    addresses: Vec<String>,
    pinned_at_ms: u64,
}

/// Why a connection was refused at the resolver.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RebindVerdict {
    /// Connect to this address.
    Connect {
        /// The pinned address.
        address: String,
        /// True when the address differs from what the name resolved to on a
        /// later lookup — i.e. a rebinding attempt was caught.
        rebound: bool,
    },
    /// Refuse.
    Refuse {
        /// Why.
        reason: String,
    },
}

impl Default for DnsGuard {
    fn default() -> Self {
        Self { pins: BTreeMap::new(), ttl_ms: 30_000, blocked: 0 }
    }
}

impl DnsGuard {
    /// An empty guard.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Record the addresses a name resolved to, after the policy checked them.
    ///
    /// Returns `false` when any address fails [`NetworkPolicy::check_ip`], in
    /// which case nothing is pinned — a partially-safe resolution is not safe.
    pub fn pin(&mut self, host: &str, addresses: &[String], policy: &NetworkPolicy, now_ms: u64) -> bool {
        let key = host.to_ascii_lowercase();
        if addresses.is_empty() {
            return false;
        }
        for a in addresses {
            if policy.check_ip(a).denies() {
                self.blocked += 1;
                return false;
            }
        }
        self.pins.insert(key, Pin { addresses: addresses.to_vec(), pinned_at_ms: now_ms });
        self.pins.retain(|_, p| now_ms.saturating_sub(p.pinned_at_ms) <= self.ttl_ms);
        true
    }

    /// Ask whether connecting to `address` for `host` is allowed.
    ///
    /// The answer is `Connect` only when the address was pinned and the pin has
    /// not expired. A name that resolves to something new is refused — that is
    /// the rebinding case.
    pub fn check(&mut self, host: &str, address: &str, policy: &NetworkPolicy, now_ms: u64) -> RebindVerdict {
        let key = host.to_ascii_lowercase();
        let expired = self
            .pins
            .get(&key)
            .is_some_and(|p| now_ms.saturating_sub(p.pinned_at_ms) > self.ttl_ms);
        if expired {
            self.pins.remove(&key);
        }
        match self.pins.get(&key) {
            Some(p) if p.addresses.iter().any(|a| a == address) => {
                RebindVerdict::Connect { address: address.to_string(), rebound: false }
            }
            Some(_) => {
                self.blocked += 1;
                RebindVerdict::Refuse {
                    reason: format!(
                        "{host} resolved to {address}, which is not the pinned address — DNS rebinding suspected"
                    ),
                }
            }
            None => {
                // Never pinned: check the literal, and refuse private/link-local
                // regardless of what the policy default says, because an
                // unpinned connect means the check happened on the name, not the
                // address.
                if let Some(v) = self.unpinned_refusal(address, policy) {
                    self.blocked += 1;
                    return v;
                }
                RebindVerdict::Connect { address: address.to_string(), rebound: true }
            }
        }
    }

    fn unpinned_refusal(&self, address: &str, policy: &NetworkPolicy) -> Option<RebindVerdict> {
        match classify_ip(address) {
            IpClass::CloudMetadata => Some(RebindVerdict::Refuse {
                reason: format!("{address} is a cloud metadata endpoint"),
            }),
            IpClass::LinkLocal if policy.block_link_local => Some(RebindVerdict::Refuse {
                reason: format!("{address} is link-local"),
            }),
            IpClass::Private if policy.block_private_ranges => Some(RebindVerdict::Refuse {
                reason: format!("{address} is in a private range and was never pinned by a policy-checked lookup"),
            }),
            IpClass::Loopback | IpClass::Public | IpClass::NotAnIp | IpClass::Private | IpClass::LinkLocal => None,
        }
    }

    /// Number of live pins.
    #[must_use]
    pub fn len(&self) -> usize {
        self.pins.len()
    }

    /// True when nothing is pinned.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.pins.is_empty()
    }

    /// Drop every pin (called on session end).
    pub fn clear(&mut self) {
        self.pins.clear();
    }
}

/// Proxy environment for the sandboxed child process.
///
/// The sandbox routes egress through a local filtering proxy; the child gets
/// `http_proxy`/`https_proxy` pointing at it and `no_proxy` covering loopback so
/// dev servers keep working. Generating this in one place means the child can
/// never be given a proxy that disagrees with [`NetworkPolicy`].
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProxyConfig {
    /// Proxy URL, e.g. `http://127.0.0.1:8788`.
    pub url: String,
    /// Hosts that bypass the proxy.
    pub no_proxy: Vec<String>,
    /// Maximum body bytes the proxy will relay.
    pub max_response_bytes: u64,
    /// Redirect budget the proxy enforces.
    pub max_redirects: u8,
    /// Allowlisted hosts, empty when the policy is `open`.
    pub allow_hosts: Vec<String>,
    /// Denied hosts.
    pub deny_hosts: Vec<String>,
}

impl ProxyConfig {
    /// Derive proxy config from a policy and a local proxy address.
    #[must_use]
    pub fn from_policy(policy: &NetworkPolicy, proxy_addr: &str) -> Self {
        Self {
            url: format!("http://{proxy_addr}"),
            no_proxy: vec![
                "localhost".into(),
                "127.0.0.1".into(),
                "::1".into(),
                ".svc".into(),
                ".cluster.local".into(),
            ],
            max_response_bytes: policy.max_response_bytes,
            max_redirects: policy.max_redirects,
            allow_hosts: policy.allow_hosts.clone(),
            deny_hosts: policy.deny_hosts.clone(),
        }
    }

    /// Environment variables for the child process.
    #[must_use]
    pub fn env(&self) -> Vec<(String, String)> {
        let no = self.no_proxy.join(",");
        vec![
            ("HTTP_PROXY".into(), self.url.clone()),
            ("HTTPS_PROXY".into(), self.url.clone()),
            ("http_proxy".into(), self.url.clone()),
            ("https_proxy".into(), self.url.clone()),
            ("NO_PROXY".into(), no.clone()),
            ("no_proxy".into(), no),
        ]
    }

    /// A PAC (proxy auto-config) script implementing the same policy, for tools
    /// that honour PAC but not `http_proxy`.
    #[must_use]
    pub fn to_pac(&self) -> String {
        let mut allow = String::new();
        for h in &self.allow_hosts {
            allow.push_str(&format!(
                "  if (shExpMatch(host, \"{h}\")) return \"PROXY {proxy}\";\n",
                proxy = self.url.trim_start_matches("http://")
            ));
        }
        let mut deny = String::new();
        for h in &self.deny_hosts {
            deny.push_str(&format!("  if (shExpMatch(host, \"{h}\")) return \"DIRECT\";\n"));
        }
        format!(
            "function FindProxyForURL(url, host) {{\n{deny}{allow}  if (isPlainHostName(host)) return \"DIRECT\";\n  if (shExpMatch(host, \"localhost\")) return \"DIRECT\";\n  if (isInNet(dnsResolve(host), \"127.0.0.0\", \"255.0.0.0\")) return \"DIRECT\";\n  return \"PROXY {proxy}\";\n}}\n",
            proxy = self.url.trim_start_matches("http://")
        )
    }
}

#[cfg(test)]
mod guard_tests {
    use super::*;

    fn policy() -> NetworkPolicy {
        NetworkPolicy { default: NetworkDefault::Allowlisted, allow_hosts: vec!["api.example.com".into()], deny_ports: Vec::new(), ..Default::default() }
    }

    #[test]
    fn pinning_a_checked_resolution_allows_the_connect() {
        let mut g = DnsGuard::new();
        assert!(g.pin("api.example.com", &["93.184.216.34".into()], &policy(), 1000));
        match g.check("api.example.com", "93.184.216.34", &policy(), 1500) {
            RebindVerdict::Connect { address, rebound } => {
                assert_eq!(address, "93.184.216.34");
                assert!(!rebound);
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn pinning_refuses_when_any_address_is_private() {
        let mut g = DnsGuard::new();
        assert!(!g.pin("api.example.com", &["93.184.216.34".into(), "10.0.0.1".into()], &policy(), 1000));
        assert!(g.is_empty(), "a partially-safe resolution must not be pinned at all");
        assert_eq!(g.blocked, 1);
    }

    #[test]
    fn a_second_different_address_is_treated_as_rebinding() {
        let mut g = DnsGuard::new();
        g.pin("api.example.com", &["93.184.216.34".into()], &policy(), 1000);
        match g.check("api.example.com", "127.0.0.1", &policy(), 1100) {
            RebindVerdict::Refuse { reason } => assert!(reason.contains("rebinding"), "{reason}"),
            other => panic!("{other:?}"),
        }
        assert_eq!(g.blocked, 1);
    }

    #[test]
    fn pins_expire() {
        let mut g = DnsGuard::new();
        g.ttl_ms = 100;
        g.pin("api.example.com", &["93.184.216.34".into()], &policy(), 1000);
        // Expired pin: the address is public, so the connect is allowed but is
        // flagged as needing a fresh, policy-checked lookup.
        match g.check("api.example.com", "93.184.216.34", &policy(), 2000) {
            RebindVerdict::Connect { rebound, .. } => assert!(rebound),
            other => panic!("{other:?}"),
        }
        assert!(g.is_empty(), "the expired pin must be dropped");
    }

    #[test]
    fn an_unpinned_private_address_is_refused() {
        let mut g = DnsGuard::new();
        for addr in ["10.1.2.3", "192.168.0.1", "169.254.169.254", "127.0.0.1"] {
            let v = g.check("anything.example", addr, &policy(), 1);
            assert!(matches!(v, RebindVerdict::Refuse { .. }), "{addr} => {v:?}");
        }
    }

    #[test]
    fn an_unpinned_public_address_is_allowed_but_flagged() {
        let mut g = DnsGuard::new();
        match g.check("anything.example", "8.8.8.8", &policy(), 1) {
            RebindVerdict::Connect { rebound, .. } => assert!(rebound),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn clear_drops_every_pin() {
        let mut g = DnsGuard::new();
        g.pin("a.example", &["8.8.8.8".into()], &policy(), 1);
        g.pin("b.example", &["8.8.4.4".into()], &policy(), 1);
        assert_eq!(g.len(), 2);
        g.clear();
        assert!(g.is_empty());
    }

    #[test]
    fn proxy_config_derives_from_the_policy() {
        let p = policy();
        let c = ProxyConfig::from_policy(&p, "127.0.0.1:8788");
        assert_eq!(c.url, "http://127.0.0.1:8788");
        assert_eq!(c.allow_hosts, vec!["api.example.com".to_string()]);
        assert_eq!(c.max_redirects, p.max_redirects);
        let env = c.env();
        assert!(env.iter().any(|(k, v)| k == "HTTPS_PROXY" && v == "http://127.0.0.1:8788"));
        assert!(env.iter().any(|(k, v)| k == "no_proxy" && v.contains("localhost")));
    }

    #[test]
    fn the_pac_script_encodes_the_same_policy() {
        let c = ProxyConfig::from_policy(&policy(), "127.0.0.1:8788");
        let pac = c.to_pac();
        assert!(pac.starts_with("function FindProxyForURL(url, host) {"), "{pac}");
        assert!(pac.contains("shExpMatch(host, \"api.example.com\")"), "{pac}");
        assert!(pac.contains("PROXY 127.0.0.1:8788"), "{pac}");
        assert!(pac.contains("isPlainHostName"), "{pac}");
    }

    #[test]
    fn guard_round_trips_through_json() {
        let mut g = DnsGuard::new();
        g.pin("a.example", &["8.8.8.8".into()], &policy(), 1);
        let json = serde_json::to_string(&g).unwrap();
        let back: DnsGuard = serde_json::from_str(&json).unwrap();
        assert_eq!(back, g);
    }
}
