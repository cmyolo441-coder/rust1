//! Incident reports (`rustplan.txt` §6.4, §9.5 `src/incident.rs`).
//!
//! When something goes wrong — a sandbox violation, a deny storm, a secret that
//! almost left the building — support needs one artefact that answers *who,
//! what, when, under which policy, and prove it*. This module builds that
//! artefact from the audit chain.
//!
//! Properties that matter:
//!
//! * **Self-proving.** The report embeds the chain anchor (`count` + `root_hash`)
//!   so a reader can verify the excerpt was not cherry-picked from a longer log.
//! * **Redacted.** Secrets in argv, env dumps and tool output are masked before
//!   the report is written; the fingerprint stays so two findings can be tied to
//!   the same credential.
//! * **Deterministic.** Same records in → same report out, byte for byte, so a
//!   report can be diffed against a reproduction.

use std::collections::BTreeMap;
use std::path::Path;

use serde::{Deserialize, Serialize};

use agent_protocol::ids::{ThreadId, TurnId};

use crate::attribution::Attribution;
use crate::audit::{Actor, Anchor, AuditAction, AuditRecord, Outcome};
use crate::engine::PolicySnapshot;
use crate::redaction::{RedactionConfig, Redactor};

/// How bad the incident is. Drives routing, not just colour.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Severity {
    /// Informational; nothing was refused.
    Info,
    /// A control fired but nothing dangerous happened.
    Low,
    /// A control fired repeatedly, or once on something sensitive.
    Medium,
    /// An actual boundary was crossed or attempted with force.
    High,
    /// Credential exposure, sandbox escape attempt, or destructive action.
    Critical,
}

impl Severity {
    /// Stable label.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::Info => "info",
            Self::Low => "low",
            Self::Medium => "medium",
            Self::High => "high",
            Self::Critical => "critical",
        }
    }

    /// RFC5424 severity (0=emerg … 7=debug), for syslog export.
    #[must_use]
    pub const fn syslog(&self) -> u8 {
        match self {
            Self::Info => 6,
            Self::Low => 6,
            Self::Medium => 4,
            Self::High => 3,
            Self::Critical => 2,
        }
    }
}

/// One thing worth reporting.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Finding {
    /// Stable finding code, e.g. `sandbox_violation`.
    pub code: String,
    /// Severity of this finding.
    pub severity: Severity,
    /// One-sentence statement of fact.
    pub statement: String,
    /// How many times it happened.
    pub count: usize,
    /// Audit record ids that evidence it.
    pub evidence: Vec<String>,
    /// Suggested remediation.
    pub recommendation: String,
}

/// A timeline entry.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TimelineEntry {
    /// ms since epoch.
    pub ts_ms: u64,
    /// Actor label.
    pub actor: String,
    /// Action.
    pub action: AuditAction,
    /// Outcome.
    pub outcome: Outcome,
    /// Short human description, redacted.
    pub text: String,
    /// Audit record id.
    pub record_id: String,
}

/// The report itself.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct IncidentReport {
    /// `inc_` + ULID.
    pub id: String,
    /// Generation time.
    pub generated_at_ms: u64,
    /// Overall severity: the max over findings.
    pub severity: Severity,
    /// One-line title.
    pub title: String,
    /// Paragraph summary.
    pub summary: String,
    /// Thread under investigation.
    pub thread_id: ThreadId,
    /// Turn, when the incident is turn-scoped.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Who/what was responsible.
    pub attribution: Attribution,
    /// Ordered findings.
    pub findings: Vec<Finding>,
    /// Ordered timeline.
    pub timeline: Vec<TimelineEntry>,
    /// Policy in force at generation time.
    pub policy: PolicySnapshot,
    /// Chain anchor proving the excerpt's position in the log.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub chain_anchor: Option<Anchor>,
    /// Record ids included, so a reader can re-fetch them.
    pub record_ids: Vec<String>,
    /// Agent build version.
    pub agent_version: String,
    /// Redaction config used, so a reader knows what was masked.
    pub redaction: String,
}

/// Which records go into a report.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct IncidentFilter {
    /// Only this thread.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub thread_id: Option<ThreadId>,
    /// Only this turn.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Only these actions. Empty = all.
    #[serde(default)]
    pub actions: Vec<AuditAction>,
    /// Start of the window, inclusive.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub since_ms: Option<u64>,
    /// End of the window, inclusive.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub until_ms: Option<u64>,
    /// Only compliance-relevant actions.
    #[serde(default)]
    pub compliance_only: bool,
    /// Only records with a non-`Allowed` outcome.
    #[serde(default)]
    pub failures_only: bool,
}

impl IncidentFilter {
    /// True when a record passes.
    #[must_use]
    pub fn matches(&self, r: &AuditRecord) -> bool {
        if let Some(t) = &self.thread_id {
            if &r.thread_id != t {
                return false;
            }
        }
        if let Some(t) = &self.turn_id {
            if r.turn_id.as_ref() != Some(t) {
                return false;
            }
        }
        if !self.actions.is_empty() && !self.actions.contains(&r.action) {
            return false;
        }
        if let Some(s) = self.since_ms {
            if r.ts_ms < s {
                return false;
            }
        }
        if let Some(u) = self.until_ms {
            if r.ts_ms > u {
                return false;
            }
        }
        if self.compliance_only && !r.action.is_compliance_relevant() {
            return false;
        }
        if self.failures_only && matches!(r.outcome, Outcome::Allowed | Outcome::Info) {
            return false;
        }
        true
    }
}

/// Build a report from audit records.
///
/// # Panics
/// Never.
#[must_use]
pub fn build(
    records: &[AuditRecord],
    filter: &IncidentFilter,
    policy: PolicySnapshot,
    attribution: Attribution,
    anchor: Option<Anchor>,
) -> IncidentReport {
    let redactor = Redactor::new(RedactionConfig::for_model());
    let selected: Vec<&AuditRecord> = records.iter().filter(|r| filter.matches(r)).collect();

    let timeline: Vec<TimelineEntry> = selected
        .iter()
        .map(|r| TimelineEntry {
            ts_ms: r.ts_ms,
            actor: r.actor.label(),
            action: r.action,
            outcome: r.outcome,
            text: redactor.redact_str(&describe(r)),
            record_id: r.id.clone(),
        })
        .collect();

    let findings = analyse(&selected, &redactor);
    let severity = findings.iter().map(|f| f.severity).max().unwrap_or(Severity::Info);
    let counts = count_by_action(&selected);
    let title = format!(
        "{}: {} record(s), {} finding(s)",
        severity.as_str().to_uppercase(),
        selected.len(),
        findings.len()
    );
    let summary = summarise(&selected, &counts, &findings, severity);

    IncidentReport {
        id: format!("inc_{}", ulid::Ulid::new()),
        generated_at_ms: agent_protocol::now_ms(),
        severity,
        title,
        summary,
        thread_id: attribution.thread_id,
        turn_id: attribution.turn_id,
        attribution,
        findings,
        timeline,
        policy,
        chain_anchor: anchor,
        record_ids: selected.iter().map(|r| r.id.clone()).collect(),
        agent_version: agent_protocol::BUILD_VERSION.to_string(),
        redaction: format!(
            "enabled, entropy threshold {}, min token {}, fingerprint on",
            redactor.config().entropy_threshold,
            redactor.config().min_entropy_token
        ),
    }
}

/// Markdown rendering — what actually gets pasted into a ticket.
#[must_use]
pub fn to_markdown(r: &IncidentReport) -> String {
    let mut out = String::with_capacity(4096);
    out.push_str(&format!("# Incident {} — {}\n\n", r.id, r.severity.as_str().to_uppercase()));
    out.push_str(&format!("**{}**\n\n{}\n\n", r.title, r.summary));
    out.push_str("## Attribution\n\n");
    out.push_str(&format!("- actor: `{}`\n", r.attribution.label()));
    out.push_str(&format!("- thread: `{}`\n", r.attribution.thread_id));
    if let Some(t) = r.attribution.turn_id {
        out.push_str(&format!("- turn: `{t}`\n"));
    }
    if let Some(m) = &r.attribution.model {
        out.push_str(&format!("- model: `{m}`\n"));
    }
    if let Some(w) = &r.attribution.worker_id {
        out.push_str(&format!("- worker: `{w}`\n"));
    }
    if let Some(f) = &r.attribution.prompt_fingerprint {
        out.push_str(&format!("- prompt fingerprint: `{f}`\n"));
    }
    out.push_str(&format!("- agent version: `{}`\n\n", r.agent_version));

    out.push_str("## Findings\n\n");
    if r.findings.is_empty() {
        out.push_str("_None. Every evaluated action was permitted._\n\n");
    } else {
        for f in &r.findings {
            out.push_str(&format!("### `{}` — {}\n\n", f.code, f.severity.as_str()));
            out.push_str(&format!("{}\n\n", f.statement));
            out.push_str(&format!("- occurrences: {}\n", f.count));
            out.push_str(&format!("- evidence: {}\n", f.evidence.iter().map(|e| format!("`{e}`")).collect::<Vec<_>>().join(", ")));
            out.push_str(&format!("- recommendation: {}\n\n", f.recommendation));
        }
    }

    out.push_str("## Policy in force\n\n");
    out.push_str(&format!("- mode: `{}`\n", r.policy.mode));
    out.push_str("- rules (evaluation order):\n");
    for (effect, pattern, managed) in &r.policy.rules {
        out.push_str(&format!("  - {} `{}`{}\n", effect, pattern, if *managed { " _(managed)_" } else { "" }));
    }
    if !r.policy.grants.is_empty() {
        out.push_str("- session grants:\n");
        for g in &r.policy.grants {
            out.push_str(&format!("  - `{}` by {} ({:?})\n", g.pattern, g.granted_by, g.scope));
        }
    }
    out.push('\n');

    out.push_str("## Timeline\n\n");
    out.push_str("| time (UTC) | actor | action | outcome | detail |\n|---|---|---|---|---|\n");
    for t in &r.timeline {
        out.push_str(&format!(
            "| {} | {} | {} | {:?} | {} |\n",
            agent_protocol::iso_from_ms(t.ts_ms),
            t.actor,
            t.action.as_str(),
            t.outcome,
            t.text.replace('|', "\\|").replace('\n', " ")
        ));
    }
    out.push('\n');

    out.push_str("## Verification\n\n");
    match &r.chain_anchor {
        Some(a) => {
            out.push_str(&format!(
                "- chain anchor: count **{}**, root `{}` at index {}\n",
                a.count, a.root_hash, a.index
            ));
            out.push_str("- verify with `agent audit verify` and compare the count and root above.\n");
        }
        None => out.push_str("- no chain anchor: this report was built from an in-memory log.\n"),
    }
    out.push_str(&format!("- records included: {}\n", r.record_ids.len()));
    out.push_str(&format!("- redaction: {}\n", r.redaction));
    out
}

fn describe(r: &AuditRecord) -> String {
    let mut parts: Vec<String> = Vec::new();
    for k in ["tool", "command", "path", "host", "url", "reason", "mode", "pattern", "syscall"] {
        if let Some(v) = r.detail.get(k) {
            parts.push(format!("{k}={v}"));
        }
    }
    if let Some(p) = &r.policy_ref {
        parts.push(format!("policy={p}"));
    }
    if parts.is_empty() {
        // Fall back to the whole detail map, sorted, so output is stable.
        for (k, v) in &r.detail {
            parts.push(format!("{k}={v}"));
        }
    }
    format!("{} {}", r.action.as_str(), parts.join(" "))
}

fn count_by_action(records: &[&AuditRecord]) -> BTreeMap<AuditAction, usize> {
    let mut m = BTreeMap::new();
    for r in records {
        *m.entry(r.action).or_insert(0) += 1;
    }
    m
}

/// Turn a set of records into findings. Each rule below corresponds to something
/// a security reviewer actually asks about.
fn analyse(records: &[&AuditRecord], redactor: &Redactor) -> Vec<Finding> {
    let mut out = Vec::new();

    #[inline]
    fn push(
        out: &mut Vec<Finding>,
        redactor: &Redactor,
        code: &'static str,
        severity: Severity,
        statement: String,
        recommendation: &str,
        matching: &[&AuditRecord],
    ) {
        if matching.is_empty() {
            return;
        }
        out.push(Finding {
            code: code.to_string(),
            severity,
            statement: redactor.redact_str(&statement),
            count: matching.len(),
            evidence: matching.iter().take(10).map(|r| r.id.clone()).collect(),
            recommendation: recommendation.to_string(),
        });
    }

    let select = |a: AuditAction| -> Vec<&AuditRecord> {
        records.iter().copied().filter(|r| r.action == a).collect()
    };

    let sandbox = select(AuditAction::SandboxViolation);
    push(
        &mut out,
        redactor,
        "sandbox_violation",
        Severity::Critical,
        format!("{} sandbox violation(s): the kernel refused an operation the agent attempted", sandbox.len()),
        "Inspect the syscall/path in the timeline. If it is legitimate, widen the sandbox profile deliberately and record why; if not, treat it as an attempted escape.",
        &sandbox,
    );

    let net = select(AuditAction::NetworkBlocked);
    push(
        &mut out,
        redactor,
        "network_blocked",
        Severity::High,
        format!("{} blocked egress attempt(s)", net.len()),
        "Check the destination. Link-local or private ranges usually mean SSRF; a public host may just need an allowlist entry.",
        &net,
    );

    let secrets = select(AuditAction::SecretRedacted);
    push(
        &mut out,
        redactor,
        "secret_redacted",
        if secrets.len() > 3 { Severity::High } else { Severity::Medium },
        format!("{} secret(s) were redacted before leaving the process", secrets.len()),
        "Rotate anything whose fingerprint appears more than once, and find out why the value is reachable from the workspace.",
        &secrets,
    );

    let denied = select(AuditAction::ToolDenied);
    push(
        &mut out,
        redactor,
        "tool_denied",
        if denied.len() >= 5 { Severity::Medium } else { Severity::Low },
        format!("{} tool call(s) were denied by policy", denied.len()),
        "If the model retried the same denied call repeatedly, the prompt needs a stronger hint; if the rule is wrong, fix the rule, not the model.",
        &denied,
    );

    let refused = select(AuditAction::ToolRefused);
    push(
        &mut out,
        redactor,
        "tool_refused_by_human",
        Severity::Medium,
        format!("{} call(s) were refused at an approval prompt", refused.len()),
        "A human looked at the exact argv and said no. Read the timeline entry before adjusting any rule.",
        &refused,
    );

    let pushes = select(AuditAction::PushAttempted);
    push(
        &mut out,
        redactor,
        "push_attempted",
        Severity::High,
        format!("{} attempt(s) to publish commits to a remote", pushes.len()),
        "Push is never automatic (§7). Confirm a human initiated each one.",
        &pushes,
    );

    let grants = select(AuditAction::GrantRemembered);
    push(
        &mut out,
        redactor,
        "grant_remembered",
        if grants.len() >= 5 { Severity::Medium } else { Severity::Low },
        format!("{} approval(s) were remembered for the session", grants.len()),
        "Long-lived grants widen the blast radius of later turns. Revoke anything no longer needed with `agent policy revoke`.",
        &grants,
    );

    let modes = select(AuditAction::ModeChanged);
    push(
        &mut out,
        redactor,
        "mode_changed",
        Severity::Low,
        format!("{} permission-mode change(s) during the session", modes.len()),
        "Escalations should be rare and deliberate; a session that climbs to auto-edit or bypass deserves a second look.",
        &modes,
    );

    let managed = select(AuditAction::ManagedPolicyApplied);
    push(
        &mut out,
        redactor,
        "managed_policy_applied",
        Severity::Info,
        format!("managed policy was applied {} time(s)", managed.len()),
        "Informational: enterprise constraints were in force for this session.",
        &managed,
    );

    let failed = records
        .iter()
        .copied()
        .filter(|r| r.outcome == Outcome::Failed)
        .collect::<Vec<_>>();
    push(
        &mut out,
        redactor,
        "tool_failed",
        Severity::Low,
        format!("{} permitted call(s) failed after execution", failed.len()),
        "Failures after approval usually mean a wrong path or a missing dependency, not a policy problem.",
        &failed,
    );

    // Repeated identical denials are their own signal: the model is looping.
    let mut by_reason: BTreeMap<String, usize> = BTreeMap::new();
    for r in records.iter().copied().filter(|r| r.action == AuditAction::ToolDenied) {
        let key = r.policy_ref.clone().unwrap_or_else(|| r.detail.get("tool").cloned().unwrap_or_default());
        *by_reason.entry(key).or_insert(0) += 1;
    }
    let loops: Vec<(String, usize)> = by_reason.into_iter().filter(|(_, n)| *n >= 3).collect();
    if !loops.is_empty() {
        let detail = loops
            .iter()
            .map(|(k, n)| format!("{n}× {k}"))
            .collect::<Vec<_>>()
            .join(", ");
        out.push(Finding {
            code: "denial_loop".to_string(),
            severity: Severity::Medium,
            statement: redactor.redact_str(&format!("the same call was denied repeatedly: {detail}")),
            count: loops.iter().map(|(_, n)| n).sum(),
            evidence: records
                .iter()
                .filter(|r| r.action == AuditAction::ToolDenied)
                .take(5)
                .map(|r| r.id.clone())
                .collect(),
            recommendation: "A model retrying a denied action burns budget. Add the reason to the tool result hint, or teach the plan stage that the action is unavailable.".into(),
        });
    }

    // A worker acting with no parent turn is an attribution gap.
    let orphan_workers: Vec<&AuditRecord> = records
        .iter()
        .copied()
        .filter(|r| matches!(r.actor, Actor::Worker { .. }) && r.turn_id.is_none())
        .collect();
    push(
        &mut out,
        redactor,
        "unattributed_worker",
        Severity::High,
        format!("{} action(s) by a worker could not be tied to a turn", orphan_workers.len()),
        "Attribution gaps break the audit story. This is a bug in the spawning path, not a user error — report it.",
        &orphan_workers,
    );

    out.sort_by(|a, b| b.severity.cmp(&a.severity).then_with(|| a.code.cmp(&b.code)));
    out
}

fn summarise(
    records: &[&AuditRecord],
    counts: &BTreeMap<AuditAction, usize>,
    findings: &[Finding],
    severity: Severity,
) -> String {
    let window = match (records.first(), records.last()) {
        (Some(a), Some(b)) if records.len() > 1 => {
            format!("{} → {}", agent_protocol::iso_from_ms(a.ts_ms), agent_protocol::iso_from_ms(b.ts_ms))
        }
        (Some(a), _) => agent_protocol::iso_from_ms(a.ts_ms),
        _ => "no records".to_string(),
    };
    let top = counts
        .iter()
        .map(|(a, n)| format!("{}={n}", a.as_str()))
        .collect::<Vec<_>>()
        .join(", ");
    let worst = findings.first().map(|f| f.code.as_str()).unwrap_or("none");
    format!(
        "{n} audited action(s) over {window}. Severity {sev} (worst finding: `{worst}`). Breakdown: {top}.",
        n = records.len(),
        sev = severity.as_str()
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::audit::{AuditBuilder, Outcome as O};
    use agent_protocol::permission::Mode;

    fn rec(action: AuditAction, outcome: O, detail: &[(&str, &str)], ts: u64) -> AuditRecord {
        let mut b = AuditBuilder::new(ThreadId::new(), Actor::Model { id: "gpt-5".into(), provider: "openai".into() }, action)
            .outcome(outcome)
            .at(ts);
        for (k, v) in detail {
            b = b.detail(*k, *v);
        }
        b.build(0, crate::audit::GENESIS_HASH)
    }

    fn snapshot() -> PolicySnapshot {
        PolicySnapshot { mode: Mode::Ask, rules: Vec::new(), grants: Vec::new() }
    }

    fn attribution() -> Attribution {
        Attribution::user("dev", ThreadId::new())
    }

    #[test]
    fn an_empty_log_produces_an_info_report() {
        let r = build(&[], &IncidentFilter::default(), snapshot(), attribution(), None);
        assert_eq!(r.severity, Severity::Info);
        assert!(r.findings.is_empty());
        assert!(r.summary.contains("0 audited action(s)"), "{}", r.summary);
        assert!(r.id.starts_with("inc_"));
    }

    #[test]
    fn a_sandbox_violation_is_critical() {
        let records = vec![rec(
            AuditAction::SandboxViolation,
            O::Denied,
            &[("syscall", "ptrace"), ("path", "/proc/1/mem")],
            1_000,
        )];
        let r = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        assert_eq!(r.severity, Severity::Critical);
        assert_eq!(r.findings[0].code, "sandbox_violation");
        assert_eq!(r.findings[0].count, 1);
        assert_eq!(r.findings[0].evidence, vec![records[0].id.clone()]);
    }

    #[test]
    fn findings_are_sorted_by_severity() {
        let records = vec![
            rec(AuditAction::ToolDenied, O::Denied, &[("tool", "shell")], 1),
            rec(AuditAction::NetworkBlocked, O::Denied, &[("host", "10.0.0.1")], 2),
            rec(AuditAction::SandboxViolation, O::Denied, &[("syscall", "mount")], 3),
        ];
        let r = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        let sevs: Vec<Severity> = r.findings.iter().map(|f| f.severity).collect();
        assert!(sevs.windows(2).all(|w| w[0] >= w[1]), "{sevs:?}");
        assert_eq!(r.findings[0].code, "sandbox_violation");
    }

    #[test]
    fn a_denial_loop_is_its_own_finding() {
        let records: Vec<AuditRecord> = (0..4u64)
            .map(|i| {
                let mut r = rec(AuditAction::ToolDenied, O::Denied, &[("tool", "shell")], i);
                r.policy_ref = Some("shell(rm -rf **)".into());
                r
            })
            .collect();
        let r = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        let f = r.findings.iter().find(|f| f.code == "denial_loop").expect("loop finding");
        assert_eq!(f.count, 4);
        assert!(f.statement.contains("4×"), "{}", f.statement);
    }

    #[test]
    fn secrets_in_details_are_redacted_in_the_report() {
        let records = vec![rec(
            AuditAction::ToolDenied,
            O::Denied,
            &[("command", "aws --secret-access-key AKIAIOSFODNN7EXAMPLE s3 ls")],
            1,
        )];
        let r = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        let md = to_markdown(&r);
        assert!(!md.contains("AKIAIOSFODNN7EXAMPLE"), "{md}");
        assert!(md.contains("[redacted:"), "{md}");
        assert!(r.timeline[0].text.contains("[redacted:"), "{}", r.timeline[0].text);
    }

    #[test]
    fn an_unattributed_worker_action_is_flagged() {
        let mut r = rec(AuditAction::ToolInvoked, O::Allowed, &[("tool", "read_file")], 1);
        r.actor = Actor::Worker { id: "wkr_1".into(), parent_thread: "thr_x".into() };
        r.turn_id = None;
        let report = build(&[r], &IncidentFilter::default(), snapshot(), attribution(), None);
        assert!(report.findings.iter().any(|f| f.code == "unattributed_worker"), "{:?}", report.findings);
    }

    #[test]
    fn filters_select_records() {
        let t = ThreadId::new();
        let turn = TurnId::new();
        let mut a = rec(AuditAction::ToolDenied, O::Denied, &[], 10);
        a.thread_id = t;
        a.turn_id = Some(turn);
        let mut b = rec(AuditAction::ToolInvoked, O::Allowed, &[], 20);
        b.thread_id = t;
        b.turn_id = Some(turn);
        let c = rec(AuditAction::SessionStart, O::Info, &[], 30);

        let f = IncidentFilter { thread_id: Some(t), ..Default::default() };
        assert!(f.matches(&a) && f.matches(&b) && !f.matches(&c));

        let f2 = IncidentFilter { actions: vec![AuditAction::ToolDenied], ..Default::default() };
        assert!(f2.matches(&a) && !f2.matches(&b));

        let f3 = IncidentFilter { since_ms: Some(15), until_ms: Some(25), ..Default::default() };
        assert!(!f3.matches(&a) && f3.matches(&b) && !f3.matches(&c));

        let f4 = IncidentFilter { failures_only: true, ..Default::default() };
        assert!(f4.matches(&a) && !f4.matches(&b));

        let f5 = IncidentFilter { compliance_only: true, ..Default::default() };
        assert!(f5.matches(&a) && !f5.matches(&c));
    }

    #[test]
    fn markdown_contains_every_section() {
        let records = vec![
            rec(AuditAction::ToolDenied, O::Denied, &[("tool", "shell"), ("command", "rm -rf build")], 1),
            rec(AuditAction::GrantRemembered, O::Allowed, &[("pattern", "shell(cargo test *)")], 2),
        ];
        let anchor = Anchor { count: 42, root_hash: "ab".repeat(32), ts_ms: 5, index: 42 };
        let r = build(
            &records,
            &IncidentFilter::default(),
            snapshot(),
            attribution(),
            Some(anchor.clone()),
        );
        let md = to_markdown(&r);
        for section in ["# Incident", "## Attribution", "## Findings", "## Policy in force", "## Timeline", "## Verification"] {
            assert!(md.contains(section), "missing {section}");
        }
        assert!(md.contains("count **42**"), "{md}");
        assert!(md.contains("agent audit verify"));
        assert!(md.contains("| time (UTC) |"), "{md}");
    }

    #[test]
    fn the_chain_anchor_is_embedded() {
        let anchor = Anchor { count: 7, root_hash: "f".repeat(64), ts_ms: 1, index: 7 };
        let r = build(&[], &IncidentFilter::default(), snapshot(), attribution(), Some(anchor.clone()));
        assert_eq!(r.chain_anchor, Some(anchor));
    }

    #[test]
    fn reports_are_deterministic_given_the_same_input() {
        let records = vec![rec(AuditAction::ToolDenied, O::Denied, &[("tool", "shell")], 1)];
        let a = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        let b = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        assert_eq!(a.findings, b.findings);
        assert_eq!(a.timeline, b.timeline);
        assert_eq!(a.summary, b.summary);
        assert_eq!(a.severity, b.severity);
    }

    #[test]
    fn severity_ordering_and_syslog_mapping() {
        assert!(Severity::Critical > Severity::High);
        assert!(Severity::High > Severity::Medium);
        assert!(Severity::Medium > Severity::Low);
        assert!(Severity::Low > Severity::Info);
        assert_eq!(Severity::Critical.syslog(), 2);
        assert_eq!(Severity::Info.syslog(), 6);
        assert_eq!(Severity::High.as_str(), "high");
    }

    #[test]
    fn kill_switch_global_stops_everything() {
        let inv = sample_inventory();
        let req = KillRequest {
            scope: KillScope::Global,
            reason: "runaway spend".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: true,
            revoke_grants: true,
            add_deny_rule: true,
        };
        let plan = plan_kill(&req, &inv);
        assert_eq!(plan.cancel_threads.len(), 2);
        assert_eq!(plan.cancel_workers.len(), 2);
        assert_eq!(plan.remove_worktrees.len(), 1);
        assert_eq!(plan.revoke_grants.len(), 2);
        assert_eq!(plan.add_deny_rules, vec!["*(*)".to_string()]);
        assert!(plan.summary.contains("cancel 2 thread(s)"), "{}", plan.summary);
        assert!(!plan.is_noop());
        assert_eq!(plan.affected(), 2 + 2 + 2);
    }

    #[test]
    fn kill_switch_repo_scopes_to_one_repository() {
        let inv = sample_inventory();
        let req = KillRequest {
            scope: KillScope::Repo { path: "/work/alpha".into() },
            reason: "customer request".into(),
            actor: Actor::Admin { id: "sec".into(), source: "/etc/agent/policy.toml".into() },
            cleanup_worktrees: true,
            revoke_grants: true,
            add_deny_rule: true,
        };
        let plan = plan_kill(&req, &inv);
        assert_eq!(plan.cancel_threads.len(), 1);
        assert_eq!(plan.cancel_workers.len(), 1);
        assert_eq!(plan.cancel_workers, vec!["wkr_1".to_string()]);
        assert!(plan.add_deny_rules.iter().any(|r| r == "write(/work/alpha/**)"), "{:?}", plan.add_deny_rules);
    }

    #[test]
    fn kill_switch_worker_scope_only_touches_that_worker() {
        let inv = sample_inventory();
        let req = KillRequest {
            scope: KillScope::Worker { worker_id: "wkr_2".into() },
            reason: "stuck".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: false,
            revoke_grants: true,
            add_deny_rule: false,
        };
        let plan = plan_kill(&req, &inv);
        assert!(plan.cancel_threads.is_empty());
        assert_eq!(plan.cancel_workers, vec!["wkr_2".to_string()]);
        assert!(plan.remove_worktrees.is_empty());
        assert!(plan.revoke_grants.is_empty(), "a worker kill must not revoke session grants");
        assert!(plan.add_deny_rules.is_empty());
    }

    #[test]
    fn kill_switch_session_scope() {
        let inv = sample_inventory();
        let tid = inv.threads[1].thread_id;
        let req = KillRequest {
            scope: KillScope::Session { thread_id: tid },
            reason: "leaked secret".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: true,
            revoke_grants: false,
            add_deny_rule: true,
        };
        let plan = plan_kill(&req, &inv);
        assert_eq!(plan.cancel_threads, vec![tid]);
        assert!(plan.cancel_workers.is_empty(), "no workers belong to thread 2");
        assert!(plan.add_deny_rules[0].contains(&tid.to_string()));
    }

    #[test]
    fn kill_switch_credential_scope_revokes_only_that_token() {
        let inv = sample_inventory();
        let req = KillRequest {
            scope: KillScope::Credential { token_id: "tok_abc".into() },
            reason: "leaked".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: false,
            revoke_grants: false,
            add_deny_rule: true,
        };
        let plan = plan_kill(&req, &inv);
        assert_eq!(plan.revoke_credentials, vec!["tok_abc".to_string()]);
        assert!(plan.cancel_threads.is_empty());
        let unknown = KillRequest { scope: KillScope::Credential { token_id: "tok_nope".into() }, ..req };
        assert!(plan_kill(&unknown, &inv).revoke_credentials.is_empty());
    }

    #[test]
    fn an_empty_scope_produces_a_noop_plan() {
        let req = KillRequest {
            scope: KillScope::Repo { path: "/work/none".into() },
            reason: "x".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: true,
            revoke_grants: false,
            add_deny_rule: false,
        };
        let plan = plan_kill(&req, &sample_inventory());
        assert!(plan.is_noop(), "{plan:?}");
        assert!(plan.summary.contains("nothing in scope"), "{}", plan.summary);
    }

    #[test]
    fn repo_paths_compare_ignoring_a_trailing_slash() {
        let inv = sample_inventory();
        let req = KillRequest {
            scope: KillScope::Repo { path: "/work/alpha/".into() },
            reason: "x".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: false,
            revoke_grants: false,
            add_deny_rule: false,
        };
        assert_eq!(plan_kill(&req, &inv).cancel_threads.len(), 1);
    }

    #[test]
    fn revocation_list_is_idempotent_and_persists() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("revoked.json");
        let mut list = RevocationList::load(&path).unwrap();
        assert!(list.entries.is_empty());
        list.revoke(RevocationKind::Credential, "tok_abc", "dev", "leaked in a log");
        list.revoke(RevocationKind::Credential, "tok_abc", "dev", "leaked in a log");
        assert_eq!(list.entries.len(), 1, "revoking twice must not duplicate");
        assert!(list.is_revoked(RevocationKind::Credential, "tok_abc"));
        assert!(!list.is_revoked(RevocationKind::Session, "tok_abc"));
        list.revoke(RevocationKind::Session, "thr_1", "dev", "kill switch");
        list.save(&path).unwrap();

        let back = RevocationList::load(&path).unwrap();
        assert_eq!(back, list);
        assert!(!path.with_extension("json.tmp").exists(), "the temp file must be renamed away");

        let mut b2 = back;
        assert!(b2.reinstate(RevocationKind::Credential, "tok_abc"));
        assert!(!b2.is_revoked(RevocationKind::Credential, "tok_abc"));
        assert!(!b2.reinstate(RevocationKind::Credential, "tok_abc"));
    }

    #[test]
    fn a_corrupt_revocation_list_is_an_error_not_an_empty_list() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("revoked.json");
        std::fs::write(&path, "{not json").unwrap();
        let err = RevocationList::load(&path).unwrap_err();
        assert!(matches!(err, RevocationError::Parse(_)), "{err}");
    }

    #[test]
    fn kill_scope_labels_are_stable() {
        assert_eq!(KillScope::Global.label(), "global");
        assert_eq!(KillScope::Repo { path: "/a".into() }.label(), "repo:/a");
        assert_eq!(KillScope::Worker { worker_id: "w1".into() }.label(), "worker:w1");
        assert_eq!(KillScope::Credential { token_id: "t1".into() }.label(), "credential:t1");
    }

    fn sample_inventory() -> Inventory {
        let t1 = ThreadId::new();
        let t2 = ThreadId::new();
        Inventory {
            threads: vec![
                LiveThread { thread_id: t1, repo_path: "/work/alpha".into(), turn_in_flight: true },
                LiveThread { thread_id: t2, repo_path: "/work/beta".into(), turn_in_flight: false },
            ],
            workers: vec![
                LiveWorker { worker_id: "wkr_1".into(), thread_id: t1, worktree: Some("/tmp/wt/alpha-1".into()), repo_path: "/work/alpha".into() },
                LiveWorker { worker_id: "wkr_2".into(), thread_id: t1, worktree: None, repo_path: "/work/beta".into() },
            ],
            grants: vec!["shell(cargo test *)|session".into(), "read(src/**)|persistent".into()],
            credentials: vec!["tok_abc".into(), "tok_def".into()],
        }
    }

    #[test]
    fn report_round_trips_through_json() {
        let records = vec![rec(AuditAction::NetworkBlocked, O::Denied, &[("host", "example.com")], 1)];
        let r = build(&records, &IncidentFilter::default(), snapshot(), attribution(), None);
        let json = serde_json::to_string(&r).unwrap();
        let back: IncidentReport = serde_json::from_str(&json).unwrap();
        assert_eq!(back, r);
    }
}

// ---------------------------------------------------------------------------
// Kill switch (§9.5 `incident.rs` acceptance: "1 command me sab workers stop")
// ---------------------------------------------------------------------------

/// What a kill switch stops.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "scope", rename_all = "snake_case")]
pub enum KillScope {
    /// Everything, everywhere: every thread, every worker, every session.
    Global,
    /// One repository. Adds a deny rule so the agent cannot come back.
    Repo {
        /// Absolute path of the repo root.
        path: String,
    },
    /// One session/thread.
    Session {
        /// Thread id.
        thread_id: ThreadId,
    },
    /// One worker.
    Worker {
        /// Worker id.
        worker_id: String,
    },
    /// One credential/token.
    Credential {
        /// Token id as recorded by `auth`.
        token_id: String,
    },
}

impl KillScope {
    /// Stable label for the audit record.
    #[must_use]
    pub fn label(&self) -> String {
        match self {
            Self::Global => "global".into(),
            Self::Repo { path } => format!("repo:{path}"),
            Self::Session { thread_id } => format!("session:{thread_id}"),
            Self::Worker { worker_id } => format!("worker:{worker_id}"),
            Self::Credential { token_id } => format!("credential:{token_id}"),
        }
    }
}

/// A kill switch request.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct KillRequest {
    /// Scope.
    pub scope: KillScope,
    /// Why. Goes into the audit record verbatim; never truncated.
    pub reason: String,
    /// Who pulled it.
    pub actor: Actor,
    /// Also remove worktrees created by workers in scope.
    #[serde(default = "yes_cleanup")]
    pub cleanup_worktrees: bool,
    /// Also revoke remembered grants matching the scope.
    #[serde(default = "yes_cleanup")]
    pub revoke_grants: bool,
    /// Also add a permanent deny rule so the scope cannot be re-entered without
    /// an explicit config edit.
    #[serde(default = "yes_cleanup")]
    pub add_deny_rule: bool,
}

const fn yes_cleanup() -> bool {
    true
}

/// What is currently running, as reported by the orchestrator. The policy crate
/// does not own any of it — it only decides what to stop.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct Inventory {
    /// Live threads.
    pub threads: Vec<LiveThread>,
    /// Live workers.
    pub workers: Vec<LiveWorker>,
    /// Remembered grants, as `pattern|scope` strings.
    pub grants: Vec<String>,
    /// Issued credentials.
    pub credentials: Vec<String>,
}

/// A live thread.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LiveThread {
    /// Thread id.
    pub thread_id: ThreadId,
    /// Repo root it is operating in.
    pub repo_path: String,
    /// True when a turn is in flight.
    pub turn_in_flight: bool,
}

/// A live worker.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LiveWorker {
    /// Worker id.
    pub worker_id: String,
    /// The thread that spawned it.
    pub thread_id: ThreadId,
    /// Its worktree, if isolation gave it one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub worktree: Option<String>,
    /// Repo it belongs to.
    pub repo_path: String,
}

/// The plan the orchestrator executes. Computing it here keeps the decision
/// auditable *before* anything is cancelled: `agent kill --dry-run` prints it.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct KillPlan {
    /// Cancellation tokens to fire (thread ids).
    pub cancel_threads: Vec<ThreadId>,
    /// Workers to cancel.
    pub cancel_workers: Vec<String>,
    /// Worktrees to remove.
    pub remove_worktrees: Vec<String>,
    /// Grant patterns to revoke.
    pub revoke_grants: Vec<String>,
    /// Credentials to revoke.
    pub revoke_credentials: Vec<String>,
    /// Deny rules to install, with the reason recorded in their origin.
    pub add_deny_rules: Vec<String>,
    /// Audit actions to write, in order.
    pub audit_actions: Vec<AuditAction>,
    /// Human summary of what will happen.
    pub summary: String,
}

impl KillPlan {
    /// True when the plan does nothing.
    #[must_use]
    pub fn is_noop(&self) -> bool {
        self.cancel_threads.is_empty()
            && self.cancel_workers.is_empty()
            && self.revoke_grants.is_empty()
            && self.revoke_credentials.is_empty()
            && self.add_deny_rules.is_empty()
    }

    /// Total number of things that will be stopped.
    #[must_use]
    pub fn affected(&self) -> usize {
        self.cancel_threads.len() + self.cancel_workers.len() + self.revoke_grants.len()
    }
}

/// Compute what a kill request will do.
///
/// Pure: no cancellation happens here, so the plan can be shown, logged and
/// approved before it is executed.
#[must_use]
pub fn plan_kill(req: &KillRequest, inv: &Inventory) -> KillPlan {
    let mut plan = KillPlan::default();
    let label = req.scope.label();

    let in_scope_thread = |t: &LiveThread| -> bool {
        match &req.scope {
            KillScope::Global => true,
            KillScope::Repo { path } => same_repo(&t.repo_path, path),
            KillScope::Session { thread_id } => &t.thread_id == thread_id,
            KillScope::Worker { .. } | KillScope::Credential { .. } => false,
        }
    };
    let in_scope_worker = |w: &LiveWorker| -> bool {
        match &req.scope {
            KillScope::Global => true,
            KillScope::Repo { path } => same_repo(&w.repo_path, path),
            KillScope::Session { thread_id } => &w.thread_id == thread_id,
            KillScope::Worker { worker_id } => &w.worker_id == worker_id,
            KillScope::Credential { .. } => false,
        }
    };

    for t in inv.threads.iter().filter(|t| in_scope_thread(t)) {
        plan.cancel_threads.push(t.thread_id);
    }
    for w in inv.workers.iter().filter(|w| in_scope_worker(w)) {
        plan.cancel_workers.push(w.worker_id.clone());
        if req.cleanup_worktrees {
            if let Some(wt) = &w.worktree {
                plan.remove_worktrees.push(wt.clone());
            }
        }
    }
    if req.revoke_grants {
        // A repo kill revokes every grant; a session kill revokes the session's.
        // Grants are not scoped in the pattern string, so the conservative
        // answer for Global/Repo is "all of them".
        let all = matches!(req.scope, KillScope::Global | KillScope::Repo { .. });
        plan.revoke_grants = if all { inv.grants.clone() } else { Vec::new() };
    }
    if let KillScope::Credential { token_id } = &req.scope {
        if inv.credentials.iter().any(|c| c == token_id) {
            plan.revoke_credentials.push(token_id.clone());
        }
    }
    if req.add_deny_rule {
        match &req.scope {
            KillScope::Repo { path } => {
                plan.add_deny_rules.push(format!("write({path}/**)"));
                plan.add_deny_rules.push(format!("shell(cd {path}*)"));
            }
            KillScope::Global => plan.add_deny_rules.push("*(*)".into()),
            KillScope::Session { thread_id } => {
                plan.add_deny_rules.push(format!("*(session:{thread_id})"));
            }
            KillScope::Worker { worker_id } => {
                plan.add_deny_rules.push(format!("*(worker:{worker_id})"));
            }
            KillScope::Credential { token_id } => {
                plan.add_deny_rules.push(format!("net(*{token_id}*)"));
            }
        }
    }
    plan.audit_actions.push(AuditAction::IncidentReport);
    if !plan.cancel_workers.is_empty() {
        plan.audit_actions.push(AuditAction::WorkerMerged);
    }

    let mut bits = Vec::new();
    if !plan.cancel_threads.is_empty() {
        bits.push(format!("cancel {} thread(s)", plan.cancel_threads.len()));
    }
    if !plan.cancel_workers.is_empty() {
        bits.push(format!("cancel {} worker(s)", plan.cancel_workers.len()));
    }
    if !plan.remove_worktrees.is_empty() {
        bits.push(format!("remove {} worktree(s)", plan.remove_worktrees.len()));
    }
    if !plan.revoke_grants.is_empty() {
        bits.push(format!("revoke {} grant(s)", plan.revoke_grants.len()));
    }
    if !plan.revoke_credentials.is_empty() {
        bits.push(format!("revoke {} credential(s)", plan.revoke_credentials.len()));
    }
    if !plan.add_deny_rules.is_empty() {
        bits.push(format!("install {} deny rule(s)", plan.add_deny_rules.len()));
    }
    plan.summary = if bits.is_empty() {
        format!("kill switch ({label}): nothing in scope")
    } else {
        format!("kill switch ({label}): {}", bits.join(", "))
    };
    plan
}

fn same_repo(a: &str, b: &str) -> bool {
    let na = a.trim_end_matches('/');
    let nb = b.trim_end_matches('/');
    na == nb
}

/// A revocation list: credentials and sessions that must not be honoured even
/// if their token file still exists. Persisted next to the audit log so it
/// survives a restart — a kill switch that forgets itself is not a kill switch.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct RevocationList {
    /// Revoked entries.
    pub entries: Vec<Revocation>,
}

/// One revocation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Revocation {
    /// What was revoked.
    pub kind: RevocationKind,
    /// Identifier.
    pub id: String,
    /// When.
    pub revoked_at_ms: u64,
    /// Who.
    pub by: String,
    /// Why.
    pub reason: String,
}

/// Kinds of revocable thing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RevocationKind {
    /// An auth token.
    Credential,
    /// A session.
    Session,
    /// A remembered grant.
    Grant,
    /// An MCP server.
    McpServer,
}

impl RevocationList {
    /// Revoke something. Idempotent: revoking twice is one entry.
    pub fn revoke(&mut self, kind: RevocationKind, id: impl Into<String>, by: impl Into<String>, reason: impl Into<String>) {
        let id = id.into();
        if self.is_revoked(kind, &id) {
            return;
        }
        self.entries.push(Revocation {
            kind,
            id,
            revoked_at_ms: agent_protocol::now_ms(),
            by: by.into(),
            reason: reason.into(),
        });
    }

    /// True when the thing is revoked.
    #[must_use]
    pub fn is_revoked(&self, kind: RevocationKind, id: &str) -> bool {
        self.entries.iter().any(|e| e.kind == kind && e.id == id)
    }

    /// Undo a revocation (an admin action; itself audited).
    pub fn reinstate(&mut self, kind: RevocationKind, id: &str) -> bool {
        let before = self.entries.len();
        self.entries.retain(|e| !(e.kind == kind && e.id == id));
        before != self.entries.len()
    }

    /// Load from a JSON file. A missing file means an empty list.
    ///
    /// # Errors
    /// On I/O or parse failure — never silently ignored, because an unreadable
    /// revocation list would un-revoke everything.
    pub fn load(path: &Path) -> Result<Self, RevocationError> {
        if !path.exists() {
            return Ok(Self::default());
        }
        let text = std::fs::read_to_string(path).map_err(|e| RevocationError::Io(e.to_string()))?;
        serde_json::from_str(&text).map_err(|e| RevocationError::Parse(e.to_string()))
    }

    /// Save atomically (write temp + rename) so a crash cannot leave a
    /// half-written list.
    ///
    /// # Errors
    /// On I/O or serialisation failure.
    pub fn save(&self, path: &Path) -> Result<(), RevocationError> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).map_err(|e| RevocationError::Io(e.to_string()))?;
        }
        let tmp = path.with_extension("json.tmp");
        let text = serde_json::to_string_pretty(self).map_err(|e| RevocationError::Parse(e.to_string()))?;
        std::fs::write(&tmp, text).map_err(|e| RevocationError::Io(e.to_string()))?;
        std::fs::rename(&tmp, path).map_err(|e| RevocationError::Io(e.to_string()))?;
        Ok(())
    }
}

/// Revocation list errors.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error, Serialize, Deserialize)]
pub enum RevocationError {
    /// I/O.
    #[error("revocation list I/O failed: {0}")]
    Io(String),
    /// Parse/serialise.
    #[error("revocation list is corrupt: {0}")]
    Parse(String),
}
