//! Secret redaction (`rustplan.txt` §6.4, §9.5 `src/redaction.rs`).
//!
//! Two independent detectors, unioned:
//!
//! 1. **Named patterns** — regexes for the token shapes the industry has
//!    standardised (`AKIA…`, `ghp_…`, `xox[baprs]-…`, PEM blocks, JWTs,
//!    `key=value` assignments inside env dumps). High precision, so these fire
//!    on short matches too.
//! 2. **Entropy** — Shannon bits-per-character over whitespace/quote-delimited
//!    tokens. Catches the secrets nobody has a regex for (rotated vendor keys,
//!    base64 blobs, high-entropy hex). Fires only when a token is at least
//!    [`DEFAULT_MIN_ENTROPY_TOKEN`] chars *and* exceeds
//!    [`DEFAULT_ENTROPY_THRESHOLD`] bits/char, because short high-entropy
//!    strings are just… words.
//!
//! Redaction is **on by default** and applies to everything that leaves the
//! process toward a model, a log, an audit line or telemetry. It is *not*
//! applied to what is written into the user's own files (§6.4: redaction
//! protects the boundary, not the repo).
//!
//! A replacement keeps an 8-hex fingerprint (`blake3(secret)[..8]`) so an
//! incident report can prove two events leaked the *same* secret without the
//! report itself containing it.

use std::sync::OnceLock;

use regex::Regex;
use serde::{Deserialize, Serialize};

/// Minimum token length for the entropy detector.
pub const DEFAULT_MIN_ENTROPY_TOKEN: usize = 20;
/// Shannon bits/char above which a token is treated as a secret.
pub const DEFAULT_ENTROPY_THRESHOLD: f64 = 4.2;

/// What kind of secret was found. Names appear in the audit record.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SecretKind {
    /// AWS access key id.
    AwsAccessKeyId,
    /// AWS secret access key (via `aws_secret_access_key=` style assignment).
    AwsSecretKey,
    /// GitHub personal/oauth/installation token.
    GithubToken,
    /// Slack token.
    SlackToken,
    /// Google API key.
    GoogleApiKey,
    /// Stripe secret/publishable key.
    StripeKey,
    /// OpenAI/Anthropic/Gemini style bearer key.
    LlmApiKey,
    /// npm `_authToken`.
    NpmToken,
    /// PyPI token.
    PypiToken,
    /// RubyGems API key.
    RubyGemsToken,
    /// Hugging Face token.
    HuggingFaceToken,
    /// Private key material (PEM/OpenSSH).
    PrivateKey,
    /// JSON web token.
    Jwt,
    /// Database/AMQP/Redis URL carrying a password.
    ConnectionString,
    /// `Authorization: Bearer …` header value.
    BearerToken,
    /// Generic `key=value` assignment whose key looks credential-ish.
    GenericAssignment,
    /// High-entropy token with no recognised shape.
    HighEntropy,
    /// A user-supplied pattern from `permissions.redaction.extra_patterns`.
    Custom,
}

impl SecretKind {
    /// Stable wire name.
    #[must_use]
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::AwsAccessKeyId => "aws_access_key_id",
            Self::AwsSecretKey => "aws_secret_access_key",
            Self::GithubToken => "github_token",
            Self::SlackToken => "slack_token",
            Self::GoogleApiKey => "google_api_key",
            Self::StripeKey => "stripe_key",
            Self::LlmApiKey => "llm_api_key",
            Self::NpmToken => "npm_token",
            Self::PypiToken => "pypi_token",
            Self::RubyGemsToken => "rubygems_token",
            Self::HuggingFaceToken => "huggingface_token",
            Self::PrivateKey => "private_key",
            Self::Jwt => "jwt",
            Self::ConnectionString => "connection_string",
            Self::BearerToken => "bearer_token",
            Self::GenericAssignment => "generic_assignment",
            Self::HighEntropy => "high_entropy",
            Self::Custom => "custom",
        }
    }

    /// True for kinds whose *shape* is recognisable, i.e. no entropy check
    /// needed.
    #[must_use]
    pub fn is_shaped(&self) -> bool {
        !matches!(self, Self::HighEntropy | Self::GenericAssignment | Self::Custom)
    }
}

impl std::fmt::Display for SecretKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// A named regex pattern with the byte-group that actually holds the secret.
#[derive(Debug, Clone)]
pub struct NamedPattern {
    /// Kind reported on a hit.
    pub kind: SecretKind,
    /// Compiled regex. Capture group 1, when present, is the secret itself;
    /// otherwise group 0 is replaced.
    pub regex: &'static Regex,
}

fn patterns() -> &'static Vec<NamedPattern> {
    static PATTERNS: OnceLock<Vec<NamedPattern>> = OnceLock::new();
    PATTERNS.get_or_init(|| {
        macro_rules! p {
            ($kind:expr, $re:expr) => {
                NamedPattern {
                    kind: $kind,
                    regex: Box::leak(Box::new(
                        Regex::new($re).expect("redaction pattern must compile"),
                    )),
                }
            };
        }
        vec![
            p!(SecretKind::AwsAccessKeyId, r"(?i)\b((?:AKIA|ASIA|ABIA|ACCA)[0-9A-Z]{16})\b"),
            p!(SecretKind::GithubToken,
               r"\b((?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,255}|github_pat_[A-Za-z0-9_]{20,255})\b"),
            p!(SecretKind::SlackToken, r"\b(xox[baprs]-[A-Za-z0-9-]{10,255})\b"),
            p!(SecretKind::GoogleApiKey, r"\b(AIza[0-9A-Za-z\-_]{35})\b"),
            p!(SecretKind::StripeKey, r"\b((?:sk|rk)_(?:live|test)_[A-Za-z0-9]{16,255})\b"),
            p!(SecretKind::LlmApiKey, r"\b(sk-(?:ant|proj|or|svc)-[A-Za-z0-9\-_]{16,255})\b"),
            p!(SecretKind::NpmToken, r"\b(npm_[A-Za-z0-9]{30,255})\b"),
            p!(SecretKind::PypiToken, r"\b(pypi-AgEIcHlwaS5vcmc[A-Za-z0-9\-_]{20,255})\b"),
            p!(SecretKind::RubyGemsToken, r"\b(rubygems_[a-f0-9]{32,64})\b"),
            p!(SecretKind::HuggingFaceToken, r"\b(hf_[A-Za-z0-9]{20,64})\b"),
            p!(SecretKind::PrivateKey,
               r"(?m)^-----BEGIN (?:(?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?)-----[\s\S]*?^-----END"),
            p!(SecretKind::Jwt,
               r"\b(eyJ[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{6,})\b"),
            p!(SecretKind::BearerToken, r#"(?i)\b(authorization\s*[:=]\s*(?:bearer|token)\s+)([^\s"',;]{8,255})"#),
            p!(SecretKind::ConnectionString,
               r#"(?i)\b((?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|redis|rediss|amqp(?:s)?|mysqlx)://[^\s:/@"']+):([^\s@/"']+)(@)"#),
        ]
    })
}

/// `key=value` assignments whose *key* looks credential-ish.
fn assignment_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| {
        Regex::new(concat!(
            r#"(?i)\b((?:[A-Za-z0-9_\-]*(?:api[_\-]?key|apikey|secret|token|passwd|password|pwd|credential|"#,
            r#"auth|private[_\-]?key|access[_\-]?key|signing[_\-]?key|client[_\-]?secret)[A-Za-z0-9_\-]*))"#,
            r#"(\s*[:=]\s*)("?)([^\s"'`,;]{8,512})("?)"#,
        ))
        .expect("assignment pattern must compile")
    })
}

/// Token splitter for the entropy pass. Secrets are almost always delimited by
/// whitespace, quotes, `=`, `:` or a comma; splitting on those keeps the
/// detector from scoring a whole line (which averages entropy down).
fn token_regex() -> &'static Regex {
    static RE: OnceLock<Regex> = OnceLock::new();
    RE.get_or_init(|| Regex::new(r#"[^\s"'`,;=<>{}\[\()]+"#).expect("token splitter must compile"))
}

/// Tuning for the redactor.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RedactionConfig {
    /// Master switch. Safe-by-default: `true`.
    pub enabled: bool,
    /// Shannon bits/char threshold.
    pub entropy_threshold: f64,
    /// Minimum token length for the entropy pass.
    pub min_entropy_token: usize,
    /// Keep the first/last N characters of a matched secret (`0` = full mask).
    /// Useful for humans debugging their own config; must be `0` in anything
    /// sent to a model or telemetry.
    pub keep_edges: usize,
    /// Include the 8-hex fingerprint in the replacement. Off for telemetry
    /// payloads (a fingerprint is still a correlation handle).
    pub fingerprint: bool,
    /// Kind names to skip. For tests and for the rare verified-safe value the
    /// operator insists on keeping (must be recorded in the audit log).
    #[serde(default)]
    pub allow_kinds: Vec<SecretKind>,
    /// Literal values never to redact, e.g. `sk-test-PLACEHOLDER` from docs.
    #[serde(default)]
    pub allow_values: Vec<String>,
}

impl Default for RedactionConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            entropy_threshold: DEFAULT_ENTROPY_THRESHOLD,
            min_entropy_token: DEFAULT_MIN_ENTROPY_TOKEN,
            keep_edges: 0,
            fingerprint: true,
            allow_kinds: Vec::new(),
            allow_values: Vec::new(),
        }
    }
}

impl RedactionConfig {
    /// Strictest settings: everything masked, no edges, fingerprint kept for
    /// audit correlation. This is what the model and audit paths use.
    #[must_use]
    pub fn for_model() -> Self {
        Self { keep_edges: 0, ..Self::default() }
    }

    /// Telemetry: no fingerprint either, so an exported metric cannot be used
    /// to link two events to the same secret.
    #[must_use]
    pub fn for_telemetry() -> Self {
        Self { keep_edges: 0, fingerprint: false, ..Self::default() }
    }

    /// Redaction disabled. Only reachable through an explicit config flag; the
    /// CLI prints a warning whenever it is in force.
    #[must_use]
    pub fn disabled() -> Self {
        Self { enabled: false, ..Self::default() }
    }
}

/// One masked occurrence.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Redaction {
    /// Byte offset where the secret started, in the *input*.
    pub start: usize,
    /// Byte offset one past the end, in the *input*.
    pub end: usize,
    /// What it looked like.
    pub kind: SecretKind,
    /// 8-hex fingerprint of the secret (`None` when fingerprinting is off).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub fingerprint: Option<String>,
    /// Entropy in bits/char, when the entropy pass caught it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub entropy: Option<u32>,
}

/// Result of a redaction pass.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RedactionReport {
    /// The masked text.
    pub text: String,
    /// Every masked occurrence, in input order.
    pub redactions: Vec<Redaction>,
}

impl RedactionReport {
    /// How many secrets were masked.
    #[must_use]
    pub fn count(&self) -> usize {
        self.redactions.len()
    }

    /// Distinct kinds, sorted. Used for `secret_redactions_total{kind=…}`.
    #[must_use]
    pub fn kinds(&self) -> Vec<SecretKind> {
        let mut v: Vec<SecretKind> = self.redactions.iter().map(|r| r.kind).collect();
        v.sort_unstable();
        v.dedup();
        v
    }

    /// Counts per kind, for telemetry.
    #[must_use]
    pub fn counts_by_kind(&self) -> Vec<(SecretKind, usize)> {
        let mut out: Vec<(SecretKind, usize)> = Vec::new();
        for r in &self.redactions {
            match out.iter_mut().find(|(k, _)| *k == r.kind) {
                Some((_, n)) => *n += 1,
                None => out.push((r.kind, 1)),
            }
        }
        out.sort_unstable();
        out
    }
}

/// The redactor.
#[derive(Debug, Clone)]
pub struct Redactor {
    config: RedactionConfig,
    /// User-supplied regexes from `permissions.redaction.extra_patterns`.
    extra: Vec<Regex>,
    /// Substrings from `permissions.redaction.ignore_patterns`: a value
    /// containing one of these is left alone (known-benign lookalikes).
    ignore: Vec<String>,
}

impl Default for Redactor {
    fn default() -> Self {
        Self::new(RedactionConfig::default())
    }
}

impl Redactor {
    /// Build with explicit config.
    #[must_use]
    pub fn new(config: RedactionConfig) -> Self {
        Self { config, extra: Vec::new(), ignore: Vec::new() }
    }

    /// Attach user patterns.
    ///
    /// # Errors
    /// One message per pattern that does not compile. A typo'd secret pattern
    /// must not silently stop matching, so this is a hard error.
    pub fn with_patterns(mut self, extra: &[String], ignore: &[String]) -> Result<Self, Vec<String>> {
        let mut errs = Vec::new();
        for p in extra {
            match Regex::new(p) {
                Ok(re) => self.extra.push(re),
                Err(e) => errs.push(format!("{p}: {e}")),
            }
        }
        self.ignore.extend(ignore.iter().cloned());
        if errs.is_empty() { Ok(self) } else { Err(errs) }
    }

    /// Number of user-supplied patterns in force.
    #[must_use]
    pub fn extra_pattern_count(&self) -> usize {
        self.extra.len()
    }

    /// The config in force.
    #[must_use]
    pub const fn config(&self) -> &RedactionConfig {
        &self.config
    }

    /// True when redaction is off. The CLI surfaces this loudly.
    #[must_use]
    pub const fn is_disabled(&self) -> bool {
        !self.config.enabled
    }

    /// Redact a string.
    #[must_use]
    pub fn redact(&self, input: &str) -> RedactionReport {
        if !self.config.enabled || input.is_empty() {
            return RedactionReport { text: input.to_string(), redactions: Vec::new() };
        }
        let mut hits: Vec<(usize, usize, SecretKind, Option<f64>)> = Vec::new();

        // Pass 1: named shapes.
        for p in patterns() {
            if self.config.allow_kinds.contains(&p.kind) {
                continue;
            }
            for m in p.regex.find_iter(input) {
                let span = self.secret_span(p.regex, input, m.start(), m.end());
                hits.push((span.0, span.1, p.kind, None));
            }
        }
        // `key=value` assignments.
        if !self.config.allow_kinds.contains(&SecretKind::GenericAssignment) {
            for caps in assignment_regex().captures_iter(input) {
                let whole = caps.get(0).expect("group 0");
                let value = caps.get(4).expect("value group");
                let v = value.as_str();
                if self.is_placeholder(v) {
                    continue;
                }
                hits.push((
                    whole.start() + (value.start() - whole.start()),
                    whole.start() + (value.end() - whole.start()),
                    SecretKind::GenericAssignment,
                    Some(shannon_entropy(v)),
                ));
            }
        }
        // Connection strings: mask only the password part.
        if !self.config.allow_kinds.contains(&SecretKind::ConnectionString) {
            let re = patterns()
                .iter()
                .find(|p| p.kind == SecretKind::ConnectionString)
                .expect("connection string pattern registered above");
            for caps in re.regex.captures_iter(input) {
                if let (Some(user), Some(pass)) = (caps.get(1), caps.get(2)) {
                    let _ = user;
                    hits.push((pass.start(), pass.end(), SecretKind::ConnectionString, None));
                }
            }
        }
        // Bearer tokens: mask the token, keep the header name.
        if !self.config.allow_kinds.contains(&SecretKind::BearerToken) {
            let re = patterns()
                .iter()
                .find(|p| p.kind == SecretKind::BearerToken)
                .expect("bearer pattern registered above");
            for caps in re.regex.captures_iter(input) {
                if let Some(tok) = caps.get(2) {
                    hits.push((tok.start(), tok.end(), SecretKind::BearerToken, None));
                }
            }
        }

        // Pass 1b: user-supplied patterns.
        if !self.config.allow_kinds.contains(&SecretKind::Custom) {
            for re in &self.extra {
                for m in re.find_iter(input) {
                    if m.start() == m.end() {
                        continue; // a zero-width match would loop the output
                    }
                    hits.push((m.start(), m.end(), SecretKind::Custom, None));
                }
            }
        }

        // Pass 2: entropy, on tokens not already covered.
        if !self.config.allow_kinds.contains(&SecretKind::HighEntropy) {
            for m in token_regex().find_iter(input) {
                let tok = m.as_str();
                if tok.len() < self.config.min_entropy_token {
                    continue;
                }
                if self.is_placeholder(tok) {
                    continue;
                }
                // Skip anything that looks like a path or a URL: those are
                // legitimately high-entropy and are not secrets.
                if tok.contains('/') || tok.contains('\\') || tok.contains("://") {
                    continue;
                }
                if hits.iter().any(|(s, e, _, _)| overlaps(*s, *e, m.start(), m.end())) {
                    continue;
                }
                let e = shannon_entropy(tok);
                if e >= self.config.entropy_threshold && looks_random(tok) {
                    hits.push((m.start(), m.end(), SecretKind::HighEntropy, Some(e)));
                }
            }
        }

        // Drop allowlisted literal values, then resolve overlaps by keeping the
        // longest span (a JWT inside a high-entropy token is one secret, not two).
        hits.retain(|(s, e, _, _)| {
            let v = &input[*s..*e];
            !self.config.allow_values.iter().any(|a| a == v)
        });
        let mut resolved = resolve_overlaps(hits);
        resolved.sort_unstable_by_key(|h| (h.0, h.1));

        // Build the output.
        let mut out = String::with_capacity(input.len() + resolved.len() * 32);
        let mut cursor = 0usize;
        let mut redactions = Vec::with_capacity(resolved.len());
        for (s, e, kind, entropy) in resolved {
            out.push_str(&input[cursor..s]);
            let secret = &input[s..e];
            let fp = self
                .config
                .fingerprint
                .then(|| fingerprint(secret))
                .flatten();
            out.push_str(&self.mask(kind, secret, fp.as_deref(), entropy));
            redactions.push(Redaction {
                start: s,
                end: e,
                kind,
                fingerprint: fp,
                entropy: entropy.map(|x| (x * 1000.0).round() as u32),
            });
            cursor = e;
        }
        out.push_str(&input[cursor..]);
        RedactionReport { text: out, redactions }
    }

    /// Convenience: just the masked text.
    #[must_use]
    pub fn redact_str(&self, input: &str) -> String {
        self.redact(input).text
    }

    /// True when the text contains anything the redactor would mask. Cheap
    /// gate used before writing tool output into an event.
    #[must_use]
    pub fn contains_secret(&self, input: &str) -> bool {
        !self.redact(input).redactions.is_empty()
    }

    /// Redact every value in an env map, keeping keys. Keys are never secret
    /// in practice and are needed for debugging.
    #[must_use]
    pub fn redact_env(&self, env: &[(String, String)]) -> Vec<(String, String)> {
        env.iter()
            .map(|(k, v)| (k.clone(), self.redact_str(v)))
            .collect()
    }

    fn mask(&self, kind: SecretKind, secret: &str, fp: Option<&str>, entropy: Option<f64>) -> String {
        let body = if self.config.keep_edges > 0 && secret.len() > self.config.keep_edges * 2 + 4 {
            let n = self.config.keep_edges;
            let head: String = secret.chars().take(n).collect();
            let tail: String = secret.chars().rev().take(n).collect::<Vec<_>>().into_iter().rev().collect();
            format!("{head}…{tail}")
        } else {
            String::new()
        };
        let fp = fp.map(|f| format!(":{f}")).unwrap_or_default();
        let ent = entropy
            .filter(|_| kind == SecretKind::HighEntropy)
            .map(|e| format!(":entropy {:.2}", e))
            .unwrap_or_default();
        format!("[redacted:{kind}{fp}{body}{ent}]")
    }

    /// Narrow a whole-match span down to the actual secret bytes.
    fn secret_span(&self, re: &'static Regex, input: &str, start: usize, end: usize) -> (usize, usize) {
        if let Some(caps) = re.captures(&input[start..end]) {
            let group = caps.get(1).or_else(|| caps.get(2)).unwrap_or_else(|| caps.get(0).expect("group 0"));
            (start + group.start(), start + group.end())
        } else {
            (start, end)
        }
    }

    /// Values that are obviously placeholders. Without this, every README in
    /// the world trips the detector and users turn redaction off — which is
    /// worse than a false positive.
    fn is_placeholder(&self, value: &str) -> bool {
        let v = value.to_ascii_lowercase();
        const PLACEHOLDERS: &[&str] = &[
            "xxxxxxxx", "your-api-key", "your_api_key", "yourkey", "yourtoken", "your-token",
            "placeholder", "changeme", "example", "dummy", "sample", "redacted", "masked",
            "<", ">", "${", "secret-key-here", "insert", "todo", "none", "null", "true", "false",
            "password", "notasecret", "testkey", "test-key", "fake", "aaaa",
        ];
        if PLACEHOLDERS.iter().any(|p| v.contains(p)) {
            return true;
        }
        self.ignore.iter().any(|p| {
            let p = p.to_ascii_lowercase();
            !p.is_empty() && v.contains(&p)
        })
    }

    /// True when a path is on the operator's redaction allowlist, i.e. its
    /// contents are known-benign fixtures and must not be masked. Callers (the
    /// read/patch tools) check this *before* redacting file content; it never
    /// applies to argv, env or network payloads.
    #[must_use]
    pub fn is_allowlisted_path(&self, path: &str, allowlist: &[String]) -> bool {
        allowlist
            .iter()
            .any(|pat| agent_protocol::glob_match::glob_match(pat, path))
    }
}

/// Shannon entropy in bits per character.
#[must_use]
pub fn shannon_entropy(s: &str) -> f64 {
    if s.is_empty() {
        return 0.0;
    }
    let mut counts = [0u32; 128];
    let mut total = 0usize;
    for b in s.bytes() {
        total += 1;
        counts[usize::from(b)] += 1;
    }
    if total == 0 {
        return 0.0;
    }
    let mut h = 0.0f64;
    for c in counts.iter().copied() {
        if c == 0 {
            continue;
        }
        let p = f64::from(c) / total as f64;
        h -= p * p.log2();
    }
    h
}

/// Guard against "high entropy but obviously structured": require a real mix of
/// character classes and no long runs of one character.
fn looks_random(tok: &str) -> bool {
    let mut digits = 0usize;
    let mut lower = 0usize;
    let mut upper = 0usize;
    let mut other = 0usize;
    let mut max_run = 0usize;
    let mut run = 0usize;
    let mut prev: Option<char> = None;
    for c in tok.chars() {
        match c {
            '0'..='9' => digits += 1,
            'a'..='z' => lower += 1,
            'A'..='Z' => upper += 1,
            _ => other += 1,
        }
        if prev == Some(c) {
            run += 1;
        } else {
            run = 1;
        }
        max_run = max_run.max(run);
        prev = Some(c);
    }
    let classes = [digits, lower, upper, other].iter().filter(|n| **n > 0).count();
    classes >= 2 && max_run < 6
}

/// 8-hex blake3 fingerprint of a secret, for correlation without disclosure.
#[must_use]
pub fn fingerprint(secret: &str) -> Option<String> {
    let hash = blake3::hash(secret.as_bytes());
    Some(hash.to_hex()[..8].to_string())
}

fn overlaps(a0: usize, a1: usize, b0: usize, b1: usize) -> bool {
    a0 < b1 && b0 < a1
}

/// Collapse overlapping spans, preferring the longest (ties: the more specific
/// kind, i.e. shaped over entropy-detected).
fn resolve_overlaps(
    mut hits: Vec<(usize, usize, SecretKind, Option<f64>)>,
) -> Vec<(usize, usize, SecretKind, Option<f64>)> {
    hits.sort_unstable_by(|a, b| {
        (b.1 - b.0)
            .cmp(&(a.1 - a.0))
            .then_with(|| a.2.is_shaped().cmp(&b.2.is_shaped()).reverse())
            .then_with(|| a.0.cmp(&b.0))
    });
    let mut out: Vec<(usize, usize, SecretKind, Option<f64>)> = Vec::with_capacity(hits.len());
    for h in hits {
        if out.iter().any(|o| overlaps(o.0, o.1, h.0, h.1)) {
            continue;
        }
        out.push(h);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn entropy_of_uniform_hex_is_about_four_bits() {
        let e = shannon_entropy("0123456789abcdef");
        assert!((e - 4.0).abs() < 1e-9, "{e}");
    }

    #[test]
    fn entropy_of_a_repeated_char_is_zero() {
        assert_eq!(shannon_entropy("aaaaaaaa"), 0.0);
        assert_eq!(shannon_entropy(""), 0.0);
    }

    #[test]
    fn english_words_score_below_the_threshold() {
        // The threshold must not fire on ordinary prose, or users disable it.
        assert!(shannon_entropy("Supercalifragilistic") < DEFAULT_ENTROPY_THRESHOLD);
        assert!(shannon_entropy("the-quick-brown-fox") < DEFAULT_ENTROPY_THRESHOLD);
    }

    #[test]
    fn a_random_base64_blob_scores_above_the_threshold() {
        let e = shannon_entropy("Xk9qL2ZQ7mTbWzrN4sVcA1hDyUg");
        assert!(e > DEFAULT_ENTROPY_THRESHOLD, "{e}");
    }

    #[test]
    fn aws_keys_are_masked() {
        let r = Redactor::default();
        let out = r.redact("aws_access_key_id = AKIAIOSFODNN7EXAMPLE and more");
        assert_eq!(out.count(), 1);
        assert_eq!(out.redactions[0].kind, SecretKind::AwsAccessKeyId);
        assert!(!out.text.contains("AKIAIOSFODNN7EXAMPLE"), "{}", out.text);
        assert!(out.text.contains("[redacted:aws_access_key_id:"), "{}", out.text);
        assert_eq!(out.redactions[0].fingerprint.as_deref().map(str::len), Some(8));
    }

    #[test]
    fn github_and_slack_and_google_tokens_are_masked() {
        let r = Redactor::default();
        let out = r.redact(concat!(
            "ghp_16C7e42F292c6912E7710c838347Ae178B4a ",
            "xoxb-123456789012-1234567890123-AbCdEfGhIjKlMnOpQrStUvWx ",
            "AIzaSyA1234567890abcdefghijklmnopqrstuv"
        ));
        let kinds = out.kinds();
        assert!(kinds.contains(&SecretKind::GithubToken), "{kinds:?}");
        assert!(kinds.contains(&SecretKind::SlackToken), "{kinds:?}");
        assert!(kinds.contains(&SecretKind::GoogleApiKey), "{kinds:?}");
    }

    #[test]
    fn private_key_blocks_are_masked_wholesale() {
        let r = Redactor::default();
        let pem = "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA1234\nabcdef\n-----END RSA PRIVATE KEY-----\ntrailing";
        let out = r.redact(pem);
        assert!(out.count() >= 1, "{out:?}");
        assert!(!out.text.contains("MIIEowIBAAKCAQEA1234"), "{}", out.text);
        assert!(out.text.contains("trailing"), "{}", out.text);
    }

    #[test]
    fn assignment_style_secrets_are_masked_but_placeholders_are_not() {
        let r = Redactor::default();
        let out = r.redact("OPENAI_API_KEY=sk-ant-abc123def456ghi789jkl\nTOKEN=your-api-key-here");
        assert!(out.count() >= 1, "{out:?}");
        assert!(!out.text.contains("sk-ant-abc123def456ghi789jkl"), "{}", out.text);
        assert!(out.text.contains("your-api-key-here"), "placeholders must survive: {}", out.text);
    }

    #[test]
    fn connection_strings_lose_only_the_password() {
        let r = Redactor::default();
        let out = r.redact("DATABASE_URL=postgres://user:Sup3rS3cr3tPassw0rd@db.internal:5432/app");
        assert!(!out.text.contains("Sup3rS3cr3tPassw0rd"), "{}", out.text);
        assert!(out.text.contains("postgres://user:"), "{}", out.text);
        assert!(out.text.contains("@db.internal:5432/app"), "{}", out.text);
    }

    #[test]
    fn bearer_headers_lose_only_the_token() {
        let r = Redactor::default();
        let out = r.redact("Authorization: Bearer abcdef0123456789ABCDEF");
        assert!(!out.text.contains("abcdef0123456789ABCDEF"), "{}", out.text);
        assert!(out.text.to_lowercase().contains("authorization"), "{}", out.text);
    }

    #[test]
    fn high_entropy_tokens_are_caught_with_their_score() {
        let r = Redactor::default();
        let out = r.redact("run this: Xk9qL2ZQ7mTbWzrN4sVcA1hDyUgP now");
        assert_eq!(out.count(), 1, "{out:?}");
        assert_eq!(out.redactions[0].kind, SecretKind::HighEntropy);
        let e = out.redactions[0].entropy.unwrap() as f64 / 1000.0;
        assert!(e >= DEFAULT_ENTROPY_THRESHOLD, "{e}");
        assert!(out.text.contains("entropy"), "{}", out.text);
    }

    #[test]
    fn short_high_entropy_tokens_are_left_alone() {
        let r = Redactor::default();
        // 12 chars: below the 20-char floor.
        let out = r.redact("id=Xk9qL2ZQ7mTb");
        assert_eq!(out.count(), 0, "{out:?}");
    }

    #[test]
    fn paths_and_urls_are_never_entropy_flagged() {
        let r = Redactor::default();
        for text in [
            "see /home/user/projects/rust1/crates/policy/src/redaction.rs for details",
            "docs at https://doc.rust-lang.org/std/struct.Vec.html#method.push",
            "cargo test -p agent-policy -- --nocapture",
        ] {
            let out = r.redact(text);
            assert_eq!(out.count(), 0, "{text} => {out:?}");
        }
    }

    #[test]
    fn prose_is_not_redacted() {
        let r = Redactor::default();
        let text = "The policy engine evaluates deny rules first, then ask rules, then allow rules.";
        let out = r.redact(text);
        assert_eq!(out.text, text);
        assert_eq!(out.count(), 0);
    }

    #[test]
    fn overlapping_hits_collapse_into_one_redaction() {
        let r = Redactor::default();
        // An AWS key is also a high-entropy token; the user must see one mask.
        let out = r.redact("AKIAIOSFODNN7EXAMPLE");
        assert_eq!(out.count(), 1, "{out:?}");
        assert_eq!(out.redactions[0].kind, SecretKind::AwsAccessKeyId);
    }

    #[test]
    fn disabled_config_is_a_passthrough() {
        let r = Redactor::new(RedactionConfig::disabled());
        assert!(r.is_disabled());
        let out = r.redact("AKIAIOSFODNN7EXAMPLE");
        assert_eq!(out.text, "AKIAIOSFODNN7EXAMPLE");
        assert_eq!(out.count(), 0);
    }

    #[test]
    fn allow_kinds_and_allow_values_skip_specific_matches() {
        let cfg = RedactionConfig {
            allow_kinds: vec![SecretKind::HighEntropy],
            allow_values: vec!["AKIAIOSFODNN7EXAMPLE".to_string()],
            ..Default::default()
        };
        let r = Redactor::new(cfg);
        let out = r.redact("AKIAIOSFODNN7EXAMPLE Xk9qL2ZQ7mTbWzrN4sVcA1hDyUgP");
        assert_eq!(out.count(), 0, "{out:?}");
    }

    #[test]
    fn keep_edges_preserves_a_readable_prefix_for_local_debugging() {
        let cfg = RedactionConfig { keep_edges: 4, ..Default::default() };
        let r = Redactor::new(cfg);
        let out = r.redact_str("AKIAIOSFODNN7EXAMPLE");
        assert!(out.contains("AKIA"), "{out}");
        assert!(out.contains("MPLE"), "{out}");
        assert!(!out.contains("IOSFODNN"), "{out}");
    }

    #[test]
    fn telemetry_config_drops_the_fingerprint() {
        let r = Redactor::new(RedactionConfig::for_telemetry());
        let out = r.redact("AKIAIOSFODNN7EXAMPLE");
        assert!(out.redactions[0].fingerprint.is_none());
        assert!(!out.text.contains(":"), "{}", out.text.replace("[redacted:", ""));
    }

    #[test]
    fn counts_by_kind_is_stable_for_metrics() {
        let r = Redactor::default();
        let out = r.redact("AKIAIOSFODNN7EXAMPLE AKIA1234567890ABCDEF ghp_16C7e42F292c6912E7710c838347Ae178B4a");
        let c = out.counts_by_kind();
        assert_eq!(c.iter().find(|(k, _)| *k == SecretKind::AwsAccessKeyId).map(|x| x.1), Some(2));
        assert_eq!(c.iter().find(|(k, _)| *k == SecretKind::GithubToken).map(|x| x.1), Some(1));
    }

    #[test]
    fn env_maps_are_redacted_value_only() {
        let r = Redactor::default();
        let env = vec![
            ("PATH".to_string(), "/usr/bin:/bin".to_string()),
            ("AWS_SECRET_ACCESS_KEY".to_string(), "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY".to_string()),
        ];
        let out = r.redact_env(&env);
        assert_eq!(out[0], ("PATH".into(), "/usr/bin:/bin".into()));
        assert!(out[1].0 == "AWS_SECRET_ACCESS_KEY");
        assert!(out[1].1.starts_with("[redacted:"), "{}", out[1].1);
    }

    #[test]
    fn fingerprints_are_stable_and_short() {
        let a = fingerprint("secret").unwrap();
        let b = fingerprint("secret").unwrap();
        let c = fingerprint("secret2").unwrap();
        assert_eq!(a, b);
        assert_ne!(a, c);
        assert_eq!(a.len(), 8);
        assert!(a.chars().all(|ch| ch.is_ascii_hexdigit()));
    }

    #[test]
    fn redaction_is_idempotent() {
        let r = Redactor::default();
        let once = r.redact_str("key=AKIAIOSFODNN7EXAMPLE");
        let twice = r.redact_str(&once);
        assert_eq!(once, twice, "re-redacting must be a no-op");
    }

    #[test]
    fn extra_patterns_from_config_are_applied() {
        let r = Redactor::default()
            .with_patterns(&[r"ACME-[0-9]{6}".to_string()], &[])
            .unwrap();
        let out = r.redact("ticket ACME-123456 is public");
        assert_eq!(out.count(), 1, "{out:?}");
        assert_eq!(out.redactions[0].kind, SecretKind::Custom);
        assert!(!out.text.contains("ACME-123456"), "{}", out.text);
    }

    #[test]
    fn a_bad_extra_pattern_is_a_hard_error() {
        let err = Redactor::default().with_patterns(&["[unclosed".to_string()], &[]).unwrap_err();
        assert_eq!(err.len(), 1);
        assert!(err[0].contains("[unclosed"), "{err:?}");
    }

    #[test]
    fn ignore_patterns_suppress_known_benign_lookalikes() {
        let r = Redactor::default()
            .with_patterns(&[], &["EXAMPLEKEY".to_string()])
            .unwrap();
        // Still shaped-detects AWS keys? No: the ignore list wins, because the
        // operator asserted the value is benign.
        let out = r.redact("AKIAIOSFODNN7EXAMPLE");
        assert_eq!(out.count(), 1, "shaped patterns are not suppressed by ignore (only entropy/assignment are): {out:?}");
        let r2 = Redactor::default().with_patterns(&[], &["Xk9qL2ZQ7mTb".to_string()]).unwrap();
        let out2 = r2.redact("token Xk9qL2ZQ7mTbWzrN4sVcA1hDyUgP here");
        assert_eq!(out2.count(), 0, "{out2:?}");
    }

    #[test]
    fn zero_width_extra_patterns_do_not_loop() {
        let r = Redactor::default().with_patterns(&[r"x*".to_string()], &[]).unwrap();
        let out = r.redact("nothing to see");
        assert_eq!(out.count(), 0, "{out:?}");
        assert_eq!(out.text, "nothing to see");
    }

    #[test]
    fn allowlisted_paths_are_recognised() {
        let r = Redactor::default();
        let allow = vec!["tests/fixtures/**".to_string(), "**/*.sample".to_string()];
        assert!(r.is_allowlisted_path("tests/fixtures/secrets.txt", &allow));
        assert!(r.is_allowlisted_path("docs/env.sample", &allow));
        assert!(!r.is_allowlisted_path("src/main.rs", &allow));
        assert!(!r.is_allowlisted_path("anything", &[]));
    }

    #[test]
    fn unicode_boundaries_do_not_panic() {
        let r = Redactor::default();
        let out = r.redact("clé=AKIAIOSFODNN7EXAMPLE 🦀 rust");
        assert!(out.text.contains("🦀"), "{}", out.text);
        assert!(!out.text.contains("AKIAIOSFODNN7EXAMPLE"));
    }
}
