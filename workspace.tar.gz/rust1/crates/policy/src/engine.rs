//! Deny-first evaluation engine (`rustplan.txt` §9.5 `src/engine.rs`, §10.4).
//!
//! Order of evaluation, non-negotiable (golden rule #5):
//!
//! 1. **deny** rules — if any matches, the call is refused. An `allow *`
//!    config cannot rescue it.
//! 2. **ask** rules — force a human prompt even in `bypass` mode.
//! 3. session **grants** (remembered approvals, with expiry).
//! 4. **allow** rules.
//! 5. the **mode** table (`policy::modes`) as the default.
//!
//! Within each step the *most specific* match wins (longer literal prefix
//! beats a wildcard). Every decision returns an [`Explanation`] string that
//! names the rule and where it came from, because that single line is what
//! makes enterprise support tractable.
//!
//! Decisions are memoised per `(tool, risk, canonical subject)`. The cache is
//! dropped wholesale whenever a grant is added or revoked — a stale "deny"
//! would be merely annoying, a stale "allow" would be a security bug.

use std::collections::HashMap;
use std::sync::RwLock;
use std::time::Duration;

use serde::{Deserialize, Serialize};

use agent_protocol::permission::{Decision, Mode, ModeDecision, RememberScope};
use agent_protocol::tool::RiskClass;

use crate::attribution::Attribution;
use crate::modes::mode_decision;
use crate::rules::{Effect, Rule, RuleOrigin, Selector, Subject};

/// A remembered approval (or refusal) granted mid-session.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Grant {
    /// The pattern, in §10.4 syntax.
    pub pattern: String,
    /// The compiled rule.
    pub rule: Rule,
    /// Absolute expiry (ms since epoch); `None` = end of session.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub expires_at_ms: Option<u64>,
    /// Scope the user chose.
    pub scope: RememberScope,
    /// Who granted it.
    pub granted_by: String,
    /// Attribution at grant time.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub attribution: Option<Attribution>,
}

impl Grant {
    /// True when the grant has expired relative to `now_ms`.
    #[must_use]
    pub fn is_expired(&self, now_ms: u64) -> bool {
        self.expires_at_ms.is_some_and(|e| e <= now_ms)
    }

    /// Compute the absolute expiry from a TTL.
    #[must_use]
    pub fn expiry_for(scope: RememberScope, ttl: Duration, now_ms: u64) -> Option<u64> {
        match scope {
            RememberScope::ThisTurn => Some(now_ms),
            RememberScope::ThisSession => None,
            RememberScope::Persistent => {
                if ttl.is_zero() { None } else { Some(now_ms + ttl.as_millis() as u64) }
            }
        }
    }
}

/// Why the engine produced a decision. Rendered for users, models and audit.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Explanation {
    /// The effect that won.
    pub effect: Effect,
    /// Human sentence, e.g. `denied by rule #3 shell(rm -rf **) at .agent/config.toml:12`.
    pub text: String,
    /// Index of the winning rule in the rule list, if a rule decided it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rule_index: Option<usize>,
    /// The winning pattern.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pattern: Option<String>,
    /// True when the decision came from the admin-managed layer and cannot be
    /// overridden by the user.
    #[serde(default)]
    pub managed: bool,
    /// Every rule that matched, most specific first. Kept for `--verbose` and
    /// the debug overlay.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub considered: Vec<ConsideredRule>,
}

/// One rule that matched, for the verbose reason tree.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ConsideredRule {
    /// Index in the rule list.
    pub index: usize,
    /// Pattern text.
    pub pattern: String,
    /// Effect.
    pub effect: Effect,
    /// Specificity score.
    pub specificity: u32,
    /// Origin rendering.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub origin: Option<String>,
}

/// The engine's answer.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Verdict {
    /// What to do.
    pub decision: Decision,
    /// Why.
    pub explanation: Explanation,
}

impl Verdict {
    /// True when the call may run without a prompt.
    #[must_use]
    pub fn allows(&self) -> bool {
        self.decision.allows()
    }

    /// True when a human must be consulted.
    #[must_use]
    pub fn needs_human(&self) -> bool {
        self.decision.needs_human()
    }

    /// The one-line reason, for `Event::ToolDenied`.
    #[must_use]
    pub fn reason(&self) -> String {
        self.explanation.text.clone()
    }
}

/// The policy engine.
pub struct PolicyEngine {
    /// Rules sorted so that the first match within an effect is the most
    /// specific one. Sorting is `(effect rank desc, specificity desc)`.
    rules: Vec<Rule>,
    /// Index of each rule in the *original* declaration order, preserved so
    /// `explain()` can say "rule #3" meaningfully.
    original_index: Vec<usize>,
    /// Current mode.
    mode: Mode,
    /// Session grants, newest first.
    grants: RwLock<Vec<Grant>>,
    /// Decision cache.
    cache: RwLock<HashMap<String, Verdict>>,
    /// Hit/miss counters, exported as `policy_cache_hit_ratio`.
    stats: RwLock<CacheStats>,
}

/// Cache effectiveness counters.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct CacheStats {
    /// Cache hits.
    pub hits: u64,
    /// Cache misses.
    pub misses: u64,
    /// Number of full invalidations.
    pub invalidations: u64,
}

impl CacheStats {
    /// Hit ratio in `[0, 1]`; `None` when nothing was evaluated yet.
    #[must_use]
    pub fn hit_ratio(&self) -> Option<f64> {
        let total = self.hits + self.misses;
        if total == 0 { None } else { Some(self.hits as f64 / total as f64) }
    }
}

impl PolicyEngine {
    /// Build an engine from rules. Rules that fail to parse are returned as
    /// errors rather than silently dropped (golden rule #11: no silent
    /// fallback) — a typo'd deny rule that vanishes is a security hole.
    ///
    /// # Errors
    /// One entry per malformed pattern, with its origin.
    pub fn new(
        mode: Mode,
        allow: &[String],
        deny: &[String],
        ask: &[String],
        origins: impl Fn(Effect) -> Option<RuleOrigin>,
    ) -> Result<Self, Vec<(String, String)>> {
        let mut errors = Vec::new();
        let mut rules: Vec<(usize, Rule)> = Vec::new();
        // Rule numbers are assigned in evaluation order (deny, ask, allow) and
        // are what `explain()` prints as "rule #N". They are stable for the
        // lifetime of the engine, which is all a support conversation needs.
        let mut next_index = 0usize;
        for (effect, list) in [(Effect::Deny, deny), (Effect::Ask, ask), (Effect::Allow, allow)] {
            let origin = origins(effect);
            for p in list.iter() {
                let i = next_index;
                next_index += 1;
                match Rule::parse_with_origin(p, effect, origin.clone()) {
                    Ok(mut r) => {
                        // A rule from the managed layer is immutable.
                        if origin.as_ref().is_some_and(|o| o.layer == "managed") {
                            r.managed = true;
                        }
                        rules.push((i, r));
                    }
                    Err(e) => errors.push((p.clone(), e.to_string())),
                }
            }
        }
        if !errors.is_empty() {
            return Err(errors);
        }
        Ok(Self::from_rules(mode, rules.into_iter().map(|(_, r)| r).collect()))
    }

    /// Build from pre-parsed rules.
    #[must_use]
    pub fn from_rules(mode: Mode, mut rules: Vec<Rule>) -> Self {
        let original_index: Vec<usize> = (0..rules.len()).collect();
        // Stable sort: deny > ask > allow, then most specific first.
        let mut paired: Vec<(usize, Rule)> =
            rules.drain(..).zip(original_index.iter().copied()).map(|(r, i)| (i, r)).collect();
        paired.sort_by(|a, b| {
            b.1.effect
                .rank()
                .cmp(&a.1.effect.rank())
                .then_with(|| b.1.specificity().cmp(&a.1.specificity()))
                .then_with(|| a.0.cmp(&b.0))
        });
        let (original_index, rules): (Vec<usize>, Vec<Rule>) = paired.into_iter().unzip();
        Self {
            rules,
            original_index,
            mode,
            grants: RwLock::new(Vec::new()),
            cache: RwLock::new(HashMap::new()),
            stats: RwLock::new(CacheStats::default()),
        }
    }

    /// An engine with no rules at all: everything falls through to the mode.
    #[must_use]
    pub fn permissive(mode: Mode) -> Self {
        Self::from_rules(mode, Vec::new())
    }

    /// Current mode.
    #[must_use]
    pub fn mode(&self) -> Mode {
        self.mode
    }

    /// Switch mode, invalidating the decision cache.
    pub fn set_mode(&mut self, mode: Mode) {
        self.mode = mode;
        self.invalidate("mode change");
    }

    /// The rule set, in evaluation order.
    #[must_use]
    pub fn rules(&self) -> &[Rule] {
        &self.rules
    }

    /// Evaluate a subject.
    ///
    /// # Panics
    /// Never. A poisoned cache lock is treated as a miss (fail-closed: the
    /// decision is recomputed rather than assumed allowed).
    pub fn evaluate(&self, subject: &Subject<'_>) -> Verdict {
        let key = cache_key(subject);
        if let Ok(cache) = self.cache.read() {
            if let Some(v) = cache.get(&key) {
                if let Ok(mut s) = self.stats.write() {
                    s.hits += 1;
                }
                return v.clone();
            }
        }
        if let Ok(mut s) = self.stats.write() {
            s.misses += 1;
        }

        let verdict = self.evaluate_uncached(subject);
        if let Ok(mut cache) = self.cache.write() {
            // Bound the cache: 4096 entries is far more than a session needs
            // and keeps a pathological loop from growing memory forever.
            if cache.len() >= 4096 {
                cache.clear();
            }
            cache.insert(key, verdict.clone());
        }
        verdict
    }

    fn evaluate_uncached(&self, subject: &Subject<'_>) -> Verdict {
        let now = agent_protocol::now_ms();
        let mut considered: Vec<ConsideredRule> = Vec::new();

        // Collect every match once, grouped by effect.
        let mut matches: Vec<(usize, &Rule, u32)> = Vec::new();
        for (slot, rule) in self.rules.iter().enumerate() {
            if let Some(spec) = subject.matches(rule) {
                matches.push((self.original_index[slot], rule, spec));
            }
        }
        // Grants behave like allow rules but are checked after `ask`.
        let grant_matches: Vec<(usize, Rule, u32)> = {
            let grants = self.grants.read().map(|g| g.clone()).unwrap_or_default();
            grants
                .iter()
                .enumerate()
                .filter(|(_, g)| !g.is_expired(now))
                .filter_map(|(i, g)| {
                    subject.matches(&g.rule).map(|spec| (i, g.rule.clone(), spec))
                })
                .collect()
        };

        for (_, rule, spec) in &matches {
            considered.push(ConsideredRule {
                index: self.original_index[self.rules.iter().position(|r| std::ptr::eq(r, *rule)).unwrap_or(0)],
                pattern: rule.pattern(),
                effect: rule.effect,
                specificity: *spec,
                origin: rule.origin.as_ref().map(RuleOrigin::render),
            });
        }
        considered.sort_by(|a, b| b.specificity.cmp(&a.specificity));

        // 1. deny
        if let Some((idx, rule, _spec)) = best_match(&matches, Effect::Deny) {
            return Verdict {
                decision: Decision::Deny { reason: explain(idx, rule) },
                explanation: Explanation {
                    effect: Effect::Deny,
                    text: explain(idx, rule),
                    rule_index: Some(idx),
                    pattern: Some(rule.pattern()),
                    managed: rule.managed,
                    considered,
                },
            };
        }

        // 2. ask
        if let Some((idx, rule, _)) = best_match(&matches, Effect::Ask) {
            return Verdict {
                decision: Decision::Ask,
                explanation: Explanation {
                    effect: Effect::Ask,
                    text: format!("prompt required by rule #{} {}", idx + 1, rule.pattern()),
                    rule_index: Some(idx),
                    pattern: Some(rule.pattern()),
                    managed: rule.managed,
                    considered,
                },
            };
        }

        // 3. session grants
        if let Some((gi, grant, _spec)) = best_grant(&grant_matches) {
            return Verdict {
                decision: Decision::Allow,
                explanation: Explanation {
                    effect: Effect::Allow,
                    text: format!("allowed by remembered grant #{gi} {}", grant.pattern()),
                    rule_index: None,
                    pattern: Some(grant.pattern()),
                    managed: false,
                    considered,
                },
            };
        }

        // 4. allow
        if let Some((idx, rule, _)) = best_match(&matches, Effect::Allow) {
            return Verdict {
                decision: Decision::Allow,
                explanation: Explanation {
                    effect: Effect::Allow,
                    text: format!("allowed by rule #{} {}", idx + 1, rule.pattern()),
                    rule_index: Some(idx),
                    pattern: Some(rule.pattern()),
                    managed: rule.managed,
                    considered,
                },
            };
        }

        // 5. mode default
        let md = mode_decision(self.mode, subject.risk);
        let text = match md {
            ModeDecision::Allow => format!("allowed by mode `{}` ({} is automatic)", self.mode, subject.risk),
            ModeDecision::Ask => format!("mode `{}` requires approval for {}", self.mode, subject.risk),
            ModeDecision::Deny => format!("denied by mode `{}`: {} is not permitted", self.mode, subject.risk),
        };
        let decision = match md {
            ModeDecision::Allow => Decision::Allow,
            ModeDecision::Ask => Decision::Ask,
            ModeDecision::Deny => Decision::Deny { reason: text.clone() },
        };
        Verdict {
            decision,
            explanation: Explanation {
                effect: match md {
                    ModeDecision::Allow => Effect::Allow,
                    ModeDecision::Ask => Effect::Ask,
                    ModeDecision::Deny => Effect::Deny,
                },
                text,
                rule_index: None,
                pattern: None,
                managed: false,
                considered,
            },
        }
    }

    /// Remember a decision as a session grant.
    ///
    /// # Errors
    /// When the pattern cannot be parsed; nothing is recorded in that case.
    pub fn remember(
        &self,
        pattern: &str,
        effect: Effect,
        scope: RememberScope,
        ttl: Duration,
        granted_by: &str,
    ) -> Result<(), String> {
        let rule = Rule::parse_with_origin(
            pattern,
            effect,
            Some(RuleOrigin { layer: "session-grant".into(), path: None, line: None }),
        )
        .map_err(|e| e.to_string())?;
        let now = agent_protocol::now_ms();
        let grant = Grant {
            pattern: pattern.to_owned(),
            rule,
            expires_at_ms: Grant::expiry_for(scope, ttl, now),
            scope,
            granted_by: granted_by.to_owned(),
            attribution: None,
        };
        if let Ok(mut g) = self.grants.write() {
            g.insert(0, grant);
            // Hard cap so a long session cannot grow this without bound.
            if g.len() > 1024 {
                g.truncate(1024);
            }
        }
        self.invalidate("grant added");
        Ok(())
    }

    /// Drop every grant matching a pattern. Returns how many were removed.
    pub fn revoke(&self, pattern: &str) -> usize {
        let removed = self
            .grants
            .write()
            .map(|mut g| {
                let before = g.len();
                g.retain(|x| x.pattern != pattern);
                before - g.len()
            })
            .unwrap_or(0);
        if removed > 0 {
            self.invalidate("grant revoked");
        }
        removed
    }

    /// Drop every expired grant. Returns how many were removed.
    pub fn prune_expired(&self) -> usize {
        let now = agent_protocol::now_ms();
        let removed = self
            .grants
            .write()
            .map(|mut g| {
                let before = g.len();
                g.retain(|x| !x.is_expired(now));
                before - g.len()
            })
            .unwrap_or(0);
        if removed > 0 {
            self.invalidate("grants expired");
        }
        removed
    }

    /// Current grants, newest first.
    #[must_use]
    pub fn grants(&self) -> Vec<Grant> {
        self.grants.read().map(|g| g.clone()).unwrap_or_default()
    }

    /// Cache statistics.
    #[must_use]
    pub fn cache_stats(&self) -> CacheStats {
        self.stats.read().map(|s| *s).unwrap_or_default()
    }

    /// Drop every cached decision. Called on any state change that could
    /// affect an answer: grants, mode, rules, config reload.
    pub fn invalidate(&self, _reason: &str) {
        if let Ok(mut c) = self.cache.write() {
            c.clear();
        }
        if let Ok(mut s) = self.stats.write() {
            s.invalidations += 1;
        }
    }

    /// A snapshot of the effective policy, for `agent config explain` and the
    /// audit record of a session start.
    #[must_use]
    pub fn snapshot(&self) -> PolicySnapshot {
        PolicySnapshot {
            mode: self.mode,
            rules: self.rules.iter().map(|r| (r.effect, r.pattern(), r.managed)).collect(),
            grants: self.grants(),
        }
    }

    /// Reproducibility check: evaluate the same subject twice and assert the
    /// answers are identical. Used by the test matrix (§11.1).
    #[must_use]
    pub fn is_reproducible(&self, subject: &Subject<'_>) -> bool {
        let a = self.evaluate_uncached(subject);
        let b = self.evaluate_uncached(subject);
        a == b
    }
}

impl std::fmt::Debug for PolicyEngine {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PolicyEngine")
            .field("mode", &self.mode)
            .field("rules", &self.rules.len())
            .field("grants", &self.grants.read().map(|g| g.len()).unwrap_or(0))
            .field("cache", &self.cache.read().map(|c| c.len()).unwrap_or(0))
            .finish()
    }
}

/// An immutable record of what policy was in force.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PolicySnapshot {
    /// Mode.
    pub mode: Mode,
    /// `(effect, pattern, managed)` in evaluation order.
    pub rules: Vec<(Effect, String, bool)>,
    /// Session grants at snapshot time.
    pub grants: Vec<Grant>,
}

fn best_match<'a>(matches: &'a [(usize, &'a Rule, u32)], effect: Effect) -> Option<(usize, &'a Rule, u32)> {
    matches
        .iter()
        .filter(|(_, r, _)| r.effect == effect)
        .max_by(|a, b| a.2.cmp(&b.2).then_with(|| b.0.cmp(&a.0)))
        .copied()
}

fn best_grant(matches: &[(usize, Rule, u32)]) -> Option<(usize, &Rule, u32)> {
    matches.iter().max_by(|a, b| a.2.cmp(&b.2)).map(|(i, r, s)| (*i, r, *s))
}

fn explain(idx: usize, rule: &Rule) -> String {
    let origin = rule.origin.as_ref().map(|o| format!(" {}", o.render())).unwrap_or_default();
    let managed = if rule.managed { " (managed, cannot be overridden)" } else { "" };
    format!("denied by rule #{} {}({}){origin}{managed}", idx + 1, rule.tool, rule.selector)
}

fn cache_key(s: &Subject<'_>) -> String {
    use std::fmt::Write as _;
    let mut k = String::with_capacity(128);
    let _ = write!(k, "{}|{}|", s.tool, s.risk.badge());
    for p in s.paths {
        let _ = write!(k, "p:{p};");
    }
    if let Some(c) = s.command {
        let _ = write!(k, "c:{c};");
    }
    if let Some(a) = s.argv {
        for t in a {
            let _ = write!(k, "a:{t};");
        }
    }
    for h in s.hosts {
        let _ = write!(k, "h:{h};");
    }
    k
}

/// Convenience: is this selector an exact (non-wildcard) match? Exposed so the
/// approval UI can warn when "always allow" would grant something broader than
/// the command the user is looking at.
#[must_use]
pub fn selector_is_exact(rule: &Rule) -> bool {
    rule.selector.is_exact()
}

/// Expand a concrete call into the *narrowest* pattern that would remember it.
///
/// This is what the approval overlay shows next to "always allow", so the user
/// sees exactly what they are granting (§3.2).
#[must_use]
pub fn pattern_for(tool: &str, risk: RiskClass, subject: &Subject<'_>) -> String {
    match risk {
        RiskClass::Exec => subject
            .command
            .map(|c| format!("shell({c})"))
            .unwrap_or_else(|| format!("shell({tool})")),
        RiskClass::Network => subject
            .hosts
            .first()
            .map_or_else(|| format!("net(*)"), |h| format!("net({h})")),
        RiskClass::Read => subject
            .paths
            .first()
            .map_or_else(|| "read(*)".to_string(), |p| format!("read({p})")),
        RiskClass::Mutate | RiskClass::Destructive => subject
            .paths
            .first()
            .map_or_else(|| "write(*)".to_string(), |p| format!("write({p})")),
        RiskClass::Spawn | RiskClass::Meta => format!("*({tool})"),
    }
}

/// True when a rule's selector is a bare `*`, i.e. as broad as it gets.
#[must_use]
pub fn is_wildcard_all(rule: &Rule) -> bool {
    matches!(rule.selector, Selector::Everything)
}

#[cfg(test)]
mod tests {
    use super::*;
    use agent_protocol::ids::RequestId;

    fn engine(mode: Mode, allow: &[&str], deny: &[&str], ask: &[&str]) -> PolicyEngine {
        PolicyEngine::new(
            mode,
            &allow.iter().map(|s| s.to_string()).collect::<Vec<_>>(),
            &deny.iter().map(|s| s.to_string()).collect::<Vec<_>>(),
            &ask.iter().map(|s| s.to_string()).collect::<Vec<_>>(),
            |e| {
                Some(RuleOrigin {
                    layer: "test".into(),
                    path: Some(".agent/config.toml".into()),
                    line: Some(match e {
                        Effect::Deny => 12,
                        Effect::Ask => 20,
                        Effect::Allow => 30,
                    }),
                })
            },
        )
        .unwrap()
    }

    #[test]
    fn deny_wins_over_allow_even_with_wildcard_allow() {
        let e = engine(Mode::Bypass, &["shell(**)"], &["shell(rm -rf **)"], &[]);
        let v = e.evaluate(&Subject::shell("shell", "rm -rf /"));
        assert!(v.decision.denies(), "{v:?}");
        assert!(v.explanation.text.contains("rm -rf **"), "{}", v.explanation.text);
        assert!(v.explanation.text.contains(".agent/config.toml:12"), "{}", v.explanation.text);
        // Deny rules are numbered first, so this is rule #1 (index 0).
        assert_eq!(v.explanation.rule_index, Some(0));
    }

    #[test]
    fn deny_wins_even_in_bypass_mode() {
        let e = engine(Mode::Bypass, &[], &["write(secret/**)"], &[]);
        let paths = vec!["secret/key.pem".to_string()];
        let v = e.evaluate(&Subject::paths("write_file", RiskClass::Mutate, &paths));
        assert!(v.decision.denies());
    }

    #[test]
    fn specificity_breaks_ties() {
        // allow(shell(git status)) vs allow(shell(git *)) — both allow, but the
        // engine must report the more specific one.
        let e = engine(Mode::Ask, &["shell(git *)", "shell(git status)"], &[], &[]);
        let v = e.evaluate(&Subject::shell("shell", "git status"));
        assert!(v.allows());
        assert!(v.explanation.text.contains("git status"), "{}", v.explanation.text);
    }

    #[test]
    fn ask_rules_force_a_prompt_even_in_bypass() {
        let e = engine(Mode::Bypass, &["shell(**)"], &[], &["shell(git push **)"]);
        let v = e.evaluate(&Subject::shell("shell", "git push origin main"));
        assert!(v.needs_human(), "{v:?}");
    }

    #[test]
    fn mode_is_the_default_when_no_rule_matches() {
        let e = engine(Mode::Ask, &[], &[], &[]);
        let paths = vec!["src/a.rs".to_string()];
        assert!(e.evaluate(&Subject::paths("read_file", RiskClass::Read, &paths)).allows());
        assert!(e
            .evaluate(&Subject::paths("write_file", RiskClass::Mutate, &paths))
            .needs_human());
        assert!(e.evaluate(&Subject::shell("shell", "cargo build")).needs_human());

        let ro = engine(Mode::ReadOnly, &[], &[], &[]);
        assert!(ro.evaluate(&Subject::paths("write_file", RiskClass::Mutate, &paths)).decision.denies());
        assert!(ro.evaluate(&Subject::shell("shell", "ls")).decision.denies());
    }

    #[test]
    fn plan_mode_denies_mutations_with_an_explanation() {
        let e = engine(Mode::Plan, &[], &[], &[]);
        let paths = vec!["src/a.rs".to_string()];
        let v = e.evaluate(&Subject::paths("edit_file", RiskClass::Mutate, &paths));
        assert!(v.decision.denies());
        assert!(v.explanation.text.contains("plan"), "{}", v.explanation.text);
    }

    #[test]
    fn grants_allow_without_prompting_but_never_override_deny() {
        let e = engine(Mode::Ask, &[], &["shell(rm -rf **)"], &[]);
        e.remember("shell(cargo test *)", Effect::Allow, RememberScope::ThisSession, Duration::ZERO, "user").unwrap();
        assert!(e.evaluate(&Subject::shell("shell", "cargo test api")).allows());
        assert!(e
            .evaluate(&Subject::shell("shell", "rm -rf /"))
            .decision
            .denies(), "a grant must never defeat a deny rule");
    }

    #[test]
    fn grants_expire() {
        let e = engine(Mode::Ask, &[], &[], &[]);
        // TTL of 1ns => already expired by the time we evaluate.
        e.remember("shell(ls)", Effect::Allow, RememberScope::Persistent, Duration::from_nanos(1), "user")
            .unwrap();
        std::thread::sleep(Duration::from_millis(2));
        assert!(e.evaluate(&Subject::shell("shell", "ls")).needs_human());
        assert_eq!(e.prune_expired(), 1);
        assert!(e.grants().is_empty());
    }

    #[test]
    fn revoke_removes_a_grant_and_invalidates_the_cache() {
        let e = engine(Mode::Ask, &[], &[], &[]);
        e.remember("shell(ls)", Effect::Allow, RememberScope::ThisSession, Duration::ZERO, "user").unwrap();
        assert!(e.evaluate(&Subject::shell("shell", "ls")).allows());
        // Cached: still allows.
        assert!(e.evaluate(&Subject::shell("shell", "ls")).allows());
        assert_eq!(e.revoke("shell(ls)"), 1);
        assert!(e.evaluate(&Subject::shell("shell", "ls")).needs_human(), "stale allow after revoke");
    }

    #[test]
    fn cache_is_used_and_counted() {
        let e = engine(Mode::Ask, &["shell(git status)"], &[], &[]);
        for _ in 0..5 {
            e.evaluate(&Subject::shell("shell", "git status"));
        }
        let s = e.cache_stats();
        assert_eq!(s.misses, 1);
        assert_eq!(s.hits, 4);
        assert!((s.hit_ratio().unwrap() - 0.8).abs() < f64::EPSILON);
    }

    #[test]
    fn cache_distinguishes_different_subjects() {
        let e = engine(Mode::Ask, &["shell(git status)"], &[], &[]);
        assert!(e.evaluate(&Subject::shell("shell", "git status")).allows());
        assert!(e.evaluate(&Subject::shell("shell", "git push")).needs_human());
        assert_eq!(e.cache_stats().misses, 2);
    }

    #[test]
    fn malformed_rules_are_a_hard_error_not_a_silent_drop() {
        let err = PolicyEngine::new(Mode::Ask, &["shell(git status".into()], &[], &[], |_| None)
            .unwrap_err();
        assert_eq!(err.len(), 1);
        assert!(err[0].1.contains("must look like"), "{:?}", err[0]);
    }

    #[test]
    fn decisions_are_reproducible() {
        let e = engine(Mode::Ask, &["shell(git *)"], &["shell(rm -rf **)"], &["shell(git push **)"]);
        for cmd in ["git status", "rm -rf /", "git push origin main", "cargo build"] {
            assert!(e.is_reproducible(&Subject::shell("shell", cmd)), "{cmd}");
        }
    }

    #[test]
    fn snapshot_captures_mode_rules_and_grants() {
        let e = engine(Mode::AutoEdit, &["read(src/**)"], &["write(secret/**)"], &[]);
        e.remember("shell(ls)", Effect::Allow, RememberScope::ThisSession, Duration::ZERO, "user").unwrap();
        let s = e.snapshot();
        assert_eq!(s.mode, Mode::AutoEdit);
        assert!(s.rules.iter().any(|(_, p, _)| p == "write(secret/**)"));
        assert_eq!(s.grants.len(), 1);
        // A snapshot must be serialisable for the audit record.
        let json = serde_json::to_string(&s).unwrap();
        assert!(json.contains("secret"));
    }

    #[test]
    fn managed_rules_are_flagged() {
        let rules = vec![Rule::parse_with_origin(
            "shell(git push --force **)",
            Effect::Deny,
            Some(RuleOrigin { layer: "managed".into(), path: Some("/etc/agent/policy.toml".into()), line: Some(4) }),
        )
        .unwrap()
        .managed()];
        let e = PolicyEngine::from_rules(Mode::Bypass, rules);
        let v = e.evaluate(&Subject::shell("shell", "git push --force origin main"));
        assert!(v.decision.denies());
        assert!(v.explanation.managed, "{:?}", v.explanation);
        assert!(v.explanation.text.contains("managed"), "{}", v.explanation.text);
    }

    #[test]
    fn pattern_for_produces_the_narrowest_rememberable_pattern() {
        let s = Subject::shell("shell", "cargo test api");
        assert_eq!(pattern_for("shell", RiskClass::Exec, &s), "shell(cargo test api)");
        let hosts = vec!["api.example.com".to_string()];
        assert_eq!(pattern_for("web_fetch", RiskClass::Network, &Subject::net("web_fetch", &hosts)), "net(api.example.com)");
        let paths = vec!["src/a.rs".to_string()];
        assert_eq!(pattern_for("write_file", RiskClass::Mutate, &Subject::paths("write_file", RiskClass::Mutate, &paths)), "write(src/a.rs)");
    }

    #[test]
    fn grant_expiry_follows_scope() {
        let now = 1_000_000;
        assert_eq!(Grant::expiry_for(RememberScope::ThisTurn, Duration::from_secs(60), now), Some(now));
        assert_eq!(Grant::expiry_for(RememberScope::ThisSession, Duration::from_secs(60), now), None);
        assert_eq!(
            Grant::expiry_for(RememberScope::Persistent, Duration::from_secs(60), now),
            Some(now + 60_000)
        );
        assert_eq!(Grant::expiry_for(RememberScope::Persistent, Duration::ZERO, now), None);
    }

    #[test]
    fn a_request_id_is_not_needed_to_evaluate() {
        // Evaluation is a pure function of the subject; the request id only
        // exists so the UI can correlate an answer.
        let _ = RequestId::new();
        let e = engine(Mode::Ask, &[], &[], &[]);
        assert!(e.evaluate(&Subject::shell("shell", "ls")).needs_human());
    }

    #[test]
    fn wildcard_detection_works() {
        let r = Rule::parse("*(*)", Effect::Allow).unwrap();
        assert!(is_wildcard_all(&r));
        let r2 = Rule::parse("shell(ls)", Effect::Allow).unwrap();
        assert!(!is_wildcard_all(&r2));
        assert!(selector_is_exact(&r2));
    }
}
