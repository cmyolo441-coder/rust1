//! Attribution (`rustplan.txt` §9.5 `src/attribution.rs`, §6.4).
//!
//! "Who did this?" has to be answerable months later, from the audit log alone,
//! for an action taken by a *sub-agent worker* running a *different model* on a
//! *different provider*, triggered by a prompt the user never typed. That needs
//! more than a username.
//!
//! An [`Attribution`] therefore records the full causal chain:
//!
//! ```text
//! user → thread → turn → (worker → parent turn) → model/provider → tool call
//! ```
//!
//! plus a fingerprint of the system prompt that produced the call, so "the model
//! was told X" is verifiable without storing the prompt itself (§6.4: prompts
//! are code, and code is versioned — the fingerprint ties a decision to a
//! version).

use serde::{Deserialize, Serialize};

use agent_protocol::ids::{CallId, RequestId, ThreadId, TurnId};

/// Full causal attribution for one action.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Attribution {
    /// Human identity, when a human is in the loop.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub user: Option<String>,
    /// Thread the action belongs to.
    pub thread_id: ThreadId,
    /// Turn, when the action belongs to one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Worker id, when a sub-agent acted.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub worker_id: Option<String>,
    /// The worker's parent turn — the turn that spawned it. Lets an auditor walk
    /// up the tree without any other state.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub parent_turn_id: Option<TurnId>,
    /// Model that produced the tool call.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    /// Provider.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider: Option<String>,
    /// Provider request id (`req_…`), for correlating with provider-side logs.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub request_id: Option<RequestId>,
    /// The tool call id.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub call_id: Option<CallId>,
    /// blake3 fingerprint (8 hex) of the system prompt in force.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prompt_fingerprint: Option<String>,
    /// Build version of the agent binary.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agent_version: Option<String>,
    /// Wall clock, ms since epoch.
    pub ts_ms: u64,
}

impl Attribution {
    /// Minimal attribution for a user-initiated action.
    #[must_use]
    pub fn user(user: impl Into<String>, thread_id: ThreadId) -> Self {
        Self {
            user: Some(user.into()),
            thread_id,
            turn_id: None,
            worker_id: None,
            parent_turn_id: None,
            model: None,
            provider: None,
            request_id: None,
            call_id: None,
            prompt_fingerprint: None,
            agent_version: Some(agent_protocol::BUILD_VERSION.to_string()),
            ts_ms: agent_protocol::now_ms(),
        }
    }

    /// Attribution for a model-initiated tool call.
    #[must_use]
    pub fn model_call(
        thread_id: ThreadId,
        turn_id: TurnId,
        model: impl Into<String>,
        provider: impl Into<String>,
        call_id: CallId,
    ) -> Self {
        Self {
            user: None,
            thread_id,
            turn_id: Some(turn_id),
            worker_id: None,
            parent_turn_id: None,
            model: Some(model.into()),
            provider: Some(provider.into()),
            request_id: None,
            call_id: Some(call_id),
            prompt_fingerprint: None,
            agent_version: Some(agent_protocol::BUILD_VERSION.to_string()),
            ts_ms: agent_protocol::now_ms(),
        }
    }

    /// Derive a worker's attribution from the turn that spawned it.
    #[must_use]
    pub fn for_worker(mut self, worker_id: impl Into<String>, spawner: &Attribution) -> Self {
        self.worker_id = Some(worker_id.into());
        self.parent_turn_id = spawner.turn_id;
        if self.user.is_none() {
            self.user = spawner.user.clone();
        }
        self
    }

    /// Attach the prompt fingerprint.
    #[must_use]
    pub fn with_prompt(mut self, fingerprint: impl Into<String>) -> Self {
        self.prompt_fingerprint = Some(fingerprint.into());
        self
    }

    /// Attach a provider request id.
    #[must_use]
    pub fn with_request(mut self, request_id: RequestId) -> Self {
        self.request_id = Some(request_id);
        self
    }

    /// True when a model — not a human — originated the action.
    #[must_use]
    pub const fn is_model_originated(&self) -> bool {
        self.model.is_some() && self.user.is_none()
    }

    /// True when a sub-agent acted. Actions by workers get an extra line in
    /// incident reports because the user never saw the reasoning.
    #[must_use]
    pub const fn is_worker(&self) -> bool {
        self.worker_id.is_some()
    }

    /// One-line rendering for reports and logs.
    #[must_use]
    pub fn label(&self) -> String {
        let who = match (&self.user, &self.model) {
            (Some(u), Some(m)) => format!("{u}+model:{m}"),
            (Some(u), None) => format!("user:{u}"),
            (None, Some(m)) => format!("model:{m}"),
            (None, None) => "system".to_string(),
        };
        let worker = self.worker_id.as_ref().map(|w| format!(" worker:{w}")).unwrap_or_default();
        let turn = self.turn_id.as_ref().map(|t| format!(" turn:{}", t.body())).unwrap_or_default();
        format!("{who}{worker}{turn}")
    }

    /// Flatten into `key=value` pairs for an audit record's detail map.
    #[must_use]
    pub fn to_detail(&self) -> Vec<(String, String)> {
        let mut out = Vec::new();
        if let Some(u) = &self.user {
            out.push(("actor_user".into(), u.clone()));
        }
        out.push(("actor_thread".into(), self.thread_id.to_string()));
        if let Some(t) = &self.turn_id {
            out.push(("actor_turn".into(), t.to_string()));
        }
        if let Some(w) = &self.worker_id {
            out.push(("actor_worker".into(), w.clone()));
        }
        if let Some(p) = &self.parent_turn_id {
            out.push(("actor_parent_turn".into(), p.to_string()));
        }
        if let Some(m) = &self.model {
            out.push(("actor_model".into(), m.clone()));
        }
        if let Some(p) = &self.provider {
            out.push(("actor_provider".into(), p.clone()));
        }
        if let Some(r) = &self.request_id {
            out.push(("actor_request".into(), r.to_string()));
        }
        if let Some(c) = &self.call_id {
            out.push(("actor_call".into(), c.to_string()));
        }
        if let Some(f) = &self.prompt_fingerprint {
            out.push(("prompt_fingerprint".into(), f.clone()));
        }
        if let Some(v) = &self.agent_version {
            out.push(("agent_version".into(), v.clone()));
        }
        out
    }
}

/// Fingerprint a system prompt so a decision can be tied to a prompt version
/// without storing the prompt.
#[must_use]
pub fn prompt_fingerprint(system_prompt: &str) -> String {
    blake3::hash(system_prompt.as_bytes()).to_hex()[..8].to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn user_attribution_labels_the_human() {
        let a = Attribution::user("dev", ThreadId::new());
        assert!(!a.is_model_originated());
        assert!(a.label().starts_with("user:dev"), "{}", a.label());
        assert_eq!(a.agent_version.as_deref(), Some(agent_protocol::BUILD_VERSION));
    }

    #[test]
    fn model_attribution_labels_the_model() {
        let a = Attribution::model_call(
            ThreadId::new(),
            TurnId::new(),
            "gpt-5",
            "openai",
            CallId::new(),
        );
        assert!(a.is_model_originated());
        assert!(a.label().contains("model:gpt-5"), "{}", a.label());
        assert!(!a.is_worker());
    }

    #[test]
    fn worker_attribution_carries_the_parent_turn() {
        let parent = Attribution::model_call(ThreadId::new(), TurnId::new(), "gpt-5", "openai", CallId::new());
        let w = Attribution::model_call(parent.thread_id, TurnId::new(), "haiku", "anthropic", CallId::new())
            .for_worker("wkr_1", &parent);
        assert!(w.is_worker());
        assert_eq!(w.parent_turn_id, parent.turn_id);
        assert!(w.label().contains("worker:wkr_1"), "{}", w.label());
    }

    #[test]
    fn detail_pairs_cover_every_present_field() {
        let a = Attribution::model_call(ThreadId::new(), TurnId::new(), "gpt-5", "openai", CallId::new())
            .with_prompt(prompt_fingerprint("you are an agent"))
            .with_request(RequestId::new());
        let d = a.to_detail();
        for key in ["actor_thread", "actor_turn", "actor_model", "actor_provider", "actor_call", "prompt_fingerprint", "actor_request", "agent_version"] {
            assert!(d.iter().any(|(k, _)| k == key), "missing {key} in {d:?}");
        }
    }

    #[test]
    fn prompt_fingerprints_are_stable_and_discriminating() {
        let a = prompt_fingerprint("you are a coding agent");
        let b = prompt_fingerprint("you are a coding agent");
        let c = prompt_fingerprint("you are a coding agent.");
        assert_eq!(a, b);
        assert_ne!(a, c);
        assert_eq!(a.len(), 8);
    }

    #[test]
    fn attribution_round_trips_through_json() {
        let a = Attribution::user("dev", ThreadId::new()).with_prompt("abcd1234".to_string());
        let json = serde_json::to_string(&a).unwrap();
        let back: Attribution = serde_json::from_str(&json).unwrap();
        assert_eq!(back, a);
    }
}
