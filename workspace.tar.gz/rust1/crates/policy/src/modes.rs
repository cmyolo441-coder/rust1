//! Permission modes and mode transitions (`rustplan.txt` §3, §6.4, §9.5
//! `src/modes.rs`).
//!
//! Five modes, from most to least restrictive:
//!
//! | mode        | reads | edits | shell/net | spawn |
//! |-------------|-------|-------|-----------|-------|
//! | `plan`      | ✔     | ✖     | ✖         | ✖     |
//! | `read-only` | ✔     | ✖     | read-only | ✖     |
//! | `ask`       | ✔     | ask   | ask       | ask   |
//! | `auto-edit` | ✔     | ✔     | ask       | ask   |
//! | `bypass`    | ✔     | ✔     | ✔         | ✔     |
//!
//! The table itself lives in `protocol::permission::Mode::decide` so that the
//! TUI badge, the ACP surface and the engine can never disagree. What lives
//! *here* is everything the table does not cover:
//!
//! * the **baseline rule set** every mode gets for free (deny on `.git`,
//!   `~/.ssh`, private keys, `sudo`, curl-pipe-shell, …) — a user who writes an
//!   empty config is still protected;
//! * **transitions**, with the rule that `bypass` cannot be entered from inside
//!   a running session (§3: it is a CLI flag, and entering it mid-session is how
//!   a prompt injection escalates);
//! * the **managed ceiling**: an admin can pin `max_mode = read-only` and no
//!   amount of user action raises it.

use serde::{Deserialize, Serialize};

use agent_protocol::permission::{Mode, ModeDecision};
use agent_protocol::tool::RiskClass;

/// The mode decision for a risk class under a mode. Thin wrapper over the
/// protocol table so `engine.rs` has one place to call.
#[must_use]
pub fn mode_decision(mode: Mode, risk: RiskClass) -> ModeDecision {
    mode.decide(risk)
}

/// Everything the UI and `agent config explain` need about a mode.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ModeInfo {
    /// The mode.
    pub mode: Mode,
    /// One-word badge for the status line.
    pub badge: &'static str,
    /// One-sentence description shown in the mode picker.
    pub blurb: &'static str,
    /// Longer explanation for `agent modes --explain`.
    pub detail: &'static str,
    /// True when the mode may mutate the workspace without a prompt.
    pub auto_edits: bool,
    /// True when the mode may execute without a prompt.
    pub auto_execs: bool,
    /// True when entering this mode requires a CLI flag / restart.
    pub requires_restart: bool,
    /// ANSI colour hint (256-colour index) for the badge.
    pub color: u8,
}

/// Metadata for all five modes, in escalating order.
#[must_use]
pub const fn all_modes() -> [ModeInfo; 5] {
    [
        ModeInfo {
            mode: Mode::Plan,
            badge: "PLAN",
            blurb: "Research and plan only — nothing is written or executed.",
            detail: concat!(
                "Reads are automatic. Every mutating tool, every shell command and every ",
                "network call is denied. Use it to have the agent investigate a codebase and ",
                "produce a plan you can review before any change happens."
            ),
            auto_edits: false,
            auto_execs: false,
            requires_restart: false,
            color: 39,
        },
        ModeInfo {
            mode: Mode::ReadOnly,
            badge: "READ-ONLY",
            blurb: "Reads plus a curated set of safe read-only commands.",
            detail: concat!(
                "File reads are automatic. Mutations are denied outright. Shell commands are ",
                "allowed only when the classifier rates them read-only (ls, cat, git log, rg, …); ",
                "anything else is denied, not prompted — this mode is for auditors who need a ",
                "guarantee, not a conversation."
            ),
            auto_edits: false,
            auto_execs: false,
            requires_restart: false,
            color: 45,
        },
        ModeInfo {
            mode: Mode::Ask,
            badge: "ASK",
            blurb: "Default. Reads run; everything else asks first.",
            detail: concat!(
                "The safe-by-default mode. Reads and meta tools run automatically; every edit, ",
                "shell command, network call and worker spawn raises an approval prompt showing ",
                "the exact argv, the cwd, a risk badge and what 'always allow' would grant."
            ),
            auto_edits: false,
            auto_execs: false,
            requires_restart: false,
            color: 214,
        },
        ModeInfo {
            mode: Mode::AutoEdit,
            badge: "AUTO-EDIT",
            blurb: "Edits inside the workspace run; shell and network still ask.",
            detail: concat!(
                "File writes inside the project are automatic. Destructive operations (delete, ",
                "move, anything outside the workspace), shell execution and network access still ",
                "prompt. Good for long refactor sessions where you trust the edit budget but not ",
                "arbitrary commands."
            ),
            auto_edits: true,
            auto_execs: false,
            requires_restart: false,
            color: 118,
        },
        ModeInfo {
            mode: Mode::Bypass,
            badge: "BYPASS",
            blurb: "No prompts. Only reachable with --dangerously-bypass, never mid-session.",
            detail: concat!(
                "Every tool runs without asking, including network and worker spawn. Deny rules ",
                "still apply and ask rules still force a prompt, because a managed policy must ",
                "survive a user's impatience. Entering this mode from inside a session is refused: ",
                "it requires the CLI flag plus a typed acknowledgement, so a prompt injection ",
                "cannot escalate itself."
            ),
            auto_edits: true,
            auto_execs: true,
            requires_restart: true,
            color: 196,
        },
    ]
}

/// Look up a mode's metadata.
#[must_use]
pub fn info(mode: Mode) -> ModeInfo {
    all_modes().into_iter().find(|m| m.mode == mode).unwrap_or_else(|| all_modes()[2].clone())
}

/// Rank of a mode from most (0) to least (4) restrictive.
#[must_use]
pub const fn rank(mode: Mode) -> u8 {
    match mode {
        Mode::Plan => 0,
        Mode::ReadOnly => 1,
        Mode::Ask => 2,
        Mode::AutoEdit => 3,
        Mode::Bypass => 4,
    }
}

/// True when `candidate` is at least as permissive as `ceiling`.
#[must_use]
pub fn exceeds_ceiling(candidate: Mode, ceiling: Mode) -> bool {
    rank(candidate) > rank(ceiling)
}

/// Expand a command prefix into the two argv patterns that cover it, in the
/// grammar of §10.4: an exact match and a "this prefix plus anything" match.
///
/// ```text
/// shell_prefix("git push") == ["shell(git push)", "shell(git push **)"]
/// ```
///
/// `**` matches zero or more trailing tokens, so the pair covers both
/// `git push` and `git push origin main`. Writing `shell(git push*)` instead
/// would match neither: `push*` is a *single-token* glob and the matcher
/// requires the whole argv to be consumed.
#[must_use]
pub fn shell_prefix(command: &str) -> Vec<String> {
    vec![format!("shell({command})"), format!("shell({command} **)")]
}

/// Expand every entry of a command-prefix list.
fn expand(prefixes: &[&str]) -> Vec<String> {
    prefixes.iter().flat_map(|p| shell_prefix(p)).collect()
}

/// Command prefixes denied in **every** mode, including `bypass` (§6.4: fail
/// closed). These are the "you cannot shoot yourself in the foot even with an
/// empty config file" rules. A user may add to them; only a managed policy may
/// subtract, and doing so is itself audited.
#[must_use]
pub fn baseline_shell_deny() -> Vec<&'static str> {
    vec![
        // Irreversible filesystem damage.
        "rm -rf /",
        "rm -rf /*",
        "rm -rf ~",
        "rm -fr /",
        "rm -fr ~",
        // Privilege escalation.
        "sudo",
        "doas",
        "pkexec",
        "su",
        // Block devices and filesystems.
        "mkfs",
        "dd",
        "fdisk",
        "parted",
        // Power state.
        "shutdown",
        "reboot",
        "halt",
        "poweroff",
        // Sandbox escape hatches: these defeat every other layer.
        "bwrap",
        "unshare",
        "nsenter",
        "chroot",
        "setenforce",
        "semanage",
        // History rewriting / leaking.
        "git push --force",
        "git push -f",
        "git reset --hard",
        "git clean -fdx",
        "git filter-branch",
        "git update-ref -d",
        "git checkout -f",
        // Service state.
        "systemctl stop",
        "systemctl disable",
        "service --stop",
    ]
}

/// Path and host patterns denied in every mode.
#[must_use]
pub fn baseline_path_deny() -> Vec<&'static str> {
    vec![
        // Version control internals: rewriting these can hide history.
        "write(.git/**)",
        "write(**/.git/**)",
        // Credential material.
        "read(~/.ssh/**)",
        "read(**/.ssh/**)",
        "read(~/.gnupg/**)",
        "read(**/.gnupg/**)",
        "read(~/.aws/credentials)",
        "read(**/.aws/credentials)",
        "read(~/.config/gh/hosts.yml)",
        "write(~/.ssh/**)",
        "write(**/.ssh/**)",
        "write(**/*.pem)",
        "write(**/*.key)",
        "write(**/*.p12)",
        "write(**/id_rsa*)",
        "write(**/.env)",
        "write(**/.env.*)",
        "read(**/.env)",
        "read(**/.env.*)",
        // Outside the workspace.
        "write(/etc/**)",
        "write(/usr/**)",
        "write(/bin/**)",
        "write(/sbin/**)",
        "write(/boot/**)",
        "write(~/.bashrc)",
        "write(~/.zshrc)",
        "write(~/.profile)",
        "write(~/.config/agent/managed/**)",
        // The agent's own state: editing the audit log is how you hide.
        "write(**/audit.jsonl)",
        "write(**/rollout-*.jsonl)",
        // Cloud metadata endpoints (SSRF / credential theft).
        "net(169.254.169.254)",
        "net(metadata.google.internal)",
        "net(169.254.170.2)",
    ]
}

/// The full baseline deny set: shell prefixes expanded, plus path/host rules.
#[must_use]
pub fn baseline_deny() -> Vec<String> {
    let mut out = expand(&baseline_shell_deny());
    out.extend(baseline_path_deny().iter().map(|s| (*s).to_string()));
    out
}

/// Command prefixes that always prompt, in any mode that would otherwise run
/// them automatically. They install code, publish artefacts, or talk to a
/// cluster — the three things a human should see before they happen.
#[must_use]
pub fn baseline_shell_ask() -> Vec<&'static str> {
    vec![
        // Package installation touches the network *and* runs install scripts.
        "npm install",
        "npm i",
        "npm ci",
        "yarn add",
        "yarn install",
        "pnpm add",
        "pnpm install",
        "pip install",
        "pip3 install",
        "uv pip install",
        "cargo install",
        "cargo add",
        "apt install",
        "apt-get install",
        "brew install",
        "gem install",
        "go install",
        // Publishing / pushing crosses a boundary.
        "git push",
        "cargo publish",
        "npm publish",
        "yarn publish",
        "twine upload",
        // Downloads: remote code or remote data entering the workspace.
        "curl",
        "wget",
        // Infrastructure and clusters.
        "kubectl",
        "helm",
        "terraform apply",
        "terraform destroy",
        "aws",
        "gcloud",
        "az",
        "docker run",
        "docker system prune",
        // Containers/VMs.
        "ssh",
        "scp",
        "rsync",
    ]
}

/// Baseline ask rules, expanded.
#[must_use]
pub fn baseline_ask() -> Vec<String> {
    expand(&baseline_shell_ask())
}

/// Read-only commands that `read-only` mode may run without a prompt. Curated:
/// the classifier's opinion is not enough on its own for a mode whose whole
/// promise is "nothing changed".
#[must_use]
pub fn readonly_allowlist() -> Vec<&'static str> {
    vec![
        "ls", "ll", "la", "pwd", "cat", "head", "tail", "less", "more", "wc", "nl",
        "file", "stat", "du", "df", "tree", "find", "realpath", "dirname", "basename",
        "grep", "egrep", "fgrep", "rg", "ag", "ack", "sed -n", "awk", "cut", "sort",
        "uniq", "diff", "cmp", "comm", "tr", "column", "jq", "yq", "tomlq",
        "echo", "printf", "date", "uname", "hostname", "whoami", "id", "env", "printenv",
        "which", "whereis", "type", "ps", "top -b", "free", "uptime", "lsof",
        "git status", "git log", "git show", "git diff", "git branch", "git remote -v",
        "git rev-parse", "git describe", "git blame", "git ls-files", "git tag",
        "git config --get", "git shortlog", "git stash list", "git worktree list",
        "cargo tree", "cargo metadata", "cargo --version", "rustc --version",
        "node --version", "python --version", "python3 --version", "npm ls", "pip list",
    ]
}

/// Per-mode extra rules layered on top of the baseline.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct ModeRules {
    /// Additional allow patterns.
    pub allow: Vec<String>,
    /// Additional ask patterns.
    pub ask: Vec<String>,
    /// Additional deny patterns.
    pub deny: Vec<String>,
}

/// The default rule set a mode ships with.
///
/// Note the deliberate asymmetry: `read-only` gets an *allow* list of commands
/// (curated above), while `plan` gets none at all — plan mode is for reading
/// files and thinking, not for shelling out.
#[must_use]
pub fn default_rules(mode: Mode) -> ModeRules {
    match mode {
        Mode::Plan => ModeRules {
            allow: Vec::new(),
            // Read-only shell is still a mutation risk surface (it can hang,
            // fork-bomb, or exfiltrate through argv), so plan mode prompts
            // rather than allows — and the mode table denies everything else.
            ask: Vec::new(),
            deny: vec!["shell(**)".into(), "net(*)".into(), "write(**)".into()],
        },
        Mode::ReadOnly => ModeRules {
            allow: readonly_allowlist().iter().flat_map(|c| shell_prefix(c)).collect(),
            ask: Vec::new(),
            deny: vec!["write(**)".into(), "net(*)".into()],
        },
        Mode::Ask => ModeRules {
            allow: Vec::new(),
            ask: baseline_ask(),
            deny: Vec::new(),
        },
        Mode::AutoEdit => ModeRules {
            // Edits are automatic *inside the workspace only*; the path
            // confinement check in tools/ owns the rest.
            allow: vec!["write(**)".into()],
            ask: baseline_ask(),
            deny: Vec::new(),
        },
        Mode::Bypass => ModeRules {
            allow: vec!["*(*)".into()],
            // Even in bypass these must stop and ask: they are irreversible or
            // externally visible.
            ask: [
                "git push",
                "cargo publish",
                "npm publish",
                "rm -rf",
                "kubectl delete",
                "terraform destroy",
            ]
            .iter()
            .flat_map(|c| shell_prefix(c))
            .collect(),
            deny: Vec::new(),
        },
    }
}

/// A requested mode change and whether it is legal.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ModeTransition {
    /// From.
    pub from: Mode,
    /// To.
    pub to: Mode,
    /// True when this escalates privileges.
    pub escalates: bool,
    /// True when the transition needs a typed acknowledgement.
    pub needs_acknowledgement: bool,
    /// The acknowledgement phrase, when one is needed.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub acknowledgement: Option<String>,
}

/// Why a mode change was refused.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum TransitionError {
    /// A managed policy pins a ceiling below the requested mode.
    #[error("mode `{requested}` exceeds the managed ceiling `{ceiling}`; ask your administrator")]
    ManagedCeiling {
        /// Requested mode.
        requested: Mode,
        /// Ceiling.
        ceiling: Mode,
    },
    /// `bypass` cannot be entered from inside a session.
    #[error("`bypass` can only be entered with --dangerously-bypass at startup, never mid-session")]
    BypassRequiresRestart,
    /// The acknowledgement phrase did not match.
    #[error("acknowledgement required: type `{expected}` to continue")]
    AcknowledgementRequired {
        /// Phrase the user must type.
        expected: String,
    },
    /// Escalating while a turn is executing could apply two rule sets to the
    /// same tool call.
    #[error("cannot change mode while a turn is {state}; interrupt first")]
    TurnInFlight {
        /// Turn state label.
        state: String,
    },
}

/// The acknowledgement phrase for entering `bypass`.
pub const BYPASS_ACK: &str = "I understand the risks";

/// Evaluate a mode change.
///
/// # Errors
/// [`TransitionError`] when the change is not permitted. Nothing has been
/// mutated when this returns an error.
#[must_use]
pub fn transition(
    from: Mode,
    to: Mode,
    ceiling: Mode,
    bypass_flag_present: bool,
    turn_state: Option<&str>,
) -> Result<ModeTransition, TransitionError> {
    if exceeds_ceiling(to, ceiling) {
        return Err(TransitionError::ManagedCeiling { requested: to, ceiling });
    }
    let escalates = rank(to) > rank(from);
    let needs_acknowledgement = to == Mode::Bypass;
    if needs_acknowledgement && !bypass_flag_present {
        return Err(TransitionError::BypassRequiresRestart);
    }
    if escalates && from != to {
        // A mode change mid-turn would mean one tool call is judged by two
        // rule sets. Force the user to interrupt first (§2.6 single writer).
        if let Some(state) = turn_state {
            if !matches!(state, "idle" | "done" | "cancelled" | "failed") {
                return Err(TransitionError::TurnInFlight { state: state.to_string() });
            }
        }
    }
    Ok(ModeTransition {
        from,
        to,
        escalates,
        needs_acknowledgement,
        acknowledgement: needs_acknowledgement.then(|| BYPASS_ACK.to_string()),
    })
}

/// Check a typed acknowledgement against the expected phrase. Case-sensitive on
/// purpose: the point is friction, not convenience.
///
/// # Errors
/// [`TransitionError::AcknowledgementRequired`] when it does not match.
pub fn check_acknowledgement(typed: &str, expected: &str) -> Result<(), TransitionError> {
    if typed.trim() == expected {
        Ok(())
    } else {
        Err(TransitionError::AcknowledgementRequired { expected: expected.to_string() })
    }
}

/// Clamp a mode to a ceiling, used at config load so an operator's
/// `max_mode = "read-only"` wins over a user's `mode = "bypass"`.
#[must_use]
pub fn clamp(mode: Mode, ceiling: Mode) -> Mode {
    if exceeds_ceiling(mode, ceiling) { ceiling } else { mode }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_mode_has_metadata() {
        for m in all_modes() {
            assert!(!m.badge.is_empty());
            assert!(!m.blurb.is_empty());
            assert!(m.detail.len() > 40, "{} detail too short", m.badge);
            assert_eq!(info(m.mode), m);
        }
        assert_eq!(all_modes().len(), 5);
    }

    #[test]
    fn ranks_are_strictly_ordered() {
        let r = [rank(Mode::Plan), rank(Mode::ReadOnly), rank(Mode::Ask), rank(Mode::AutoEdit), rank(Mode::Bypass)];
        assert!(r.windows(2).all(|w| w[0] < w[1]), "{r:?}");
    }

    #[test]
    fn the_mode_table_matches_the_documentation() {
        use ModeDecision::*;
        // plan: nothing but reads.
        assert_eq!(mode_decision(Mode::Plan, RiskClass::Read), Allow);
        assert_eq!(mode_decision(Mode::Plan, RiskClass::Mutate), Deny);
        assert_eq!(mode_decision(Mode::Plan, RiskClass::Exec), Deny);
        // read-only: same.
        assert_eq!(mode_decision(Mode::ReadOnly, RiskClass::Exec), Deny);
        // ask: reads auto, rest prompt.
        assert_eq!(mode_decision(Mode::Ask, RiskClass::Read), Allow);
        assert_eq!(mode_decision(Mode::Ask, RiskClass::Mutate), Ask);
        assert_eq!(mode_decision(Mode::Ask, RiskClass::Exec), Ask);
        assert_eq!(mode_decision(Mode::Ask, RiskClass::Network), Ask);
        // auto-edit: edits auto, exec prompts.
        assert_eq!(mode_decision(Mode::AutoEdit, RiskClass::Mutate), Allow);
        assert_eq!(mode_decision(Mode::AutoEdit, RiskClass::Destructive), Ask);
        assert_eq!(mode_decision(Mode::AutoEdit, RiskClass::Exec), Ask);
        // bypass: everything auto except meta.
        assert_eq!(mode_decision(Mode::Bypass, RiskClass::Exec), Allow);
        assert_eq!(mode_decision(Mode::Bypass, RiskClass::Meta), Ask);
        // Meta always prompts, in every mode: ask_user is the point of it.
        for m in [Mode::Plan, Mode::ReadOnly, Mode::Ask, Mode::AutoEdit, Mode::Bypass] {
            assert_eq!(mode_decision(m, RiskClass::Meta), Ask, "{m}");
        }
    }

    #[test]
    fn default_rules_for_plan_deny_everything_dangerous() {
        let r = default_rules(Mode::Plan);
        assert!(r.deny.contains(&"shell(**)".to_string()));
        assert!(r.deny.contains(&"write(**)".to_string()));
        assert!(r.allow.is_empty(), "plan mode must not auto-allow anything");
    }

    #[test]
    fn read_only_allows_only_the_curated_commands() {
        let r = default_rules(Mode::ReadOnly);
        assert!(r.allow.iter().any(|a| a == "shell(git log **)"));
        assert!(r.allow.iter().any(|a| a == "shell(rg)"));
        assert!(!r.allow.iter().any(|a| a.starts_with("shell(rm")), "{:?}", r.allow);
        assert!(r.deny.contains(&"write(**)".to_string()));
    }

    #[test]
    fn bypass_still_asks_for_irreversible_things() {
        let r = default_rules(Mode::Bypass);
        assert!(r.ask.iter().any(|a| a == "shell(git push **)"));
        assert!(r.ask.iter().any(|a| a == "shell(rm -rf **)"));
        assert_eq!(r.allow, vec!["*(*)".to_string()]);
    }

    #[test]
    fn baseline_deny_covers_the_classic_foot_guns() {
        let b = baseline_deny();
        for needle in [
            "write(.git/**)",
            "read(~/.ssh/**)",
            "shell(sudo)",
            "shell(sudo **)",
            "shell(rm -rf /)",
            "shell(rm -rf / **)",
            "shell(git push --force **)",
            "net(169.254.169.254)",
        ] {
            assert!(b.contains(&needle.to_string()), "missing baseline deny {needle}");
        }
        // A curl-pipe-shell line is denied by the ask layer + the classifier,
        // but the download itself must at least prompt.
        assert!(baseline_ask().contains(&"shell(curl **)".to_string()));
        // Every baseline pattern must parse as a real rule.
        for p in &b {
            assert!(
                crate::rules::Rule::parse(p, crate::rules::Effect::Deny).is_ok(),
                "baseline pattern {p} does not parse"
            );
        }
    }

    #[test]
    fn baseline_ask_and_allowlist_patterns_parse() {
        for p in baseline_ask() {
            assert!(crate::rules::Rule::parse(&p, crate::rules::Effect::Ask).is_ok(), "{p}");
        }
        for c in readonly_allowlist() {
            for p in shell_prefix(c) {
                assert!(crate::rules::Rule::parse(&p, crate::rules::Effect::Allow).is_ok(), "{p}");
            }
        }
        // Every baseline pattern of every kind must parse.
        for p in baseline_deny() {
            assert!(crate::rules::Rule::parse(&p, crate::rules::Effect::Deny).is_ok(), "{p}");
        }
    }

    #[test]
    fn shell_prefix_expansion_matches_both_forms() {
        use crate::rules::{Effect, Rule, Subject};
        for p in shell_prefix("git push") {
            let r = Rule::parse(&p, Effect::Ask).unwrap();
            assert!(
                Subject::shell("shell", "git push").matches(&r).is_some(),
                "{p} should match the bare command"
            );
        }
        let rest = Rule::parse("shell(git push **)", Effect::Ask).unwrap();
        assert!(Subject::shell("shell", "git push origin main").matches(&rest).is_some());
        // And the single-token glob form must NOT be relied upon.
        let wrong = Rule::parse("shell(git push*)", Effect::Ask).unwrap();
        assert!(
            Subject::shell("shell", "git push origin main").matches(&wrong).is_none(),
            "`git push*` is a one-token glob; it cannot match a longer argv"
        );
    }

    #[test]
    fn downgrade_is_always_legal() {
        for from in [Mode::Bypass, Mode::AutoEdit, Mode::Ask] {
            let t = transition(from, Mode::Plan, Mode::Bypass, false, Some("streaming")).unwrap();
            assert!(!t.escalates);
            assert!(!t.needs_acknowledgement);
        }
    }

    #[test]
    fn escalation_mid_turn_is_refused() {
        let err = transition(Mode::Ask, Mode::AutoEdit, Mode::Bypass, false, Some("executing")).unwrap_err();
        assert!(matches!(err, TransitionError::TurnInFlight { .. }), "{err}");
        // ...but is fine once the turn settles.
        assert!(transition(Mode::Ask, Mode::AutoEdit, Mode::Bypass, false, Some("done")).is_ok());
        assert!(transition(Mode::Ask, Mode::AutoEdit, Mode::Bypass, false, None).is_ok());
    }

    #[test]
    fn bypass_needs_the_flag() {
        let err = transition(Mode::Ask, Mode::Bypass, Mode::Bypass, false, None).unwrap_err();
        assert!(matches!(err, TransitionError::BypassRequiresRestart), "{err}");
        let ok = transition(Mode::Ask, Mode::Bypass, Mode::Bypass, true, None).unwrap();
        assert!(ok.needs_acknowledgement);
        assert_eq!(ok.acknowledgement.as_deref(), Some(BYPASS_ACK));
        assert!(ok.escalates);
    }

    #[test]
    fn a_managed_ceiling_caps_the_mode() {
        let err = transition(Mode::Ask, Mode::AutoEdit, Mode::ReadOnly, true, None).unwrap_err();
        match err {
            TransitionError::ManagedCeiling { requested, ceiling } => {
                assert_eq!(requested, Mode::AutoEdit);
                assert_eq!(ceiling, Mode::ReadOnly);
            }
            other => panic!("{other}"),
        }
        assert_eq!(clamp(Mode::Bypass, Mode::Ask), Mode::Ask);
        assert_eq!(clamp(Mode::Plan, Mode::Ask), Mode::Plan);
        assert_eq!(clamp(Mode::Ask, Mode::Bypass), Mode::Ask);
    }

    #[test]
    fn acknowledgement_is_case_sensitive() {
        assert!(check_acknowledgement(BYPASS_ACK, BYPASS_ACK).is_ok());
        assert!(check_acknowledgement(&format!("  {BYPASS_ACK}  "), BYPASS_ACK).is_ok());
        assert!(check_acknowledgement("i understand the risks", BYPASS_ACK).is_err());
        assert!(check_acknowledgement("yes", BYPASS_ACK).is_err());
    }

    #[test]
    fn transition_errors_serialise_for_the_wire() {
        let e = TransitionError::ManagedCeiling { requested: Mode::Bypass, ceiling: Mode::Ask };
        let json = serde_json::to_value(&e).unwrap();
        assert_eq!(json["kind"], "managed_ceiling");
        assert!(json.to_string().contains("bypass"));
    }
}
