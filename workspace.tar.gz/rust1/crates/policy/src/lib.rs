//! # `agent-policy` — the control plane
//!
//! One crate owns the answer to "may this happen?". Everything else in the
//! system asks it and obeys (`rustplan.txt` §6.4, §9.5, §10.4).
//!
//! ```text
//!   config layers ──► managed.rs ──► engine.rs ──► Verdict { decision, explain }
//!        │                              ▲   ▲
//!        └─► modes.rs (baseline rules) ──┘   └── classifier.rs (risk of THIS argv)
//!
//!   redaction.rs ── everything leaving the process
//!   network.rs   ── egress + DNS-rebinding guard + proxy config
//!   audit.rs     ── hash-chained record of every decision
//!   incident.rs  ── reports, kill switch, revocations
//! ```
//!
//! ## The one rule that matters
//!
//! **Deny first.** Evaluation order is `deny → ask → grant → allow → mode`
//! ([`engine::PolicyEngine::evaluate`]). A config containing `allow: ["*"]`
//! still refuses `rm -rf /`, because the baseline deny list in
//! [`modes::baseline_deny`] is merged in before the user's rules and can only be
//! added to. Managed policy merges with most-restrictive-wins
//! ([`managed::merge`]), so an administrator can narrow a developer's config but
//! never widen it.
//!
//! ## The facade
//!
//! [`Policy`] is what `core` holds. It bundles the engine, the redactor, the
//! network policy, the DNS guard and the audit chain behind one type so a call
//! site cannot use one without the others:
//!
//! ```
//! use agent_policy::{Policy, CallContext, PolicyOptions};
//! use agent_protocol::{AgentConfig, RiskClass, ToolCall};
//! use agent_protocol::ids::CallId;
//! use serde_json::json;
//!
//! let cfg = AgentConfig::default();
//! let policy = Policy::from_config(&cfg, PolicyOptions::default()).unwrap();
//!
//! let call = ToolCall::new(CallId::new(), "shell", json!({"command": "rm -rf /"}), RiskClass::Exec);
//! let ctx = CallContext::new("/work/repo");
//! let verdict = policy.evaluate_call(&call, &ctx);
//! assert!(verdict.decision.denies(), "{}", verdict.explanation.text);
//! ```
//!
//! ## Determinism
//!
//! No policy decision reads the clock (except grant expiry), the network, the
//! environment or a random source. Same config + same subject → same verdict,
//! which is what makes [`PolicyEngine::is_reproducible`] a meaningful test and
//! what lets `agent audit explain <record-id>` replay a decision months later.

#![forbid(unsafe_code)]
#![warn(missing_docs, clippy::pedantic)]

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::time::Duration;

use serde::{Deserialize, Serialize};

pub mod attribution;
pub mod audit;
pub mod audit_export;
pub mod classifier;
pub mod engine;
pub mod incident;
pub mod managed;
pub mod modes;
pub mod network;
pub mod redaction;
pub mod rules;

pub use attribution::{prompt_fingerprint, Attribution};
pub use audit::{
    Actor, Anchor, AuditAction, AuditBuilder, AuditChain, AuditError, AuditReader, AuditRecord,
    Outcome, VerifyReport, ANCHOR_INTERVAL, GENESIS_HASH,
};
pub use audit_export::{ExportBatch, ExportFormat, ExportOptions, RotatingJsonl};
pub use classifier::{
    classify_host, classify_path, classify_shell, classify_unknown_tool, parse_command, risk_rank,
    Ambiguity, CommandShape, RiskAssessment, Signal,
};
pub use engine::{
    pattern_for, CacheStats, Explanation, Grant, PolicyEngine, PolicySnapshot, Verdict,
};
pub use incident::{
    build as build_incident, plan_kill, to_markdown as incident_markdown, Finding, IncidentFilter,
    IncidentReport, Inventory, KillPlan, KillRequest, KillScope, RevocationKind, RevocationList,
    Severity,
};
pub use managed::{EffectivePolicy, ManagedError, ManagedPolicy, Override, UserPolicy};
pub use modes::{
    all_modes, baseline_ask, baseline_deny, clamp as clamp_mode, default_rules, info as mode_info,
    mode_decision, readonly_allowlist, transition as mode_transition, ModeInfo, ModeTransition,
    TransitionError, BYPASS_ACK,
};
pub use network::{
    classify_ip, host_glob, DnsGuard, IpClass, NetworkDefault, NetworkPolicy, NetworkVerdict,
    ParsedUrl, PortRange, ProxyConfig, RebindVerdict, UrlError,
};
pub use redaction::{
    fingerprint as secret_fingerprint, shannon_entropy, Redaction, RedactionConfig,
    RedactionReport, Redactor, SecretKind, DEFAULT_ENTROPY_THRESHOLD, DEFAULT_MIN_ENTROPY_TOKEN,
};
pub use rules::{Effect, Rule, RuleOrigin, RuleTool, Selector, Subject};

use agent_protocol::config_types::{AgentConfig, NetworkMode};
use agent_protocol::permission::{Decision, Mode, RememberScope};
use agent_protocol::tool::{RiskClass, ToolCall};

/// Everything the caller knows about the environment a call would run in.
///
/// Deliberately plain data: the policy crate must not touch the filesystem to
/// make a decision, or a decision would depend on state that can change between
/// the check and the execution (a TOCTOU hole the size of a symlink).
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct CallContext {
    /// Workspace root, absolute. The confinement boundary.
    pub workspace_root: PathBuf,
    /// Directory the call would run in.
    pub cwd: PathBuf,
    /// Workspace-relative paths the call touches.
    pub paths: Vec<String>,
    /// Absolute paths the call touches (used for the confinement check).
    pub absolute_paths: Vec<String>,
    /// Shell command line, when the tool runs a process.
    pub command: Option<String>,
    /// Already-tokenised argv, when the caller has it.
    pub argv: Vec<String>,
    /// Hosts the call would contact.
    pub hosts: Vec<String>,
    /// URLs the call would fetch (hosts are extracted into `hosts`).
    pub urls: Vec<String>,
}

impl CallContext {
    /// A context with just a workspace root.
    #[must_use]
    pub fn new(workspace_root: impl Into<PathBuf>) -> Self {
        let root = workspace_root.into();
        Self { cwd: root.clone(), workspace_root: root, ..Default::default() }
    }

    /// Add paths.
    #[must_use]
    pub fn with_paths(mut self, paths: impl IntoIterator<Item = impl Into<String>>) -> Self {
        self.paths.extend(paths.into_iter().map(Into::into));
        self
    }

    /// Add a command.
    #[must_use]
    pub fn with_command(mut self, command: impl Into<String>) -> Self {
        self.command = Some(command.into());
        self
    }

    /// Add hosts.
    #[must_use]
    pub fn with_hosts(mut self, hosts: impl IntoIterator<Item = impl Into<String>>) -> Self {
        self.hosts.extend(hosts.into_iter().map(Into::into));
        self
    }

    /// Paths that fall outside the workspace root. Computed lexically; the
    /// sandbox does the real (symlink-resolving) check at execution time.
    #[must_use]
    pub fn paths_outside_workspace(&self) -> Vec<String> {
        let mut out = Vec::new();
        for p in self.paths.iter().chain(self.absolute_paths.iter()) {
            let abs = classifier::normalise(Path::new(p), &self.workspace_root);
            if !abs.starts_with(&self.workspace_root) {
                out.push(p.clone());
            }
        }
        out
    }
}

/// Build-time options for [`Policy::from_config`].
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PolicyOptions {
    /// Path to the managed policy, overriding `enterprise.managed_policy_path`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub managed_policy_path: Option<PathBuf>,
    /// Require the managed file to be root-owned and not group/world-writable.
    /// On by default; tests turn it off.
    #[serde(default = "yes")]
    pub require_root_owned_managed: bool,
    /// Merge the built-in baseline deny/ask lists. On by default — turning it
    /// off means an empty config allows everything, which is the one thing this
    /// crate exists to prevent.
    #[serde(default = "yes")]
    pub include_baseline: bool,
    /// `--dangerously-bypass` was passed.
    #[serde(default)]
    pub bypass_flag: bool,
    /// `--no-sandbox` was passed.
    #[serde(default)]
    pub no_sandbox: bool,
    /// Where the audit chain should be written. `None` = in-memory only.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub audit_path: Option<PathBuf>,
    /// OS username, for attribution.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub user: Option<String>,
    /// Proxy address the sandbox will point children at.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub proxy_addr: Option<String>,
    /// Path to the persisted revocation list.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub revocations_path: Option<PathBuf>,
}

const fn yes() -> bool {
    true
}

impl Default for PolicyOptions {
    fn default() -> Self {
        Self {
            managed_policy_path: None,
            require_root_owned_managed: true,
            include_baseline: true,
            bypass_flag: false,
            no_sandbox: false,
            audit_path: None,
            user: None,
            proxy_addr: None,
            revocations_path: None,
        }
    }
}

/// What went wrong while building or reloading a [`Policy`].
#[derive(Debug, thiserror::Error)]
pub enum PolicyError {
    /// One or more rule patterns did not parse.
    #[error("{count} policy rule(s) failed to parse; refusing to start:\n{detail}")]
    BadRules {
        /// How many.
        count: usize,
        /// Rendered list.
        detail: String,
    },
    /// A user redaction pattern did not compile.
    #[error("redaction pattern failed to compile:\n{0}")]
    BadRedactionPattern(String),
    /// The managed policy could not be loaded.
    #[error("managed policy: {0}")]
    Managed(#[from] ManagedError),
    /// The audit chain could not be opened or does not verify.
    #[error("audit chain: {0}")]
    Audit(#[from] AuditError),
    /// The revocation list could not be read.
    #[error("revocation list: {0}")]
    Revocations(#[from] incident::RevocationError),
    /// The user asked for something managed policy forbids.
    #[error("{0}")]
    Forbidden(String),
}

/// The policy facade: engine + redactor + network + audit behind one handle.
pub struct Policy {
    engine: PolicyEngine,
    redactor: Redactor,
    network: NetworkPolicy,
    dns: DnsGuard,
    audit: Option<AuditChain>,
    revocations: RevocationList,
    effective: EffectivePolicy,
    managed: Option<ManagedPolicy>,
    managed_path: Option<PathBuf>,
    warnings: Vec<String>,
    config: AgentConfig,
    options: PolicyOptions,
    proxy: Option<ProxyConfig>,
    stats: FacadeStats,
}

/// Call counters, exported as `policy_decisions_total{decision=…}`.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct FacadeStats {
    /// Decisions made.
    pub evaluated: u64,
    /// Decisions that denied.
    pub denied: u64,
    /// Decisions that needed a human.
    pub prompted: u64,
    /// Decisions that allowed.
    pub allowed: u64,
    /// Secrets masked on the way out.
    pub redactions: u64,
    /// Audit records appended.
    pub audited: u64,
}

impl Policy {
    /// Build from a resolved [`AgentConfig`].
    ///
    /// # Errors
    /// [`PolicyError::BadRules`] when any pattern is malformed — the agent
    /// refuses to start with a typo'd deny rule rather than silently dropping
    /// it. Also [`PolicyError::Managed`], [`PolicyError::Audit`],
    /// [`PolicyError::Revocations`] and [`PolicyError::BadRedactionPattern`].
    pub fn from_config(config: &AgentConfig, options: PolicyOptions) -> Result<Self, PolicyError> {
        let mut warnings = Vec::new();

        // --- managed layer -------------------------------------------------
        let managed_override = options
            .managed_policy_path
            .as_ref()
            .map(|p| p.to_string_lossy().to_string())
            .or_else(|| config.enterprise.managed_policy_path.clone());
        let loaded = managed::load(managed_override.as_deref(), options.require_root_owned_managed)?;
        let (managed, managed_path) = match loaded {
            Some((m, p, w)) => {
                warnings.extend(w);
                (Some(m), Some(p))
            }
            None => (None, None),
        };

        // --- merge ---------------------------------------------------------
        let user = user_policy_from_config(config, &options);
        let effective = managed::merge(&user, managed.as_ref());
        for o in &effective.overrides {
            warnings.push(format!("managed policy: {}", o.render()));
        }
        if options.no_sandbox && !effective.sandbox_required {
            warnings.push(
                "sandbox disabled by --no-sandbox: the OS layer is off, only in-process policy remains"
                    .into(),
            );
        }
        if !config.permissions.redaction.enabled && !effective.redaction_required {
            warnings.push(
                "secret redaction is DISABLED: anything the agent reads can reach the model verbatim"
                    .into(),
            );
        }
        if matches!(config.sandbox.network, NetworkMode::Allow) {
            warnings.push("network mode is `allow`: egress is unrestricted".into());
        }

        // --- rules ---------------------------------------------------------
        let (deny, ask, allow) = rule_lists(config, &effective, &options);
        let engine = PolicyEngine::new(effective.mode, &allow, &deny, &ask, |effect| {
            Some(RuleOrigin {
                layer: "config".into(),
                path: Some("permissions".into()),
                line: Some(match effect {
                    Effect::Deny => 1,
                    Effect::Ask => 2,
                    Effect::Allow => 3,
                }),
            })
        })
        .map_err(|errs| PolicyError::BadRules {
            count: errs.len(),
            detail: errs.iter().map(|(p, e)| format!("  {p}: {e}")).collect::<Vec<_>>().join("\n"),
        })?;

        // --- redaction -----------------------------------------------------
        let rc = &config.permissions.redaction;
        let redaction_config = RedactionConfig {
            enabled: if effective.redaction_required { true } else { rc.enabled },
            entropy_threshold: f64::from(rc.entropy_threshold),
            min_entropy_token: rc.min_token_len,
            ..RedactionConfig::for_model()
        };
        let redactor = Redactor::new(redaction_config)
            .with_patterns(&rc.extra_patterns, &rc.ignore_patterns)
            .map_err(|errs| PolicyError::BadRedactionPattern(errs.join("\n  ")))?;

        // --- network / audit / revocations ---------------------------------
        let network = effective.network.clone();
        let audit = match &options.audit_path {
            Some(p) => Some(AuditChain::open(p)?),
            None => None,
        };
        let revocations = match &options.revocations_path {
            Some(p) => RevocationList::load(p)?,
            None => RevocationList::default(),
        };
        let proxy = options.proxy_addr.as_ref().map(|addr| ProxyConfig::from_policy(&network, addr));

        Ok(Self {
            engine,
            redactor,
            network,
            dns: DnsGuard::new(),
            audit,
            revocations,
            effective,
            managed,
            managed_path,
            warnings,
            config: config.clone(),
            options,
            proxy,
            stats: FacadeStats::default(),
        })
    }

    /// Rebuild from a fresh config, preserving session grants and the audit
    /// chain. Called by `Op::Reload`/SIGHUP.
    ///
    /// # Errors
    /// Same as [`Policy::from_config`]. On error the old policy stays in force —
    /// a failed reload must never leave the agent permissive.
    pub fn reload(&mut self, config: &AgentConfig) -> Result<ReloadReport, PolicyError> {
        let grants = self.engine.grants();
        let audit = self.audit.take();
        let revocations = std::mem::take(&mut self.revocations);
        let options = self.options.clone();
        let before = self.effective.mode;

        let mut fresh = match Self::from_config(config, options) {
            Ok(p) => p,
            Err(e) => {
                // Restore and report.
                self.audit = audit;
                self.revocations = revocations;
                return Err(e);
            }
        };
        fresh.audit = audit;
        fresh.revocations = revocations;
        for g in grants {
            let ttl = g
                .expires_at_ms
                .map(|e| Duration::from_millis(e.saturating_sub(agent_protocol::now_ms())))
                .unwrap_or(Duration::ZERO);
            // Grants survive a reload only if the new policy would still allow
            // the pattern: a reload that adds a deny rule must not be defeated by
            // a grant made before it.
            let _ = fresh.engine.remember(&g.pattern, g.rule.effect, g.scope, ttl, &g.granted_by);
        }
        let after = fresh.effective.mode;
        let report = ReloadReport {
            mode_before: before,
            mode_after: after,
            rules_before: self.engine.rules().len(),
            rules_after: fresh.engine.rules().len(),
            warnings: fresh.warnings.clone(),
            grants_preserved: fresh.engine.grants().len(),
        };
        *self = fresh;
        Ok(report)
    }

    // -- evaluation ---------------------------------------------------------

    /// Evaluate a tool call.
    ///
    /// The risk class on the call is a *floor*: for shell calls the classifier
    /// may raise it (a `Read`-labelled call that turns out to be `rm -rf` is
    /// reclassified before the rules see it). It can never lower it.
    pub fn evaluate_call(&mut self, call: &ToolCall, ctx: &CallContext) -> Verdict {
        let (subject_data, assessment) = self.subject_for(call, ctx);
        let subject = Subject {
            tool: &subject_data.tool,
            risk: subject_data.risk,
            paths: &subject_data.paths,
            command: subject_data.command.as_deref(),
            argv: if subject_data.argv.is_empty() { None } else { Some(&subject_data.argv) },
            hosts: &subject_data.hosts,
        };
        let mut v = self.engine.evaluate(&subject);

        // A classifier escalation turns an automatic allow into a prompt. It
        // never turns a prompt into an allow, and never undoes a deny.
        if v.decision.allows() && risk_rank(assessment.class) > risk_rank(subject_data.risk) {
            v = Verdict {
                decision: Decision::Ask,
                explanation: Explanation {
                    effect: Effect::Ask,
                    text: format!(
                        "allowed by rule, but the risk classifier rated this {} ({}): {}",
                        assessment.class,
                        assessment.band(),
                        assessment.reasons().lines().next().unwrap_or("see details")
                    ),
                    rule_index: v.explanation.rule_index,
                    pattern: v.explanation.pattern,
                    managed: v.explanation.managed,
                    considered: v.explanation.considered,
                },
            };
        }
        self.stats.evaluated += 1;
        match &v.decision {
            Decision::Deny { .. } | Decision::DenyAlways { .. } => self.stats.denied += 1,
            Decision::Ask => self.stats.prompted += 1,
            _ => self.stats.allowed += 1,
        }
        v
    }

    /// Evaluate without mutating counters — for the debug overlay and tests.
    #[must_use]
    pub fn peek_call(&self, call: &ToolCall, ctx: &CallContext) -> Verdict {
        let (d, assessment) = self.subject_for(call, ctx);
        let subject = Subject {
            tool: &d.tool,
            risk: d.risk,
            paths: &d.paths,
            command: d.command.as_deref(),
            argv: if d.argv.is_empty() { None } else { Some(&d.argv) },
            hosts: &d.hosts,
        };
        let v = self.engine.evaluate(&subject);
        if v.decision.allows() && risk_rank(assessment.class) > risk_rank(d.risk) {
            return Verdict { decision: Decision::Ask, ..v };
        }
        v
    }

    /// The one-line explanation of a decision (§10.4: `explain()` returns the
    /// rule location).
    #[must_use]
    pub fn explain(&self, call: &ToolCall, ctx: &CallContext) -> String {
        self.peek_call(call, ctx).explanation.text
    }

    /// Risk assessment for a call, independent of the rules. Shown in the
    /// approval overlay and stored in the audit record.
    #[must_use]
    pub fn assess(&self, call: &ToolCall, ctx: &CallContext) -> RiskAssessment {
        self.subject_for(call, ctx).1
    }

    fn subject_for(&self, call: &ToolCall, ctx: &CallContext) -> (SubjectData, RiskAssessment) {
        let mut data = SubjectData {
            tool: call.name.clone(),
            risk: call.risk,
            paths: ctx.paths.clone(),
            command: ctx.command.clone(),
            argv: ctx.argv.clone(),
            hosts: ctx.hosts.clone(),
        };

        // Pull the interesting arguments out of the call payload when the
        // caller did not pre-extract them.
        if data.command.is_none() {
            if let Some(c) = call.args.get("command").and_then(|v| v.as_str()) {
                data.command = Some(c.to_string());
            }
        }
        if data.paths.is_empty() {
            for key in ["path", "file_path", "file", "target", "old_path", "new_path"] {
                if let Some(p) = call.args.get(key).and_then(|v| v.as_str()) {
                    if !data.paths.iter().any(|x| x == p) {
                        data.paths.push(p.to_string());
                    }
                }
            }
            if let Some(arr) = call.args.get("paths").and_then(|v| v.as_array()) {
                for v in arr {
                    if let Some(p) = v.as_str() {
                        data.paths.push(p.to_string());
                    }
                }
            }
        }
        if data.hosts.is_empty() {
            for key in ["url", "uri", "host", "endpoint"] {
                if let Some(u) = call.args.get(key).and_then(|v| v.as_str()) {
                    match ParsedUrl::parse(u) {
                        Ok(parsed) => {
                            if !data.hosts.contains(&parsed.host) {
                                data.hosts.push(parsed.host);
                            }
                        }
                        // Not a URL: treat it as a bare host.
                        Err(UrlError::NoScheme(_)) => {
                            if !data.hosts.contains(&u.to_string()) {
                                data.hosts.push(u.to_string());
                            }
                        }
                        Err(_) => {}
                    }
                }
            }
        }
        if data.argv.is_empty() {
            if let Some(c) = &data.command {
                data.argv = agent_protocol::glob_match::shell_words(c);
            } else if let Some(arr) = call.args.get("argv").and_then(|v| v.as_array()) {
                data.argv = arr.iter().filter_map(|v| v.as_str().map(str::to_string)).collect();
            }
        }

        // Risk: registry value is the floor; the classifier may raise it.
        let assessment = if let Some(cmd) = &data.command {
            classifier::classify_shell(cmd)
        } else if !data.hosts.is_empty() {
            classifier::classify_host(&data.hosts[0], None)
        } else if !data.paths.is_empty() {
            let op = if call.risk == RiskClass::Read { "read" } else { "write" };
            classifier::classify_path(op, &data.paths[0], &ctx.workspace_root)
        } else if call.name.starts_with("mcp__") {
            classifier::classify_unknown_tool(&call.name)
        } else {
            RiskAssessment { class: call.risk, score: 0, signals: Vec::new() }
        };
        if risk_rank(assessment.class) > risk_rank(data.risk) {
            data.risk = assessment.class;
        }
        (data, assessment)
    }

    // -- mode / grants ------------------------------------------------------

    /// Current mode.
    #[must_use]
    pub fn mode(&self) -> Mode {
        self.engine.mode()
    }

    /// Change mode.
    ///
    /// # Errors
    /// [`TransitionError`] when the change is not legal (managed ceiling,
    /// bypass without the flag, escalation mid-turn).
    pub fn set_mode(
        &mut self,
        next: Mode,
        turn_state: Option<&str>,
    ) -> Result<ModeTransition, TransitionError> {
        let ceiling = self
            .managed
            .as_ref()
            .and_then(|m| m.max_mode)
            .unwrap_or(Mode::Bypass);
        let t = modes::transition(self.engine.mode(), next, ceiling, self.options.bypass_flag, turn_state)?;
        self.engine.set_mode(next);
        Ok(t)
    }

    /// Remember an approval.
    ///
    /// # Errors
    /// When the pattern does not parse, or when more than
    /// `permissions.remember_max` grants would be live.
    pub fn remember(
        &mut self,
        pattern: &str,
        effect: Effect,
        scope: RememberScope,
    ) -> Result<(), PolicyError> {
        let max = self.config.permissions.remember_max;
        if max > 0 && self.engine.grants().len() >= max {
            return Err(PolicyError::Forbidden(format!(
                "already remembering {max} approvals; revoke one first (`agent policy grants`)"
            )));
        }
        let ttl = Duration::from_secs(self.config.permissions.remember_ttl_secs);
        let by = self.options.user.clone().unwrap_or_else(|| "user".into());
        self.engine.remember(pattern, effect, scope, ttl, &by).map_err(|e| PolicyError::Forbidden(e))
    }

    /// Revoke a remembered approval. Returns how many were dropped.
    pub fn revoke(&mut self, pattern: &str) -> usize {
        self.engine.revoke(pattern)
    }

    /// Live grants.
    #[must_use]
    pub fn grants(&self) -> Vec<Grant> {
        self.engine.grants()
    }

    // -- redaction ----------------------------------------------------------

    /// Redact text before it leaves the process.
    pub fn redact(&mut self, text: &str) -> RedactionReport {
        let r = self.redactor.redact(text);
        self.stats.redactions += r.count() as u64;
        r
    }

    /// Redact, returning only the masked text.
    #[must_use]
    pub fn redact_str(&self, text: &str) -> String {
        self.redactor.redact_str(text)
    }

    /// The redactor, for callers that need the config (the read tool checks
    /// `is_allowlisted_path`).
    #[must_use]
    pub const fn redactor(&self) -> &Redactor {
        &self.redactor
    }

    /// Path allowlist from config, so tools do not have to reach into the config.
    #[must_use]
    pub fn redaction_allowlist(&self) -> &[String] {
        &self.config.permissions.redaction.allowlist_paths
    }

    // -- network ------------------------------------------------------------

    /// Check a URL against the egress policy.
    #[must_use]
    pub fn check_url(&self, url: &str) -> NetworkVerdict {
        self.network.check_url_str(url)
    }

    /// The egress policy.
    #[must_use]
    pub const fn network(&self) -> &NetworkPolicy {
        &self.network
    }

    /// Proxy configuration for sandboxed children.
    #[must_use]
    pub const fn proxy(&self) -> Option<&ProxyConfig> {
        self.proxy.as_ref()
    }

    /// Pin a DNS resolution after checking it. Returns `false` when any address
    /// is disallowed, in which case nothing is pinned.
    pub fn pin_dns(&mut self, host: &str, addresses: &[String]) -> bool {
        let now = agent_protocol::now_ms();
        let net = self.network.clone();
        self.dns.pin(host, addresses, &net, now)
    }

    /// Ask whether a connect to `address` for `host` may proceed.
    pub fn check_connect(&mut self, host: &str, address: &str) -> RebindVerdict {
        let now = agent_protocol::now_ms();
        let net = self.network.clone();
        self.dns.check(host, address, &net, now)
    }

    // -- audit / incident ---------------------------------------------------

    /// Append an audit record.
    ///
    /// # Errors
    /// On serialisation or I/O failure. When no audit sink is configured this is
    /// a no-op that returns `None` — the caller decides whether that is fatal
    /// (it is, when `enterprise.require_audit` is set; see
    /// [`Policy::audit_required`]).
    pub fn audit(&mut self, builder: AuditBuilder) -> Result<Option<AuditRecord>, AuditError> {
        match &mut self.audit {
            Some(chain) => {
                let (rec, _anchor) = chain.append(builder)?;
                self.stats.audited += 1;
                Ok(Some(rec))
            }
            None => Ok(None),
        }
    }

    /// Flush the audit chain to disk.
    ///
    /// # Errors
    /// On I/O failure.
    pub fn flush_audit(&mut self) -> Result<(), AuditError> {
        match &mut self.audit {
            Some(c) => c.flush(),
            None => Ok(()),
        }
    }

    /// Records buffered in memory (for in-memory chains and tests).
    #[must_use]
    pub fn audit_buffered(&self) -> usize {
        self.audit.as_ref().map(AuditChain::buffered).unwrap_or(0)
    }

    /// True when a managed policy requires the audit log.
    #[must_use]
    pub const fn audit_required(&self) -> bool {
        self.effective.audit_required
    }

    /// Attribution for a user action in the current thread.
    #[must_use]
    pub fn attribution_for(&self, thread: agent_protocol::ids::ThreadId) -> Attribution {
        Attribution::user(self.options.user.clone().unwrap_or_else(|| "user".into()), thread)
    }

    /// Compute a kill-switch plan (nothing is cancelled here).
    #[must_use]
    pub fn plan_kill(&self, req: &KillRequest, inv: &Inventory) -> KillPlan {
        incident::plan_kill(req, inv)
    }

    /// The revocation list.
    #[must_use]
    pub const fn revocations(&self) -> &RevocationList {
        &self.revocations
    }

    /// Mutate the revocation list (used by `agent kill --credential`).
    pub fn revocations_mut(&mut self) -> &mut RevocationList {
        &mut self.revocations
    }

    /// Persist the revocation list, when a path was configured.
    ///
    /// # Errors
    /// On I/O failure, or [`PolicyError::Forbidden`] when no path is configured.
    pub fn save_revocations(&self) -> Result<(), PolicyError> {
        match &self.options.revocations_path {
            Some(p) => self.revocations.save(p).map_err(Into::into),
            None => Err(PolicyError::Forbidden("no revocation list path configured".into())),
        }
    }

    // -- introspection ------------------------------------------------------

    /// The effective policy after the managed merge.
    #[must_use]
    pub const fn effective(&self) -> &EffectivePolicy {
        &self.effective
    }

    /// The managed policy, when one was loaded.
    #[must_use]
    pub const fn managed(&self) -> Option<&ManagedPolicy> {
        self.managed.as_ref()
    }

    /// Where the managed policy came from.
    #[must_use]
    pub fn managed_path(&self) -> Option<&Path> {
        self.managed_path.as_deref()
    }

    /// A snapshot for the audit record and `agent config explain`.
    #[must_use]
    pub fn snapshot(&self) -> PolicySnapshot {
        self.engine.snapshot()
    }

    /// Warnings to show the user at startup. Never empty-by-accident: a
    /// permissive configuration always produces at least one.
    #[must_use]
    pub fn warnings(&self) -> &[String] {
        &self.warnings
    }

    /// Decision counters.
    #[must_use]
    pub const fn stats(&self) -> FacadeStats {
        self.stats
    }

    /// Cache statistics from the engine.
    #[must_use]
    pub fn cache_stats(&self) -> CacheStats {
        self.engine.cache_stats()
    }

    /// The underlying engine, for tests and the debug overlay.
    #[must_use]
    pub const fn engine(&self) -> &PolicyEngine {
        &self.engine
    }

    /// Rendered `/permissions` view: mode, rules by effect, grants.
    #[must_use]
    pub fn render_permissions(&self) -> String {
        let info = modes::info(self.engine.mode());
        let mut out = String::new();
        out.push_str(&format!("mode: {} — {}\n", info.badge, info.blurb));
        if let Some(p) = &self.managed_path {
            out.push_str(&format!("managed policy: {}\n", p.display()));
        }
        let mut by_effect: BTreeMap<Effect, Vec<String>> = BTreeMap::new();
        for r in self.engine.rules() {
            let label = if r.managed {
                format!("{} (managed)", r.pattern())
            } else {
                r.pattern()
            };
            by_effect.entry(r.effect).or_default().push(label);
        }
        for effect in [Effect::Deny, Effect::Ask, Effect::Allow] {
            if let Some(list) = by_effect.get(&effect) {
                out.push_str(&format!("\n{effect} ({}):\n", list.len()));
                for p in list {
                    out.push_str(&format!("  {p}\n"));
                }
            }
        }
        let grants = self.engine.grants();
        out.push_str(&format!("\nremembered this session ({}):\n", grants.len()));
        for g in &grants {
            out.push_str(&format!("  {} ({:?}) by {}\n", g.pattern, g.scope, g.granted_by));
        }
        out
    }

    /// `agent config explain` output: every layer, every override, every warning.
    #[must_use]
    pub fn render_explain(&self) -> String {
        let mut out = String::new();
        out.push_str("# effective policy\n\n");
        out.push_str(&format!("mode: {}\n", self.effective.mode));
        out.push_str(&format!("sandbox required: {}\n", self.effective.sandbox_required));
        out.push_str(&format!("redaction required: {}\n", self.effective.redaction_required));
        out.push_str(&format!("audit required: {}\n", self.effective.audit_required));
        out.push_str(&format!("bypass forbidden: {}\n", self.effective.bypass_forbidden));
        out.push_str(&format!("network default: {}\n", self.effective.network.default.as_str()));
        if let Some(w) = self.effective.max_workers {
            out.push_str(&format!("max workers: {w}\n"));
        }
        out.push_str(&format!("\nrules: {} deny, {} ask, {} allow\n",
            self.effective.deny.len(), self.effective.ask.len(), self.effective.allow.len()));
        if !self.effective.overrides.is_empty() {
            out.push_str("\n## managed overrides\n\n");
            for o in &self.effective.overrides {
                out.push_str(&format!("- {}\n", o.render()));
            }
        }
        if !self.warnings.is_empty() {
            out.push_str("\n## warnings\n\n");
            for w in &self.warnings {
                out.push_str(&format!("- {w}\n"));
            }
        }
        out
    }
}

impl std::fmt::Debug for Policy {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Policy")
            .field("mode", &self.engine.mode())
            .field("rules", &self.engine.rules().len())
            .field("grants", &self.engine.grants().len())
            .field("managed", &self.managed_path)
            .field("network_default", &self.network.default)
            .field("redaction_enabled", &self.redactor.config().enabled)
            .field("audit", &self.audit.is_some())
            .field("stats", &self.stats)
            .finish()
    }
}

/// What a reload changed.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReloadReport {
    /// Mode before.
    pub mode_before: Mode,
    /// Mode after.
    pub mode_after: Mode,
    /// Rule count before.
    pub rules_before: usize,
    /// Rule count after.
    pub rules_after: usize,
    /// Grants that survived.
    pub grants_preserved: usize,
    /// Warnings from the new config.
    pub warnings: Vec<String>,
}

/// Owned mirror of a [`Subject`], because the borrowed one cannot outlive the
/// extraction step.
struct SubjectData {
    tool: String,
    risk: RiskClass,
    paths: Vec<String>,
    command: Option<String>,
    argv: Vec<String>,
    hosts: Vec<String>,
}

/// Assemble the three rule lists: baseline + mode defaults + config + managed.
fn rule_lists(
    config: &AgentConfig,
    effective: &EffectivePolicy,
    options: &PolicyOptions,
) -> (Vec<String>, Vec<String>, Vec<String>) {
    let mut deny: Vec<String> = Vec::new();
    let mut ask: Vec<String> = Vec::new();
    let mut allow: Vec<String> = Vec::new();

    if options.include_baseline {
        deny.extend(modes::baseline_deny());
        ask.extend(modes::baseline_ask());
        let md = modes::default_rules(effective.mode);
        deny.extend(md.deny);
        ask.extend(md.ask);
        allow.extend(md.allow);
    }
    for cmd in &config.permissions.shell_readonly_allowlist {
        let c = cmd.trim();
        if !c.is_empty() {
            allow.push(format!("shell({c} *)"));
            allow.push(format!("shell({c})"));
        }
    }
    deny.extend(effective.deny.iter().cloned());
    ask.extend(effective.ask.iter().cloned());
    allow.extend(effective.allow.iter().cloned());
    deny.dedup();
    ask.dedup();
    allow.dedup();
    (deny, ask, allow)
}

fn user_policy_from_config(config: &AgentConfig, options: &PolicyOptions) -> UserPolicy {
    let max_workers = u8::try_from(config.agents.max_workers).unwrap_or(u8::MAX);
    UserPolicy {
        mode: config.permissions.mode,
        allow: config.permissions.allow.clone(),
        ask: config.permissions.ask.clone(),
        deny: config.permissions.deny.clone(),
        network: network_from_mode(&config.sandbox.network),
        no_sandbox: options.no_sandbox || !config.sandbox.enabled,
        redaction_disabled: !config.permissions.redaction.enabled,
        audit_disabled: false,
        bypass_flag: options.bypass_flag,
        max_workers: Some(max_workers),
        max_model_tier: None,
        provider: config.model.name.as_ref().map(|m| m.provider.to_string()),
        model: config.model.name.as_ref().map(ToString::to_string),
    }
}

/// Map the config's [`NetworkMode`] onto the egress policy.
#[must_use]
pub fn network_from_mode(mode: &NetworkMode) -> NetworkPolicy {
    match mode {
        NetworkMode::Deny => NetworkPolicy {
            default: NetworkDefault::LocalhostOnly,
            // `*` in deny_hosts is an explicit "nothing leaves", not a default.
            deny_hosts: vec!["*".into()],
            ..NetworkPolicy::default()
        },
        NetworkMode::LocalhostOnly => NetworkPolicy::default(),
        NetworkMode::Allowlist { hosts } => NetworkPolicy {
            default: NetworkDefault::Allowlisted,
            allow_hosts: hosts.clone(),
            ..NetworkPolicy::default()
        },
        NetworkMode::Allow => NetworkPolicy {
            default: NetworkDefault::Open,
            // Private ranges stay blocked even in `allow`: unrestricted egress is
            // about the internet, not about the LAN next to the CI runner.
            block_private_ranges: true,
            deny_ports: Vec::new(),
            ..NetworkPolicy::default()
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use agent_protocol::ids::{CallId, ThreadId};
    use serde_json::json;

    fn cfg() -> AgentConfig {
        AgentConfig::default()
    }

    fn opts() -> PolicyOptions {
        PolicyOptions { require_root_owned_managed: false, ..Default::default() }
    }

    fn ctx() -> CallContext {
        CallContext::new("/work/repo")
    }

    fn call(name: &str, args: serde_json::Value, risk: RiskClass) -> ToolCall {
        ToolCall::new(CallId::new(), name, args, risk)
    }

    #[test]
    fn default_config_builds_and_is_safe() {
        let p = Policy::from_config(&cfg(), opts()).unwrap();
        assert_eq!(p.mode(), Mode::Ask);
        assert!(p.engine().rules().len() > 40, "baseline rules must be present");
        assert!(p.warnings().is_empty() || p.warnings().iter().all(|w| !w.is_empty()));
    }

    #[test]
    fn rm_rf_is_denied_by_the_baseline_even_with_allow_everything() {
        let mut c = cfg();
        c.permissions.allow = vec!["*(*)".into()];
        c.permissions.mode = Mode::Bypass;
        let mut p = Policy::from_config(&c, PolicyOptions { bypass_flag: true, ..opts() }).unwrap();
        let v = p.evaluate_call(&call("shell", json!({"command": "rm -rf /"}), RiskClass::Exec), &ctx());
        assert!(v.decision.denies(), "{v:?}");
        assert!(v.explanation.text.contains("rm -rf"), "{}", v.explanation.text);
    }

    #[test]
    fn a_read_in_the_workspace_is_automatic_in_ask_mode() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("read_file", json!({"path": "src/main.rs"}), RiskClass::Read);
        let v = p.evaluate_call(&c, &ctx());
        assert!(v.allows(), "{v:?}");
    }

    #[test]
    fn an_edit_prompts_in_ask_mode_and_runs_in_auto_edit() {
        let mut ask = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("write_file", json!({"path": "src/main.rs"}), RiskClass::Mutate);
        assert!(ask.evaluate_call(&c, &ctx()).needs_human());

        let mut cfg2 = cfg();
        cfg2.permissions.mode = Mode::AutoEdit;
        let mut auto = Policy::from_config(&cfg2, opts()).unwrap();
        assert!(auto.evaluate_call(&c, &ctx()).allows(), "{:?}", auto.explain(&c, &ctx()));
    }

    #[test]
    fn paths_outside_the_workspace_are_denied() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("write_file", json!({"path": "/etc/passwd"}), RiskClass::Mutate);
        let ctx = CallContext::new("/work/repo").with_paths(["/etc/passwd"]);
        assert!(ctx.paths_outside_workspace().contains(&"/etc/passwd".to_string()));
        let v = p.evaluate_call(&c, &ctx);
        assert!(v.needs_human() || v.decision.denies(), "{v:?}");
    }

    #[test]
    fn dot_git_writes_are_denied_in_every_mode() {
        for mode in [Mode::Ask, Mode::AutoEdit, Mode::Bypass] {
            let mut c = cfg();
            c.permissions.mode = mode;
            let mut p =
                Policy::from_config(&c, PolicyOptions { bypass_flag: true, ..opts() }).unwrap();
            let call = ToolCall::new(
                CallId::new(),
                "write_file",
                json!({"path": ".git/config"}),
                RiskClass::Mutate,
            );
            let ctx = CallContext::new("/work/repo").with_paths([".git/config"]);
            let v = p.evaluate_call(&call, &ctx);
            assert!(v.decision.denies(), "{mode}: {v:?}");
        }
    }

    #[test]
    fn the_classifier_can_escalate_an_allowed_call_to_a_prompt() {
        // auto-edit allows writes; a write implemented through `sh -c` should
        // still stop and ask, because the argv is decided at run time.
        let mut c = cfg();
        c.permissions.mode = Mode::AutoEdit;
        c.permissions.allow = vec!["shell(mystery-tool *)".into()];
        let mut p = Policy::from_config(&c, opts()).unwrap();
        let call = ToolCall::new(
            CallId::new(),
            "shell",
            json!({"command": "mystery-tool --all"}),
            RiskClass::Read, // the registry under-declares; the classifier must fix it
        );
        let v = p.evaluate_call(&call, &ctx());
        assert!(v.needs_human(), "{v:?}");
        assert!(v.explanation.text.contains("classifier"), "{}", v.explanation.text);
    }

    #[test]
    fn unknown_mcp_tools_are_treated_as_network_mutations() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("mcp__acme__deploy", json!({}), RiskClass::Read);
        let a = p.assess(&c, &ctx());
        assert_eq!(a.class, RiskClass::Network, "{a:?}");
        assert!(p.evaluate_call(&c, &ctx()).needs_human());
    }

    #[test]
    fn web_fetch_urls_become_hosts_and_are_checked() {
        let p = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("web_fetch", json!({"url": "https://api.example.com/v1"}), RiskClass::Network);
        let (d, _) = p.subject_for(&c, &ctx());
        assert_eq!(d.hosts, vec!["api.example.com".to_string()]);
        // Default network mode is localhost-only => the egress check denies.
        assert!(p.check_url("https://api.example.com/v1").denies());
        assert!(p.check_url("http://127.0.0.1:3000/api").allows());
    }

    #[test]
    fn network_mode_allowlist_flows_into_the_policy() {
        let mut c = cfg();
        c.sandbox.network = NetworkMode::Allowlist { hosts: vec!["api.anthropic.com".into()] };
        let p = Policy::from_config(&c, opts()).unwrap();
        assert_eq!(p.network().default, NetworkDefault::Allowlisted);
        assert_eq!(p.network().allow_hosts, vec!["api.anthropic.com".to_string()]);
        assert!(p.check_url("https://api.anthropic.com/v1").allows());
        assert!(p.check_url("https://evil.example/").denies() || p.check_url("https://evil.example/").reason().contains("not allowlisted"));
    }

    #[test]
    fn network_mode_deny_blocks_everything() {
        let mut c = cfg();
        c.sandbox.network = NetworkMode::Deny;
        let p = Policy::from_config(&c, opts()).unwrap();
        assert!(p.check_url("https://api.anthropic.com/v1").denies());
        assert!(p.check_url("http://127.0.0.1:3000/").denies());
    }

    #[test]
    fn mode_transitions_respect_the_ceiling_and_the_flag() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        assert!(p.set_mode(Mode::AutoEdit, None).is_ok());
        assert_eq!(p.mode(), Mode::AutoEdit);
        // Bypass without the flag is refused.
        assert!(matches!(
            p.set_mode(Mode::Bypass, None),
            Err(TransitionError::BypassRequiresRestart)
        ));
        // Mid-turn escalation is refused.
        assert!(matches!(
            p.set_mode(Mode::Plan, Some("executing")),
            Ok(_) | Err(TransitionError::TurnInFlight { .. })
        ));
    }

    #[test]
    fn remember_and_revoke_round_trip() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("shell", json!({"command": "cargo test api"}), RiskClass::Exec);
        assert!(p.evaluate_call(&c, &ctx()).needs_human());
        p.remember("shell(cargo test *)", Effect::Allow, RememberScope::ThisSession).unwrap();
        assert!(p.evaluate_call(&c, &ctx()).allows());
        assert_eq!(p.grants().len(), 1);
        assert_eq!(p.revoke("shell(cargo test *)"), 1);
        assert!(p.evaluate_call(&c, &ctx()).needs_human());
    }

    #[test]
    fn remember_max_is_enforced() {
        let mut c = cfg();
        c.permissions.remember_max = 2;
        let mut p = Policy::from_config(&c, opts()).unwrap();
        p.remember("shell(ls)", Effect::Allow, RememberScope::ThisSession).unwrap();
        p.remember("shell(pwd)", Effect::Allow, RememberScope::ThisSession).unwrap();
        let err = p.remember("shell(cat *)", Effect::Allow, RememberScope::ThisSession).unwrap_err();
        assert!(matches!(err, PolicyError::Forbidden(_)), "{err}");
        assert!(err.to_string().contains("already remembering"), "{err}");
    }

    #[test]
    fn a_bad_pattern_in_config_refuses_to_start() {
        let mut c = cfg();
        c.permissions.deny = vec!["shell(rm -rf **".into()];
        let err = Policy::from_config(&c, opts()).unwrap_err();
        match err {
            PolicyError::BadRules { count, detail } => {
                assert_eq!(count, 1);
                assert!(detail.contains("rm -rf"), "{detail}");
            }
            other => panic!("{other}"),
        }
    }

    #[test]
    fn a_bad_user_redaction_pattern_refuses_to_start() {
        let mut c = cfg();
        c.permissions.redaction.extra_patterns = vec!["[bad".into()];
        let err = Policy::from_config(&c, opts()).unwrap_err();
        assert!(matches!(err, PolicyError::BadRedactionPattern(_)), "{err}");
    }

    #[test]
    fn redaction_flows_from_config() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let r = p.redact("export AWS_KEY=AKIAIOSFODNN7EXAMPLE");
        assert_eq!(r.count(), 1);
        assert_eq!(p.stats().redactions, 1);
        assert!(p.redact_str("AKIAIOSFODNN7EXAMPLE").contains("[redacted:"));
    }

    #[test]
    fn disabling_redaction_produces_a_warning() {
        let mut c = cfg();
        c.permissions.redaction.enabled = false;
        let p = Policy::from_config(&c, opts()).unwrap();
        assert!(p.warnings().iter().any(|w| w.contains("redaction is DISABLED")), "{:?}", p.warnings());
    }

    #[test]
    fn a_managed_policy_overrides_the_user_config() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("policy.toml");
        std::fs::write(
            &path,
            "max_mode = \"read-only\"\nforbid_bypass = true\nforce_sandbox = true\ndeny = [\"shell(git push*)\"]\n",
        )
        .unwrap();
        let mut c = cfg();
        c.permissions.mode = Mode::Bypass;
        c.permissions.allow = vec!["shell(git push origin main)".into()];
        let o = PolicyOptions {
            managed_policy_path: Some(path.clone()),
            require_root_owned_managed: false,
            bypass_flag: true,
            ..Default::default()
        };
        let mut p = Policy::from_config(&c, o).unwrap();
        assert_eq!(p.mode(), Mode::ReadOnly, "managed ceiling must win");
        assert!(p.effective().sandbox_required);
        assert!(p.effective().bypass_forbidden);
        assert_eq!(p.managed_path(), Some(path.as_path()));

        let push = call("shell", json!({"command": "git push origin main"}), RiskClass::Exec);
        assert!(p.evaluate_call(&push, &ctx()).decision.denies());
        // And the user cannot raise the mode back up.
        assert!(matches!(
            p.set_mode(Mode::AutoEdit, None),
            Err(TransitionError::ManagedCeiling { .. })
        ));
        assert!(p.warnings().iter().any(|w| w.contains("managed policy")), "{:?}", p.warnings());
    }

    #[test]
    fn reload_keeps_grants_and_the_audit_chain() {
        let dir = tempfile::tempdir().unwrap();
        let audit = dir.path().join("audit.jsonl");
        let o = PolicyOptions { audit_path: Some(audit.clone()), ..opts() };
        let mut p = Policy::from_config(&cfg(), o.clone()).unwrap();
        p.remember("shell(cargo test *)", Effect::Allow, RememberScope::ThisSession).unwrap();
        p.audit(AuditBuilder::new(
            ThreadId::new(),
            Actor::User { id: "dev".into() },
            AuditAction::SessionStart,
        ))
        .unwrap();
        p.flush_audit().unwrap();
        assert_eq!(p.stats().audited, 1);

        let mut c2 = cfg();
        c2.permissions.deny = vec!["write(tmp/**)".into()];
        let report = p.reload(&c2).unwrap();
        assert_eq!(report.mode_before, Mode::Ask);
        assert_eq!(report.mode_after, Mode::Ask);
        assert_eq!(report.grants_preserved, 1);
        assert!(report.rules_after > report.rules_before, "{report:?}");
        // The chain continues rather than restarting.
        p.audit(AuditBuilder::new(
            ThreadId::new(),
            Actor::User { id: "dev".into() },
            AuditAction::SessionEnd,
        ))
        .unwrap();
        p.flush_audit().unwrap();
        let report = AuditReader::verify_file(&audit).unwrap();
        assert!(report.ok, "{report:?}");
        assert_eq!(report.count, 2);
    }

    #[test]
    fn a_failed_reload_leaves_the_old_policy_in_force() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let mut bad = cfg();
        bad.permissions.deny = vec!["shell(oops".into()];
        assert!(p.reload(&bad).is_err());
        // Still functional and still denying rm -rf.
        let v = p.peek_call(&call("shell", json!({"command": "rm -rf /"}), RiskClass::Exec), &ctx());
        assert!(v.decision.denies());
    }

    #[test]
    fn dns_pinning_and_rebinding_checks_are_wired() {
        let mut c = cfg();
        c.sandbox.network = NetworkMode::Allowlist { hosts: vec!["api.example.com".into()] };
        let mut p = Policy::from_config(&c, opts()).unwrap();
        assert!(p.pin_dns("api.example.com", &["93.184.216.34".into()]));
        assert!(matches!(p.check_connect("api.example.com", "93.184.216.34"), RebindVerdict::Connect { .. }));
        assert!(matches!(p.check_connect("api.example.com", "127.0.0.1"), RebindVerdict::Refuse { .. }));
        assert!(!p.pin_dns("api.example.com", &["10.0.0.8".into()]));
    }

    #[test]
    fn proxy_config_is_derived_when_an_address_is_given() {
        let o = PolicyOptions { proxy_addr: Some("127.0.0.1:8788".into()), ..opts() };
        let p = Policy::from_config(&cfg(), o).unwrap();
        let proxy = p.proxy().expect("proxy configured");
        assert_eq!(proxy.url, "http://127.0.0.1:8788");
        assert!(proxy.env().iter().any(|(k, _)| k == "HTTPS_PROXY"));
    }

    #[test]
    fn kill_switch_plans_are_computed_not_executed() {
        let p = Policy::from_config(&cfg(), opts()).unwrap();
        let req = KillRequest {
            scope: KillScope::Global,
            reason: "runaway".into(),
            actor: Actor::User { id: "dev".into() },
            cleanup_worktrees: true,
            revoke_grants: true,
            add_deny_rule: true,
        };
        let inv = Inventory::default();
        let plan = p.plan_kill(&req, &inv);
        assert!(plan.is_noop(), "an empty inventory has nothing to stop");
        assert!(plan.summary.contains("nothing in scope"), "{}", plan.summary);
    }

    #[test]
    fn permissions_and_explain_render() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        p.remember("shell(cargo test *)", Effect::Allow, RememberScope::ThisSession).unwrap();
        let text = p.render_permissions();
        assert!(text.starts_with("mode: ASK"), "{text}");
        assert!(text.contains("deny ("), "{text}");
        assert!(text.contains("shell(cargo test *)"), "{text}");
        let explain = p.render_explain();
        assert!(explain.contains("# effective policy"), "{explain}");
        assert!(explain.contains("network default: localhost-only"), "{explain}");
    }

    #[test]
    fn decisions_are_counted() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        p.evaluate_call(&call("read_file", json!({"path": "a.rs"}), RiskClass::Read), &ctx());
        p.evaluate_call(&call("shell", json!({"command": "rm -rf /"}), RiskClass::Exec), &ctx());
        p.evaluate_call(&call("write_file", json!({"path": "a.rs"}), RiskClass::Mutate), &ctx());
        let s = p.stats();
        assert_eq!(s.evaluated, 3);
        assert_eq!(s.allowed, 1);
        assert_eq!(s.denied, 1);
        assert_eq!(s.prompted, 1);
    }

    #[test]
    fn peek_does_not_change_counters() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let c = call("read_file", json!({"path": "a.rs"}), RiskClass::Read);
        let _ = p.peek_call(&c, &ctx());
        assert_eq!(p.stats().evaluated, 0);
        let _ = p.evaluate_call(&c, &ctx());
        assert_eq!(p.stats().evaluated, 1);
    }

    #[test]
    fn shell_readonly_allowlist_from_config_auto_allows() {
        let mut c = cfg();
        c.permissions.shell_readonly_allowlist = vec!["kubectl get".into()];
        let mut p = Policy::from_config(&c, opts()).unwrap();
        let call = ToolCall::new(
            CallId::new(),
            "shell",
            json!({"command": "kubectl get pods"}),
            RiskClass::Exec,
        );
        let v = p.evaluate_call(&call, &ctx());
        assert!(v.allows(), "{v:?} — {}", v.explanation.text);
    }

    #[test]
    fn an_in_memory_policy_has_no_audit_sink() {
        let mut p = Policy::from_config(&cfg(), opts()).unwrap();
        let rec = p
            .audit(AuditBuilder::new(
                ThreadId::new(),
                Actor::User { id: "dev".into() },
                AuditAction::SessionStart,
            ))
            .unwrap();
        assert!(rec.is_none());
        assert!(!p.audit_required());
        assert_eq!(p.stats().audited, 0);
        assert!(p.flush_audit().is_ok());
    }

    #[test]
    fn network_from_mode_maps_every_variant() {
        assert_eq!(network_from_mode(&NetworkMode::Deny).deny_hosts, vec!["*".to_string()]);
        assert_eq!(network_from_mode(&NetworkMode::LocalhostOnly).default, NetworkDefault::LocalhostOnly);
        assert_eq!(
            network_from_mode(&NetworkMode::Allowlist { hosts: vec!["a.test".into()] }).allow_hosts,
            vec!["a.test".to_string()]
        );
        let open = network_from_mode(&NetworkMode::Allow);
        assert_eq!(open.default, NetworkDefault::Open);
        assert!(open.block_private_ranges, "even `allow` must not open the LAN");
    }
}
