//! The harness: turn loop, sessions, approvals, budgets, prompt assembly.
#![warn(missing_docs)]
