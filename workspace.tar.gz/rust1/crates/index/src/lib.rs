//! Code intelligence: repo map, ranking, search, file tree.
#![warn(missing_docs)]
