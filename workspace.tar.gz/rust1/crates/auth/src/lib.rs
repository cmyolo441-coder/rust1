//! Credentials: keyring, OAuth PKCE, device code, CI identity.
#![warn(missing_docs)]
