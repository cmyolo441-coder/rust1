//! Observability: tracing, OTLP, metrics, privacy scrubber, support bundle.
#![warn(missing_docs)]
