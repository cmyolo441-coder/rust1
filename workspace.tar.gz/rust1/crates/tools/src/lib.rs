//! Capability surface: file/patch/search/shell/net/lsp/plan/task tools.
#![warn(missing_docs)]
