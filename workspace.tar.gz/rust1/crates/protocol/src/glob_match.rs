//! Glob and argv pattern matching (`rustplan.txt` §10.4, §7.6).
//!
//! Two distinct grammars are used across the system and they must not be
//! confused:
//!
//! * **Path globs** — `src/**`, `*.rs`, `crates/{a,b}/src/lib.rs`. `*` does
//!   *not* cross a `/`; `**` does. Used for write sets, read sets, lease
//!   expansion, memory rules and policy `read(...)`/`write(...)` selectors.
//! * **Argv patterns** — `git status`, `cargo test *`, `rm -rf **`. Matching is
//!   per *token*: `*` matches exactly one token, `**` matches the rest of the
//!   command line. Used for policy `shell(...)` selectors. The plan is
//!   explicit that `rm -rf *` must be argv-aware rather than a string glob —
//!   a glob would let `rm  -rf  x` (double space) or `rm -rf /` slip through.
//!
//! Both are implemented here, allocation-free, with backtracking. The
//! implementation is deliberately not `globset`: policy matching has to be
//! sub-microsecond on the hot path and has to expose *why* a pattern matched
//! (specificity tie-break, §9.5 `engine.rs`).

use serde::{Deserialize, Serialize};

// ── path globs ──────────────────────────────────────────────────────────────

/// Match a workspace-relative path against a glob.
///
/// Semantics:
/// * `*` matches any run of characters except `/`.
/// * `**` matches any run of characters including `/`, and collapses the
///   redundant slash (`a/**/b` matches `a/b`).
/// * `?` matches exactly one character except `/`.
/// * `[abc]`, `[a-z]`, `[!a-z]` character classes.
/// * `{a,b,c}` alternation, nestable.
/// * A pattern without a `/` matches the basename at any depth
///   (`*.rs` matches `src/deep/x.rs`), which is what users mean when they type
///   `*.rs` into a policy rule.
/// * Matching is case-sensitive on unix and case-insensitive on windows.
#[must_use]
pub fn glob_match(pattern: &str, path: &str) -> bool {
    let path = normalize_seps(path);
    let pattern = normalize_seps(pattern);

    // Basename shortcut: a pattern with no slash matches at any depth.
    if !pattern.contains('/') {
        if let Some((_, base)) = path.rsplit_once('/') {
            if glob_match_core(pattern.as_bytes(), base.as_bytes()) {
                return true;
            }
        }
        return glob_match_core(pattern.as_bytes(), path.as_bytes());
    }

    // Allow both `./src/x` and `/abs/src/x` forms by stripping a leading `./`.
    let p = pattern.strip_prefix("./").unwrap_or(&pattern);
    let t = path.strip_prefix("./").unwrap_or(&path);
    if glob_match_core(p.as_bytes(), t.as_bytes()) {
        return true;
    }
    // A trailing `/**` also matches the directory itself.
    if let Some(prefix) = p.strip_suffix("/**") {
        return t == prefix || t.starts_with(&format!("{prefix}/"));
    }
    false
}

/// Match a path against any of several globs.
#[must_use]
pub fn matches_any(patterns: &[String], path: &str) -> bool {
    patterns.iter().any(|p| glob_match(p, path))
}

/// True when `path` is *possibly* inside `pattern`, i.e. the pattern is a
/// prefix-glob of the path or vice versa. Used by the lease system to decide
/// whether a not-yet-created file could collide with an existing lease
/// (`src/api/**` vs `src/api/mod.rs`).
#[must_use]
pub fn glob_overlaps(a: &str, b: &str) -> bool {
    if glob_match(a, b) || glob_match(b, a) {
        return true;
    }
    let la = literal_prefix(a);
    let lb = literal_prefix(b);
    if la.is_empty() || lb.is_empty() {
        // One of them is fully wild; assume overlap (conservative).
        return true;
    }
    la.starts_with(&lb) || lb.starts_with(&la)
}

/// The longest leading portion of a glob that contains no metacharacters.
#[must_use]
pub fn literal_prefix(pattern: &str) -> String {
    let mut out = String::new();
    let mut chars = pattern.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '*' | '?' | '[' | '{' => break,
            '\\' => {
                if let Some(&n) = chars.peek() {
                    out.push(n);
                    chars.next();
                } else {
                    break;
                }
            }
            _ => out.push(c),
        }
    }
    // Cut back to the last complete path segment so we compare directories.
    match out.rfind('/') {
        Some(i) => out[..=i].to_owned(),
        None => out,
    }
}

fn normalize_seps(s: &str) -> String {
    if cfg!(windows) && s.contains('\\') {
        s.replace('\\', "/")
    } else {
        s.to_owned()
    }
}

/// Core byte-wise matcher with backtracking.
fn glob_match_core(pat: &[u8], text: &[u8]) -> bool {
    let (mut p, mut t) = (0usize, 0usize);
    // Backtrack points for the most recent `*` and `**`.
    let mut star: Option<(usize, usize)> = None;
    let mut dstar: Option<(usize, usize)> = None;

    loop {
        if p < pat.len() {
            match pat[p] {
                b'*' => {
                    let is_double = pat.get(p + 1) == Some(&b'*');
                    if is_double {
                        // Skip a following slash so `a/**/b` matches `a/b`.
                        let next = if pat.get(p + 2) == Some(&b'/') { p + 3 } else { p + 2 };
                        dstar = Some((next, t));
                        p = next;
                        continue;
                    }
                    star = Some((p + 1, t));
                    p += 1;
                    continue;
                }
                b'?' if t < text.len() && text[t] != b'/' => {
                    p += 1;
                    t += 1;
                    continue;
                }
                b'[' => {
                    if let Some((matched, consumed)) = match_class(&pat[p..], text.get(t).copied()) {
                        if matched {
                            p += consumed;
                            t += 1;
                            continue;
                        }
                    } else {
                        // Malformed class: treat `[` literally.
                        if t < text.len() && text[t] == b'[' {
                            p += 1;
                            t += 1;
                            continue;
                        }
                    }
                }
                b'{' => {
                    if let Some(alts) = split_alternation(&pat[p..]) {
                        let (alts, consumed) = alts;
                        for alt in alts {
                            let mut candidate = Vec::with_capacity(pat.len());
                            candidate.extend_from_slice(&pat[..p]);
                            candidate.extend_from_slice(alt);
                            candidate.extend_from_slice(&pat[p + consumed..]);
                            if glob_match_core(&candidate, text) {
                                return true;
                            }
                        }
                        return false;
                    }
                    // Not an alternation: `{` is a literal character.
                    if t < text.len() && text[t] == b'{' {
                        p += 1;
                        t += 1;
                        continue;
                    }
                }
                c => {
                    if t < text.len() && eq_byte(c, text[t]) {
                        p += 1;
                        t += 1;
                        continue;
                    }
                }
            }
        } else if t == text.len() {
            return true;
        }

        // Mismatch: backtrack.
        if let Some((np, nt)) = dstar {
            if nt < text.len() {
                dstar = Some((np, nt + 1));
                p = np;
                t = nt + 1;
                continue;
            }
            dstar = None;
        }
        if let Some((np, nt)) = star {
            // `*` must not cross `/`.
            if nt < text.len() && text[nt] != b'/' {
                star = Some((np, nt + 1));
                p = np;
                t = nt + 1;
                continue;
            }
        }
        return false;
    }
}

fn eq_byte(a: u8, b: u8) -> bool {
    if cfg!(windows) {
        a.to_ascii_lowercase() == b.to_ascii_lowercase()
    } else {
        a == b
    }
}

/// Match a `[...]` class. Returns `(matched, bytes_consumed_in_pattern)`.
fn match_class(pat: &[u8], ch: Option<u8>) -> Option<(bool, usize)> {
    if pat.first() != Some(&b'[') {
        return None;
    }
    let mut i = 1usize;
    let negated = pat.get(i) == Some(&b'!') || pat.get(i) == Some(&b'^');
    if negated {
        i += 1;
    }
    let Some(c) = ch else {
        return Some((false, i));
    };
    let mut matched = false;
    let mut first = true;
    while i < pat.len() {
        match pat[i] {
            b']' if !first => return Some((if negated { !matched } else { matched }, i + 1)),
            b']' => {
                // A `]` in first position is literal.
                if c == b']' {
                    matched = true;
                }
                i += 1;
            }
            _ => {
                // Range?
                if i + 2 < pat.len() && pat[i + 1] == b'-' && pat[i + 2] != b']' {
                    let lo = pat[i];
                    let hi = pat[i + 2];
                    if c >= lo && c <= hi {
                        matched = true;
                    }
                    i += 3;
                } else {
                    if eq_byte(pat[i], c) {
                        matched = true;
                    }
                    i += 1;
                }
            }
        }
        first = false;
    }
    None // unterminated class
}

/// Split `{a,b,c}` into its alternatives. Returns `(alts, total_bytes_consumed)`
/// or `None` when the braces are unbalanced (in which case `{` is literal).
fn split_alternation(pat: &[u8]) -> Option<(Vec<&[u8]>, usize)> {
    if pat.first() != Some(&b'{') {
        return None;
    }
    // The opening brace at index 0 is already consumed, so depth starts at 1.
    let mut depth = 1usize;
    let mut start = 1usize;
    let mut out: Vec<&[u8]> = Vec::new();
    for i in 1..pat.len() {
        match pat[i] {
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 {
                    out.push(&pat[start..i]);
                    return Some((out, i + 1));
                }
            }
            b',' if depth == 1 => {
                out.push(&pat[start..i]);
                start = i + 1;
            }
            _ => {}
        }
    }
    None
}

/// Score how *specific* a path glob is. Higher = more specific. Used for the
/// policy tie-break (§10.4: "longer literal prefix wins").
#[must_use]
pub fn glob_specificity(pattern: &str) -> u32 {
    let literal = literal_prefix(pattern);
    let wilds = pattern.chars().filter(|c| matches!(c, '*' | '?' | '[' | '{')).count() as u32;
    let depth = pattern.matches('/').count() as u32;
    // Literal characters dominate; depth breaks ties; wildcards subtract.
    (literal.len() as u32)
        .saturating_add(depth.saturating_mul(4))
        .saturating_sub(wilds.saturating_mul(2))
}

// ── argv patterns ───────────────────────────────────────────────────────────

/// Tokenise a shell command line the way a POSIX shell would, so that policy
/// patterns match *tokens* and not raw bytes.
///
/// Handles single quotes, double quotes (with `\` escapes), backslash escapes
/// outside quotes, and comment `#` at a token start. It deliberately does
/// **not** expand variables or globs: `rm -rf $HOME` must be seen as the
/// literal token `$HOME` so a deny rule can match it.
#[must_use]
pub fn shell_words(cmd: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let mut cur = String::new();
    let mut started = false;
    let mut chars = cmd.chars().peekable();

    while let Some(c) = chars.next() {
        match c {
            ' ' | '\t' | '\n' | '\r' => {
                if !cur.is_empty() || started {
                    out.push(std::mem::take(&mut cur));
                }
                started = false;
            }
            '\'' => {
                started = true;
                while let Some(&n) = chars.peek() {
                    chars.next();
                    if n == '\'' {
                        break;
                    }
                    cur.push(n);
                }
            }
            '"' => {
                started = true;
                while let Some(&n) = chars.peek() {
                    chars.next();
                    match n {
                        '"' => break,
                        '\\' => {
                            if let Some(&e) = chars.peek() {
                                if matches!(e, '"' | '\\' | '$' | '`') {
                                    chars.next();
                                    cur.push(e);
                                } else {
                                    cur.push('\\');
                                }
                            }
                        }
                        _ => cur.push(n),
                    }
                }
            }
            '\\' => {
                started = true;
                if let Some(n) = chars.next() {
                    cur.push(n);
                }
            }
            '#' if cur.is_empty() && !started => {
                break; // comment to end of line
            }
            _ => {
                started = true;
                cur.push(c);
            }
        }
    }
    if !cur.is_empty() || started {
        out.push(cur);
    }
    out
}

/// Match an argv pattern against a command line.
///
/// * Literal tokens must be equal (case-sensitive).
/// * `*` matches exactly one token (any content).
/// * `**` matches zero or more trailing tokens.
/// * A trailing `*` inside a token (`cargo-te*`) is a substring glob.
///
/// Returns a [`ArgvMatch`] describing the outcome so the policy engine can
/// compute specificity and produce an `explain()` string.
#[must_use]
pub fn argv_match(pattern: &str, command: &str) -> Option<ArgvMatch> {
    let ptoks = shell_words(pattern);
    let ctoks = shell_words(command);
    if ptoks.is_empty() {
        return None;
    }
    argv_match_tokens(&ptoks, &ctoks)
}

/// Token-level variant of [`argv_match`].
#[must_use]
pub fn argv_match_tokens(ptoks: &[String], ctoks: &[String]) -> Option<ArgvMatch> {
    let mut literal_tokens = 0u32;
    let mut wildcards = 0u32;
    let mut ci = 0usize;

    for (pi, p) in ptoks.iter().enumerate() {
        if p == "**" {
            wildcards += 1;
            // `**` must be the last token to be meaningful; anything after it
            // is still checked against the tail.
            let tail = &ptoks[pi + 1..];
            if tail.is_empty() {
                return Some(ArgvMatch {
                    literal_tokens,
                    wildcards,
                    rest: true,
                    matched_tokens: ctoks.len().saturating_sub(ci) as u32,
                });
            }
            // Anchor the tail at the end.
            if ctoks.len() < ci + tail.len() {
                return None;
            }
            let start = ctoks.len() - tail.len();
            for (t, c) in tail.iter().zip(&ctoks[start..]) {
                if !token_matches(t, c) {
                    return None;
                }
                if t.contains('*') || t.contains('?') {
                    wildcards += 1;
                } else {
                    literal_tokens += 1;
                }
            }
            return Some(ArgvMatch {
                literal_tokens,
                wildcards,
                rest: true,
                matched_tokens: (start - ci) as u32,
            });
        }
        let Some(c) = ctoks.get(ci) else {
            return None; // pattern longer than command
        };
        if p == "*" {
            wildcards += 1;
        } else if !token_matches(p, c) {
            return None;
        } else if p.contains('*') || p.contains('?') {
            wildcards += 1;
        } else {
            literal_tokens += 1;
        }
        ci += 1;
    }

    // No `**` was present (those paths return early), so the command must be
    // fully consumed by the pattern.
    if ci != ctoks.len() {
        return None;
    }
    Some(ArgvMatch { literal_tokens, wildcards, rest: false, matched_tokens: ci as u32 })
}

fn token_matches(pattern: &str, token: &str) -> bool {
    if !pattern.contains(['*', '?', '[']) {
        return pattern == token;
    }
    glob_match_core(pattern.as_bytes(), token.as_bytes())
}

/// Detail of a successful argv match, used for specificity tie-breaks.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct ArgvMatch {
    /// Number of exactly-matched literal tokens.
    pub literal_tokens: u32,
    /// Number of wildcard tokens consumed.
    pub wildcards: u32,
    /// True when a `**` swallowed the remainder.
    pub rest: bool,
    /// Tokens matched before the `**` (0 when none).
    pub matched_tokens: u32,
}

impl ArgvMatch {
    /// Specificity score; higher wins in a tie-break (§10.4).
    #[must_use]
    pub fn specificity(&self) -> u32 {
        // Literal tokens dominate; wildcards reduce; a bare `**` is weakest.
        self.literal_tokens
            .saturating_mul(10)
            .saturating_add(self.matched_tokens)
            .saturating_sub(self.wildcards.saturating_mul(2))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn star_does_not_cross_slashes() {
        assert!(glob_match("src/*.rs", "src/main.rs"));
        assert!(!glob_match("src/*.rs", "src/deep/main.rs"));
    }

    #[test]
    fn double_star_crosses_slashes() {
        assert!(glob_match("src/**", "src/a/b/c.rs"));
        assert!(glob_match("src/**/*.rs", "src/a/b/c.rs"));
        assert!(glob_match("src/**", "src/main.rs"));
        assert!(!glob_match("src/**", "lib/main.rs"));
    }

    #[test]
    fn double_star_collapses_the_redundant_slash() {
        assert!(glob_match("a/**/b", "a/b"));
        assert!(glob_match("a/**/b", "a/x/b"));
        assert!(glob_match("a/**/b", "a/x/y/z/b"));
    }

    #[test]
    fn slashless_patterns_match_at_any_depth() {
        assert!(glob_match("*.rs", "src/deep/x.rs"));
        assert!(glob_match("*.rs", "x.rs"));
        assert!(!glob_match("*.rs", "x.py"));
    }

    #[test]
    fn question_mark_matches_one_non_slash() {
        assert!(glob_match("a?c", "abc"));
        assert!(!glob_match("a?c", "a/c"));
        assert!(!glob_match("a?c", "ac"));
    }

    #[test]
    fn character_classes_work_including_negation() {
        assert!(glob_match("[abc].rs", "b.rs"));
        assert!(!glob_match("[abc].rs", "d.rs"));
        assert!(glob_match("[!abc].rs", "d.rs"));
        assert!(glob_match("[a-z]*.rs", "main.rs"));
    }

    #[test]
    fn alternation_works_and_nests() {
        assert!(glob_match("crates/{a,b}/src/lib.rs", "crates/b/src/lib.rs"));
        assert!(!glob_match("crates/{a,b}/src/lib.rs", "crates/c/src/lib.rs"));
        assert!(glob_match("*.{rs,toml}", "Cargo.toml"));
    }

    #[test]
    fn unbalanced_brace_is_literal() {
        assert!(glob_match("a{b", "a{b"));
        assert!(!glob_match("a{b", "ab"));
    }

    #[test]
    fn trailing_double_star_matches_the_directory_itself() {
        assert!(glob_match("src/api/**", "src/api"));
        assert!(glob_match("src/api/**", "src/api/x.rs"));
    }

    #[test]
    fn relative_prefixes_are_tolerated() {
        assert!(glob_match("./src/*.rs", "src/main.rs"));
        assert!(glob_match("src/*.rs", "./src/main.rs"));
    }

    #[test]
    fn overlaps_detects_prefix_containment() {
        assert!(glob_overlaps("src/api/**", "src/api/mod.rs"));
        assert!(glob_overlaps("src/**", "src/api/mod.rs"));
        assert!(!glob_overlaps("src/api/**", "src/lib/mod.rs"));
        assert!(glob_overlaps("**", "anything"));
    }

    #[test]
    fn literal_prefix_stops_at_metacharacters() {
        assert_eq!(literal_prefix("src/api/**/*.rs"), "src/api/");
        assert_eq!(literal_prefix("*.rs"), "");
        assert_eq!(literal_prefix("src/main.rs"), "src/");
    }

    #[test]
    fn specificity_prefers_longer_literal_prefixes() {
        assert!(glob_specificity("src/api/middleware/rate.rs") > glob_specificity("src/api/**"));
        assert!(glob_specificity("src/api/**") > glob_specificity("**"));
    }

    #[test]
    fn shell_words_handles_quotes_and_escapes() {
        assert_eq!(shell_words("git commit -m \"hello world\""), ["git", "commit", "-m", "hello world"]);
        assert_eq!(shell_words("echo 'a  b'"), ["echo", "a  b"]);
        assert_eq!(shell_words(r"echo a\ b"), ["echo", "a b"]);
        assert_eq!(shell_words("ls # comment"), ["ls"]);
        assert_eq!(shell_words("rm   -rf   /tmp/x"), ["rm", "-rf", "/tmp/x"]);
        assert_eq!(shell_words(""), Vec::<String>::new());
    }

    #[test]
    fn shell_words_does_not_expand_variables() {
        assert_eq!(shell_words("rm -rf $HOME"), ["rm", "-rf", "$HOME"]);
    }

    #[test]
    fn argv_exact_match() {
        let m = argv_match("git status", "git status").unwrap();
        assert_eq!(m.literal_tokens, 2);
        assert_eq!(m.wildcards, 0);
        assert!(argv_match("git status", "git status --short").is_none());
    }

    #[test]
    fn argv_single_star_matches_one_token() {
        let m = argv_match("cargo test *", "cargo test api").unwrap();
        assert_eq!(m.wildcards, 1);
        assert!(argv_match("cargo test *", "cargo test api extra").is_none());
        assert!(argv_match("cargo test *", "cargo test").is_none());
    }

    #[test]
    fn argv_double_star_matches_the_rest() {
        assert!(argv_match("rm -rf **", "rm -rf /").is_some());
        assert!(argv_match("rm -rf **", "rm -rf /tmp/x y z").is_some());
        assert!(argv_match("rm -rf **", "rm -rf").is_some());
        assert!(argv_match("rm -rf **", "rm -r /").is_none());
    }

    #[test]
    fn argv_double_star_with_a_tail_anchors_at_the_end() {
        assert!(argv_match("cargo ** --release", "cargo build --release").is_some());
        assert!(argv_match("cargo ** --release", "cargo build").is_none());
    }

    #[test]
    fn argv_whitespace_normalisation_defeats_evasion() {
        // The plan calls this out explicitly: a string glob would miss this.
        assert!(argv_match("rm -rf **", "rm    -rf    /").is_some());
        assert!(argv_match("git status", "  git   status  ").is_some());
    }

    #[test]
    fn argv_substring_globs_work() {
        assert!(argv_match("cargo-te*", "cargo-test").is_some());
        assert!(argv_match("mcp__github__*", "mcp__github__list_prs").is_some());
    }

    #[test]
    fn argv_specificity_prefers_literal_tokens() {
        let exact = argv_match("git status", "git status").unwrap();
        let wild = argv_match("git *", "git status").unwrap();
        let rest = argv_match("git **", "git status").unwrap();
        assert!(exact.specificity() > wild.specificity());
        assert!(wild.specificity() > rest.specificity());
    }

    #[test]
    fn empty_pattern_never_matches() {
        assert!(argv_match("", "ls").is_none());
    }

    #[test]
    fn matcher_is_allocation_light_on_long_inputs() {
        // Guard against accidental quadratic blowup: 200-token command.
        let cmd = format!("echo {}", (0..200).map(|i| format!("t{i}")).collect::<Vec<_>>().join(" "));
        let pat = "echo **";
        let start = std::time::Instant::now();
        assert!(argv_match(pat, &cmd).is_some());
        assert!(start.elapsed().as_millis() < 200, "took {:?}", start.elapsed());
    }
}
