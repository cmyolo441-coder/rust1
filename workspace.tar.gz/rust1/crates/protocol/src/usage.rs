//! Token and cost accounting (`rustplan.txt` §9.1 `src/usage.rs`).
//!
//! Money is stored as **integer USD micros** (1 USD = 1_000_000 micros) at
//! every layer. Floating point never appears in a cost path: a session that
//! sums 400 turns of `f64` dollars drifts by cents, and enterprise finance
//! reconciles against these numbers.

use std::ops::{Add, AddAssign, Sub, SubAssign};

use serde::{Deserialize, Serialize};

/// One provider-reported (or locally estimated) usage sample.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "snake_case")]
pub struct Usage {
    /// Prompt/input tokens.
    pub input: u64,
    /// Completion/output tokens.
    pub output: u64,
    /// Tokens served from the provider's prompt cache.
    pub cache_read: u64,
    /// Tokens written into the provider's prompt cache.
    pub cache_write: u64,
    /// Reasoning/thinking tokens (billed as output by most providers; tracked
    /// separately so the ledger can attribute them).
    pub reasoning: u64,
    /// Total cost in USD micros.
    pub cost_micros: u64,
    /// True when these numbers came from the provider rather than our
    /// estimator. `ledger.rs` uses this to compute drift (§6.1.1).
    #[serde(default)]
    pub from_provider: bool,
}

impl Usage {
    /// Zero sample.
    #[must_use]
    pub const fn zero() -> Self {
        Self {
            input: 0,
            output: 0,
            cache_read: 0,
            cache_write: 0,
            reasoning: 0,
            cost_micros: 0,
            from_provider: false,
        }
    }

    /// Total tokens charged (input + output + cache traffic + reasoning).
    #[must_use]
    pub const fn total_tokens(&self) -> u64 {
        self.input + self.output + self.cache_read + self.cache_write + self.reasoning
    }

    /// Tokens that formed the prompt we sent, including cache hits.
    #[must_use]
    pub const fn prompt_tokens(&self) -> u64 {
        self.input + self.cache_read + self.cache_write
    }

    /// Cache hit ratio in `[0, 1]`; `None` when no prompt was sent.
    #[must_use]
    pub fn cache_hit_ratio(&self) -> Option<f64> {
        let denom = self.cache_read + self.cache_write + self.input;
        if denom == 0 {
            None
        } else {
            Some(self.cache_read as f64 / denom as f64)
        }
    }

    /// Cost as USD (display only — never used for arithmetic).
    #[must_use]
    pub fn usd(&self) -> f64 {
        self.cost_micros as f64 / 1_000_000.0
    }

    /// `$0.0412` / `$12.34` style string for the status bar.
    #[must_use]
    pub fn cost_display(&self) -> String {
        format_micros(self.cost_micros)
    }

    /// Compute cost from a price table. Used when the provider does not report
    /// cost (most don't).
    #[must_use]
    pub fn with_pricing(mut self, p: crate::model::Pricing) -> Self {
        self.cost_micros = cost_of(self, p);
        self
    }

    /// Reconcile an estimate against provider truth.
    ///
    /// Returns the relative drift `|estimate - truth| / truth` for the prompt
    /// tokens, which `context/ledger.rs` accumulates to grow the safety
    /// reserve when it exceeds 8% for three consecutive turns.
    #[must_use]
    pub fn drift_against(&self, provider: Usage) -> f64 {
        let est = self.prompt_tokens();
        let truth = provider.prompt_tokens();
        if truth == 0 {
            return if est == 0 { 0.0 } else { 1.0 };
        }
        let diff = if est > truth { est - truth } else { truth - est };
        diff as f64 / truth as f64
    }
}

/// Cost of a usage sample under a price table, in USD micros.
///
/// Integer arithmetic only: `tokens * price_per_mtok / 1_000_000`, accumulated
/// at full precision before the single division so small calls do not round to
/// zero.
#[must_use]
pub fn cost_of(u: Usage, p: crate::model::Pricing) -> u64 {
    // Work in nano-micros (1e-15 USD) to keep precision, then divide once.
    let nano = u.input.saturating_mul(p.input_per_mtok).saturating_mul(1000)
        + u.output.saturating_mul(p.output_per_mtok).saturating_mul(1000)
        + u.cache_read.saturating_mul(p.cache_read_per_mtok).saturating_mul(1000)
        + u.cache_write.saturating_mul(p.cache_write_per_mtok).saturating_mul(1000)
        + u.reasoning.saturating_mul(p.reasoning_per_mtok).saturating_mul(1000);
    nano / 1_000_000_000
}

/// Format USD micros as a human string: `$0.0042`, `$1.20`, `$1,234.56`.
#[must_use]
pub fn format_micros(micros: u64) -> String {
    let dollars = micros / 1_000_000;
    let cents = (micros % 1_000_000) / 10_000;
    let frac = (micros % 10_000) / 100;
    if dollars >= 1000 {
        // Group thousands for readability in `/cost`.
        let s = dollars.to_string();
        let bytes = s.as_bytes();
        let mut out = String::with_capacity(s.len() + 8);
        for (i, b) in bytes.iter().enumerate() {
            if i > 0 && (bytes.len() - i) % 3 == 0 {
                out.push(',');
            }
            out.push(*b as char);
        }
        format!("${out}.{cents:02}")
    } else if dollars > 0 {
        format!("${dollars}.{cents:02}")
    } else if micros >= 10_000 {
        format!("$0.{cents:02}")
    } else {
        format!("$0.{cents:02}{frac:02}")
    }
}

impl Add for Usage {
    type Output = Usage;
    fn add(mut self, rhs: Usage) -> Usage {
        self += rhs;
        self
    }
}

impl AddAssign for Usage {
    fn add_assign(&mut self, rhs: Usage) {
        self.input = self.input.saturating_add(rhs.input);
        self.output = self.output.saturating_add(rhs.output);
        self.cache_read = self.cache_read.saturating_add(rhs.cache_read);
        self.cache_write = self.cache_write.saturating_add(rhs.cache_write);
        self.reasoning = self.reasoning.saturating_add(rhs.reasoning);
        self.cost_micros = self.cost_micros.saturating_add(rhs.cost_micros);
        // A sum is only "provider truth" if every sample was.
        self.from_provider = self.from_provider && rhs.from_provider;
    }
}

impl Sub for Usage {
    type Output = Usage;
    fn sub(mut self, rhs: Usage) -> Usage {
        self -= rhs;
        self
    }
}

impl SubAssign for Usage {
    fn sub_assign(&mut self, rhs: Usage) {
        self.input = self.input.saturating_sub(rhs.input);
        self.output = self.output.saturating_sub(rhs.output);
        self.cache_read = self.cache_read.saturating_sub(rhs.cache_read);
        self.cache_write = self.cache_write.saturating_sub(rhs.cache_write);
        self.reasoning = self.reasoning.saturating_sub(rhs.reasoning);
        self.cost_micros = self.cost_micros.saturating_sub(rhs.cost_micros);
    }
}

/// Rolling accumulator used by the status bar and `/cost`.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct UsageLedger {
    /// Everything so far in this session.
    pub total: Usage,
    /// The most recent turn.
    pub last_turn: Usage,
    /// Number of model calls accounted for.
    pub calls: u64,
    /// Peak prompt tokens seen in one call (watermark).
    pub peak_prompt: u64,
}

impl UsageLedger {
    /// Record one call.
    pub fn record(&mut self, u: Usage) {
        self.last_turn = u;
        self.total += u;
        self.calls = self.calls.saturating_add(1);
        self.peak_prompt = self.peak_prompt.max(u.prompt_tokens());
    }

    /// Average cache hit ratio across the session.
    #[must_use]
    pub fn cache_hit_ratio(&self) -> Option<f64> {
        self.total.cache_hit_ratio()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Pricing;

    const P: Pricing = Pricing {
        input_per_mtok: 3_000_000,       // $3.00 / Mtok
        output_per_mtok: 15_000_000,     // $15.00 / Mtok
        cache_read_per_mtok: 300_000,    // $0.30 / Mtok
        cache_write_per_mtok: 3_750_000, // $3.75 / Mtok
        reasoning_per_mtok: 0,
    };

    #[test]
    fn cost_is_computed_in_integer_micros() {
        let u = Usage { input: 1_000_000, output: 100_000, ..Usage::zero() };
        // 1 Mtok * $3 + 0.1 Mtok * $15 = $3.00 + $1.50 = $4.50
        assert_eq!(cost_of(u, P), 4_500_000);
    }

    #[test]
    fn small_calls_do_not_round_to_zero() {
        let u = Usage { input: 100, output: 50, ..Usage::zero() };
        // 100/1e6 * 3e6 micros = 300 micros; 50/1e6 * 15e6 = 750 micros.
        assert_eq!(cost_of(u, P), 1050);
    }

    #[test]
    fn cache_traffic_is_priced_separately() {
        let u = Usage { cache_read: 1_000_000, ..Usage::zero() };
        assert_eq!(cost_of(u, P), 300_000, "$0.30");
    }

    #[test]
    fn usage_sums_component_wise() {
        let a = Usage { input: 10, output: 5, cache_read: 100, ..Usage::zero() };
        let b = Usage { input: 1, output: 2, cache_write: 7, ..Usage::zero() };
        let s = a + b;
        assert_eq!((s.input, s.output, s.cache_read, s.cache_write), (11, 7, 100, 7));
    }

    #[test]
    fn addition_saturates_instead_of_wrapping() {
        let a = Usage { input: u64::MAX, ..Usage::zero() };
        let b = Usage { input: 1, ..Usage::zero() };
        assert_eq!((a + b).input, u64::MAX);
    }

    #[test]
    fn from_provider_is_only_true_when_every_sample_was() {
        let a = Usage { from_provider: true, ..Usage::zero() };
        let b = Usage { from_provider: false, ..Usage::zero() };
        assert!((a + a).from_provider);
        assert!(!(a + b).from_provider);
    }

    #[test]
    fn cache_hit_ratio_matches_the_documented_formula() {
        let u = Usage { input: 20, cache_read: 80, cache_write: 0, ..Usage::zero() };
        assert!((u.cache_hit_ratio().unwrap() - 0.8).abs() < f64::EPSILON);
        assert_eq!(Usage::zero().cache_hit_ratio(), None);
    }

    #[test]
    fn drift_is_relative_and_bounded() {
        let est = Usage { input: 1000, ..Usage::zero() };
        let truth = Usage { input: 1100, ..Usage::zero() };
        assert!((est.drift_against(truth) - 0.0909).abs() < 0.001);
        assert_eq!(est.drift_against(Usage::zero()), 1.0);
        assert_eq!(Usage::zero().drift_against(Usage::zero()), 0.0);
    }

    #[test]
    fn cost_display_is_readable() {
        assert_eq!(format_micros(0), "$0.0000");
        assert_eq!(format_micros(4200), "$0.0042");
        assert_eq!(format_micros(4_500_000), "$4.50");
        assert_eq!(format_micros(1_234_560_000), "$1,234.56");
    }

    #[test]
    fn ledger_tracks_peaks_and_calls() {
        let mut l = UsageLedger::default();
        l.record(Usage { input: 100, ..Usage::zero() });
        l.record(Usage { input: 900, ..Usage::zero() });
        l.record(Usage { input: 400, ..Usage::zero() });
        assert_eq!(l.calls, 3);
        assert_eq!(l.peak_prompt, 900);
        assert_eq!(l.total.input, 1400);
        assert_eq!(l.last_turn.input, 400);
    }
}
