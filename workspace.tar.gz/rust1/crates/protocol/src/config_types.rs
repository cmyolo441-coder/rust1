//! The complete typed configuration schema (`rustplan.txt` §9.1
//! `src/config_types.rs`, §3.6).
//!
//! Every key has a default and a doc comment, because the docs are generated
//! from this file (`agent config schema --md`). Unknown keys are an **error**,
//! not a warning: a typo like `permisions.deny` silently disabling a deny rule
//! is exactly the failure mode an enterprise cannot tolerate.
//!
//! Types here are pure data. Loading, layering and provenance live in
//! `core/src/config/*`; semantic cross-field validation lives in
//! `core/src/config/validate.rs`.

use serde::{Deserialize, Serialize};

use crate::model::ModelId;
use crate::permission::Mode;
use crate::plan::IsolationLevel;

/// Root configuration document (`config.toml`).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct AgentConfig {
    /// Model bindings and routing.
    pub model: ModelConfig,
    /// Permission mode and rule lists.
    pub permissions: PermissionsConfig,
    /// OS sandbox.
    pub sandbox: SandboxConfig,
    /// Context window economy.
    pub context: ContextConfig,
    /// Tool toggles.
    pub tools: ToolsConfig,
    /// Parallel subagents (§7.13).
    pub agents: AgentsConfig,
    /// Lifecycle hooks.
    pub hooks: HooksConfig,
    /// Opt-in telemetry. **Default false.**
    pub telemetry: TelemetryConfig,
    /// Terminal UI preferences.
    pub ui: UiConfig,
    /// Admin-locked enterprise settings.
    pub enterprise: EnterpriseConfig,
    /// Persistence and retention.
    pub state: StateConfig,
}

impl Default for AgentConfig {
    fn default() -> Self {
        Self {
            model: ModelConfig::default(),
            permissions: PermissionsConfig::default(),
            sandbox: SandboxConfig::default(),
            context: ContextConfig::default(),
            tools: ToolsConfig::default(),
            agents: AgentsConfig::default(),
            hooks: HooksConfig::default(),
            telemetry: TelemetryConfig::default(),
            ui: UiConfig::default(),
            enterprise: EnterpriseConfig::default(),
            state: StateConfig::default(),
        }
    }
}

/// `[model]` — provider bindings and role routing.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct ModelConfig {
    /// Main model, `provider/name`. `None` means "resolve from the environment
    /// or prompt the user".
    pub name: Option<ModelId>,
    /// Sampling temperature. `None` = provider default (recommended: do not
    /// set this for agentic loops).
    pub temperature: Option<f32>,
    /// Maximum output tokens requested. `None` = the model's default.
    pub max_tokens: Option<u32>,
    /// Reasoning/thinking effort for models that support it.
    pub reasoning_effort: ReasoningEffort,
    /// Token budget for extended thinking, when the provider takes a number.
    pub thinking_budget_tokens: Option<u32>,
    /// Ordered fallback chain tried when the main model fails (§9.3
    /// `failover.rs`).
    pub fallback: Vec<ModelId>,
    /// Model used for compaction summaries. Defaults to the cheapest model
    /// that still supports JSON output.
    pub summarizer: Option<ModelId>,
    /// Model used for risk classification tie-breaks.
    pub classifier: Option<ModelId>,
    /// Model used for parallel workers.
    pub worker: Option<ModelId>,
    /// Per-provider connection settings.
    pub providers: ProvidersConfig,
    /// Request timeout in seconds for the first byte.
    pub connect_timeout_secs: u64,
    /// Total request timeout in seconds (0 = no limit beyond the turn budget).
    pub request_timeout_secs: u64,
    /// Maximum retries for transient failures.
    pub max_retries: u8,
}

impl Default for ModelConfig {
    fn default() -> Self {
        Self {
            name: None,
            temperature: None,
            max_tokens: None,
            reasoning_effort: ReasoningEffort::default(),
            thinking_budget_tokens: None,
            fallback: Vec::new(),
            summarizer: None,
            classifier: None,
            worker: None,
            providers: ProvidersConfig::default(),
            connect_timeout_secs: 10,
            request_timeout_secs: 300,
            max_retries: 3,
        }
    }
}

/// Reasoning effort for hybrid-reasoning models.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ReasoningEffort {
    /// Provider default.
    Default,
    /// Minimal reasoning; fastest and cheapest.
    Minimal,
    /// Low.
    Low,
    /// Medium.
    Medium,
    /// High; best for hard refactors.
    High,
}

impl Default for ReasoningEffort {
    fn default() -> Self {
        Self::Default
    }
}

/// `[model.providers]` — per-provider overrides.
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct ProvidersConfig {
    /// Anthropic.
    pub anthropic: ProviderEndpoint,
    /// OpenAI.
    pub openai: ProviderEndpoint,
    /// Google Gemini.
    pub gemini: ProviderEndpoint,
    /// AWS Bedrock.
    pub bedrock: ProviderEndpoint,
    /// Google Vertex AI.
    pub vertex: ProviderEndpoint,
    /// Azure OpenAI.
    pub azure: ProviderEndpoint,
    /// Local Ollama.
    pub ollama: ProviderEndpoint,
    /// OpenRouter.
    pub openrouter: ProviderEndpoint,
    /// A generic OpenAI-compatible BYO endpoint.
    pub custom: ProviderEndpoint,
}

/// Endpoint and auth settings for one provider.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct ProviderEndpoint {
    /// Base URL override. `None` = the built-in default.
    pub base_url: Option<String>,
    /// Name of the environment variable holding the API key. Secrets are
    /// **never** stored in config (§9.3 `custom.rs`).
    pub api_key_env: Option<String>,
    /// Extra headers, e.g. `HTTP-Referer` for OpenRouter.
    pub headers: Vec<HeaderPair>,
    /// Pinned API version (Azure, Bedrock).
    pub api_version: Option<String>,
    /// Region (Bedrock, Vertex).
    pub region: Option<String>,
    /// Azure deployment name.
    pub deployment: Option<String>,
    /// Requests per minute, for the local token bucket (§9.3 `ratelimit.rs`).
    pub requests_per_minute: Option<u32>,
    /// Tokens per minute, for the local token bucket.
    pub tokens_per_minute: Option<u64>,
    /// Disable this provider entirely.
    pub disabled: bool,
}

impl Default for ProviderEndpoint {
    fn default() -> Self {
        Self {
            base_url: None,
            api_key_env: None,
            headers: Vec::new(),
            api_version: None,
            region: None,
            deployment: None,
            requests_per_minute: None,
            tokens_per_minute: None,
            disabled: false,
        }
    }
}

/// One HTTP header pair.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct HeaderPair {
    /// Header name.
    pub name: String,
    /// Header value.
    pub value: String,
}

/// `[permissions]` — mode and rule lists, in the grammar of §10.4.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct PermissionsConfig {
    /// Default interaction mode.
    pub mode: Mode,
    /// Rules that always allow.
    pub allow: Vec<String>,
    /// Rules that always deny. **Deny wins over allow, always.**
    pub deny: Vec<String>,
    /// Rules that force a prompt even in `auto-edit`/`bypass`.
    pub ask: Vec<String>,
    /// How long a remembered grant lives, in seconds. 0 = this session only.
    pub remember_ttl_secs: u64,
    /// Maximum number of remembered grants before the oldest is evicted.
    pub remember_max: usize,
    /// Shell commands that count as read-only and auto-approve in `ask` mode
    /// (§10.3 footnote).
    pub shell_readonly_allowlist: Vec<String>,
    /// Refuse to run when the working directory is not a git repository and
    /// the mode would allow mutations. Off by default.
    pub require_clean_worktree: bool,
    /// Redaction of secrets before anything leaves the process (§6.4.4).
    pub redaction: RedactionConfig,
}

impl Default for PermissionsConfig {
    fn default() -> Self {
        Self {
            mode: Mode::Ask,
            allow: Vec::new(),
            deny: default_deny_rules(),
            ask: Vec::new(),
            remember_ttl_secs: 0,
            remember_max: 256,
            shell_readonly_allowlist: default_readonly_shell(),
            require_clean_worktree: false,
            redaction: RedactionConfig::default(),
        }
    }
}

/// The built-in deny list. These ship with the binary and cannot be weakened
/// by a user config layer — only by the managed layer (§9.5 `managed.rs`).
#[must_use]
pub fn default_deny_rules() -> Vec<String> {
    vec![
        "shell(rm -rf /)".into(),
        "shell(rm -rf /*)".into(),
        "shell(sudo **)".into(),
        "shell(chmod -R 777 **)".into(),
        "shell(mkfs**)".into(),
        "shell(dd if=**)".into(),
        "shell(git push --force**)".into(),
        "shell(git push -f**)".into(),
        "shell(git reset --hard**)".into(),
        "shell(curl ** | sh)".into(),
        "shell(curl ** | bash)".into(),
        "shell(wget ** | sh)".into(),
        "shell(shutdown**)".into(),
        "shell(reboot**)".into(),
        "shell(:(){ **)".into(),
        "read(/etc/shadow)".into(),
        "read(**/.ssh/id_*)".into(),
        "read(**/.aws/credentials)".into(),
        "read(**/.gnupg/**)".into(),
        "net(169.254.169.254)".into(),
        "net(metadata.google.internal)".into(),
    ]
}

/// Shell command prefixes treated as read-only for auto-approval in `ask`
/// mode. Argv-aware: the pattern must match the whole command line.
#[must_use]
pub fn default_readonly_shell() -> Vec<String> {
    vec![
        "ls", "pwd", "cat", "head", "tail", "wc", "file", "stat", "du", "df",
        "git status", "git log", "git diff", "git show", "git branch", "git rev-parse",
        "git ls-files", "git blame", "git remote", "git describe", "git tag",
        "cargo tree", "cargo metadata", "cargo --version",
        "npm ls", "pip list", "python --version", "node --version",
        "rg", "grep", "find", "tree", "echo", "which", "env", "printenv", "uname", "date",
    ]
    .into_iter()
    .map(|s| format!("shell({s} **)"))
    .collect()
}

/// `[permissions.redaction]`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct RedactionConfig {
    /// Redact secrets before they reach the model or telemetry.
    pub enabled: bool,
    /// Minimum Shannon entropy (bits/char) for a bare token to look secret.
    pub entropy_threshold: f32,
    /// Shortest token length considered for the entropy check.
    pub min_token_len: usize,
    /// Path globs whose contents are never redacted (e.g. test fixtures).
    pub allowlist_paths: Vec<String>,
    /// Extra patterns the user considers secret.
    pub extra_patterns: Vec<String>,
    /// Patterns that look secret but are known-benign (reduces false positives).
    pub ignore_patterns: Vec<String>,
}

impl Default for RedactionConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            entropy_threshold: 4.2,
            min_token_len: 20,
            allowlist_paths: Vec::new(),
            extra_patterns: Vec::new(),
            ignore_patterns: Vec::new(),
        }
    }
}

/// Network egress mode for the sandbox and the `web_fetch` SSRF guard.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "mode")]
pub enum NetworkMode {
    /// No network at all.
    Deny,
    /// Loopback only (dev servers, LSP).
    LocalhostOnly,
    /// An explicit host allowlist.
    Allowlist {
        /// Host patterns. `*` must be explicit; there is no implicit allow.
        hosts: Vec<String>,
    },
    /// Unrestricted. Only meaningful with `sandbox.enabled = false` or in a
    /// container; produces a warning event on every turn.
    Allow,
}

impl Default for NetworkMode {
    fn default() -> Self {
        Self::LocalhostOnly
    }
}

impl NetworkMode {
    /// Stable label for metrics.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            NetworkMode::Deny => "deny",
            NetworkMode::LocalhostOnly => "localhost",
            NetworkMode::Allowlist { .. } => "allowlist",
            NetworkMode::Allow => "allow",
        }
    }
}

/// `[sandbox]` — defence in depth, layer 3 (§6.4).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct SandboxConfig {
    /// Enable OS-level sandboxing. **Fail-closed**: if no backend is available
    /// the shell tool refuses to run unless `--no-sandbox` is passed.
    pub enabled: bool,
    /// Force a specific backend instead of probing.
    pub backend: Option<String>,
    /// Extra writable roots beyond the workspace.
    pub writable: Vec<String>,
    /// Extra readable roots beyond the defaults.
    pub readable: Vec<String>,
    /// Egress policy.
    pub network: NetworkMode,
    /// Allow child processes at all.
    pub allow_spawn: bool,
    /// Environment variables passed through to children. Everything else is
    /// scrubbed (§9.9 `env.rs`) — API keys never reach a child by default.
    pub env_allowlist: Vec<String>,
    /// Resource limits.
    pub resource: ResourceLimits,
    /// Refuse to run when the sandbox self-test fails at startup.
    pub fail_on_self_test: bool,
}

impl Default for SandboxConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            backend: None,
            writable: Vec::new(),
            readable: Vec::new(),
            network: NetworkMode::default(),
            allow_spawn: true,
            env_allowlist: default_env_allowlist(),
            resource: ResourceLimits::default(),
            fail_on_self_test: true,
        }
    }
}

/// Environment variables a child process may see by default.
#[must_use]
pub fn default_env_allowlist() -> Vec<String> {
    vec![
        "PATH", "HOME", "USER", "LOGNAME", "SHELL", "LANG", "LC_ALL", "LC_CTYPE",
        "TERM", "COLORTERM", "TZ", "TMPDIR", "TEMP", "TMP", "PWD", "HOSTNAME",
        "CARGO_HOME", "RUSTUP_HOME", "GOPATH", "JAVA_HOME", "NODE_PATH",
    ]
    .into_iter()
    .map(String::from)
    .collect()
}

/// `[sandbox.resource]`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct ResourceLimits {
    /// CPU seconds per command.
    pub cpu_secs: u64,
    /// Resident memory cap in MiB.
    pub memory_mib: u64,
    /// Maximum number of processes in the group.
    pub max_processes: u32,
    /// Maximum open file descriptors.
    pub max_open_files: u32,
    /// Maximum captured output bytes before truncation.
    pub max_output_bytes: u64,
    /// Wall-clock deadline per command in seconds.
    pub wall_timeout_secs: u64,
}

impl Default for ResourceLimits {
    fn default() -> Self {
        Self {
            cpu_secs: 600,
            memory_mib: 4096,
            max_processes: 256,
            max_open_files: 1024,
            max_output_bytes: 10 * 1024 * 1024,
            wall_timeout_secs: 600,
        }
    }
}

/// `[context]` — the context economy (§6.1).
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct ContextConfig {
    /// Fraction of the usable window at which compaction starts (soft
    /// watermark).
    pub compact_at: f32,
    /// Fraction at which compaction is forced before sending (hard watermark).
    pub compact_hard_at: f32,
    /// Target fraction after compaction.
    pub compact_target: f32,
    /// Token budget for the repository map.
    pub repo_map_tokens: u32,
    /// Number of recently edited files re-injected after compaction (§6.1.2).
    pub keep_recent_files: usize,
    /// Total token cap for the memory hierarchy.
    pub memory_cap: u32,
    /// Fraction of the window reserved for tool schemas before deferral kicks
    /// in (§6.1.1).
    pub tool_schema_budget: f32,
    /// Number of tools whose schema is always sent; the rest are deferred
    /// behind `tool_search`.
    pub eager_tools: usize,
    /// Maximum ledger-vs-provider drift before the safety reserve grows.
    pub drift_tolerance: f32,
    /// Number of consecutive over-tolerance turns that trigger reserve growth.
    pub drift_turns: u8,
    /// Cap on a single tool result before `snip` clips it.
    pub max_tool_output_bytes: usize,
    /// Cap on grep matches returned to the model.
    pub max_grep_matches: usize,
    /// Cap on read-file lines returned to the model.
    pub max_read_lines: usize,
}

impl Default for ContextConfig {
    fn default() -> Self {
        Self {
            compact_at: 0.72,
            compact_hard_at: 0.90,
            compact_target: 0.45,
            repo_map_tokens: 2048,
            keep_recent_files: 5,
            memory_cap: 6000,
            tool_schema_budget: 0.09,
            eager_tools: 8,
            drift_tolerance: 0.08,
            drift_turns: 3,
            max_tool_output_bytes: 30_000,
            max_grep_matches: 200,
            max_read_lines: 2000,
        }
    }
}

/// `[tools]` — per-tool toggles (§3.6).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct ToolsConfig {
    /// Explicitly enabled tools. Empty = "all built-ins allowed by mode".
    pub enabled: Vec<String>,
    /// Explicitly disabled tools. Wins over `enabled`.
    pub disabled: Vec<String>,
    /// Keep a persistent shell so `cd` and exports survive across calls.
    pub shell_session: bool,
    /// Default shell command timeout in seconds.
    pub shell_timeout_secs: u64,
    /// Maximum concurrent read-only tool calls (§6.2.4).
    pub max_parallel: usize,
    /// LSP configuration.
    pub lsp: LspConfig,
    /// `web_fetch` limits.
    pub web: WebConfig,
    /// Trash-instead-of-delete for `move_copy` (§9.8).
    pub trash_by_default: bool,
    /// Maximum depth of nested `task` subagents (§9.8 `task.rs`: depth limit 2).
    pub max_subagent_depth: u8,
}

impl Default for ToolsConfig {
    fn default() -> Self {
        Self {
            enabled: Vec::new(),
            disabled: Vec::new(),
            shell_session: true,
            shell_timeout_secs: 120,
            max_parallel: 8,
            lsp: LspConfig::default(),
            web: WebConfig::default(),
            trash_by_default: true,
            max_subagent_depth: 2,
        }
    }
}

/// `[tools.lsp]`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct LspConfig {
    /// Enable LSP-backed diagnostics.
    pub enabled: bool,
    /// Server specs to try, in order.
    pub servers: Vec<LspServerSpec>,
    /// Debounce after an edit before collecting diagnostics, in milliseconds.
    pub debounce_ms: u64,
    /// Maximum diagnostics returned to the model.
    pub max_diagnostics: usize,
}

impl Default for LspConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            servers: default_lsp_servers(),
            debounce_ms: 800,
            max_diagnostics: 50,
        }
    }
}

/// One language server spec.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LspServerSpec {
    /// Language id (`rust`, `typescript`, …).
    pub language: String,
    /// File extensions that trigger this server.
    pub extensions: Vec<String>,
    /// Command to spawn.
    pub command: String,
    /// Arguments.
    #[serde(default)]
    pub args: Vec<String>,
}

/// Default language servers, auto-detected at startup.
#[must_use]
pub fn default_lsp_servers() -> Vec<LspServerSpec> {
    vec![
        LspServerSpec {
            language: "rust".into(),
            extensions: vec!["rs".into()],
            command: "rust-analyzer".into(),
            args: vec![],
        },
        LspServerSpec {
            language: "typescript".into(),
            extensions: vec!["ts".into(), "tsx".into(), "js".into(), "jsx".into()],
            command: "typescript-language-server".into(),
            args: vec!["--stdio".into()],
        },
        LspServerSpec {
            language: "go".into(),
            extensions: vec!["go".into()],
            command: "gopls".into(),
            args: vec![],
        },
        LspServerSpec {
            language: "python".into(),
            extensions: vec!["py".into()],
            command: "pyright-langserver".into(),
            args: vec!["--stdio".into()],
        },
    ]
}

/// `[tools.web]`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct WebConfig {
    /// Enable `web_fetch`.
    pub fetch_enabled: bool,
    /// Maximum bytes downloaded.
    pub max_bytes: u64,
    /// Follow redirects at all.
    pub follow_redirects: bool,
    /// Maximum redirect hops.
    pub max_redirects: u8,
    /// Block private/link-local/metadata IPs (SSRF guard). **Never disable
    /// this without an explicit managed-policy decision.**
    pub block_private_ips: bool,
    /// Search backend configuration; `None` disables the `web_search` tool
    /// entirely, including its schema (§9.8 `net/search.rs`).
    pub search: Option<SearchConfig>,
    /// Request timeout in seconds.
    pub timeout_secs: u64,
    /// User-Agent string.
    pub user_agent: String,
}

impl Default for WebConfig {
    fn default() -> Self {
        Self {
            fetch_enabled: true,
            max_bytes: 5 * 1024 * 1024,
            follow_redirects: true,
            max_redirects: 5,
            block_private_ips: true,
            search: None,
            timeout_secs: 30,
            user_agent: concat!("agent/", env!("CARGO_PKG_VERSION")).to_string(),
        }
    }
}

/// `[tools.web.search]`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct SearchConfig {
    /// Backend id (`tavily`, `brave`, `serper`, …).
    pub backend: String,
    /// Environment variable holding the API key.
    pub api_key_env: String,
    /// Maximum results.
    pub max_results: usize,
}

impl Default for SearchConfig {
    fn default() -> Self {
        Self { backend: "tavily".into(), api_key_env: "AGENT_SEARCH_API_KEY".into(), max_results: 8 }
    }
}

/// `[agents]` — parallel subagents (§7.13).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct AgentsConfig {
    /// Enable the parallel orchestrator at all.
    pub enabled: bool,
    /// Maximum concurrent workers.
    pub max_workers: usize,
    /// Hard cap on DAG nodes (soft cap is 6, §7.3 rule 3).
    pub max_nodes: usize,
    /// Per-worker token budget.
    pub task_budget: u64,
    /// Run-level token budget; 0 = unlimited.
    pub run_budget: u64,
    /// Run-level cost cap in USD micros; 0 = unlimited.
    pub max_cost_micros: u64,
    /// Fraction of `max_cost_micros` at which a warning fires (§7.5).
    pub cost_warn_fraction: f32,
    /// Default isolation level.
    pub isolation: IsolationLevel,
    /// Merge policy (§7.9).
    pub merge_policy: MergePolicy,
    /// Verify gate timeout in seconds.
    pub verify_timeout_secs: u64,
    /// Retries allowed per node before quarantine.
    pub node_retries: u8,
    /// Lease expiry in seconds (§7.6: 5 min).
    pub lease_ttl_secs: u64,
    /// Lease heartbeat interval in seconds (§7.6: 30 s).
    pub lease_heartbeat_secs: u64,
    /// Wait time after which a queued node ages up a priority class (§7.5).
    pub aging_secs: u64,
    /// Remove worker worktrees when the run finishes.
    pub cleanup_worktrees: bool,
    /// Maximum total disk used by worktrees, in MiB.
    pub worktree_disk_cap_mib: u64,
}

impl Default for AgentsConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            max_workers: 4,
            max_nodes: 12,
            task_budget: 90_000,
            run_budget: 600_000,
            max_cost_micros: 0,
            cost_warn_fraction: 0.8,
            isolation: IsolationLevel::L2Worktree,
            merge_policy: MergePolicy::default(),
            verify_timeout_secs: 600,
            node_retries: 1,
            lease_ttl_secs: 300,
            lease_heartbeat_secs: 30,
            aging_secs: 120,
            cleanup_worktrees: true,
            worktree_disk_cap_mib: 4096,
        }
    }
}

/// How the merge queue resolves conflicts (§7.9).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MergePolicy {
    /// Auto-resolve whitespace-only conflicts, otherwise retry the worker once.
    Conservative,
    /// Retry the worker up to `node_retries` then escalate to the user.
    Retry,
    /// Escalate to the user immediately.
    Escalate,
    /// Drop the conflicting worker's change.
    Drop,
}

impl Default for MergePolicy {
    fn default() -> Self {
        Self::Conservative
    }
}

/// `[hooks]` — lifecycle hooks (§9.16).
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct HooksConfig {
    /// Runs before the model sees a new session.
    pub session_start: Vec<HookSpec>,
    /// Runs before a tool executes. Exit code 2 blocks the call.
    pub pre_tool_use: Vec<HookSpec>,
    /// Runs after a tool completes.
    pub post_tool_use: Vec<HookSpec>,
    /// Runs after the user submits, before the model call.
    pub user_prompt_submit: Vec<HookSpec>,
    /// Runs when the context is compacted.
    pub pre_compact: Vec<HookSpec>,
    /// Runs when the session ends.
    pub session_end: Vec<HookSpec>,
    /// Runs when a worker finishes.
    pub worker_complete: Vec<HookSpec>,
    /// Default timeout in seconds.
    pub timeout_secs: u64,
    /// `open` = a failing hook does not block; `closed` = it does.
    pub failure_mode: HookFailureMode,
}

/// Hook failure semantics.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HookFailureMode {
    /// A hook that crashes is ignored (with a warning event).
    Open,
    /// A hook that crashes blocks the action.
    Closed,
}

impl Default for HookFailureMode {
    fn default() -> Self {
        Self::Open
    }
}

/// One hook definition.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, tag = "kind", rename_all = "snake_case")]
pub enum HookSpec {
    /// Run a local executable; the JSON payload arrives on stdin.
    Command {
        /// Matcher expression, e.g. `tool == shell && cmd =~ ^git `.
        #[serde(default)]
        matcher: Option<String>,
        /// Command line.
        command: String,
        /// Timeout override in seconds.
        #[serde(default)]
        timeout_secs: Option<u64>,
    },
    /// POST the payload to a URL.
    Webhook {
        /// Matcher expression.
        #[serde(default)]
        matcher: Option<String>,
        /// Target URL.
        url: String,
        /// Environment variable holding a bearer token.
        #[serde(default)]
        token_env: Option<String>,
        /// Timeout override in seconds.
        #[serde(default)]
        timeout_secs: Option<u64>,
    },
}

/// `[telemetry]` — **default off** (§3.6).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct TelemetryConfig {
    /// Master switch. Default false: nothing leaves the process.
    pub enabled: bool,
    /// OTLP endpoint.
    pub otlp_endpoint: Option<String>,
    /// OTLP protocol (`grpc` or `http/protobuf`).
    pub otlp_protocol: String,
    /// Sampling rate 0..=1.
    pub sample_rate: f32,
    /// Write a local JSONL trace regardless of `enabled` (for `agent doctor`).
    pub local_trace: bool,
    /// Rolling log file size cap in MiB.
    pub max_log_mib: u64,
    /// Number of rolling log files kept.
    pub log_files: usize,
    /// Scrub paths, prompts and hostnames before export (§9.19 `privacy.rs`).
    pub scrub: bool,
    /// Include prompt text. **Off by default and audited when enabled.**
    pub include_prompts: bool,
}

impl Default for TelemetryConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            otlp_endpoint: None,
            otlp_protocol: "http/protobuf".into(),
            sample_rate: 0.1,
            local_trace: true,
            max_log_mib: 50,
            log_files: 5,
            scrub: true,
            include_prompts: false,
        }
    }
}

/// `[ui]` — terminal preferences.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct UiConfig {
    /// Theme name.
    pub theme: String,
    /// Keymap profile (`default`, `vim`, or a user file name).
    pub keymap: String,
    /// Screen-reader mode: linear output, no animation (§9.12 `a11y.rs`).
    pub a11y: bool,
    /// Disable all animation (also honoured when `TERM=dumb`).
    pub reduced_motion: bool,
    /// Enable mouse tracking.
    pub mouse: bool,
    /// Attempt kitty/sixel image rendering.
    pub images: bool,
    /// Show reasoning blocks in the transcript. Off by default (§6.3.4).
    pub show_thinking: bool,
    /// Render target frame rate.
    pub fps: u16,
    /// Collapse tool cards by default.
    pub collapse_tools: bool,
    /// Maximum transcript messages kept in memory.
    pub transcript_cache: usize,
    /// Show the parallel worker board panel.
    pub board: bool,
}

impl Default for UiConfig {
    fn default() -> Self {
        Self {
            theme: "auto".into(),
            keymap: "default".into(),
            a11y: false,
            reduced_motion: false,
            mouse: false,
            images: false,
            show_thinking: false,
            fps: 60,
            collapse_tools: true,
            transcript_cache: 4096,
            board: true,
        }
    }
}

/// `[enterprise]` — admin-locked settings (§3.6, §9.5 `managed.rs`).
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct EnterpriseConfig {
    /// Path to the managed policy file. Immutable from user layers.
    pub managed_policy_path: Option<String>,
    /// Audit sink: `jsonl`, `syslog`, `otlp`.
    pub audit_sink: Option<String>,
    /// Syslog host for RFC5424 export.
    pub audit_syslog_host: Option<String>,
    /// Identity mode: `local`, `oidc`, `ci`.
    pub identity_mode: IdentityMode,
    /// OIDC issuer for workforce identity.
    pub oidc_issuer: Option<String>,
    /// OIDC client id.
    pub oidc_client_id: Option<String>,
    /// Refuse to start outside an approved organisation.
    pub require_org: Option<String>,
    /// Anchor the audit chain every N entries.
    pub audit_anchor_every: u64,
    /// Retention days for audit logs.
    pub audit_retention_days: u32,
    /// Hard-fail (instead of warn) when a developer layer tries to weaken a
    /// managed deny rule.
    pub strict_managed: bool,
}

/// Identity mode (§9.17 `service_account.rs`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum IdentityMode {
    /// Interactive local user; OS keyring.
    Local,
    /// OIDC workforce identity.
    Oidc,
    /// CI: env vars / workload identity, never interactive.
    Ci,
}

impl Default for IdentityMode {
    fn default() -> Self {
        Self::Local
    }
}

/// `[state]` — persistence and retention (§6.5).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct StateConfig {
    /// Override the data directory. `None` = `~/.local/share/agent`.
    pub data_dir: Option<String>,
    /// Override the config directory. `None` = `~/.config/agent`.
    pub config_dir: Option<String>,
    /// Override the cache directory. `None` = `~/.cache/agent`.
    pub cache_dir: Option<String>,
    /// Rollout file rotation size in MiB.
    pub rollout_rotate_mib: u64,
    /// fsync the rollout at turn boundaries (§6.5 rule 2).
    pub fsync_turns: bool,
    /// Retention in days; 0 = keep forever.
    pub retention_days: u32,
    /// Total disk cap in MiB; GC runs when exceeded.
    pub disk_cap_mib: u64,
    /// Content-addressed snapshot store for `/undo`.
    pub snapshots: bool,
    /// Use shadow-git checkpoints when inside a git repo (§6.5).
    pub shadow_git: bool,
    /// Build the SQLite FTS index (costs disk, enables history search).
    pub fts_index: bool,
}

impl Default for StateConfig {
    fn default() -> Self {
        Self {
            data_dir: None,
            config_dir: None,
            cache_dir: None,
            rollout_rotate_mib: 100,
            fsync_turns: true,
            retention_days: 30,
            disk_cap_mib: 500,
            snapshots: true,
            shadow_git: true,
            fts_index: true,
        }
    }
}

/// Every config key path, with its default value rendered as a string.
///
/// Powers `agent config list`, `agent config explain <key>` and the generated
/// documentation. Built by walking a default instance so it can never drift
/// from the struct definitions.
#[must_use]
pub fn key_catalogue() -> Vec<(String, String, String)> {
    let default = AgentConfig::default();
    let v = serde_json::to_value(&default).unwrap_or(serde_json::Value::Null);
    let mut out = Vec::new();
    flatten("", &v, &mut out);
    out.sort_by(|a, b| a.0.cmp(&b.0));
    out
}

fn flatten(prefix: &str, v: &serde_json::Value, out: &mut Vec<(String, String, String)>) {
    match v {
        serde_json::Value::Object(map) => {
            for (k, val) in map {
                let path = if prefix.is_empty() { k.clone() } else { format!("{prefix}.{k}") };
                flatten(&path, val, out);
            }
        }
        serde_json::Value::Array(items) => {
            let rendered = if items.is_empty() {
                "[]".to_string()
            } else {
                format!("[{} items]", items.len())
            };
            out.push((prefix.to_string(), "array".to_string(), rendered));
        }
        other => {
            let ty = match other {
                serde_json::Value::Null => "unset",
                serde_json::Value::Bool(_) => "bool",
                serde_json::Value::Number(_) => "number",
                serde_json::Value::String(_) => "string",
                _ => "object",
            };
            let rendered = match other {
                serde_json::Value::Null => "(unset)".to_string(),
                serde_json::Value::String(s) => s.clone(),
                x => x.to_string(),
            };
            out.push((prefix.to_string(), ty.to_string(), rendered));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_are_safe() {
        let c = AgentConfig::default();
        assert_eq!(c.permissions.mode, Mode::Ask, "default mode must be ask");
        assert!(c.sandbox.enabled, "sandbox must default to on");
        assert!(c.sandbox.fail_on_self_test, "fail-closed by default");
        assert!(!c.telemetry.enabled, "telemetry must default to off");
        assert!(!c.telemetry.include_prompts, "prompts must never be exported by default");
        assert!(c.permissions.redaction.enabled, "redaction must default to on");
        assert_eq!(c.sandbox.network, NetworkMode::LocalhostOnly);
        assert_eq!(c.tools.max_subagent_depth, 2);
    }

    #[test]
    fn default_deny_list_covers_the_classic_destructive_commands() {
        let deny = default_deny_rules();
        for needle in ["shell(rm -rf /)", "shell(sudo **)", "shell(git push --force**)", "net(169.254.169.254)"] {
            assert!(deny.iter().any(|r| r == needle), "missing {needle}");
        }
    }

    #[test]
    fn readonly_shell_allowlist_is_argv_aware() {
        let allow = default_readonly_shell();
        assert!(allow.iter().any(|p| p == "shell(git status **)"));
        assert!(!allow.iter().any(|p| p.contains("git push")), "push must never be read-only");
    }

    #[test]
    fn unknown_keys_are_rejected() {
        let toml_src = "[permissions]\npermisions_typo = true\n";
        let err = toml::from_str::<AgentConfig>(toml_src).unwrap_err();
        assert!(err.to_string().contains("deny_unknown_fields") || err.to_string().contains("unknown"), "{err}");
    }

    #[test]
    fn a_partial_config_inherits_defaults() {
        let c: AgentConfig = toml::from_str("[context]\ncompact_at = 0.5\n").unwrap();
        assert!((c.context.compact_at - 0.5).abs() < f32::EPSILON);
        assert_eq!(c.context.keep_recent_files, ContextConfig::default().keep_recent_files);
        assert_eq!(c.permissions.mode, Mode::Ask);
    }

    #[test]
    fn model_ids_parse_from_config() {
        let c: AgentConfig = toml::from_str(
            "[model]\nname = \"anthropic/claude-sonnet-4-5\"\nfallback = [\"openai/gpt-5\"]\n",
        )
        .unwrap();
        assert_eq!(c.model.name.unwrap().provider, "anthropic");
        assert_eq!(c.model.fallback.len(), 1);
    }

    #[test]
    fn network_mode_is_externally_tagged() {
        let c: AgentConfig =
            toml::from_str("[sandbox.network]\nmode = \"allowlist\"\nhosts = [\"api.example.com\"]\n").unwrap();
        match c.sandbox.network {
            NetworkMode::Allowlist { hosts } => assert_eq!(hosts, vec!["api.example.com".to_string()]),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn hooks_support_both_kinds() {
        let c: AgentConfig = toml::from_str(
            "[[hooks.pre_tool_use]]\nkind = \"command\"\ncommand = \"./check.sh\"\nmatcher = \"tool == shell\"\n",
        )
        .unwrap();
        assert_eq!(c.hooks.pre_tool_use.len(), 1);
    }

    #[test]
    fn config_roundtrips_through_toml() {
        let c = AgentConfig::default();
        let s = toml::to_string(&c).unwrap();
        let back: AgentConfig = toml::from_str(&s).unwrap();
        assert_eq!(back, c, "config must be losslessly round-trippable");
    }

    #[test]
    fn key_catalogue_covers_every_section() {
        let keys = key_catalogue();
        let text = keys.iter().map(|(k, _, _)| k.as_str()).collect::<Vec<_>>().join("\n");
        for section in ["model.", "permissions.", "sandbox.", "context.", "tools.", "agents.", "hooks.", "telemetry.", "ui.", "enterprise.", "state."] {
            assert!(text.contains(section), "catalogue missing {section}");
        }
        assert!(keys.len() > 60, "only {} keys", keys.len());
        assert!(keys.iter().any(|(k, _, v)| k == "permissions.mode" && v == "ask"));
        assert!(keys.iter().any(|(k, _, v)| k == "telemetry.enabled" && v == "false"));
    }

    #[test]
    fn env_allowlist_never_includes_secret_variables() {
        let allow = default_env_allowlist();
        for bad in ["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "AWS_SECRET_ACCESS_KEY", "AGENT_API_KEY", "GITHUB_TOKEN"] {
            assert!(!allow.contains(&bad.to_string()), "{bad} must not reach child processes");
        }
    }
}
