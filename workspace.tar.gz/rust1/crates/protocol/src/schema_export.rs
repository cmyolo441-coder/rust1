//! JSON Schema emission and SDK stub generation (`rustplan.txt` §9.1
//! `src/schema_export.rs`, §9.14 `server/src/sdk_schema.rs`).
//!
//! The schemas here are **hand-maintained but machine-checked**: [`validate`]
//! is a small JSON-Schema subset evaluator, and the test suite asserts that
//! every sample value our own serde code produces validates against the
//! published schema. That is the drift check the plan asks for ("SDK drift CI
//! me fail") without pulling in a proc-macro that would make `protocol` slow
//! to compile.
//!
//! The subset implemented is exactly what our schemas use: `type`, `enum`,
//! `const`, `required`, `properties`, `additionalProperties`, `items`,
//! `anyOf`, `$ref` (into the local `#/$defs/…` namespace), `minimum`,
//! `maximum`, `minItems`.

use serde_json::{Map, Value};

/// Which schema to emit.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SchemaKind {
    /// The full event catalogue.
    Event,
    /// The op catalogue.
    Op,
    /// The configuration document.
    Config,
    /// A tool call.
    ToolCall,
    /// A tool result.
    ToolResult,
    /// A permission request.
    PermissionRequest,
    /// A parallel task plan.
    TaskPlan,
    /// A worker report.
    WorkerReport,
}

impl SchemaKind {
    /// All kinds.
    pub const ALL: [SchemaKind; 8] = [
        SchemaKind::Event,
        SchemaKind::Op,
        SchemaKind::Config,
        SchemaKind::ToolCall,
        SchemaKind::ToolResult,
        SchemaKind::PermissionRequest,
        SchemaKind::TaskPlan,
        SchemaKind::WorkerReport,
    ];

    /// File stem used for emitted artifacts.
    #[must_use]
    pub const fn stem(self) -> &'static str {
        match self {
            SchemaKind::Event => "event",
            SchemaKind::Op => "op",
            SchemaKind::Config => "config",
            SchemaKind::ToolCall => "tool_call",
            SchemaKind::ToolResult => "tool_result",
            SchemaKind::PermissionRequest => "permission_request",
            SchemaKind::TaskPlan => "task_plan",
            SchemaKind::WorkerReport => "worker_report",
        }
    }

    /// The `title` used inside the schema.
    #[must_use]
    pub fn title(self) -> String {
        match self {
            SchemaKind::Event => "AgentEvent".to_owned(),
            SchemaKind::Op => "AgentOp".to_owned(),
            SchemaKind::Config => "AgentConfig".to_owned(),
            SchemaKind::ToolCall => "ToolCall".to_owned(),
            SchemaKind::ToolResult => "ToolResult".to_owned(),
            SchemaKind::PermissionRequest => "PermissionRequest".to_owned(),
            SchemaKind::TaskPlan => "TaskPlan".to_owned(),
            SchemaKind::WorkerReport => "WorkerReport".to_owned(),
        }
    }
}

/// Emit the JSON Schema for one kind, with the protocol version pinned.
#[must_use]
pub fn json_schema(kind: SchemaKind) -> Value {
    let (body, defs) = match kind {
        SchemaKind::Event => (event_schema(), shared_defs()),
        SchemaKind::Op => (op_schema(), shared_defs()),
        SchemaKind::Config => (config_schema(), shared_defs()),
        SchemaKind::ToolCall => (tool_call_schema(), shared_defs()),
        SchemaKind::ToolResult => (tool_result_schema(), shared_defs()),
        SchemaKind::PermissionRequest => (permission_request_schema(), shared_defs()),
        SchemaKind::TaskPlan => (task_plan_schema(), shared_defs()),
        SchemaKind::WorkerReport => (worker_report_schema(), shared_defs()),
    };
    let mut root = Map::new();
    root.insert("$schema".into(), json("https://json-schema.org/draft/2020-12/schema"));
    root.insert("$id".into(), json(format!("https://agent.rs/schema/{}/v{}.json", kind.stem(), crate::PROTOCOL_VERSION)));
    root.insert("title".into(), json(kind.title()));
    for (k, v) in body {
        root.insert(k.to_owned(), v);
    }
    root.insert("$defs".into(), Value::Object(defs));
    Value::Object(root)
}

fn json<T: Into<Value>>(v: T) -> Value {
    v.into()
}

fn obj(pairs: Vec<(&str, Value)>) -> Value {
    Value::Object(pairs.into_iter().map(|(k, v)| (k.to_owned(), v)).collect())
}

fn props(pairs: Vec<(&str, Value)>) -> Value {
    Value::Object(pairs.into_iter().map(|(k, v)| (k.to_owned(), v)).collect())
}

fn enum_of(values: &[&str]) -> Value {
    obj(vec![("enum", Value::Array(values.iter().map(|v| json(*v)).collect()))])
}

fn ref_to(name: &str) -> Value {
    obj(vec![("$ref", json(format!("#/$defs/{name}")))])
}

fn shared_defs() -> Map<String, Value> {
    let mut d = Map::new();
    d.insert(
        "ulid".into(),
        obj(vec![("type".into(), json("string")), ("pattern".into(), json(r"^[a-z]{3}_[0-9A-HJKMNP-TV-Z]{26}$"))]),
    );
    d.insert("modelId".into(), obj(vec![("type".into(), json("string")), ("pattern".into(), json(r"^[^/]+/.+$"))]));
    d.insert(
        "usage".into(),
        obj(vec![
            ("type".into(), json("object")),
            (
                "properties".into(),
                props(vec![
                    ("input", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                    ("output", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                    ("cache_read", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                    ("cache_write", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                    ("reasoning", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                    ("cost_micros", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                    ("from_provider", obj(vec![("type", json("boolean"))])),
                ]),
            ),
        ]),
    );
    d.insert(
        "jsonValue".into(),
        obj(vec![("description".into(), json("arbitrary JSON"))]),
    );
    d
}

fn event_schema() -> Vec<(&'static str, Value)> {
    let variants: Vec<Value> = [
        "turn_started", "state_changed", "turn_completed", "turn_failed", "turn_cancelled",
        "text_delta", "thinking_delta", "text_completed", "content_replaced", "tool_requested",
        "tool_approval_needed", "tool_approval_decided", "tool_started", "tool_output_delta",
        "tool_completed", "tool_failed", "tool_denied", "context_assembled", "compact_started",
        "compact_stage", "compact_completed", "memory_loaded", "worker_spawned", "worker_progress",
        "worker_reported", "worker_cancelled", "merge_queued", "merge_completed", "verify_result",
        "usage_updated", "cost_updated", "warning", "error", "config_changed", "session_resumed",
    ]
    .iter()
    .map(|t| {
        obj(vec![
            ("type", json("object")),
            ("properties", props(vec![("type", json(*t))])),
            ("required", Value::Array(vec![json("type")])),
        ])
    })
    .collect();

    vec![
        ("type", json("object")),
        (
            "required".into(),
            Value::Array(vec![json("id"), json("thread"), json("ts"), json("seq"), json("v"), json("type")]),
        ),
        (
            "properties".into(),
            props(vec![
                ("id", ref_to("ulid")),
                ("thread", ref_to("ulid")),
                ("turn", ref_to("ulid")),
                ("worker", ref_to("ulid")),
                ("ts", obj(vec![("type", json("string")), ("format", json("date-time"))])),
                ("seq", obj(vec![("type", json("integer")), ("minimum", json(0))])),
                ("v", obj(vec![("type", json("integer")), ("minimum", json(1))])),
                ("checksum", obj(vec![("type", json("string")), ("pattern", json("^blake3:[0-9a-f]{64}$"))])),
            ]),
        ),
        ("anyOf".into(), Value::Array(variants)),
        (
            "description".into(),
            json("Additive only. Clients MUST ignore unknown `type` values."),
        ),
    ]
}

fn op_schema() -> Vec<(&'static str, Value)> {
    let variants: Vec<Value> = [
        "submit", "steer", "interrupt", "approve", "deny", "compact", "set_mode", "set_model",
        "spawn_workers", "cancel_workers", "shutdown",
    ]
    .iter()
    .map(|t| {
        obj(vec![
            ("type", json("object")),
            ("properties", props(vec![("op", json(*t))])),
            ("required", Value::Array(vec![json("op")])),
        ])
    })
    .collect();
    vec![
        ("type", json("object")),
        (
            "required".into(),
            Value::Array(vec![json("id"), json("protocol_version"), json("op")]),
        ),
        (
            "properties".into(),
            props(vec![
                ("id", ref_to("ulid")),
                ("protocol_version", obj(vec![("type", json("integer")), ("minimum", json(1))])),
                ("sent_at_ms", obj(vec![("type", json("integer")), ("minimum", json(0))])),
            ]),
        ),
        ("anyOf".into(), Value::Array(variants)),
    ]
}

fn config_schema() -> Vec<(&'static str, Value)> {
    // Derived from the real defaults so it cannot drift: every key in the
    // default document becomes an optional property with the right type.
    let defaults = serde_json::to_value(crate::config_types::AgentConfig::default())
        .unwrap_or(Value::Object(Map::new()));
    let mut properties = Map::new();
    if let Value::Object(map) = &defaults {
        for (section, value) in map {
            let mut section_props = Map::new();
            if let Value::Object(fields) = value {
                for (k, v) in fields {
                    section_props.insert(k.clone(), json_type_of(v));
                }
            }
            properties.insert(
                section.clone(),
                obj(vec![
                    ("type", json("object")),
                    ("properties", Value::Object(section_props)),
                ]),
            );
        }
    }
    vec![
        ("type", json("object")),
        ("additionalProperties", json(false)),
        ("properties", Value::Object(properties)),
    ]
}

fn json_type_of(v: &Value) -> Value {
    match v {
        Value::Null => obj(vec![("description", json("unset; see the Rust type for the real shape"))]),
        Value::Bool(_) => obj(vec![("type", json("boolean"))]),
        Value::Number(n) if n.is_i64() || n.is_u64() => obj(vec![("type", json("integer"))]),
        Value::Number(_) => obj(vec![("type", json("number"))]),
        Value::String(_) => obj(vec![("type", json("string"))]),
        Value::Array(items) => obj(vec![
            ("type", json("array")),
            ("items", items.first().map_or_else(|| obj(vec![("description", json("see Rust type"))]), json_type_of)),
        ]),
        Value::Object(_) => obj(vec![("type", json("object"))]),
    }
}

fn tool_call_schema() -> Vec<(&'static str, Value)> {
    vec![
        ("type", json("object")),
        ("required", Value::Array(vec![json("id"), json("name")])),
        (
            "properties",
            props(vec![
                ("id", ref_to("ulid")),
                ("name", obj(vec![("type", json("string")), ("minLength", json(1))])),
                ("args", ref_to("jsonValue")),
                (
                    "risk",
                    enum_of(&["read", "mutate", "destructive", "exec", "network", "spawn", "meta"]),
                ),
                ("index", obj(vec![("type", json("integer")), ("minimum", json(0))])),
            ]),
        ),
        ("additionalProperties", json(false)),
    ]
}

fn tool_result_schema() -> Vec<(&'static str, Value)> {
    vec![
        ("type", json("object")),
        ("required", Value::Array(vec![json("status")])),
        (
            "properties",
            props(vec![
                ("status", enum_of(&["ok", "err", "denied"])),
                ("call_id", ref_to("ulid")),
                ("summary", obj(vec![("type", json("string"))])),
                ("truncated", obj(vec![("type", json("boolean"))])),
                ("duration_ms", obj(vec![("type", json("integer")), ("minimum", json(0))])),
            ]),
        ),
    ]
}

fn permission_request_schema() -> Vec<(&'static str, Value)> {
    vec![
        ("type", json("object")),
        ("required", Value::Array(vec![json("request_id"), json("tool"), json("risk"), json("args_preview"), json("raised_at_ms")])),
        (
            "properties",
            props(vec![
                ("request_id", ref_to("ulid")),
                ("tool", obj(vec![("type", json("string"))])),
                (
                    "risk",
                    enum_of(&["read", "mutate", "destructive", "exec", "network", "spawn", "meta"]),
                ),
                ("args_preview", obj(vec![("type", json("string"))])),
                ("args", ref_to("jsonValue")),
                ("paths", obj(vec![("type", json("array")), ("items", obj(vec![("type", json("string"))]))])),
                ("cwd", obj(vec![("type", json("string"))])),
                ("rule_hint", obj(vec![("type", json("string"))])),
                ("scope", enum_of(&["once", "turn", "session"])),
                ("remember_pattern", obj(vec![("type", json("string"))])),
                ("raised_at_ms", obj(vec![("type", json("integer"))])),
            ]),
        ),
    ]
}

fn task_plan_schema() -> Vec<(&'static str, Value)> {
    // Reuse the authoritative planner schema (§7.3) so the model and the SDK
    // see exactly the same contract; only the JSON-Schema keywords are kept.
    let s = crate::plan::planner_json_schema();
    let mut out: Vec<(&'static str, Value)> = Vec::new();
    if let Value::Object(m) = s {
        for (k, v) in m {
            let key: &'static str = match k.as_str() {
                "type" => "type",
                "required" => "required",
                "properties" => "properties",
                "additionalProperties" => "additionalProperties",
                _ => continue,
            };
            out.push((key, v));
        }
    }
    out
}

fn worker_report_schema() -> Vec<(&'static str, Value)> {
    vec![
        ("type", json("object")),
        ("required", Value::Array(vec![json("node_id"), json("status"), json("summary")])),
        (
            "properties",
            props(vec![
                ("node_id", obj(vec![("type", json("string")), ("minLength", json(1))])),
                ("status", enum_of(&["done", "partial", "blocked", "failed"])),
                ("summary", obj(vec![("type", json("string")), ("minLength", json(1))])),
                (
                    "files_changed",
                    obj(vec![("type", json("array")), ("items", obj(vec![("type", json("string"))]))]),
                ),
                ("commits", obj(vec![("type", json("array")), ("items", obj(vec![("type", json("string"))]))])),
                ("acceptance_met", obj(vec![("type", json("boolean"))])),
                ("confidence", obj(vec![("type", json("number")), ("minimum", json(0.0)), ("maximum", json(1.0))])),
                ("blockers", obj(vec![("type", json("array")), ("items", obj(vec![("type", json("string"))]))])),
                ("cost", ref_to("usage")),
            ]),
        ),
        ("additionalProperties", json(false)),
    ]
}

/// Validate `value` against a schema produced by [`json_schema`].
///
/// Returns the list of JSON-pointer paths that failed. An empty vec means the
/// value conforms. Implements the subset described in the module docs.
#[must_use]
pub fn validate(schema: &Value, value: &Value) -> Vec<String> {
    let mut errors = Vec::new();
    validate_at(schema, value, "", schema, &mut errors);
    errors
}

fn validate_at(
    schema: &Value,
    value: &Value,
    path: &str,
    root: &Value,
    errors: &mut Vec<String>,
) {
    // $ref
    if let Some(r) = schema.get("$ref").and_then(Value::as_str) {
        if let Some(target) = resolve_ref(r, root) {
            validate_at(&target, value, path, root, errors);
        }
        return;
    }

    // anyOf
    if let Some(any) = schema.get("anyOf").and_then(Value::as_array) {
        let ok = any.iter().any(|sub| {
            let mut local = Vec::new();
            validate_at(sub, value, path, root, &mut local);
            local.is_empty()
        });
        if !ok {
            errors.push(format!("{path}: does not match any of the allowed shapes"));
        }
        // Also validate the sibling keywords (properties/required) against the
        // value, since `anyOf` only constrains the discriminator here.
        validate_keywords(schema, value, path, root, errors, &["anyOf"]);
        return;
    }

    validate_keywords(schema, value, path, root, errors, &[]);
}

fn validate_keywords(
    schema: &Value,
    value: &Value,
    path: &str,
    root: &Value,
    errors: &mut Vec<String>,
    skip: &[&str],
) {
    let has = |k: &str| !skip.contains(&k) && schema.get(k).is_some();

    if let Some(t) = schema.get("type").and_then(Value::as_str).filter(|_| has("type")) {
        if !type_matches(t, value) {
            errors.push(format!("{path}: expected type {t}"));
            return;
        }
    }
    if let Some(e) = schema.get("enum").and_then(Value::as_array).filter(|_| has("enum")) {
        if !e.contains(value) {
            errors.push(format!("{path}: value {value} not in enum"));
        }
    }
    if let Some(c) = schema.get("const").filter(|_| has("const")) {
        if c != value {
            errors.push(format!("{path}: expected const {c}"));
        }
    }
    if let Some(min) = schema.get("minimum").and_then(Value::as_f64).filter(|_| has("minimum")) {
        if value.as_f64().is_some_and(|n| n < min) {
            errors.push(format!("{path}: {value} < minimum {min}"));
        }
    }
    if let Some(max) = schema.get("maximum").and_then(Value::as_f64).filter(|_| has("maximum")) {
        if value.as_f64().is_some_and(|n| n > max) {
            errors.push(format!("{path}: {value} > maximum {max}"));
        }
    }

    match value {
        Value::Object(map) => {
            if let Some(req) = schema.get("required").and_then(Value::as_array).filter(|_| has("required")) {
                for r in req {
                    if let Some(name) = r.as_str() {
                        if !map.contains_key(name) {
                            errors.push(format!("{path}: missing required field `{name}`"));
                        }
                    }
                }
            }
            if let Some(p) = schema.get("properties").and_then(Value::as_object).filter(|_| has("properties")) {
                for (k, v) in map {
                    if let Some(sub) = p.get(k) {
                        validate_at(sub, v, &format!("{path}/{k}"), root, errors);
                    } else if schema.get("additionalProperties") == Some(&Value::Bool(false)) && has("additionalProperties") {
                        errors.push(format!("{path}/{k}: additional property not allowed"));
                    }
                }
            }
        }
        Value::Array(items) => {
            if let Some(n) = schema.get("minItems").and_then(Value::as_u64).filter(|_| has("minItems")) {
                if (items.len() as u64) < n {
                    errors.push(format!("{path}: fewer than {n} items"));
                }
            }
            if let Some(item_schema) = schema.get("items").filter(|_| has("items")) {
                for (i, it) in items.iter().enumerate() {
                    validate_at(item_schema, it, &format!("{path}/{i}"), root, errors);
                }
            }
        }
        Value::String(s) => {
            if let Some(min) = schema.get("minLength").and_then(Value::as_u64).filter(|_| has("minLength")) {
                if (s.chars().count() as u64) < min {
                    errors.push(format!("{path}: shorter than {min}"));
                }
            }
            if let Some(pat) = schema.get("pattern").and_then(Value::as_str).filter(|_| has("pattern")) {
                if !regex_matches(pat, s) {
                    errors.push(format!("{path}: `{s}` does not match pattern {pat}"));
                }
            }
        }
        _ => {}
    }
}

fn type_matches(t: &str, v: &Value) -> bool {
    match t {
        "object" => v.is_object(),
        "array" => v.is_array(),
        "string" => v.is_string(),
        "boolean" => v.is_boolean(),
        "null" => v.is_null(),
        "integer" => v.is_i64() || v.is_u64(),
        "number" => v.is_number(),
        _ => true,
    }
}

fn resolve_ref(r: &str, root: &Value) -> Option<Value> {
    let path = r.strip_prefix("#/")?;
    let mut cur = root;
    for seg in path.split('/') {
        cur = cur.get(seg)?;
    }
    Some(cur.clone())
}

/// Minimal regex subset: anchors, literals, `.`, `*`, `+`, `?`, character
/// classes and alternation. Enough for the handful of patterns our schemas
/// use, and avoids a regex dependency in a crate that everything imports.
fn regex_matches(pattern: &str, text: &str) -> bool {
    let anchored_end = pattern.ends_with('$');
    let body = pattern.trim_end_matches('$');
    let anchored_start = body.starts_with('^');
    let body = body.trim_start_matches('^');
    let re = match regex::Regex::new(body) {
        Ok(r) => r,
        Err(_) => return text == body,
    };
    let found = re.find(text);
    match (anchored_start, anchored_end, found) {
        (_, _, None) => false,
        (true, true, Some(m)) => m.start() == 0 && m.end() == text.len(),
        (true, false, Some(m)) => m.start() == 0,
        (false, true, Some(m)) => m.end() == text.len(),
        (false, false, Some(_)) => true,
    }
}

/// Render TypeScript declarations for one schema.
#[must_use]
pub fn typescript(kind: SchemaKind) -> String {
    let schema = json_schema(kind);
    let mut out = String::new();
    out.push_str("// Generated by agent-protocol. Do not edit.\n");
    out.push_str(&format!(
        "// protocol v{} · schema `{}`\n\n",
        crate::PROTOCOL_VERSION,
        kind.stem()
    ));
    out.push_str("export type Json = string | number | boolean | null | Json[] | { [k: string]: Json };\n\n");
    if let Some(defs) = schema.get("$defs").and_then(Value::as_object) {
        for (name, def) in defs {
            out.push_str(&ts_type_alias(name, def));
            out.push('\n');
        }
    }
    out.push_str(&ts_interface(&kind.title(), &schema));
    out
}

fn ts_type_alias(name: &str, def: &Value) -> String {
    if let Some(e) = def.get("enum").and_then(Value::as_array) {
        let parts: Vec<String> = e.iter().filter_map(|v| v.as_str().map(|s| format!("\"{s}\""))).collect();
        return format!("export type {name} = {};\n", parts.join(" | "));
    }
    if def.get("type").and_then(Value::as_str) == Some("string") {
        let pattern = def.get("pattern").and_then(Value::as_str).unwrap_or("");
        return format!("/** pattern: `{pattern}` */\nexport type {name} = string;\n");
    }
    format!("export type {name} = {};\n", ts_type(def))
}

fn ts_type(v: &Value) -> String {
    if let Some(r) = v.get("$ref").and_then(Value::as_str) {
        return r.rsplit('/').next().unwrap_or("unknown").to_string();
    }
    if let Some(any) = v.get("anyOf").and_then(Value::as_array) {
        return any.iter().map(ts_type).collect::<Vec<_>>().join(" | ");
    }
    match v.get("type").and_then(Value::as_str) {
        Some("object") => {
            let p = v.get("properties").and_then(Value::as_object);
            let req: Vec<&str> = v
                .get("required")
                .and_then(Value::as_array)
                .map(|a| a.iter().filter_map(|x| x.as_str()).collect())
                .unwrap_or_default();
            match p {
                Some(p) if !p.is_empty() => {
                    let fields: Vec<String> = p
                        .iter()
                        .map(|(k, sub)| {
                            let opt = if req.contains(&k.as_str()) { "" } else { "?" };
                            format!("  {k}{opt}: {};", ts_type(sub))
                        })
                        .collect();
                    format!("{{\n{}\n}}", fields.join("\n"))
                }
                _ => "Record<string, Json>".to_string(),
            }
        }
        Some("array") => {
            let inner = v.get("items").map(ts_type).unwrap_or_else(|| "Json".to_string());
            if inner.contains(' ') || inner.contains('{') {
                format!("({inner})[]")
            } else {
                format!("{inner}[]")
            }
        }
        Some("string") => "string".to_string(),
        Some("integer") | Some("number") => "number".to_string(),
        Some("boolean") => "boolean".to_string(),
        Some("null") => "null".to_string(),
        _ => "Json".to_string(),
    }
}

fn ts_interface(name: &str, schema: &Value) -> String {
    let req: Vec<&str> = schema
        .get("required")
        .and_then(Value::as_array)
        .map(|a| a.iter().filter_map(|x| x.as_str()).collect())
        .unwrap_or_default();
    let mut fields: Vec<String> = Vec::new();
    if let Some(p) = schema.get("properties").and_then(Value::as_object) {
        for (k, sub) in p {
            let opt = if req.contains(&k.as_str()) { "" } else { "?" };
            fields.push(format!("  {k}{opt}: {};", ts_type(sub)));
        }
    }
    if let Some(any) = schema.get("anyOf").and_then(Value::as_array) {
        let discs: Vec<String> = any
            .iter()
            .filter_map(|v| v.get("properties").and_then(|p| p.get("type")).and_then(Value::as_str))
            .map(|t| format!("  | {{ type: \"{t}\"; [k: string]: Json }}"))
            .collect();
        if !discs.is_empty() {
            fields.push(format!("  /** one of: */\n{}", discs.join("\n")));
        }
    }
    format!("export interface {name} {{\n{}\n}}\n", fields.join("\n"))
}

/// Render Python type stubs for one schema.
#[must_use]
pub fn python(kind: SchemaKind) -> String {
    let schema = json_schema(kind);
    let mut out = String::new();
    out.push_str("# Generated by agent-protocol. Do not edit.\n");
    out.push_str(&format!(
        "# protocol v{} · schema `{}`\n",
        crate::PROTOCOL_VERSION,
        kind.stem()
    ));
    out.push_str("from __future__ import annotations\n\nfrom typing import Any, Literal, TypedDict\nfrom typing_extensions import NotRequired\n\n");
    if let Some(defs) = schema.get("$defs").and_then(Value::as_object) {
        for (name, def) in defs {
            out.push_str(&py_alias(name, def));
            out.push('\n');
        }
    }
    out.push_str(&py_typeddict(&kind.title(), &schema));
    out
}

fn py_alias(name: &str, def: &Value) -> String {
    let py_name = to_pascal(name);
    if let Some(e) = def.get("enum").and_then(Value::as_array) {
        let parts: Vec<String> = e.iter().filter_map(|v| v.as_str().map(|s| format!("Literal[\"{s}\"]"))).collect();
        return format!("{py_name} = {}\n", parts.join(" | "));
    }
    if def.get("type").and_then(Value::as_str) == Some("string") {
        return format!("{py_name} = str\n");
    }
    format!("{py_name} = {}\n", py_type(def))
}

fn py_type(v: &Value) -> String {
    if let Some(r) = v.get("$ref").and_then(Value::as_str) {
        return to_pascal(r.rsplit('/').next().unwrap_or("Any"));
    }
    if let Some(any) = v.get("anyOf").and_then(Value::as_array) {
        return any.iter().map(py_type).collect::<Vec<_>>().join(" | ");
    }
    match v.get("type").and_then(Value::as_str) {
        Some("object") => {
            let p = v.get("properties").and_then(Value::as_object);
            match p {
                Some(p) if !p.is_empty() => "dict[str, Any]".to_string(),
                _ => "dict[str, Any]".to_string(),
            }
        }
        Some("array") => {
            let inner = v.get("items").map(py_type).unwrap_or_else(|| "Any".to_string());
            format!("list[{inner}]")
        }
        Some("string") => "str".to_string(),
        Some("integer") => "int".to_string(),
        Some("number") => "float".to_string(),
        Some("boolean") => "bool".to_string(),
        Some("null") => "None".to_string(),
        _ => "Any".to_string(),
    }
}

fn py_typeddict(name: &str, schema: &Value) -> String {
    let req: Vec<&str> = schema
        .get("required")
        .and_then(Value::as_array)
        .map(|a| a.iter().filter_map(|x| x.as_str()).collect())
        .unwrap_or_default();
    let mut fields: Vec<String> = Vec::new();
    if let Some(p) = schema.get("properties").and_then(Value::as_object) {
        for (k, sub) in p {
            let ty = py_type(sub);
            if req.contains(&k.as_str()) {
                fields.push(format!("    {k}: {ty}"));
            } else {
                fields.push(format!("    {k}: NotRequired[{ty}]"));
            }
        }
    }
    if fields.is_empty() {
        fields.push("    type: str".to_string());
    }
    format!("class {name}(TypedDict, total=False):\n{}\n", fields.join("\n"))
}

fn to_pascal(s: &str) -> String {
    s.split(|c: char| !c.is_alphanumeric())
        .filter(|p| !p.is_empty())
        .map(|p| {
            let mut c = p.chars();
            match c.next() {
                Some(f) => f.to_uppercase().collect::<String>() + c.as_str(),
                None => String::new(),
            }
        })
        .collect()
}

/// Emit all schemas and stubs into `dir/sdk/`.
///
/// # Errors
/// Any I/O failure while creating the directory or writing a file.
pub fn emit_all(dir: &std::path::Path) -> std::io::Result<Vec<std::path::PathBuf>> {
    let sdk = dir.join("sdk");
    std::fs::create_dir_all(&sdk)?;
    let mut written = Vec::new();
    for kind in SchemaKind::ALL {
        let schema = json_schema(kind);
        let pretty = serde_json::to_string_pretty(&schema).unwrap_or_default();
        let p = sdk.join(format!("{}.schema.json", kind.stem()));
        std::fs::write(&p, pretty)?;
        written.push(p);

        let p = sdk.join(format!("{}.ts", kind.stem()));
        std::fs::write(&p, typescript(kind))?;
        written.push(p);

        let p = sdk.join(format!("{}.pyi", kind.stem()));
        std::fs::write(&p, python(kind))?;
        written.push(p);
    }
    // A machine-readable index so CI can diff the whole directory in one shot.
    let index: Value = SchemaKind::ALL
        .iter()
        .map(|k| {
            serde_json::json!({
                "kind": k.stem(),
                "title": k.title(),
                "protocol_version": crate::PROTOCOL_VERSION,
                "files": [format!("{}.schema.json", k.stem()), format!("{}.ts", k.stem()), format!("{}.pyi", k.stem())],
            })
        })
        .collect();
    let p = sdk.join("index.json");
    std::fs::write(&p, serde_json::to_string_pretty(&index).unwrap_or_default())?;
    written.push(p);
    Ok(written)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event::{Event, EventEnvelope, TextDelta};
    use crate::ids::{CallId, ThreadId, TurnId};

    #[test]
    fn every_schema_is_well_formed_json_schema() {
        for kind in SchemaKind::ALL {
            let s = json_schema(kind);
            assert_eq!(s["$schema"], "https://json-schema.org/draft/2020-12/schema");
            assert_eq!(s["title"], kind.title());
            assert!(s["$id"].as_str().unwrap().contains(kind.stem()), "{s}");
            assert!(s.get("$defs").is_some());
        }
    }

    #[test]
    fn event_schema_lists_every_discriminator() {
        let s = json_schema(SchemaKind::Event);
        let any = s["anyOf"].as_array().unwrap();
        assert!(any.len() >= 35, "only {} variants", any.len());
        let tags: Vec<&str> = any.iter().filter_map(|v| v["properties"]["type"].as_str()).collect();
        assert!(tags.contains(&"turn_started"));
        assert!(tags.contains(&"session_resumed"));
    }

    #[test]
    fn real_events_validate_against_the_published_schema() {
        let schema = json_schema(SchemaKind::Event);
        let env = EventEnvelope::new(
            ThreadId::new(),
            3,
            Event::TextDelta(TextDelta { turn_id: TurnId::new(), block: 0, text: "hi".into() }),
        );
        let v = serde_json::to_value(&env).unwrap();
        let errs = validate(&schema, &v);
        assert!(errs.is_empty(), "{errs:?}\n{v}");
    }

    #[test]
    fn rollout_lines_validate_after_the_checksum_is_removed() {
        let schema = json_schema(SchemaKind::Event);
        let env = EventEnvelope::new(
            ThreadId::new(),
            1,
            Event::TurnCompleted(crate::event::TurnCompleted {
                turn_id: TurnId::new(),
                outcome: crate::event::TurnOutcome::Completed,
                final_text: "done".into(),
                usage: crate::usage::Usage::zero(),
                session_usage: crate::usage::Usage::zero(),
                duration_ms: 12,
                ttft_ms: Some(300),
                model_calls: 1,
                tool_calls: 0,
                files_changed: vec!["a.rs".into()],
            }),
        );
        let line = env.to_rollout_line().unwrap();
        let mut v: Value = serde_json::from_str(&line).unwrap();
        v.as_object_mut().unwrap().remove("checksum");
        let errs = validate(&schema, &v);
        assert!(errs.is_empty(), "{errs:?}");
    }

    #[test]
    fn validator_catches_missing_required_fields() {
        let schema = json_schema(SchemaKind::Event);
        let bad = serde_json::json!({"thread": "thr_01ARZ3NDEKTSV4RRFFQ69G5FAV", "ts": "x"});
        let errs = validate(&schema, &bad);
        assert!(errs.iter().any(|e| e.contains("missing required field `id`")), "{errs:?}");
        assert!(errs.iter().any(|e| e.contains("`seq`")), "{errs:?}");
    }

    #[test]
    fn validator_catches_wrong_types() {
        let schema = json_schema(SchemaKind::ToolCall);
        let bad = serde_json::json!({"id": "cal_01ARZ3NDEKTSV4RRFFQ69G5FAV", "name": 42});
        let errs = validate(&schema, &bad);
        assert!(errs.iter().any(|e| e.contains("expected type string")), "{errs:?}");
    }

    #[test]
    fn validator_checks_ulid_pattern() {
        let schema = json_schema(SchemaKind::ToolCall);
        let bad = serde_json::json!({"id": "not-a-ulid", "name": "read_file"});
        let errs = validate(&schema, &bad);
        assert!(errs.iter().any(|e| e.contains("does not match pattern")), "{errs:?}");
        let good = serde_json::json!({"id": CallId::new().to_string(), "name": "read_file"});
        assert!(validate(&schema, &good).is_empty());
    }

    #[test]
    fn validator_checks_enums() {
        let schema = json_schema(SchemaKind::ToolCall);
        let bad = serde_json::json!({"id": CallId::new().to_string(), "name": "x", "risk": "spooky"});
        assert!(!validate(&schema, &bad).is_empty());
    }

    #[test]
    fn additional_properties_false_is_enforced_where_declared() {
        let schema = json_schema(SchemaKind::WorkerReport);
        let bad = serde_json::json!({"node_id": "n1", "status": "done", "summary": "s", "surprise": 1});
        let errs = validate(&schema, &bad);
        assert!(errs.iter().any(|e| e.contains("additional property")), "{errs:?}");
    }

    #[test]
    fn config_schema_is_derived_from_the_real_defaults() {
        let s = json_schema(SchemaKind::Config);
        let p = s["properties"].as_object().unwrap();
        for section in ["model", "permissions", "sandbox", "context", "tools", "agents", "telemetry", "ui"] {
            assert!(p.contains_key(section), "missing [{section}]");
        }
        assert_eq!(p["telemetry"]["properties"]["enabled"]["type"], "boolean");
        assert_eq!(p["context"]["properties"]["compact_at"]["type"], "number");
    }

    #[test]
    fn typescript_output_is_plausible() {
        let ts = typescript(SchemaKind::WorkerReport);
        assert!(ts.contains("export interface WorkerReport"), "{ts}");
        assert!(ts.contains("node_id: string;"));
        assert!(ts.contains("Generated by agent-protocol"));
        assert!(ts.contains("export type Usage") || ts.contains("usage"), "{ts}");
    }

    #[test]
    fn python_output_is_plausible() {
        let py = python(SchemaKind::WorkerReport);
        assert!(py.contains("class WorkerReport(TypedDict, total=False):"), "{py}");
        assert!(py.contains("node_id: str"));
        assert!(py.contains("NotRequired["));
    }

    #[test]
    fn emit_all_writes_the_expected_files() {
        let dir = tempfile::tempdir().unwrap();
        let written = emit_all(dir.path()).unwrap();
        assert_eq!(written.len(), SchemaKind::ALL.len() * 3 + 1);
        for p in &written {
            assert!(p.exists(), "{p:?}");
            assert!(std::fs::metadata(p).unwrap().len() > 0, "{p:?} empty");
        }
        assert!(dir.path().join("sdk/index.json").exists());
        let index: Value =
            serde_json::from_str(&std::fs::read_to_string(dir.path().join("sdk/index.json")).unwrap()).unwrap();
        assert_eq!(index.as_array().unwrap().len(), SchemaKind::ALL.len());
    }

    #[test]
    fn task_plan_schema_is_the_planner_contract() {
        let s = json_schema(SchemaKind::TaskPlan);
        assert!(s["properties"]["nodes"]["items"]["properties"]["kind"]["enum"]
            .as_array()
            .is_some_and(|a| a.len() == 7));
    }

    #[test]
    fn regex_subset_handles_anchors() {
        assert!(regex_matches("^[a-z]{3}_[0-9A-HJKMNP-TV-Z]{26}$", "thr_01ARZ3NDEKTSV4RRFFQ69G5FAV"));
        assert!(!regex_matches("^[a-z]{3}_[0-9A-HJKMNP-TV-Z]{26}$", "THR_01ARZ3NDEKTSV4RRFFQ69G5FAV"));
        assert!(regex_matches("^a", "abc"));
        assert!(!regex_matches("^a", "bac"));
        assert!(regex_matches("c$", "abc"));
    }

    #[test]
    fn pascal_case_helper_is_stable() {
        assert_eq!(to_pascal("model_id"), "ModelId");
        assert_eq!(to_pascal("usage"), "Usage");
        assert_eq!(to_pascal("a-b_c"), "ABC");
    }

    #[test]
    fn task_plan_schema_exposes_the_node_contract() {
        let body = task_plan_schema();
        assert!(!body.is_empty());
        let names: Vec<&str> = body.iter().map(|(k, _)| *k).collect();
        assert!(names.contains(&"properties"));
        assert!(names.contains(&"required"));
    }
}
