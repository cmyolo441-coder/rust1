//! ANSI escape sequence handling (`rustplan.txt` §6.2.3, §9.1 `src/content.rs`).
//!
//! Two invariants matter for an agent harness:
//!
//! 1. **The model never sees escape sequences.** Colours, cursor moves and
//!    OSC hyperlinks are pure noise to a language model and can even be used
//!    to smuggle text past a human reviewer, so every tool result is passed
//!    through [`strip`] before it reaches the prompt.
//! 2. **Stripping must not corrupt UTF-8.** We operate on `char` boundaries
//!    and never emit a partial sequence.
//!
//! This is a *trust boundary* in the sense of §9.12 `render/markdown.rs`:
//! anything the model prints back is also stripped before it hits the
//! terminal, so a hostile tool output cannot repaint the user's screen.

use std::fmt::Write as _;

/// Strip all ANSI escape sequences (CSI, OSC, DCS, SOS, PM, APC and the
/// single-character escapes) from `input`.
///
/// Control characters other than `\n`, `\r` and `\t` are dropped as well;
/// they carry no information for a model and break line-based tools.
#[must_use]
pub fn strip(input: &str) -> String {
    if !input.bytes().any(|b| b == 0x1b || (b < 0x20 && b != b'\n' && b != b'\r' && b != b'\t')) {
        return input.to_owned();
    }

    let mut out = String::with_capacity(input.len());
    let mut chars = input.chars().peekable();

    while let Some(c) = chars.next() {
        match c {
            '\u{1b}' => {
                // Skip one escape sequence.
                match chars.peek() {
                    Some('[') => {
                        chars.next();
                        // CSI: parameter/intermediate bytes 0x30-0x3F, then a
                        // final byte in 0x40-0x7E.
                        while let Some(&n) = chars.peek() {
                            chars.next();
                            if matches!(n as u32, 0x40..=0x7e) {
                                break;
                            }
                        }
                    }
                    Some(']') => {
                        chars.next();
                        // OSC: terminated by BEL or ST (ESC \).
                        while let Some(n) = chars.next() {
                            if n == '\u{7}' {
                                break;
                            }
                            if n == '\u{1b}' {
                                if chars.peek() == Some(&'\\') {
                                    chars.next();
                                }
                                break;
                            }
                        }
                    }
                    Some('P') | Some('X') | Some('^') | Some('_') => {
                        chars.next();
                        // DCS / SOS / PM / APC: terminated by ST.
                        while let Some(n) = chars.next() {
                            if n == '\u{1b}' {
                                if chars.peek() == Some(&'\\') {
                                    chars.next();
                                }
                                break;
                            }
                        }
                    }
                    Some(_) => {
                        // Two-character escape such as ESC ( B.
                        chars.next();
                    }
                    None => {}
                }
            }
            c if (c as u32) < 0x20 && c != '\n' && c != '\r' && c != '\t' => {
                // Drop other C0 controls; represent DEL as nothing too.
            }
            '\u{7f}' => {}
            c => out.push(c),
        }
    }
    out
}

/// True when `input` contains any escape sequence or non-printable control.
#[must_use]
pub fn contains_escapes(input: &str) -> bool {
    input
        .bytes()
        .any(|b| b == 0x1b || b == 0x7f || (b < 0x20 && b != b'\n' && b != b'\r' && b != b'\t'))
}

/// Collapse runs of blank lines (more than `max`) down to `max`.
///
/// Tool output from compilers and test runners is full of vertical padding
/// that costs tokens without adding signal.
#[must_use]
pub fn squeeze_blank_lines(input: &str, max: usize) -> String {
    let mut out = String::with_capacity(input.len());
    let mut run = 0usize;
    for line in input.split_inclusive('\n') {
        if line.trim().is_empty() {
            run += 1;
            if run > max {
                continue;
            }
        } else {
            run = 0;
        }
        let _ = out.write_str(line);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_sgr_sequences() {
        assert_eq!(strip("\u{1b}[31mred\u{1b}[0m"), "red");
        assert_eq!(strip("\u{1b}[1;38;5;208mfoo\u{1b}[m bar"), "foo bar");
    }

    #[test]
    fn strips_osc_hyperlinks() {
        let s = "\u{1b}]8;;https://example.com\u{7}link\u{1b}]8;;\u{7}";
        assert_eq!(strip(s), "link");
    }

    #[test]
    fn strips_osc_terminated_by_st() {
        let s = "a\u{1b}]0;window title\u{1b}\\b";
        assert_eq!(strip(s), "ab");
    }

    #[test]
    fn preserves_plain_text_byte_for_byte() {
        let s = "hello\nworld\t!\r\n";
        assert_eq!(strip(s), s);
    }

    #[test]
    fn never_produces_invalid_utf8() {
        // A truncated escape at the very end of the buffer.
        let s = "abc\u{1b}[3";
        let out = strip(s);
        assert_eq!(out, "abc");
        assert!(out.chars().all(|c| c.is_ascii()));
    }

    #[test]
    fn drops_control_characters_but_keeps_newlines_and_tabs() {
        assert_eq!(strip("a\u{0}b\nc\td"), "ab\nc\td");
    }

    #[test]
    fn detects_escapes() {
        assert!(contains_escapes("\u{1b}[0m"));
        assert!(!contains_escapes("plain"));
    }

    #[test]
    fn squeezes_blank_runs() {
        let s = "a\n\n\n\n\nb\n";
        assert_eq!(squeeze_blank_lines(s, 1), "a\n\nb\n");
    }

    #[test]
    fn emoji_and_cjk_survive() {
        let s = "\u{1b}[32m✅ 完了\u{1b}[0m";
        assert_eq!(strip(s), "✅ 完了");
    }
}
