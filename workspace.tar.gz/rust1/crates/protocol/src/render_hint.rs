//! Render hints: how the capability plane tells the UI plane to draw a result
//! (`rustplan.txt` §9.8 `tools/src/render.rs`, golden rule from §4.1).
//!
//! > "Agar `tui` ko `tools` ka type chahiye, matlab aapne UI ko domain logic
//! > de diya hai — wo render *hints* ke through aana chahiye, type ke through
//! > nahi."
//!
//! So the `tools` crate never hands the TUI a `ReadResult` or a `ShellOutput`.
//! It hands it a [`RenderHint`]: a closed vocabulary of *shapes* the UI knows
//! how to draw. Adding a tool therefore requires zero TUI changes, and the
//! forbidden dependency edge (`tui -> tools`) stays impossible to introduce.

use serde::{Deserialize, Serialize};

/// How a tool result should be drawn.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RenderKind {
    /// Plain text block.
    Text,
    /// Syntax-highlighted code with a language tag.
    Code,
    /// Unified or side-by-side diff.
    Diff,
    /// Terminal output (monospace, exit code badge).
    Terminal,
    /// Markdown table.
    Table,
    /// An image from the blob store.
    Image,
    /// Pretty-printed JSON.
    Json,
    /// A file listing / tree.
    Tree,
    /// Search matches grouped by file.
    Grep,
    /// A plan/todo list with statuses.
    Plan,
    /// A question awaiting a choice.
    Question,
    /// The parallel worker board.
    Board,
    /// Nothing worth drawing; only the summary line shows.
    Silent,
}

impl RenderKind {
    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            RenderKind::Text => "text",
            RenderKind::Code => "code",
            RenderKind::Diff => "diff",
            RenderKind::Terminal => "terminal",
            RenderKind::Table => "table",
            RenderKind::Image => "image",
            RenderKind::Json => "json",
            RenderKind::Tree => "tree",
            RenderKind::Grep => "grep",
            RenderKind::Plan => "plan",
            RenderKind::Question => "question",
            RenderKind::Board => "board",
            RenderKind::Silent => "silent",
        }
    }

    /// Default glyph for the collapsed tool card.
    #[must_use]
    pub const fn glyph(self) -> &'static str {
        match self {
            RenderKind::Text => "¶",
            RenderKind::Code => "⌘",
            RenderKind::Diff => "±",
            RenderKind::Terminal => "$",
            RenderKind::Table => "▦",
            RenderKind::Image => "▣",
            RenderKind::Json => "{}",
            RenderKind::Tree => "⊟",
            RenderKind::Grep => "⌕",
            RenderKind::Plan => "☰",
            RenderKind::Question => "?",
            RenderKind::Board => "▤",
            RenderKind::Silent => "·",
        }
    }

    /// Whether the card should start collapsed. Noisy tools (reads, greps) are
    /// collapsed so the transcript stays scannable; diffs and questions are
    /// not.
    #[must_use]
    pub const fn collapsed_by_default(self) -> bool {
        matches!(
            self,
            RenderKind::Text
                | RenderKind::Code
                | RenderKind::Terminal
                | RenderKind::Tree
                | RenderKind::Grep
                | RenderKind::Json
                | RenderKind::Silent
        )
    }
}

/// Everything the UI needs to draw a tool card without understanding the tool.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RenderHint {
    /// Shape of the payload.
    pub kind: RenderKind,
    /// One-line summary for the collapsed card (e.g. `read_file src/a.rs 1-200`).
    pub summary: String,
    /// Language tag for `Code` payloads (`rs`, `py`, `json`, …).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub language: Option<String>,
    /// Whether to start collapsed. `None` = use [`RenderKind::collapsed_by_default`].
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub collapse: Option<bool>,
    /// Badge text, e.g. `exit 1`, `+140 -3`, `200 matches`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub badge: Option<String>,
    /// Tone for the badge: `ok`, `warn`, `err`, `muted`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tone: Option<String>,
    /// Paths this result touched — makes the card clickable and feeds
    /// `/diff` and the "last edited files" restore list.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub paths: Vec<String>,
    /// Wall time, for the card footer.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_ms: Option<u64>,
}

impl RenderHint {
    /// Minimal hint.
    #[must_use]
    pub fn new(kind: RenderKind, summary: impl Into<String>) -> Self {
        Self {
            kind,
            summary: summary.into(),
            language: None,
            collapse: None,
            badge: None,
            tone: None,
            paths: Vec::new(),
            duration_ms: None,
        }
    }

    /// Effective collapse state.
    #[must_use]
    pub fn is_collapsed(&self) -> bool {
        self.collapse.unwrap_or_else(|| self.kind.collapsed_by_default())
    }

    /// Builder: set the language.
    #[must_use]
    pub fn with_language(mut self, lang: impl Into<String>) -> Self {
        self.language = Some(lang.into());
        self
    }

    /// Builder: set the badge and tone.
    #[must_use]
    pub fn with_badge(mut self, badge: impl Into<String>, tone: impl Into<String>) -> Self {
        self.badge = Some(badge.into());
        self.tone = Some(tone.into());
        self
    }

    /// Builder: add a path.
    #[must_use]
    pub fn with_path(mut self, path: impl Into<String>) -> Self {
        self.paths.push(path.into());
        self
    }

    /// Builder: set duration.
    #[must_use]
    pub fn with_duration(mut self, ms: u64) -> Self {
        self.duration_ms = Some(ms);
        self
    }

    /// Builder: force expanded.
    #[must_use]
    pub fn expanded(mut self) -> Self {
        self.collapse = Some(false);
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn noisy_kinds_collapse_and_diffs_do_not() {
        assert!(RenderKind::Grep.collapsed_by_default());
        assert!(RenderKind::Terminal.collapsed_by_default());
        assert!(!RenderKind::Diff.collapsed_by_default());
        assert!(!RenderKind::Question.collapsed_by_default());
    }

    #[test]
    fn explicit_collapse_overrides_the_kind_default() {
        let h = RenderHint::new(RenderKind::Grep, "3 matches");
        assert!(h.is_collapsed());
        assert!(!h.expanded().is_collapsed());
    }

    #[test]
    fn hints_are_small_enough_to_broadcast_per_call() {
        let h = RenderHint::new(RenderKind::Diff, "edit_file src/a.rs")
            .with_badge("+12 -3", "ok")
            .with_path("src/a.rs")
            .with_duration(4);
        let s = serde_json::to_string(&h).unwrap();
        assert!(s.len() < 300, "{s}");
        assert_eq!(h.kind.as_str(), "diff");
    }

    #[test]
    fn every_kind_has_a_glyph_and_label() {
        for k in [
            RenderKind::Text, RenderKind::Code, RenderKind::Diff, RenderKind::Terminal,
            RenderKind::Table, RenderKind::Image, RenderKind::Json, RenderKind::Tree,
            RenderKind::Grep, RenderKind::Plan, RenderKind::Question, RenderKind::Board,
            RenderKind::Silent,
        ] {
            assert!(!k.as_str().is_empty());
            assert!(!k.glyph().is_empty());
        }
    }
}
