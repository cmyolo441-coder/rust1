//! Sortable, type-safe identifiers (`rustplan.txt` §9.1 `src/ids.rs`).
//!
//! Every id in the system is a [ULID](https://github.com/ulid/spec):
//! lexicographically sortable by creation time, 26 characters of Crockford
//! base32, 128 bits of entropy. Sorting ids therefore sorts events in a JSONL
//! rollout without a separate sequence column, and accidental mix-ups (a
//! [`ThreadId`] where a [`TurnId`] is wanted) become compile errors instead of
//! silent data corruption.
//!
//! The textual form carries a kind prefix (`thr_`, `trn_`, `cal_`, …) so that
//! a stray id in a log line is self-describing. Parsing accepts both the
//! prefixed and the bare ULID body.

use std::fmt;
use std::str::FromStr;

use serde::de::{Deserialize, Deserializer, Error as DeError, Visitor};
use serde::ser::{Serialize, Serializer};
use ulid::Ulid;

/// Error returned when an identifier string cannot be parsed.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[error("invalid {kind} `{value}`: {reason}")]
pub struct ParseIdError {
    /// Human readable name of the id kind, e.g. `"thread id"`.
    pub kind: &'static str,
    /// The offending input.
    pub value: String,
    /// Why parsing failed.
    pub reason: String,
}

impl ParseIdError {
    fn new(kind: &'static str, value: &str, source: ulid::DecodeError) -> Self {
        Self { kind, value: value.to_owned(), reason: source.to_string() }
    }
}

/// Generates a newtype wrapper around [`Ulid`] with shared semantics.
macro_rules! id_macro {
    (
        $(#[$meta:meta])*
        $name:ident, $kind:literal, $prefix:literal
    ) => {
        $(#[$meta])*
        #[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
        pub struct $name(Ulid);

        impl $name {
            /// Prefix used in the textual form, e.g. `"thr"` for threads.
            pub const PREFIX: &'static str = $prefix;
            /// Human readable kind, used in error messages.
            pub const KIND: &'static str = $kind;

            /// Create a fresh id from the system clock plus random entropy.
            #[must_use]
            pub fn new() -> Self {
                Self(Ulid::new())
            }

            /// Wrap an existing [`Ulid`].
            #[must_use]
            pub const fn from_ulid(u: Ulid) -> Self {
                Self(u)
            }

            /// Borrow the inner [`Ulid`].
            #[must_use]
            pub const fn as_ulid(&self) -> &Ulid {
                &self.0
            }

            /// Milliseconds since the unix epoch encoded in this id.
            #[must_use]
            pub fn timestamp_ms(&self) -> u64 {
                self.0.timestamp_ms()
            }

            /// The bare ULID body, without the `kind_` prefix.
            #[must_use]
            pub fn body(&self) -> String {
                self.0.to_string()
            }

            /// Parse from either the prefixed (`thr_01J…`) or bare form.
            ///
            /// # Errors
            /// Returns [`ParseIdError`] when the input is not a valid ULID.
            pub fn parse(s: &str) -> Result<Self, ParseIdError> {
                let body = s.strip_prefix(concat!($prefix, "_")).unwrap_or(s);
                Ulid::from_string(body)
                    .map(Self)
                    .map_err(|e| ParseIdError::new($kind, s, e))
            }

            /// Build a reproducible id from a timestamp and a seed. Golden
            /// tests use this so that snapshots stay byte stable.
            #[must_use]
            pub fn from_parts(ms: u64, seed: u128) -> Self {
                Self(Ulid::from_parts(ms, seed))
            }
        }

        impl Default for $name {
            fn default() -> Self { Self::new() }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                write!(f, "{}_{}", $prefix, self.0)
            }
        }

        impl fmt::Debug for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                write!(f, "{}({})", stringify!($name), self.0)
            }
        }

        impl FromStr for $name {
            type Err = ParseIdError;
            fn from_str(s: &str) -> Result<Self, Self::Err> { Self::parse(s) }
        }

        impl Serialize for $name {
            fn serialize<S: Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
                s.serialize_str(&self.to_string())
            }
        }

        impl<'de> Deserialize<'de> for $name {
            fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
                struct IdVisitor;
                impl Visitor<'_> for IdVisitor {
                    type Value = $name;
                    fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                        write!(f, "a {} string", $kind)
                    }
                    fn visit_str<E: DeError>(self, v: &str) -> Result<$name, E> {
                        $name::parse(v).map_err(DeError::custom)
                    }
                    fn visit_string<E: DeError>(self, v: String) -> Result<$name, E> {
                        $name::parse(&v).map_err(DeError::custom)
                    }
                }
                d.deserialize_str(IdVisitor)
            }
        }

        impl From<$name> for String {
            fn from(v: $name) -> String { v.to_string() }
        }

        impl From<Ulid> for $name {
            fn from(u: Ulid) -> Self { Self(u) }
        }
    };
}

id_macro!(
    /// Identifier of a conversation thread (one `Agent` actor, one writer).
    ThreadId, "thread id", "thr"
);
id_macro!(
    /// Identifier of a single user-prompt-driven turn.
    TurnId, "turn id", "trn"
);
id_macro!(
    /// Identifier of one tool invocation inside a turn.
    CallId, "call id", "cal"
);
id_macro!(
    /// Identifier of a persisted session (may span many threads on resume).
    SessionId, "session id", "ses"
);
id_macro!(
    /// Identifier of a parallel subagent worker.
    WorkerId, "worker id", "wkr"
);
id_macro!(
    /// Identifier of a parallel run (a whole DAG execution).
    RunId, "run id", "run"
);
id_macro!(
    /// Identifier of a single operation submitted by a client.
    OpId, "op id", "op"
);
id_macro!(
    /// Identifier of a single emitted event.
    EventId, "event id", "evt"
);
id_macro!(
    /// Identifier of a permission request awaiting a decision.
    RequestId, "request id", "req"
);
id_macro!(
    /// Identifier of a plan/todo item.
    TaskId, "task id", "tsk"
);
id_macro!(
    /// Identifier of a blob stored in the content-addressed store.
    BlobId, "blob id", "blb"
);

/// All id kinds, for diagnostics and schema export.
pub const ALL_ID_KINDS: &[&str] = &[
    ThreadId::KIND,
    TurnId::KIND,
    CallId::KIND,
    SessionId::KIND,
    WorkerId::KIND,
    RunId::KIND,
    OpId::KIND,
    EventId::KIND,
    RequestId::KIND,
    TaskId::KIND,
    BlobId::KIND,
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ids_are_sortable_by_creation_time() {
        let a = ThreadId::new();
        std::thread::sleep(std::time::Duration::from_millis(2));
        let b = ThreadId::new();
        assert!(a < b, "{a} should sort before {b}");
        assert!(a.to_string() < b.to_string(), "textual order == temporal order");
    }

    #[test]
    fn ids_roundtrip_through_prefixed_and_bare_form() {
        let t = TurnId::new();
        let prefixed = t.to_string();
        assert!(prefixed.starts_with("trn_"));
        assert_eq!(TurnId::parse(&prefixed).unwrap(), t);
        assert_eq!(TurnId::parse(t.body().as_str()).unwrap(), t);
    }

    #[test]
    fn ids_reject_garbage_with_actionable_error() {
        let e = ThreadId::parse("not-an-id").unwrap_err();
        assert_eq!(e.kind, "thread id");
        let msg = e.to_string();
        assert!(msg.contains("not-an-id"), "{msg}");
        assert!(msg.contains("thread id"), "{msg}");
    }

    #[test]
    fn ids_survive_serde_roundtrip() {
        let w = WorkerId::new();
        let json = serde_json::to_string(&w).unwrap();
        let back: WorkerId = serde_json::from_str(&json).unwrap();
        assert_eq!(w, back);
    }

    #[test]
    fn deterministic_ids_are_reproducible() {
        let a = CallId::from_parts(1_700_000_000_000, 42);
        let b = CallId::from_parts(1_700_000_000_000, 42);
        assert_eq!(a, b);
        assert_eq!(a.to_string(), b.to_string());
        assert_eq!(a.timestamp_ms(), 1_700_000_000_000);
    }

    #[test]
    fn every_kind_has_a_distinct_prefix() {
        let prefixes = [
            ThreadId::PREFIX, TurnId::PREFIX, CallId::PREFIX, SessionId::PREFIX,
            WorkerId::PREFIX, RunId::PREFIX, OpId::PREFIX, EventId::PREFIX,
            RequestId::PREFIX, TaskId::PREFIX, BlobId::PREFIX,
        ];
        let mut sorted = prefixes.to_vec();
        sorted.sort_unstable();
        sorted.dedup();
        assert_eq!(sorted.len(), prefixes.len(), "prefix collision");
    }
}
