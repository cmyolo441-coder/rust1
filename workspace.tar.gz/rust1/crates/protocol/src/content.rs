//! Content blocks carried inside messages and tool results
//! (`rustplan.txt` §9.1 `src/content.rs`).
//!
//! Design rules enforced here:
//! * **Images never inline their bytes into events.** They live in the
//!   content-addressed blob store; the event carries only a handle plus the
//!   media type. That keeps the JSONL rollout small enough to `jq`.
//! * **Terminal output is stored twice**: raw (with ANSI) for the human-facing
//!   transcript and stripped for the model. The model must never see escape
//!   sequences (§6.2.3).
//! * **Diffs are structured**, not stringly typed, so the TUI can render them
//!   without re-parsing.

use serde::{Deserialize, Serialize};
use serde_json::Value;

/// Maximum bytes of a content block that may travel inline in an event.
/// Anything larger must be spilled to the blob store.
pub const MAX_INLINE_BYTES: usize = 256 * 1024;

/// A single block of content inside a [`crate::message::Message`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ContentPart {
    /// Plain text (markdown-ish; the renderer decides).
    Text {
        /// The text.
        text: String,
    },
    /// Model-visible reasoning. Redacted from history by default (§6.3.4).
    Thinking {
        /// Reasoning text, if the provider disclosed it.
        text: String,
        /// Provider signature required to replay the block; opaque.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        signature: Option<String>,
        /// Whether the provider refused to disclose the text.
        #[serde(default)]
        redacted: bool,
    },
    /// An image, stored out of band.
    Image {
        /// Blob store id (`blb_…`).
        blob: String,
        /// MIME type, e.g. `image/png`.
        media_type: String,
        /// Pixel width if known.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        width: Option<u32>,
        /// Pixel height if known.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        height: Option<u32>,
        /// Alternative text used when the model cannot see images.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        alt: Option<String>,
    },
    /// A link to a resource the model may pull in on demand (`@file`, MCP
    /// resource, web URL).
    ResourceLink {
        /// URI of the resource.
        uri: String,
        /// Human readable name.
        name: String,
        /// MIME type if known.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        media_type: Option<String>,
        /// Byte size if known — used for budget accounting before loading.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        size: Option<u64>,
    },
    /// A structured diff (see [`Diff`]).
    Diff(Diff),
    /// Captured terminal output.
    Terminal(TerminalOutput),
    /// A tool invocation requested by the model.
    ToolUse(crate::tool::ToolCall),
    /// The result of a tool invocation.
    ToolResult(crate::tool::ToolResult),
    /// Marker left behind when compaction replaced content (§6.1.2).
    Compacted {
        /// Short human description of what was removed.
        summary: String,
        /// Pointer into the JSONL rollout so `/undo`-style restore can find it.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        pointer: Option<String>,
        /// Tokens freed by the replacement.
        tokens_freed: u32,
    },
    /// Anything this build does not understand, preserved verbatim.
    Unknown {
        /// The original `type` discriminator.
        kind: String,
        /// Raw payload.
        value: Value,
    },
}

impl ContentPart {
    /// Convenience constructor for a text part.
    #[must_use]
    pub fn text(s: impl Into<String>) -> Self {
        Self::Text { text: s.into() }
    }

    /// The textual payload of this part, if it has one.
    ///
    /// Used by token estimation and by the summariser.
    #[must_use]
    pub fn as_text(&self) -> Option<&str> {
        match self {
            Self::Text { text } | Self::Thinking { text, .. } => Some(text),
            _ => None,
        }
    }

    /// True when the part carries no model-visible tokens (images, links).
    #[must_use]
    pub const fn is_reference_only(&self) -> bool {
        matches!(self, Self::Image { .. } | Self::ResourceLink { .. })
    }

    /// Approximate inline byte size, used to decide blob spilling.
    #[must_use]
    pub fn inline_bytes(&self) -> usize {
        match self {
            Self::Text { text } | Self::Thinking { text, .. } => text.len(),
            Self::Diff(d) => d.raw_bytes(),
            Self::Terminal(t) => t.stripped.len() + t.raw.as_ref().map_or(0, String::len),
            Self::Image { .. } | Self::ResourceLink { .. } | Self::Compacted { .. } => 0,
            Self::ToolUse(_) | Self::ToolResult(_) | Self::Unknown { .. } => 0,
        }
    }

    /// Replace oversized inline text with a blob handle, returning the
    /// (possibly rewritten) part and the spilled bytes.
    ///
    /// `spill` is called with the payload that must be persisted; it returns
    /// the blob id.
    pub fn spill_if_oversized<F>(self, limit: usize, spill: &mut F) -> (Self, Option<String>)
    where
        F: FnMut(&str) -> String,
    {
        match self {
            Self::Terminal(mut t) if t.stripped.len() > limit => {
                let blob = spill(&t.stripped);
                let kept = crate::truncate::head_tail(&t.stripped, limit / 2, limit / 2);
                t.raw = None;
                t.stripped = kept;
                t.spilled_to = Some(blob.clone());
                (Self::Terminal(t), Some(blob))
            }
            other => (other, None),
        }
    }
}

/// A structured diff: list of files, each with hunks.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Diff {
    /// Per-file changes.
    pub files: Vec<DiffFile>,
    /// The unified-diff text the tool produced (kept so the TUI can render the
    /// model's view verbatim and the audit log stays faithful).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub unified: Option<String>,
}

impl Diff {
    /// Empty diff.
    #[must_use]
    pub const fn empty() -> Self {
        Self { files: Vec::new(), unified: None }
    }

    /// True when nothing changed.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.files.is_empty()
    }

    /// Total added/removed line counts.
    #[must_use]
    pub fn stat(&self) -> (usize, usize) {
        self.files.iter().fold((0, 0), |(a, d), f| (a + f.added, d + f.removed))
    }

    /// `2 files, +140 -3` style summary used in worker reports.
    #[must_use]
    pub fn stat_line(&self) -> String {
        let (a, d) = self.stat();
        let n = self.files.len();
        format!("{n} file{}, +{a} -{d}", if n == 1 { "" } else { "s" })
    }

    fn raw_bytes(&self) -> usize {
        self.unified.as_ref().map_or(0, String::len)
            + self.files.iter().map(|f| f.path.len() + f.hunks.iter().map(|h| h.text.len()).sum::<usize>()).sum::<usize>()
    }
}

/// One file inside a [`Diff`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DiffFile {
    /// Workspace-relative path after the change.
    pub path: String,
    /// Path before the change (renames).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub old_path: Option<String>,
    /// What happened to the file.
    pub change: FileChange,
    /// Hunks, in file order.
    pub hunks: Vec<Hunk>,
    /// Lines added.
    pub added: usize,
    /// Lines removed.
    pub removed: usize,
    /// Set when the file is binary and hunks are meaningless.
    #[serde(default)]
    pub binary: bool,
}

/// The kind of change a [`DiffFile`] describes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FileChange {
    /// New file.
    Added,
    /// Existing file modified.
    Modified,
    /// File removed.
    Deleted,
    /// File renamed (possibly with edits).
    Renamed,
    /// Only the mode changed.
    ModeChanged,
}

/// A single diff hunk.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Hunk {
    /// First line of the old range (1-based).
    pub old_start: usize,
    /// Number of old lines.
    pub old_lines: usize,
    /// First line of the new range (1-based).
    pub new_start: usize,
    /// Number of new lines.
    pub new_lines: usize,
    /// The hunk body (` `, `+`, `-` prefixed lines).
    pub text: String,
}

/// Captured terminal output, stored twice: raw for humans, stripped for models.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TerminalOutput {
    /// ANSI-stripped text. **This is what the model sees.**
    pub stripped: String,
    /// Original text with escapes, retained for the transcript only.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub raw: Option<String>,
    /// Process exit code, if the output came from a command.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub exit_code: Option<i32>,
    /// Wall time in milliseconds.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_ms: Option<u64>,
    /// True when output was truncated to respect a byte cap.
    #[serde(default)]
    pub truncated: bool,
    /// Blob id when the full output was spilled out of band.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub spilled_to: Option<String>,
    /// Human readable truncation hint, e.g.
    /// `showing last 30000 of 1048576 bytes`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hint: Option<String>,
}

impl TerminalOutput {
    /// Build from raw text, stripping ANSI on the way in.
    #[must_use]
    pub fn from_raw(raw: impl Into<String>, exit_code: Option<i32>) -> Self {
        let raw = raw.into();
        let stripped = crate::ansi::strip(&raw);
        Self {
            stripped,
            raw: Some(raw),
            exit_code,
            duration_ms: None,
            truncated: false,
            spilled_to: None,
            hint: None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn content_parts_tag_by_type() {
        let v = serde_json::to_value(ContentPart::text("hi")).unwrap();
        assert_eq!(v["type"], "text");
        assert_eq!(v["text"], "hi");
    }

    #[test]
    fn diff_stat_line_reads_naturally() {
        let d = Diff {
            files: vec![
                DiffFile {
                    path: "a.rs".into(),
                    old_path: None,
                    change: FileChange::Modified,
                    hunks: vec![],
                    added: 140,
                    removed: 3,
                    binary: false,
                },
                DiffFile {
                    path: "b.rs".into(),
                    old_path: None,
                    change: FileChange::Added,
                    hunks: vec![],
                    added: 2,
                    removed: 0,
                    binary: false,
                },
            ],
            unified: None,
        };
        assert_eq!(d.stat_line(), "2 files, +142 -3");
    }

    #[test]
    fn terminal_output_strips_ansi_for_the_model() {
        let t = TerminalOutput::from_raw("\u{1b}[31mboom\u{1b}[0m", Some(1));
        assert_eq!(t.stripped, "boom");
        assert!(t.raw.unwrap().contains("boom"));
        assert_eq!(t.exit_code, Some(1));
    }

    #[test]
    fn oversized_terminal_output_spills_to_a_blob() {
        let big = "x".repeat(4096);
        let part = ContentPart::Terminal(TerminalOutput::from_raw(big, None));
        let (out, blob) = part.spill_if_oversized(512, &mut |_| "blb_test".to_string());
        assert_eq!(blob.as_deref(), Some("blb_test"));
        match out {
            ContentPart::Terminal(t) => {
                assert!(t.spilled_to.is_some());
                assert!(t.stripped.len() <= 1024);
                assert!(t.raw.is_none(), "raw must not be kept after spilling");
            }
            other => panic!("expected terminal, got {other:?}"),
        }
    }
}
