//! Permission modes and approval requests (`rustplan.txt` §9.1
//! `src/permission.rs`, §3.2, §6.4.3).
//!
//! The five interaction modes form a lattice over `(read, edit, shell, net)`
//! capabilities. [`Mode::decide`] is the single place that answers "does this
//! risk class need a human in this mode?", and it is exhaustively unit tested
//! (§9.4 `core/src/approval/modes.rs` acceptance: *mode table unit-tested
//! exhaustively*).

use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Serialize};

use crate::ids::RequestId;
use crate::tool::RiskClass;

/// Interaction / permission mode (`--mode`, `/mode`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Mode {
    /// Design/analysis. Reads allowed, nothing mutated, shell restricted to a
    /// read-only allowlist, no network.
    Plan,
    /// Review/audit. Same as [`Mode::Plan`] but shell is fully denied.
    ReadOnly,
    /// Default. Reads automatic; every mutation, exec and network call prompts.
    Ask,
    /// Power user. File edits are automatic; exec and network still prompt.
    AutoEdit,
    /// Containers/CI only. Everything automatic. Requires an explicit flag,
    /// prints a banner and writes an audit entry (§3.2).
    Bypass,
}

impl Mode {
    /// All modes, most restrictive first.
    pub const ALL: [Mode; 5] =
        [Mode::Plan, Mode::ReadOnly, Mode::Ask, Mode::AutoEdit, Mode::Bypass];

    /// Stable wire/CLI name.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Mode::Plan => "plan",
            Mode::ReadOnly => "read-only",
            Mode::Ask => "ask",
            Mode::AutoEdit => "auto-edit",
            Mode::Bypass => "bypass",
        }
    }

    /// One-line description for `/help` and the mode picker overlay.
    #[must_use]
    pub const fn blurb(self) -> &'static str {
        match self {
            Mode::Plan => "read, analyse and propose; never modify anything",
            Mode::ReadOnly => "read-only review; no shell, no edits",
            Mode::Ask => "prompt before every edit, command and network call",
            Mode::AutoEdit => "apply file edits automatically; prompt for commands",
            Mode::Bypass => "run everything without prompting (containers/CI only)",
        }
    }

    /// Numeric restrictiveness; higher = more restrictive. Used by the managed
    /// policy merge ("most restrictive wins", §9.5 `managed.rs`).
    #[must_use]
    pub const fn restrictiveness(self) -> u8 {
        match self {
            Mode::ReadOnly => 4,
            Mode::Plan => 3,
            Mode::Ask => 2,
            Mode::AutoEdit => 1,
            Mode::Bypass => 0,
        }
    }

    /// Merge two modes, keeping the more restrictive one.
    #[must_use]
    pub fn most_restrictive(self, other: Mode) -> Mode {
        if self.restrictiveness() >= other.restrictiveness() { self } else { other }
    }

    /// True when the mode is safe to enter without an explicit user opt-in.
    #[must_use]
    pub const fn requires_explicit_opt_in(self) -> bool {
        matches!(self, Mode::Bypass)
    }

    /// Decide what should happen for a risk class in this mode.
    ///
    /// This is the authoritative mode table (§3.2). `allow` means "run it";
    /// `ask` means "emit `ToolApprovalNeeded` and wait"; `deny` means "refuse
    /// and tell the model why".
    #[must_use]
    pub fn decide(self, risk: RiskClass) -> ModeDecision {
        use ModeDecision::{Allow, Ask, Deny};
        use RiskClass::*;
        match (self, risk) {
            // Meta tools (ask_user) always go to the human, in every mode.
            (_, Meta) => Ask,
            // Spawn always prompts at least once per session.
            (Mode::Bypass, Spawn) => Allow,
            (_, Spawn) => Ask,

            // Read-only tools: automatic everywhere.
            (_, Read) => Allow,

            // Mutations.
            (Mode::Plan, Mutate | Destructive | Exec | Network) => Deny,
            (Mode::ReadOnly, Mutate | Destructive | Exec | Network) => Deny,
            (Mode::Ask, Mutate | Destructive) => Ask,
            (Mode::AutoEdit, Mutate) => Allow,
            (Mode::AutoEdit, Destructive) => Ask,
            (Mode::Bypass, Mutate | Destructive) => Allow,

            // Exec and network.
            (Mode::Ask, Exec | Network) => Ask,
            (Mode::AutoEdit, Exec | Network) => Ask,
            (Mode::Bypass, Exec | Network) => Allow,
        }
    }

    /// Legal mode transitions (§9.4 `approval/modes.rs`). `plan -> ask` happens
    /// when the user confirms a plan; `bypass` can only be entered from the CLI
    /// flag, never from inside a session.
    #[must_use]
    pub fn can_transition_to(self, next: Mode) -> bool {
        match (self, next) {
            (Mode::Bypass, Mode::Bypass) => true,
            // Leaving bypass is always allowed.
            (Mode::Bypass, _) => true,
            // Entering bypass requires a restart with the flag.
            (_, Mode::Bypass) => false,
            (a, b) if a == b => true,
            _ => true,
        }
    }
}

impl Default for Mode {
    fn default() -> Self {
        Mode::Ask
    }
}

impl fmt::Display for Mode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Parse error for a mode name.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[error("unknown mode `{0}`; expected one of: plan, read-only, ask, auto-edit, bypass")]
pub struct UnknownMode(pub String);

impl FromStr for Mode {
    type Err = UnknownMode;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let norm = s.trim().to_ascii_lowercase().replace('_', "-");
        let found = Mode::ALL.iter().copied().find(|m| {
            m.as_str() == norm
                || match norm.as_str() {
                    "readonly" => matches!(m, Mode::ReadOnly),
                    "autoedit" | "auto" => matches!(m, Mode::AutoEdit),
                    "yolo" => matches!(m, Mode::Bypass),
                    "design" => matches!(m, Mode::Plan),
                    _ => false,
                }
        });
        found.ok_or_else(|| UnknownMode(s.to_owned()))
    }
}

/// What the mode table says about a call.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ModeDecision {
    /// Run without prompting.
    Allow,
    /// Prompt the human.
    Ask,
    /// Refuse and report.
    Deny,
}

/// A decision on a [`PermissionRequest`].
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "decision", rename_all = "snake_case")]
pub enum Decision {
    /// Run this call.
    Allow,
    /// Refuse this call; `reason` goes back to the model.
    Deny {
        /// Why. Shown to the user and to the model.
        #[serde(default)]
        reason: String,
    },
    /// Defer to the human (only produced by the policy engine, never by a UI).
    Ask,
    /// Run this call *and* remember the decision for a pattern.
    AllowAlways {
        /// Pattern to remember, in the grammar of §10.4.
        pattern: String,
        /// How long to remember it.
        #[serde(default)]
        scope: RememberScope,
    },
    /// Refuse and remember the refusal.
    DenyAlways {
        /// Pattern to remember.
        pattern: String,
        /// How long to remember it.
        #[serde(default)]
        scope: RememberScope,
    },
}

impl Decision {
    /// True when the call may execute.
    #[must_use]
    pub const fn allows(&self) -> bool {
        matches!(self, Decision::Allow | Decision::AllowAlways { .. })
    }

    /// True when the call must not execute.
    #[must_use]
    pub const fn denies(&self) -> bool {
        matches!(self, Decision::Deny { .. } | Decision::DenyAlways { .. })
    }

    /// True when a human must be consulted.
    #[must_use]
    pub const fn needs_human(&self) -> bool {
        matches!(self, Decision::Ask)
    }

    /// Stable label for metrics.
    #[must_use]
    pub const fn as_str(&self) -> &'static str {
        match self {
            Decision::Allow => "allow",
            Decision::Deny { .. } => "deny",
            Decision::Ask => "ask",
            Decision::AllowAlways { .. } => "allow_always",
            Decision::DenyAlways { .. } => "deny_always",
        }
    }
}

/// Re-export so callers can `use protocol::permission::RememberScope`.
pub use crate::op::RememberScope;

/// Everything a UI needs to show an honest approval prompt (§3.2).
///
/// The prompt *must* contain the exact command/argv, the cwd, a risk badge,
/// the sandbox status and an expanded preview of what "always allow" would
/// grant. Nothing here is derived from the model's stream — the chrome is
/// fixed (§9.12 `render/approval.rs`).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PermissionRequest {
    /// Single-use correlation id; the answer must carry it back.
    pub request_id: RequestId,
    /// Tool being invoked.
    pub tool: String,
    /// Risk class badge.
    pub risk: RiskClass,
    /// Redacted one-line preview of the arguments (e.g. the exact shell argv).
    pub args_preview: String,
    /// Full argument object, for the expandable detail pane.
    #[serde(default)]
    pub args: serde_json::Value,
    /// Workspace-relative paths this call would touch.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub paths: Vec<String>,
    /// Directory the call would execute in.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cwd: Option<String>,
    /// Which policy rule matched, if any (`explain()` output).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rule_hint: Option<String>,
    /// Sandbox state that will apply to the call.
    #[serde(default)]
    pub sandbox: SandboxStatus,
    /// Scope of the request: single call, this turn, or this session.
    #[serde(default)]
    pub scope: RequestScope,
    /// Pattern that "always allow" would remember, pre-expanded so the user
    /// can see exactly what they are granting.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remember_pattern: Option<String>,
    /// Milliseconds since epoch when the request was raised.
    pub raised_at_ms: u64,
}

/// Scope of a permission request.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RequestScope {
    /// This single call.
    #[default]
    Once,
    /// Every identical call in this turn.
    Turn,
    /// Every matching call in this session.
    Session,
}

/// Sandbox state surfaced in the approval prompt.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(tag = "status", rename_all = "snake_case")]
pub enum SandboxStatus {
    /// A kernel-enforced backend will contain the process.
    Enabled {
        /// Backend name, e.g. `bwrap`, `seatbelt`.
        backend: String,
    },
    /// Sandboxing was requested but no backend is available; the call will be
    /// refused unless `--no-sandbox` was passed (golden rule #6).
    #[default]
    Unavailable,
    /// The user explicitly disabled the sandbox; the banner is showing.
    DisabledByFlag,
    /// This call does not execute a process, so no sandbox applies.
    NotApplicable,
}

impl SandboxStatus {
    /// Short label for the prompt chrome.
    #[must_use]
    pub fn label(&self) -> String {
        match self {
            SandboxStatus::Enabled { backend } => format!("sandboxed ({backend})"),
            SandboxStatus::Unavailable => "sandbox UNAVAILABLE".to_owned(),
            SandboxStatus::DisabledByFlag => "sandbox OFF (--no-sandbox)".to_owned(),
            SandboxStatus::NotApplicable => "no process".to_owned(),
        }
    }

    /// True when a kernel backend will contain the process.
    #[must_use]
    pub const fn is_enforced(&self) -> bool {
        matches!(self, SandboxStatus::Enabled { .. })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mode_table_is_exhaustive_over_every_mode_and_risk() {
        let risks = [
            RiskClass::Read, RiskClass::Mutate, RiskClass::Destructive, RiskClass::Exec,
            RiskClass::Network, RiskClass::Spawn, RiskClass::Meta,
        ];
        for m in Mode::ALL {
            for r in risks {
                let d = m.decide(r);
                // Sanity invariants that must hold for every combination.
                if matches!(m, Mode::Plan | Mode::ReadOnly) {
                    assert!(
                        !matches!(d, ModeDecision::Allow) || matches!(r, RiskClass::Read),
                        "{m:?}/{r:?} must not allow non-reads"
                    );
                }
                if matches!(m, Mode::Bypass) {
                    assert_ne!(d, ModeDecision::Deny, "{m:?}/{r:?} must never deny");
                }
                if matches!(r, RiskClass::Meta) {
                    assert_eq!(d, ModeDecision::Ask, "ask_user always prompts");
                }
            }
        }
    }

    #[test]
    fn default_mode_is_ask() {
        assert_eq!(Mode::default(), Mode::Ask);
    }

    #[test]
    fn mode_parsing_accepts_aliases_and_rejects_nonsense() {
        assert_eq!("plan".parse::<Mode>().unwrap(), Mode::Plan);
        assert_eq!("read-only".parse::<Mode>().unwrap(), Mode::ReadOnly);
        assert_eq!("readonly".parse::<Mode>().unwrap(), Mode::ReadOnly);
        assert_eq!("auto_edit".parse::<Mode>().unwrap(), Mode::AutoEdit);
        assert_eq!("YOLO".parse::<Mode>().unwrap(), Mode::Bypass);
        let e = "sudo".parse::<Mode>().unwrap_err();
        assert!(e.to_string().contains("sudo"));
        assert!(e.to_string().contains("bypass"));
    }

    #[test]
    fn bypass_requires_explicit_opt_in_and_cannot_be_entered_live() {
        assert!(Mode::Bypass.requires_explicit_opt_in());
        assert!(!Mode::Ask.requires_explicit_opt_in());
        assert!(!Mode::Ask.can_transition_to(Mode::Bypass));
        assert!(Mode::Bypass.can_transition_to(Mode::Ask));
    }

    #[test]
    fn most_restrictive_wins() {
        assert_eq!(Mode::Bypass.most_restrictive(Mode::Ask), Mode::Ask);
        assert_eq!(Mode::ReadOnly.most_restrictive(Mode::Plan), Mode::ReadOnly);
    }

    #[test]
    fn decision_predicates_are_consistent() {
        assert!(Decision::Allow.allows());
        assert!(Decision::Deny { reason: String::new() }.denies());
        assert!(Decision::Ask.needs_human());
        assert!(Decision::AllowAlways { pattern: "shell(git *)".into(), scope: RememberScope::ThisSession }.allows());
    }

    #[test]
    fn permission_request_serialises_with_defaults_omitted() {
        let r = PermissionRequest {
            request_id: RequestId::new(),
            tool: "shell".into(),
            risk: RiskClass::Exec,
            args_preview: "command=cargo test".into(),
            args: serde_json::json!({"command": "cargo test"}),
            paths: vec![],
            cwd: Some("/repo".into()),
            rule_hint: None,
            sandbox: SandboxStatus::Enabled { backend: "bwrap".into() },
            scope: RequestScope::Once,
            remember_pattern: None,
            raised_at_ms: 0,
        };
        let v = serde_json::to_value(&r).unwrap();
        assert!(v.get("paths").is_none(), "empty vec must not serialise: {v}");
        assert_eq!(v["sandbox"], serde_json::json!({"status": "enabled", "backend": "bwrap"}));
        // Round-trips.
        let back: PermissionRequest = serde_json::from_value(v).unwrap();
        assert_eq!(back.sandbox, SandboxStatus::Enabled { backend: "bwrap".into() });
    }

    #[test]
    fn sandbox_label_is_honest() {
        assert_eq!(SandboxStatus::Unavailable.label(), "sandbox UNAVAILABLE");
        assert_eq!(
            SandboxStatus::Enabled { backend: "seatbelt".into() }.label(),
            "sandboxed (seatbelt)"
        );
        assert!(SandboxStatus::DisabledByFlag.label().contains("--no-sandbox"));
    }
}
