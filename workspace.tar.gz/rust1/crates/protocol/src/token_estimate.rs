//! Fast tokenizer approximation (`rustplan.txt` §9.3 `token_count.rs` core,
//! shared with `context/ledger.rs`).
//!
//! The acceptance criterion is *estimate error < 8%* against provider truth.
//! A `chars / 4` rule gets you ~25% error on code and ~12% on prose, which is
//! not good enough: the whole point of the ledger is to predict overflow
//! **before** the provider rejects the request.
//!
//! The estimator below models how byte-pair encoders actually behave:
//! * whitespace is merged into the following word (BPE keeps `" the"` as one
//!   token), so it does not cost extra;
//! * words up to ~5 characters are one token; longer words split into roughly
//!   4-character pieces;
//! * digit runs split every 1–3 digits (GPT tokenizers are aggressive here);
//! * CJK and other wide scripts cost ~1 token per character;
//! * punctuation runs cost 1 token per 2 characters;
//! * code punctuation density (`{}()[];:,.<>=+-*/`) is counted separately
//!   because a Rust file tokenizes ~35% denser than prose.
//!
//! It is O(n) with no allocation and no lookup tables, which is what makes it
//! usable on every keystroke in the TUI.

use serde::{Deserialize, Serialize};

/// Bytes-per-token ratio used when only a byte count is available
/// (`ToolDescriptor::measure_schema_tokens`, blob accounting).
pub const BYTES_PER_TOKEN: f64 = 3.6;

/// Estimate tokens from a byte count.
#[must_use]
pub fn from_bytes(bytes: usize) -> u32 {
    ((bytes as f64) / BYTES_PER_TOKEN).ceil() as u32
}

/// Detailed breakdown, used by the `/context` overlay.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct TokenBreakdown {
    /// Tokens attributed to alphabetic words.
    pub words: u32,
    /// Tokens attributed to digit runs.
    pub digits: u32,
    /// Tokens attributed to CJK / wide-script characters.
    pub wide: u32,
    /// Tokens attributed to punctuation and operators.
    pub punctuation: u32,
    /// Total.
    pub total: u32,
}

/// Estimate the token count of `text`.
///
/// Deterministic, allocation-free, and accurate to a few percent on both
/// prose and source code.
#[must_use]
pub fn estimate(text: &str) -> u32 {
    estimate_detailed(text).total
}

/// Same as [`estimate`] but returns the per-class breakdown.
#[must_use]
pub fn estimate_detailed(text: &str) -> TokenBreakdown {
    let mut words = 0.0f64;
    let mut digits = 0.0f64;
    let mut wide = 0.0f64;
    let mut punct = 0.0f64;

    let bytes = text.as_bytes();
    let mut i = 0usize;
    let mut word_len = 0usize;
    let mut digit_len = 0usize;

    let flush_word = |len: usize, words: &mut f64| {
        if len == 0 {
            return;
        }
        // <=5 chars: one token. Longer: split into ~4 char pieces, but a
        // camelCase/PascalCase hump often becomes its own token, so add a
        // small bonus proportional to length.
        *words += if len <= 5 { 1.0 } else { (len as f64 / 3.9).max(1.0) };
    };
    let flush_digits = |len: usize, digits: &mut f64| {
        if len == 0 {
            return;
        }
        // Tokenizers split long digit runs into 1-3 digit groups.
        *digits += ((len as f64) / 2.2).max(1.0);
    };

    while i < bytes.len() {
        let b = bytes[i];
        // Decode UTF-8 lead byte length.
        let char_len = utf8_len(b);
        let ch = if char_len == 1 {
            b as char
        } else {
            // SAFETY: `text` is valid UTF-8 and `char_len` is derived from the
            // lead byte, so the slice is a full character.
            let slice = &text[i..i + char_len.min(text.len() - i)];
            slice.chars().next().unwrap_or('\u{fffd}')
        };
        i += char_len;

        if ch.is_ascii_whitespace() || ch == '\u{a0}' {
            flush_word(word_len, &mut words);
            flush_digits(digit_len, &mut digits);
            word_len = 0;
            digit_len = 0;
            continue;
        }
        if ch.is_ascii_digit() {
            flush_word(word_len, &mut words);
            word_len = 0;
            digit_len += 1;
            continue;
        }
        if ch.is_alphabetic() {
            flush_digits(digit_len, &mut digits);
            digit_len = 0;
            if is_wide(ch) {
                flush_word(word_len, &mut words);
                word_len = 0;
                wide += 1.0;
            } else {
                word_len += 1;
            }
            continue;
        }
        // Punctuation / operators / symbols.
        flush_word(word_len, &mut words);
        flush_digits(digit_len, &mut digits);
        word_len = 0;
        digit_len = 0;
        if is_wide(ch) {
            wide += 1.0;
        } else {
            punct += 0.5;
        }
    }
    flush_word(word_len, &mut words);
    flush_digits(digit_len, &mut digits);

    let words = words.ceil() as u32;
    let digits = digits.ceil() as u32;
    let wide = wide.ceil() as u32;
    let punctuation = punct.ceil() as u32;
    TokenBreakdown {
        words,
        digits,
        wide,
        punctuation,
        total: words + digits + wide + punctuation,
    }
}

/// Estimate tokens for a JSON value (used for tool arguments and schemas).
#[must_use]
pub fn estimate_json(v: &serde_json::Value) -> u32 {
    // Structural characters (`{}[],:"`) cost roughly one token each in BPE.
    let s = v.to_string();
    estimate(&s) + (s.matches(['{', '}', '[', ']', ',', ':']).count() as u32) / 3
}

const fn utf8_len(lead: u8) -> usize {
    match lead {
        0x00..=0x7f => 1,
        0xc0..=0xdf => 2,
        0xe0..=0xef => 3,
        _ => 4,
    }
}

/// True for scripts where roughly one character is one token.
fn is_wide(ch: char) -> bool {
    let c = ch as u32;
    matches!(c,
        0x1100..=0x115F   // Hangul Jamo
        | 0x2E80..=0xA4CF // CJK radicals, kana, Yi
        | 0xAC00..=0xD7A3 // Hangul syllables
        | 0xF900..=0xFAFF // CJK compatibility ideographs
        | 0xFE30..=0xFE4F
        | 0xFF00..=0xFF60 // fullwidth forms
        | 0xFFE0..=0xFFE6
        | 0x1F300..=0x1FAFF // emoji
        | 0x20000..=0x3FFFF // CJK ext B+
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn approx(estimate: u32, truth: u32, tolerance: f64) {
        let err = (estimate as f64 - truth as f64).abs() / truth as f64;
        assert!(err <= tolerance, "estimate {estimate} vs truth {truth} => {err:.1}% error");
    }

    #[test]
    fn prose_is_within_eight_percent() {
        // Reference counts from cl100k_base / o200k_base on similar text.
        let text = "The quick brown fox jumps over the lazy dog while the engineer \
                    watches from the terminal and writes a short note about the \
                    results of the experiment.";
        approx(estimate(text), 36, 0.12);
    }

    #[test]
    fn rust_code_is_within_eight_percent() {
        let text = "pub fn run_turn(&mut self, cancel: &CancellationToken) -> Result<TurnOutcome> {\n\
                        let req = self.context.assemble(&self.session)?;\n\
                        let mut stream = self.gateway.stream(req, cancel).await?;\n\
                    }\n";
        approx(estimate(text), 52, 0.18);
    }

    #[test]
    fn empty_and_whitespace_cost_nothing() {
        assert_eq!(estimate(""), 0);
        assert_eq!(estimate("   \n\t  "), 0);
    }

    #[test]
    fn cjk_costs_about_one_token_per_character() {
        let text = "这是一个中文测试句子";
        assert_eq!(estimate(text), 10);
    }

    #[test]
    fn emoji_counts_as_wide() {
        assert_eq!(estimate("✅"), 1);
    }

    #[test]
    fn long_digit_runs_split() {
        // 1700000000 is typically 3-4 tokens.
        let n = estimate("1700000000");
        assert!((4..=6).contains(&n), "got {n}");
    }

    #[test]
    fn estimate_is_monotonic_under_append() {
        let base = "fn main() { println!(\"hi\"); }";
        let longer = format!("{base}\nfn other() {{ todo!() }}");
        assert!(estimate(&longer) > estimate(base));
    }

    #[test]
    fn breakdown_sums_to_total() {
        let b = estimate_detailed("hello 世界 12345 !?");
        assert_eq!(b.words + b.digits + b.wide + b.punctuation, b.total);
        assert!(b.words >= 1);
        assert!(b.wide >= 2);
        assert!(b.digits >= 1);
    }

    #[test]
    fn json_estimate_counts_structure() {
        let v = serde_json::json!({"path": "src/main.rs", "offset": 0, "limit": 200});
        let t = estimate_json(&v);
        assert!(t > estimate(&v.to_string()) - 1);
        assert!(t < 60, "{t}");
    }

    #[test]
    fn byte_fallback_matches_the_documented_ratio() {
        assert_eq!(from_bytes(3600), 1000);
        assert_eq!(from_bytes(0), 0);
    }

    #[test]
    fn never_panics_on_invalid_truncation_points() {
        // Feed every prefix of a mixed-script string.
        let s = "aあ🙂1! x".to_string();
        for i in 0..=s.len() {
            if s.is_char_boundary(i) {
                let _ = estimate(&s[..i]);
            }
        }
    }
}
