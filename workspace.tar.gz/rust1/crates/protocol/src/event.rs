//! Event catalogue: agent → client (`rustplan.txt` §9.1 `src/event.rs`, §10.2).
//!
//! **35 events in 6 families.** This is the single source of truth for four
//! consumers at once — the TUI projection, the JSON-RPC app-server, the JSONL
//! rollout (durable truth) and the telemetry tap — so the rules are strict:
//!
//! * Every event carries `{ id, thread_id, turn_id?, ts, schema_version, seq }`
//!   in an [`EventEnvelope`].
//! * `#[serde(tag = "type", rename_all = "snake_case")]` — the discriminator is
//!   stable and machine readable.
//! * **Additive only.** A variant may gain `#[serde(default)]` fields; it may
//!   never be renamed or removed. Clients must ignore unknown variants
//!   ([`Event::Unknown`]).
//! * `seq` is per-thread monotonic, which is what makes replay deterministic
//!   and lets a lagging subscriber detect the gap instead of silently
//!   diverging.

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::content::ContentPart;
use crate::ids::{CallId, EventId, RequestId, RunId, ThreadId, TurnId, WorkerId};
use crate::permission::{Decision, PermissionRequest};
use crate::plan::{NodeKind, TaskPlan};
use crate::tool::{DeniedBy, RiskClass, ToolCall, ToolError, ToolResult};
use crate::usage::Usage;
use crate::{Mode, ModelId};

/// Bumped when an event's *meaning* changes. Adding fields does not bump it.
pub const EVENT_SCHEMA_VERSION: u32 = 1;

/// The six event families (§10.2).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EventFamily {
    /// Turn lifecycle.
    Turn,
    /// Model-visible content.
    Content,
    /// Tool invocation lifecycle.
    Tools,
    /// Context window management.
    Context,
    /// Parallel subagents.
    Workers,
    /// Cross-cutting system notices.
    System,
}

impl EventFamily {
    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            EventFamily::Turn => "turn",
            EventFamily::Content => "content",
            EventFamily::Tools => "tools",
            EventFamily::Context => "context",
            EventFamily::Workers => "workers",
            EventFamily::System => "system",
        }
    }
}

/// Delivery semantics of an event.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Durability {
    /// Written to the JSONL rollout *and* the SQLite index.
    Durable,
    /// Written to the rollout only (high volume, low value for queries).
    RolloutOnly,
    /// Broadcast to subscribers only; never persisted (keystroke-level noise).
    Transient,
}

/// An agent event.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Event {
    // ── Turn ────────────────────────────────────────────────────────────────
    /// A turn began.
    TurnStarted(TurnStarted),
    /// The agent moved between turn states (§4.4).
    StateChanged(StateChanged),
    /// The turn finished successfully.
    TurnCompleted(TurnCompleted),
    /// The turn failed.
    TurnFailed(TurnFailed),
    /// The turn was cancelled by the user or the budget.
    TurnCancelled(TurnCancelled),

    // ── Content ─────────────────────────────────────────────────────────────
    /// Incremental assistant text.
    TextDelta(TextDelta),
    /// Incremental reasoning text (hidden by default, §6.3.4).
    ThinkingDelta(ThinkingDelta),
    /// The assistant message is complete.
    TextCompleted(TextCompleted),
    /// Compaction replaced part of the visible transcript.
    ContentReplaced(ContentReplaced),

    // ── Tools ───────────────────────────────────────────────────────────────
    /// The model asked for a tool call.
    ToolRequested(ToolRequested),
    /// A human decision is required; the turn is parked.
    ToolApprovalNeeded(ToolApprovalNeeded),
    /// The human (or a remembered grant) decided.
    ToolApprovalDecided(ToolApprovalDecided),
    /// Execution started.
    ToolStarted(ToolStarted),
    /// Incremental tool output (throttled, §9.9 `exec/stream.rs`).
    ToolOutputDelta(ToolOutputDelta),
    /// The tool finished.
    ToolCompleted(ToolCompleted),
    /// The tool errored in a way the model can act on.
    ToolFailed(ToolFailed),
    /// The tool was refused before executing.
    ToolDenied(ToolDenied),

    // ── Context ─────────────────────────────────────────────────────────────
    /// A request was assembled; sizes only, never content (§10.2).
    ContextAssembled(ContextAssembled),
    /// Compaction began.
    CompactStarted(CompactStarted),
    /// One ladder stage ran (§6.1.2).
    CompactStage(CompactStage),
    /// Compaction finished.
    CompactCompleted(CompactCompleted),
    /// Memory files (AGENTS.md hierarchy) were loaded.
    MemoryLoaded(MemoryLoaded),

    // ── Workers ─────────────────────────────────────────────────────────────
    /// A parallel run's worker started.
    WorkerSpawned(WorkerSpawned),
    /// Progress from a worker (throttled to 10 fps for the board).
    WorkerProgress(WorkerProgress),
    /// A worker returned its [`crate::worker::WorkerReport`].
    WorkerReported(WorkerReported),
    /// A worker was cancelled.
    WorkerCancelled(WorkerCancelled),
    /// A worker's branch entered the merge queue.
    MergeQueued(MergeQueued),
    /// A merge finished (success or conflict).
    MergeCompleted(MergeCompleted),
    /// A verify gate ran.
    VerifyResult(VerifyResult),

    // ── System ──────────────────────────────────────────────────────────────
    /// Token/cost counters moved.
    UsageUpdated(UsageUpdated),
    /// Session cost changed (separate event so `/cost` can subscribe cheaply).
    CostUpdated(CostUpdated),
    /// Non-fatal problem worth surfacing (golden rule #11: no silent fallback).
    Warning(Warning),
    /// Fatal problem for this turn or session.
    Error(ErrorEvent),
    /// Config changed (hot reload or `/config set`).
    ConfigChanged(ConfigChanged),
    /// A session was resumed, possibly with drift warnings (§6.5 rule 5).
    SessionResumed(SessionResumed),

    /// An event this build does not understand. Preserved verbatim so a newer
    /// agent's rollout can be replayed by an older TUI without data loss.
    Unknown(UnknownEvent),
}

impl Event {
    /// Which family this event belongs to.
    #[must_use]
    pub const fn family(&self) -> EventFamily {
        match self {
            Event::TurnStarted(_)
            | Event::StateChanged(_)
            | Event::TurnCompleted(_)
            | Event::TurnFailed(_)
            | Event::TurnCancelled(_) => EventFamily::Turn,

            Event::TextDelta(_)
            | Event::ThinkingDelta(_)
            | Event::TextCompleted(_)
            | Event::ContentReplaced(_) => EventFamily::Content,

            Event::ToolRequested(_)
            | Event::ToolApprovalNeeded(_)
            | Event::ToolApprovalDecided(_)
            | Event::ToolStarted(_)
            | Event::ToolOutputDelta(_)
            | Event::ToolCompleted(_)
            | Event::ToolFailed(_)
            | Event::ToolDenied(_) => EventFamily::Tools,

            Event::ContextAssembled(_)
            | Event::CompactStarted(_)
            | Event::CompactStage(_)
            | Event::CompactCompleted(_)
            | Event::MemoryLoaded(_) => EventFamily::Context,

            Event::WorkerSpawned(_)
            | Event::WorkerProgress(_)
            | Event::WorkerReported(_)
            | Event::WorkerCancelled(_)
            | Event::MergeQueued(_)
            | Event::MergeCompleted(_)
            | Event::VerifyResult(_) => EventFamily::Workers,

            Event::UsageUpdated(_)
            | Event::CostUpdated(_)
            | Event::Warning(_)
            | Event::Error(_)
            | Event::ConfigChanged(_)
            | Event::SessionResumed(_) => EventFamily::System,

            Event::Unknown(_) => EventFamily::System,
        }
    }

    /// Stable `type` discriminator, matching the serde tag.
    #[must_use]
    pub fn kind(&self) -> &'static str {
        match self {
            Event::TurnStarted(_) => "turn_started",
            Event::StateChanged(_) => "state_changed",
            Event::TurnCompleted(_) => "turn_completed",
            Event::TurnFailed(_) => "turn_failed",
            Event::TurnCancelled(_) => "turn_cancelled",
            Event::TextDelta(_) => "text_delta",
            Event::ThinkingDelta(_) => "thinking_delta",
            Event::TextCompleted(_) => "text_completed",
            Event::ContentReplaced(_) => "content_replaced",
            Event::ToolRequested(_) => "tool_requested",
            Event::ToolApprovalNeeded(_) => "tool_approval_needed",
            Event::ToolApprovalDecided(_) => "tool_approval_decided",
            Event::ToolStarted(_) => "tool_started",
            Event::ToolOutputDelta(_) => "tool_output_delta",
            Event::ToolCompleted(_) => "tool_completed",
            Event::ToolFailed(_) => "tool_failed",
            Event::ToolDenied(_) => "tool_denied",
            Event::ContextAssembled(_) => "context_assembled",
            Event::CompactStarted(_) => "compact_started",
            Event::CompactStage(_) => "compact_stage",
            Event::CompactCompleted(_) => "compact_completed",
            Event::MemoryLoaded(_) => "memory_loaded",
            Event::WorkerSpawned(_) => "worker_spawned",
            Event::WorkerProgress(_) => "worker_progress",
            Event::WorkerReported(_) => "worker_reported",
            Event::WorkerCancelled(_) => "worker_cancelled",
            Event::MergeQueued(_) => "merge_queued",
            Event::MergeCompleted(_) => "merge_completed",
            Event::VerifyResult(_) => "verify_result",
            Event::UsageUpdated(_) => "usage_updated",
            Event::CostUpdated(_) => "cost_updated",
            Event::Warning(_) => "warning",
            Event::Error(_) => "error",
            Event::ConfigChanged(_) => "config_changed",
            Event::SessionResumed(_) => "session_resumed",
            Event::Unknown(u) => {
                // Cannot return a borrowed &'static str for an arbitrary name;
                // callers needing the raw name use `Unknown::name`.
                let _ = u;
                "unknown"
            }
        }
    }

    /// Persistence policy for this event.
    #[must_use]
    pub const fn durability(&self) -> Durability {
        match self {
            // Keystroke-level noise: never persisted.
            Event::TextDelta(_) | Event::ThinkingDelta(_) | Event::ToolOutputDelta(_) => {
                Durability::Transient
            }
            // Volume is moderate and the rollout is the replay truth.
            Event::WorkerProgress(_) | Event::StateChanged(_) | Event::UsageUpdated(_) => {
                Durability::RolloutOnly
            }
            Event::Unknown(_) => Durability::RolloutOnly,
            _ => Durability::Durable,
        }
    }

    /// The turn this event belongs to, when applicable.
    #[must_use]
    pub fn turn_id(&self) -> Option<TurnId> {
        match self {
            Event::TurnStarted(e) => Some(e.turn_id),
            Event::TurnCompleted(e) => Some(e.turn_id),
            Event::TurnFailed(e) => Some(e.turn_id),
            Event::TurnCancelled(e) => Some(e.turn_id),
            Event::StateChanged(e) => Some(e.turn_id),
            Event::TextDelta(e) => Some(e.turn_id),
            Event::ThinkingDelta(e) => Some(e.turn_id),
            Event::TextCompleted(e) => Some(e.turn_id),
            Event::ToolRequested(e) => Some(e.turn_id),
            Event::ToolApprovalNeeded(e) => Some(e.turn_id),
            Event::ToolApprovalDecided(e) => Some(e.turn_id),
            Event::ToolStarted(e) => Some(e.turn_id),
            Event::ToolOutputDelta(e) => Some(e.turn_id),
            Event::ToolCompleted(e) => Some(e.turn_id),
            Event::ToolFailed(e) => Some(e.turn_id),
            Event::ToolDenied(e) => Some(e.turn_id),
            Event::ContextAssembled(e) => Some(e.turn_id),
            Event::CompactStarted(e) => e.turn_id,
            Event::CompactStage(e) => e.turn_id,
            Event::CompactCompleted(e) => e.turn_id,
            Event::UsageUpdated(e) => Some(e.turn_id),
            Event::CostUpdated(e) => Some(e.turn_id),
            Event::VerifyResult(e) => e.turn_id,
            Event::ContentReplaced(e) => e.turn_id,
            Event::MemoryLoaded(_)
            | Event::WorkerSpawned(_)
            | Event::WorkerProgress(_)
            | Event::WorkerReported(_)
            | Event::WorkerCancelled(_)
            | Event::MergeQueued(_)
            | Event::MergeCompleted(_)
            | Event::Warning(_)
            | Event::Error(_)
            | Event::ConfigChanged(_)
            | Event::SessionResumed(_)
            | Event::Unknown(_) => None,
        }
    }
}

/// Everything the transports wrap around an [`Event`].
///
/// The wire names follow the rollout line documented in §10.5:
///
/// ```json
/// {"v":1,"ts":"2026-10-30T09:12:44.118Z","thread":"thr_01JB…",
///  "turn":"trn_01JB…","type":"tool_completed", … ,"checksum":"blake3:…"}
/// ```
///
/// Two deliberate details:
/// * The header keys are `thread`/`turn`, **not** `thread_id`/`turn_id`. The
///   event payload is flattened into the same object, and several payloads
///   carry their own `turn_id`; sharing a key would make serde steal the field
///   from the inner event and fail with a confusing `missing field`.
/// * `ts` is an ISO-8601 string on the wire (human readable under `jq`) while
///   the Rust field stays a `u64` millisecond count.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct EventEnvelope {
    /// Globally unique event id.
    pub id: EventId,
    /// Owning thread.
    #[serde(rename = "thread")]
    pub thread_id: ThreadId,
    /// Owning turn, if the event is turn-scoped.
    #[serde(rename = "turn", default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Agent clock at emission, milliseconds since the unix epoch.
    #[serde(rename = "ts", serialize_with = "ser_ts", deserialize_with = "de_ts")]
    pub ts_ms: u64,
    /// Per-thread monotonic sequence; gaps mean a subscriber lagged.
    #[serde(default)]
    pub seq: u64,
    /// Event schema version.
    #[serde(rename = "v", default = "default_schema_version")]
    pub schema_version: u32,
    /// Worker that produced the event, for parallel runs.
    #[serde(rename = "worker", default, skip_serializing_if = "Option::is_none")]
    pub worker_id: Option<WorkerId>,
    /// The event.
    #[serde(flatten)]
    pub event: Event,
    /// blake3 checksum of the line with this field absent. Written only into
    /// the JSONL rollout (§10.5) so `agent audit verify` can detect a single
    /// flipped bit in a multi-gigabyte file. `None` for in-memory broadcasts.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub checksum: Option<String>,
}

const fn default_schema_version() -> u32 {
    EVENT_SCHEMA_VERSION
}

fn ser_ts<S: serde::Serializer>(ms: &u64, s: S) -> Result<S::Ok, S::Error> {
    s.serialize_str(&crate::iso_from_ms(*ms))
}

fn de_ts<'de, D: serde::Deserializer<'de>>(d: D) -> Result<u64, D::Error> {
    use serde::de::Error as _;
    match Value::deserialize(d)? {
        Value::Number(n) => n.as_u64().ok_or_else(|| D::Error::custom("ts must be a u64")),
        Value::String(s) => {
            if let Ok(ms) = s.parse::<u64>() {
                return Ok(ms);
            }
            chrono::DateTime::parse_from_rfc3339(&s)
                .map(|dt| dt.timestamp_millis().max(0) as u64)
                .map_err(|e| D::Error::custom(format!("ts `{s}` is neither millis nor RFC3339: {e}")))
        }
        other => Err(D::Error::custom(format!("ts must be a string or integer, got {other}"))),
    }
}

/// Best-effort `ts` parse used on the fallback path, which has to cope with
/// both the ISO string form and a bare millisecond integer.
fn parse_ts_value(v: Option<&Value>) -> u64 {
    match v {
        Some(Value::Number(n)) => n.as_u64().unwrap_or(0),
        Some(Value::String(s)) => s
            .parse::<u64>()
            .ok()
            .or_else(|| {
                chrono::DateTime::parse_from_rfc3339(s)
                    .ok()
                    .map(|dt| dt.timestamp_millis().max(0) as u64)
            })
            .unwrap_or(0),
        _ => 0,
    }
}

impl EventEnvelope {
    /// Wrap an event for a thread with an explicit sequence number.
    #[must_use]
    pub fn new(thread_id: ThreadId, seq: u64, event: Event) -> Self {
        Self {
            id: EventId::new(),
            thread_id,
            turn_id: event.turn_id(),
            ts_ms: crate::now_ms(),
            seq,
            schema_version: EVENT_SCHEMA_VERSION,
            worker_id: None,
            event,
            checksum: None,
        }
    }

    /// Attach the producing worker.
    #[must_use]
    pub fn from_worker(mut self, w: WorkerId) -> Self {
        self.worker_id = Some(w);
        self
    }

    /// Serialise to one JSONL rollout line (§10.5).
    ///
    /// # Errors
    /// Only if the event contains a value serde cannot serialise.
    pub fn to_rollout_line(&self) -> Result<String, serde_json::Error> {
        let mut v = serde_json::to_value(self)?;
        // The rollout line carries a blake3 checksum so `audit verify` can
        // detect a single flipped bit in a multi-gigabyte file.
        let body = serde_json::to_string(&v)?;
        let sum = blake3::hash(body.as_bytes());
        if let Some(obj) = v.as_object_mut() {
            obj.insert("checksum".to_owned(), Value::String(format!("blake3:{sum}")));
        }
        serde_json::to_string(&v)
    }

    /// Verify a rollout line's checksum.
    ///
    /// # Errors
    /// Returns `false`-equivalent error text when the line does not parse.
    pub fn verify_rollout_line(line: &str) -> Result<bool, serde_json::Error> {
        let v: Value = serde_json::from_str(line)?;
        let Some(expected) = v.get("checksum").and_then(Value::as_str) else {
            return Ok(false);
        };
        let mut copy = v.clone();
        if let Some(obj) = copy.as_object_mut() {
            obj.remove("checksum");
        }
        let body = serde_json::to_string(&copy)?;
        let actual = blake3::hash(body.as_bytes()).to_string();
        Ok(expected.strip_prefix("blake3:").unwrap_or(expected) == actual)
    }

    /// Parse a rollout line into an envelope. Unknown event types degrade to
    /// [`Event::Unknown`] so an old agent can still replay a new rollout.
    ///
    /// # Errors
    /// When the line is not a JSON object.
    pub fn from_rollout_line(line: &str) -> Result<Self, serde_json::Error> {
        match serde_json::from_str::<Self>(line) {
            Ok(env) => Ok(env),
            Err(e) => {
                let v: Value = serde_json::from_str(line)?;
                let name = v.get("type").and_then(Value::as_str).unwrap_or("<missing>");
                let thread_id = v
                    .get("thread")
                    .or_else(|| v.get("thread_id"))
                    .and_then(Value::as_str)
                    .and_then(|s| ThreadId::parse(s).ok())
                    .unwrap_or_default();
                Ok(Self {
                    id: v.get("id")
                        .and_then(Value::as_str)
                        .and_then(|s| EventId::parse(s).ok())
                        .unwrap_or_default(),
                    thread_id,
                    turn_id: v.get("turn")
                        .or_else(|| v.get("turn_id"))
                        .and_then(Value::as_str)
                        .and_then(|s| TurnId::parse(s).ok()),
                    ts_ms: parse_ts_value(v.get("ts").or_else(|| v.get("ts_ms"))),
                    seq: v.get("seq").and_then(Value::as_u64).unwrap_or(0),
                    schema_version: v
                        .get("v")
                        .or_else(|| v.get("schema_version"))
                        .and_then(Value::as_u64)
                        .map_or(EVENT_SCHEMA_VERSION, |x| x as u32),
                    worker_id: v.get("worker")
                        .or_else(|| v.get("worker_id"))
                        .and_then(Value::as_str)
                        .and_then(|s| WorkerId::parse(s).ok()),
                    event: Event::Unknown(UnknownEvent { name: name.to_owned(), payload: v }),
                    checksum: None,
                })
                .map_err(|_: serde_json::Error| e)
            }
        }
    }
}

// ── Turn family ─────────────────────────────────────────────────────────────

/// Payload of [`Event::TurnStarted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TurnStarted {
    /// The new turn.
    pub turn_id: TurnId,
    /// Model bound for this turn.
    pub model: ModelId,
    /// Permission mode in force.
    pub mode: Mode,
    /// The user prompt, echoed so the transcript is self-contained.
    pub prompt: String,
    /// Token budget at turn start (input side).
    pub budget_tokens: u32,
    /// Running session totals at turn start.
    #[serde(default)]
    pub session_usage: Usage,
}

/// Turn state machine states (§4.4). Exhaustive; an illegal transition is a
/// compile error at the call site because `core/agent/state.rs` matches on
/// this enum.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TurnState {
    /// Waiting for an op.
    Idle,
    /// Building the prompt.
    Assembling,
    /// Receiving model output.
    Streaming,
    /// Waiting for a human decision.
    Approving,
    /// Running tools.
    Executing,
    /// Running the compaction ladder.
    Compacting,
    /// Running post-edit verification.
    Verifying,
    /// Retrying after a transient failure.
    Retrying,
    /// Terminal: success.
    Done,
    /// Terminal: user cancelled.
    Cancelled,
    /// Terminal: failure.
    Failed,
}

impl TurnState {
    /// True for the three terminal states.
    #[must_use]
    pub const fn is_terminal(self) -> bool {
        matches!(self, TurnState::Done | TurnState::Cancelled | TurnState::Failed)
    }

    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            TurnState::Idle => "idle",
            TurnState::Assembling => "assembling",
            TurnState::Streaming => "streaming",
            TurnState::Approving => "approving",
            TurnState::Executing => "executing",
            TurnState::Compacting => "compacting",
            TurnState::Verifying => "verifying",
            TurnState::Retrying => "retrying",
            TurnState::Done => "done",
            TurnState::Cancelled => "cancelled",
            TurnState::Failed => "failed",
        }
    }
}

impl std::fmt::Display for TurnState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Payload of [`Event::StateChanged`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct StateChanged {
    /// The turn.
    pub turn_id: TurnId,
    /// State we left.
    pub from: TurnState,
    /// State we entered.
    pub to: TurnState,
    /// Why, in one line (shown in the debug overlay).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
}

/// How a turn ended.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TurnOutcome {
    /// The model stopped asking for tools.
    Completed,
    /// A budget (tokens/calls/time/cost) was hit.
    BudgetStop,
    /// The user interrupted.
    Cancelled,
    /// Too many identical calls (`core/agent/limits.rs`).
    LoopDetected,
    /// The model hit its output cap repeatedly without progress.
    MaxTurns,
    /// An unrecoverable error.
    Failed,
}

impl TurnOutcome {
    /// Exit-code contribution (§3.7).
    #[must_use]
    pub const fn exit_code(self) -> u8 {
        match self {
            TurnOutcome::Completed => 0,
            TurnOutcome::BudgetStop | TurnOutcome::MaxTurns => 53,
            TurnOutcome::Cancelled => 130,
            TurnOutcome::LoopDetected => 1,
            TurnOutcome::Failed => 1,
        }
    }
}

/// Payload of [`Event::TurnCompleted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TurnCompleted {
    /// The turn.
    pub turn_id: TurnId,
    /// How it ended.
    pub outcome: TurnOutcome,
    /// Final assistant text (also in the transcript; duplicated here so
    /// headless `agent exec` can print it without replaying).
    #[serde(default)]
    pub final_text: String,
    /// Usage for this turn.
    #[serde(default)]
    pub usage: Usage,
    /// Session totals after this turn.
    #[serde(default)]
    pub session_usage: Usage,
    /// Wall time.
    pub duration_ms: u64,
    /// Milliseconds to first token (§2.7 success metric).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ttft_ms: Option<u64>,
    /// Number of model calls (a turn loops once per tool round).
    pub model_calls: u32,
    /// Number of tool calls executed.
    pub tool_calls: u32,
    /// Files touched, workspace-relative, deduplicated.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub files_changed: Vec<String>,
}

/// Payload of [`Event::TurnFailed`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TurnFailed {
    /// The turn.
    pub turn_id: TurnId,
    /// Stable error code (`E2xxx`, …).
    pub code: String,
    /// One-line message.
    pub message: String,
    /// What the user should do next (§10.6: every error has a next action).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remediation: Option<String>,
    /// True when a retry might succeed.
    #[serde(default)]
    pub retryable: bool,
    /// Verbose detail, only populated when `--verbose`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub detail: Option<Value>,
}

/// Payload of [`Event::TurnCancelled`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TurnCancelled {
    /// The turn.
    pub turn_id: TurnId,
    /// Who cancelled it.
    pub by: CancelledBy,
    /// Reason text for the audit log.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
    /// Partial assistant text produced before cancellation (never blanked —
    /// §9.3 `stream.rs` acceptance).
    #[serde(default)]
    pub partial_text: String,
    /// Child processes killed as part of the cancel tree.
    #[serde(default)]
    pub processes_killed: u32,
}

/// Who cancelled a turn.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CancelledBy {
    /// The user pressed Ctrl-C / Esc.
    User,
    /// A budget was exhausted.
    Budget,
    /// Loop detection fired.
    Limits,
    /// The parent turn of a subagent ended.
    Parent,
    /// The process is shutting down.
    Shutdown,
    /// The editor/IDE cancelled through ACP or JSON-RPC.
    Client,
}

// ── Content family ──────────────────────────────────────────────────────────

/// Payload of [`Event::TextDelta`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TextDelta {
    /// The turn.
    pub turn_id: TurnId,
    /// Index of the assistant message inside the turn.
    #[serde(default)]
    pub block: u32,
    /// The new text.
    pub text: String,
}

/// Payload of [`Event::ThinkingDelta`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ThinkingDelta {
    /// The turn.
    pub turn_id: TurnId,
    /// The new reasoning text.
    pub text: String,
    /// True when the provider refused to disclose the text.
    #[serde(default)]
    pub redacted: bool,
}

/// Payload of [`Event::TextCompleted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TextCompleted {
    /// The turn.
    pub turn_id: TurnId,
    /// Full assistant text for this block.
    pub text: String,
    /// Tool calls requested alongside the text, if any.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tool_calls: Vec<ToolCall>,
    /// Why the model stopped.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stop_reason: Option<crate::message::StopReason>,
}

/// Payload of [`Event::ContentReplaced`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ContentReplaced {
    /// Turn during which the replacement happened, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Index range in the transcript that was replaced.
    pub from_index: usize,
    /// End index (exclusive).
    pub to_index: usize,
    /// What replaced it.
    pub replacement: ContentPart,
    /// Tokens freed.
    pub tokens_freed: u32,
}

// ── Tools family ────────────────────────────────────────────────────────────

/// Payload of [`Event::ToolRequested`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolRequested {
    /// The turn.
    pub turn_id: TurnId,
    /// The call.
    pub call: ToolCall,
    /// Risk resolved by the registry.
    pub risk: RiskClass,
    /// Position in the model's batch, for order-preserving result merge.
    #[serde(default)]
    pub index: u32,
}

/// Payload of [`Event::ToolApprovalNeeded`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolApprovalNeeded {
    /// The turn.
    pub turn_id: TurnId,
    /// Everything the approval overlay needs (§3.2).
    #[serde(flatten)]
    pub request: PermissionRequest,
}

/// Payload of [`Event::ToolApprovalDecided`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolApprovalDecided {
    /// The turn.
    pub turn_id: TurnId,
    /// The request that was answered.
    pub request_id: RequestId,
    /// The call id it referred to.
    pub call_id: CallId,
    /// The decision.
    pub decision: Decision,
    /// Who decided: a human, a remembered grant, or the mode table.
    pub by: DecidedBy,
    /// Milliseconds the human took (metric `approval_latency_ms`).
    #[serde(default)]
    pub latency_ms: u64,
}

/// Who made an approval decision.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DecidedBy {
    /// The human at the keyboard.
    Human,
    /// A session grant remembered earlier.
    Remembered,
    /// The mode table auto-allowed it.
    Mode,
    /// A policy rule matched.
    Policy,
    /// A pre-tool hook returned a decision.
    Hook,
    /// Nobody answered before the timeout; default is deny.
    Timeout,
}

/// Payload of [`Event::ToolStarted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolStarted {
    /// The turn.
    pub turn_id: TurnId,
    /// The call.
    pub call_id: CallId,
    /// Tool name.
    pub name: String,
    /// Sandbox backend in force, if a process will run.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sandbox: Option<String>,
}

/// Payload of [`Event::ToolOutputDelta`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolOutputDelta {
    /// The turn.
    pub turn_id: TurnId,
    /// The call.
    pub call_id: CallId,
    /// ANSI-stripped chunk.
    pub text: String,
    /// True for stderr.
    #[serde(default)]
    pub stderr: bool,
}

/// Payload of [`Event::ToolCompleted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolCompleted {
    /// The turn.
    pub turn_id: TurnId,
    /// The shaped result.
    ///
    /// Deliberately *not* `#[serde(flatten)]`: `ToolResult` is an internally
    /// tagged enum, and serde cannot flatten an enum inside another
    /// internally tagged enum. Nesting it keeps the rollout line unambiguous
    /// (`result.status` rather than a `status` key colliding with event keys).
    pub result: ToolResult,
    /// Tool name (denormalised so the TUI does not need the call).
    pub name: String,
    /// Wall time.
    pub duration_ms: u64,
    /// Render hint for the tool card (§9.8 `render.rs`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub render: Option<crate::render_hint::RenderHint>,
}

/// Payload of [`Event::ToolFailed`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolFailed {
    /// The turn.
    pub turn_id: TurnId,
    /// The call.
    pub call_id: CallId,
    /// Tool name.
    pub name: String,
    /// Typed error.
    pub error: ToolError,
    /// Wall time.
    pub duration_ms: u64,
}

/// Payload of [`Event::ToolDenied`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolDenied {
    /// The turn.
    pub turn_id: TurnId,
    /// The call.
    pub call_id: CallId,
    /// Tool name.
    pub name: String,
    /// Which layer refused.
    pub by: DeniedBy,
    /// `policy::explain()` output.
    pub reason: String,
}

// ── Context family ──────────────────────────────────────────────────────────

/// Payload of [`Event::ContextAssembled`]. **Sizes only** — never content,
/// because this event is emitted on every turn and goes to telemetry.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ContextAssembled {
    /// The turn.
    pub turn_id: TurnId,
    /// Tokens per section kind (§6.1.1 ledger).
    pub sections: Vec<SectionSize>,
    /// Total prompt tokens we expect to send.
    pub total_tokens: u32,
    /// Usable window for this model.
    pub window: u32,
    /// Fraction of the window used, 0..=1.
    pub pressure: f32,
    /// Whether a cache breakpoint was placed and where.
    #[serde(default)]
    pub cache_boundary_index: Option<usize>,
    /// Estimated tokens of the cache-stable prefix.
    #[serde(default)]
    pub cached_prefix_tokens: u32,
}

/// One section of the assembled prompt and its token cost.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct SectionSize {
    /// Section kind label (bounded set, §10.7).
    pub kind: crate::context_types::SectionKind,
    /// Estimated tokens.
    pub tokens: u32,
}

/// Payload of [`Event::CompactStarted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CompactStarted {
    /// Turn that triggered compaction, if inside one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Why: pressure threshold, manual `/compact`, or provider overflow.
    pub trigger: CompactTrigger,
    /// Tokens before compaction.
    pub before_tokens: u32,
    /// Target after compaction.
    pub target_tokens: u32,
    /// Optional user focus hint.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub focus: Option<String>,
}

/// Why compaction ran.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CompactTrigger {
    /// Pre-flight pressure watermark (§9.6 `pressure.rs`).
    Pressure,
    /// The user asked (`/compact`).
    Manual,
    /// The provider rejected the request as too long.
    Overflow,
    /// A new session fork inherited a large history.
    Fork,
}

/// Payload of [`Event::CompactStage`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CompactStage {
    /// Turn, if inside one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Ladder stage that ran (§6.1.2).
    pub stage: crate::context_types::CompactStage,
    /// Tokens before this stage.
    pub before_tokens: u32,
    /// Tokens after this stage.
    pub after_tokens: u32,
    /// True when this stage got us under the target and the ladder stopped.
    #[serde(default)]
    pub sufficient: bool,
}

/// Payload of [`Event::CompactCompleted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CompactCompleted {
    /// Turn, if inside one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Tokens before.
    pub before_tokens: u32,
    /// Tokens after.
    pub after_tokens: u32,
    /// Stages that ran, in order.
    pub stages: Vec<crate::context_types::CompactStage>,
    /// True when a model call was needed (stage 4).
    #[serde(default)]
    pub used_model: bool,
    /// Wall time.
    pub duration_ms: u64,
    /// Summary text injected into the new prefix, if stage 4 ran.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub summary: Option<String>,
}

/// Payload of [`Event::MemoryLoaded`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MemoryLoaded {
    /// Memory files found, in precedence order (§6.1.4).
    pub files: Vec<MemoryFile>,
    /// Total tokens after caps and dedupe.
    pub tokens: u32,
    /// Files skipped because they exceeded their cap.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub truncated: Vec<String>,
}

/// One memory file that was loaded.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MemoryFile {
    /// Which layer of the hierarchy (§6.1.4).
    pub layer: crate::context_types::MemoryLayer,
    /// Absolute path.
    pub path: String,
    /// Bytes loaded after cap.
    pub bytes: usize,
    /// Estimated tokens.
    pub tokens: u32,
}

// ── Workers family ──────────────────────────────────────────────────────────

/// Payload of [`Event::WorkerSpawned`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkerSpawned {
    /// The run.
    pub run_id: RunId,
    /// The worker.
    pub worker_id: WorkerId,
    /// DAG node id.
    pub node_id: String,
    /// Node kind.
    pub kind: NodeKind,
    /// Goal, for the board card.
    pub goal: String,
    /// Isolation level granted.
    pub isolation: crate::plan::IsolationLevel,
    /// Worktree path, if one was created.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub worktree: Option<String>,
    /// Model the worker is bound to.
    pub model: ModelId,
    /// Token budget.
    pub budget_tokens: u64,
}

/// Payload of [`Event::WorkerProgress`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkerProgress {
    /// The run.
    pub run_id: RunId,
    /// The worker.
    pub worker_id: WorkerId,
    /// Current lifecycle state.
    pub state: crate::worker::WorkerState,
    /// Progress 0..=100.
    pub percent: u8,
    /// Tokens used so far.
    pub tokens: u64,
    /// Cost so far, USD micros.
    pub cost_micros: u64,
    /// One-line status for the board.
    #[serde(default)]
    pub note: String,
}

/// Payload of [`Event::WorkerReported`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkerReported {
    /// The run.
    pub run_id: RunId,
    /// The worker.
    pub worker_id: WorkerId,
    /// The structured report (§7.8).
    pub report: crate::worker::WorkerReport,
}

/// Payload of [`Event::WorkerCancelled`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkerCancelled {
    /// The run.
    pub run_id: RunId,
    /// The worker.
    pub worker_id: WorkerId,
    /// Why.
    pub reason: String,
    /// True when the lease was revoked because the worker stalled (§7.6).
    #[serde(default)]
    pub stalled: bool,
}

/// Payload of [`Event::MergeQueued`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MergeQueued {
    /// The run.
    pub run_id: RunId,
    /// The worker whose branch is queued.
    pub worker_id: WorkerId,
    /// DAG node id.
    pub node_id: String,
    /// Position in the queue.
    pub position: usize,
}

/// Payload of [`Event::MergeCompleted`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MergeCompleted {
    /// The run.
    pub run_id: RunId,
    /// The worker.
    pub worker_id: WorkerId,
    /// DAG node id.
    pub node_id: String,
    /// Outcome.
    pub outcome: MergeOutcome,
    /// Conflicting paths, when the outcome is `Conflict`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub conflicts: Vec<String>,
    /// Files merged.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub files: Vec<String>,
}

/// Outcome of a merge-queue step (§7.9).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MergeOutcome {
    /// Fast-forward or clean 3-way merge.
    Merged,
    /// Conflict; the worker gets one retry.
    Conflict,
    /// The merge was reverted after a verify-gate failure.
    Reverted,
    /// The node was quarantined after two failures.
    Quarantined,
    /// Nothing to merge (worker produced no changes).
    Empty,
}

/// Payload of [`Event::VerifyResult`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct VerifyResult {
    /// The run, when verifying a worker merge.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub run_id: Option<RunId>,
    /// Turn, when verifying inside a normal turn (§9.4 `verify.rs`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Command that was run.
    pub command: String,
    /// Verdict.
    pub verdict: VerifyVerdict,
    /// Exit code.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub exit_code: Option<i32>,
    /// Wall time.
    pub duration_ms: u64,
    /// Tail of the output, capped and ANSI-stripped.
    #[serde(default)]
    pub evidence: String,
}

/// Verdict of a verification gate.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VerifyVerdict {
    /// Everything passed.
    Pass,
    /// Tests/lint failed.
    Fail,
    /// The command itself could not run (missing binary, timeout).
    InfraError,
    /// No verification command could be detected.
    Skipped,
}

// ── System family ───────────────────────────────────────────────────────────

/// Payload of [`Event::UsageUpdated`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct UsageUpdated {
    /// The turn.
    pub turn_id: TurnId,
    /// Delta for this model call.
    pub delta: Usage,
    /// Session total after the delta.
    pub total: Usage,
    /// Model that produced it.
    pub model: ModelId,
}

/// Payload of [`Event::CostUpdated`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CostUpdated {
    /// The turn.
    pub turn_id: TurnId,
    /// Session cost so far, USD micros.
    pub cost_micros: u64,
    /// Budget cap in micros, if configured.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub budget_micros: Option<u64>,
    /// Cache hit ratio 0..=1.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cache_hit_ratio: Option<f64>,
}

/// Severity of a [`Event::Warning`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Severity {
    /// Informational; shown in the debug overlay only.
    Info,
    /// Worth a toast.
    Warn,
    /// Shown as a persistent banner.
    Error,
    /// Process-level; usually followed by a shutdown.
    Critical,
}

/// Payload of [`Event::Warning`]. Golden rule #11: every degradation is loud.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Warning {
    /// Severity.
    pub severity: Severity,
    /// Stable code for filtering (`sandbox.unavailable`, `cache.miss.storm`, …).
    pub code: String,
    /// Human message.
    pub message: String,
    /// What to do about it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remediation: Option<String>,
    /// Turn context, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
}

/// Payload of [`Event::Error`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ErrorEvent {
    /// Stable code (§10.6).
    pub code: String,
    /// One-line message.
    pub message: String,
    /// Next action for the user.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remediation: Option<String>,
    /// Verbose detail when `--verbose`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub detail: Option<Value>,
    /// Turn context, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Process exit code this error maps to (§3.7).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub exit_code: Option<u8>,
}

/// Payload of [`Event::ConfigChanged`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ConfigChanged {
    /// Dotted keys that changed.
    pub keys: Vec<String>,
    /// Where the new values came from (§9.4 `config/layers.rs`).
    #[serde(default)]
    pub source: String,
    /// True when the change needs a restart to take effect.
    #[serde(default)]
    pub requires_restart: bool,
}

/// Payload of [`Event::SessionResumed`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SessionResumed {
    /// Thread that was resumed.
    pub thread_id: ThreadId,
    /// Rollout file the events came from.
    pub rollout_path: String,
    /// Number of events replayed.
    pub events_replayed: u64,
    /// Drift detected against the recorded environment (§6.5 rule 5).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub drift: Vec<DriftWarning>,
    /// Turns reconstructed.
    pub turns: u32,
    /// True when an incomplete turn was marked interrupted (§9.11
    /// `turns_repo.rs`).
    #[serde(default)]
    pub reconciled_incomplete_turn: bool,
}

/// A difference between the recorded session environment and now.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DriftWarning {
    /// What drifted (`cwd`, `git_head`, `model`, `config`).
    pub kind: String,
    /// Value recorded in the rollout.
    pub recorded: String,
    /// Value observed now.
    pub current: String,
}

/// An event this build does not understand.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct UnknownEvent {
    /// The original `type` discriminator.
    pub name: String,
    /// Full raw payload.
    pub payload: Value,
}

/// A parallel plan as broadcast to clients. Kept here (not in `plan.rs`) so
/// the worker/run event payloads can reference it without a cycle.
pub type BroadcastPlan = TaskPlan;

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ids::ThreadId;

    fn env(event: Event) -> EventEnvelope {
        EventEnvelope::new(ThreadId::new(), 1, event)
    }

    #[test]
    fn every_event_has_a_family_and_a_kind() {
        let samples = sample_events();
        assert!(samples.len() >= 35, "catalogue shrank: {}", samples.len());
        for (name, e) in &samples {
            let _ = e.family();
            assert!(!e.kind().is_empty(), "{name}");
        }
    }

    #[test]
    fn kind_matches_the_serde_tag_for_every_event() {
        for (name, e) in sample_events() {
            let v = serde_json::to_value(&e).unwrap();
            let tag = v["type"].as_str().unwrap_or_default();
            if let Event::Unknown(_) = e {
                continue; // arbitrary name by construction
            }
            assert_eq!(tag, e.kind(), "{name}: tag {tag} != kind {}", e.kind());
        }
    }

    #[test]
    fn envelopes_carry_the_required_header_fields() {
        let e = env(Event::Warning(Warning {
            severity: Severity::Warn,
            code: "sandbox.unavailable".into(),
            message: "no backend".into(),
            remediation: Some("install bubblewrap".into()),
            turn_id: None,
        }));
        let v = serde_json::to_value(&e).unwrap();
        for f in ["id", "thread", "ts", "seq", "v", "type"] {
            assert!(v.get(f).is_some(), "missing {f} in {v}");
        }
        assert_eq!(v["v"], EVENT_SCHEMA_VERSION);
        // `ts` is ISO-8601 on the wire (§10.5).
        assert!(chrono::DateTime::parse_from_rfc3339(v["ts"].as_str().unwrap()).is_ok());
        // `thread`/`turn`, not `thread_id`/`turn_id`, so the flattened payload
        // keeps its own `turn_id`.
        assert!(v.get("thread_id").is_none(), "{v}");
    }

    #[test]
    fn rollout_lines_are_checksummed_and_verifiable() {
        let e = env(Event::TurnStarted(TurnStarted {
            turn_id: TurnId::new(),
            model: ModelId::new("mock", "scripted"),
            mode: Mode::Ask,
            prompt: "hello".into(),
            budget_tokens: 100,
            session_usage: Usage::zero(),
        }));
        let line = e.to_rollout_line().unwrap();
        assert!(line.contains("\"checksum\":\"blake3:"), "{line}");
        assert!(EventEnvelope::verify_rollout_line(&line).unwrap());

        // Flip one bit in the payload and the checksum must fail.
        let tampered = line.replacen("hello", "hellp", 1);
        assert!(!EventEnvelope::verify_rollout_line(&tampered).unwrap());
    }

    #[test]
    fn rollout_lines_roundtrip() {
        let e = env(Event::ToolCompleted(ToolCompleted {
            turn_id: TurnId::new(),
            result: ToolResult::ok_text(CallId::new(), "read 3 lines", "a\nb\nc"),
            name: "read_file".into(),
            duration_ms: 4,
            render: None,
        }));
        let line = e.to_rollout_line().unwrap();
        let back = EventEnvelope::from_rollout_line(&line).unwrap();
        assert_eq!(back.event.kind(), "tool_completed");
        assert_eq!(back.thread_id, e.thread_id);
        assert_eq!(back.seq, e.seq);
    }

    #[test]
    fn unknown_events_are_preserved_not_rejected() {
        let line = serde_json::json!({
            "id": EventId::new().to_string(),
            "thread_id": ThreadId::new().to_string(),
            "ts_ms": 1, "seq": 7, "schema_version": 99,
            "type": "quantum_entangled",
            "qubit": 3,
        })
        .to_string();
        let e = EventEnvelope::from_rollout_line(&line).unwrap();
        match &e.event {
            Event::Unknown(u) => {
                assert_eq!(u.name, "quantum_entangled");
                assert_eq!(u.payload["qubit"], 3);
            }
            other => panic!("expected Unknown, got {other:?}"),
        }
        assert_eq!(e.seq, 7);
    }

    #[test]
    fn deltas_are_transient_and_not_persisted() {
        let e = Event::TextDelta(TextDelta { turn_id: TurnId::new(), block: 0, text: "x".into() });
        assert_eq!(e.durability(), Durability::Transient);
        let w = Event::WorkerProgress(WorkerProgress {
            run_id: RunId::new(),
            worker_id: WorkerId::new(),
            state: crate::worker::WorkerState::Running,
            percent: 10,
            tokens: 0,
            cost_micros: 0,
            note: String::new(),
        });
        assert_eq!(w.durability(), Durability::RolloutOnly);
        let c = Event::TurnCompleted(TurnCompleted {
            turn_id: TurnId::new(),
            outcome: TurnOutcome::Completed,
            final_text: String::new(),
            usage: Usage::zero(),
            session_usage: Usage::zero(),
            duration_ms: 1,
            ttft_ms: None,
            model_calls: 1,
            tool_calls: 0,
            files_changed: vec![],
        });
        assert_eq!(c.durability(), Durability::Durable);
    }

    #[test]
    fn exit_codes_match_the_published_contract() {
        assert_eq!(TurnOutcome::Completed.exit_code(), 0);
        assert_eq!(TurnOutcome::BudgetStop.exit_code(), 53);
        assert_eq!(TurnOutcome::Cancelled.exit_code(), 130);
        assert_eq!(TurnOutcome::Failed.exit_code(), 1);
    }

    #[test]
    fn terminal_states_are_exactly_three() {
        let terminal: Vec<_> = [
            TurnState::Idle, TurnState::Assembling, TurnState::Streaming, TurnState::Approving,
            TurnState::Executing, TurnState::Compacting, TurnState::Verifying, TurnState::Retrying,
            TurnState::Done, TurnState::Cancelled, TurnState::Failed,
        ]
        .into_iter()
        .filter(|s| s.is_terminal())
        .collect();
        assert_eq!(terminal.len(), 3);
    }

    #[test]
    fn context_assembled_carries_sizes_only() {
        let e = Event::ContextAssembled(ContextAssembled {
            turn_id: TurnId::new(),
            sections: vec![SectionSize {
                kind: crate::context_types::SectionKind::SystemCore,
                tokens: 1200,
            }],
            total_tokens: 1200,
            window: 200_000,
            pressure: 0.006,
            cache_boundary_index: Some(1),
            cached_prefix_tokens: 1200,
        });
        let s = serde_json::to_string(&e).unwrap();
        assert!(s.len() < 500, "context events must stay tiny: {s}");
    }

    /// One instance of every variant, so the tests above actually cover the
    /// whole catalogue. Adding a variant without adding it here fails
    /// `every_event_has_a_family_and_a_kind`.
    fn sample_events() -> Vec<(&'static str, Event)> {
        let tid = TurnId::new();
        let cid = CallId::new();
        let rid = RequestId::new();
        let run = RunId::new();
        let wid = WorkerId::new();
        let call = ToolCall::new(cid, "shell", serde_json::json!({"command": "ls"}), RiskClass::Exec);
        let req = PermissionRequest {
            request_id: rid,
            tool: "shell".into(),
            risk: RiskClass::Exec,
            args_preview: "command=ls".into(),
            args: serde_json::json!({"command": "ls"}),
            paths: vec![],
            cwd: Some("/repo".into()),
            rule_hint: None,
            sandbox: crate::permission::SandboxStatus::NotApplicable,
            scope: crate::permission::RequestScope::Once,
            remember_pattern: None,
            raised_at_ms: 0,
        };
        vec![
            ("turn_started", Event::TurnStarted(TurnStarted {
                turn_id: tid, model: ModelId::new("mock", "m"), mode: Mode::Ask,
                prompt: "p".into(), budget_tokens: 1, session_usage: Usage::zero(),
            })),
            ("state_changed", Event::StateChanged(StateChanged {
                turn_id: tid, from: TurnState::Idle, to: TurnState::Streaming, reason: None,
            })),
            ("turn_completed", Event::TurnCompleted(TurnCompleted {
                turn_id: tid, outcome: TurnOutcome::Completed, final_text: String::new(),
                usage: Usage::zero(), session_usage: Usage::zero(), duration_ms: 1,
                ttft_ms: None, model_calls: 1, tool_calls: 0, files_changed: vec![],
            })),
            ("turn_failed", Event::TurnFailed(TurnFailed {
                turn_id: tid, code: "E2001".into(), message: "m".into(),
                remediation: None, retryable: true, detail: None,
            })),
            ("turn_cancelled", Event::TurnCancelled(TurnCancelled {
                turn_id: tid, by: CancelledBy::User, reason: None,
                partial_text: String::new(), processes_killed: 0,
            })),
            ("text_delta", Event::TextDelta(TextDelta { turn_id: tid, block: 0, text: "x".into() })),
            ("thinking_delta", Event::ThinkingDelta(ThinkingDelta {
                turn_id: tid, text: "x".into(), redacted: false,
            })),
            ("text_completed", Event::TextCompleted(TextCompleted {
                turn_id: tid, text: "x".into(), tool_calls: vec![], stop_reason: None,
            })),
            ("content_replaced", Event::ContentReplaced(ContentReplaced {
                turn_id: None, from_index: 0, to_index: 1,
                replacement: ContentPart::Compacted { summary: "s".into(), pointer: None, tokens_freed: 1 },
                tokens_freed: 1,
            })),
            ("tool_requested", Event::ToolRequested(ToolRequested {
                turn_id: tid, call: call.clone(), risk: RiskClass::Exec, index: 0,
            })),
            ("tool_approval_needed", Event::ToolApprovalNeeded(ToolApprovalNeeded {
                turn_id: tid, request: req,
            })),
            ("tool_approval_decided", Event::ToolApprovalDecided(ToolApprovalDecided {
                turn_id: tid, request_id: rid, call_id: cid, decision: Decision::Allow,
                by: DecidedBy::Human, latency_ms: 1,
            })),
            ("tool_started", Event::ToolStarted(ToolStarted {
                turn_id: tid, call_id: cid, name: "shell".into(), sandbox: None,
            })),
            ("tool_output_delta", Event::ToolOutputDelta(ToolOutputDelta {
                turn_id: tid, call_id: cid, text: "x".into(), stderr: false,
            })),
            ("tool_completed", Event::ToolCompleted(ToolCompleted {
                turn_id: tid, result: ToolResult::ok_text(cid, "s", "t"),
                name: "shell".into(), duration_ms: 1, render: None,
            })),
            ("tool_failed", Event::ToolFailed(ToolFailed {
                turn_id: tid, call_id: cid, name: "shell".into(),
                error: ToolError::new(crate::tool::ToolErrorKind::Timeout, "t"), duration_ms: 1,
            })),
            ("tool_denied", Event::ToolDenied(ToolDenied {
                turn_id: tid, call_id: cid, name: "shell".into(), by: DeniedBy::Policy,
                reason: "r".into(),
            })),
            ("context_assembled", Event::ContextAssembled(ContextAssembled {
                turn_id: tid, sections: vec![], total_tokens: 0, window: 1,
                pressure: 0.0, cache_boundary_index: None, cached_prefix_tokens: 0,
            })),
            ("compact_started", Event::CompactStarted(CompactStarted {
                turn_id: None, trigger: CompactTrigger::Pressure, before_tokens: 1,
                target_tokens: 1, focus: None,
            })),
            ("compact_stage", Event::CompactStage(CompactStage {
                turn_id: None, stage: crate::context_types::CompactStage::Snip,
                before_tokens: 2, after_tokens: 1, sufficient: false,
            })),
            ("compact_completed", Event::CompactCompleted(CompactCompleted {
                turn_id: None, before_tokens: 2, after_tokens: 1, stages: vec![],
                used_model: false, duration_ms: 1, summary: None,
            })),
            ("memory_loaded", Event::MemoryLoaded(MemoryLoaded {
                files: vec![], tokens: 0, truncated: vec![],
            })),
            ("worker_spawned", Event::WorkerSpawned(WorkerSpawned {
                run_id: run, worker_id: wid, node_id: "n1".into(), kind: NodeKind::Implement,
                goal: "g".into(), isolation: crate::plan::IsolationLevel::default(),
                worktree: None, model: ModelId::new("mock", "m"), budget_tokens: 1,
            })),
            ("worker_progress", Event::WorkerProgress(WorkerProgress {
                run_id: run, worker_id: wid, state: crate::worker::WorkerState::Running,
                percent: 1, tokens: 0, cost_micros: 0, note: String::new(),
            })),
            ("worker_reported", Event::WorkerReported(WorkerReported {
                run_id: run, worker_id: wid,
                report: crate::worker::WorkerReport::done("n1", "s"),
            })),
            ("worker_cancelled", Event::WorkerCancelled(WorkerCancelled {
                run_id: run, worker_id: wid, reason: "r".into(), stalled: false,
            })),
            ("merge_queued", Event::MergeQueued(MergeQueued {
                run_id: run, worker_id: wid, node_id: "n1".into(), position: 0,
            })),
            ("merge_completed", Event::MergeCompleted(MergeCompleted {
                run_id: run, worker_id: wid, node_id: "n1".into(),
                outcome: MergeOutcome::Merged, conflicts: vec![], files: vec![],
            })),
            ("verify_result", Event::VerifyResult(VerifyResult {
                run_id: None, turn_id: None, command: "cargo test".into(),
                verdict: VerifyVerdict::Pass, exit_code: Some(0), duration_ms: 1,
                evidence: String::new(),
            })),
            ("usage_updated", Event::UsageUpdated(UsageUpdated {
                turn_id: tid, delta: Usage::zero(), total: Usage::zero(),
                model: ModelId::new("mock", "m"),
            })),
            ("cost_updated", Event::CostUpdated(CostUpdated {
                turn_id: tid, cost_micros: 0, budget_micros: None, cache_hit_ratio: None,
            })),
            ("warning", Event::Warning(Warning {
                severity: Severity::Warn, code: "c".into(), message: "m".into(),
                remediation: None, turn_id: None,
            })),
            ("error", Event::Error(ErrorEvent {
                code: "E1001".into(), message: "m".into(), remediation: None,
                detail: None, turn_id: None, exit_code: Some(1),
            })),
            ("config_changed", Event::ConfigChanged(ConfigChanged {
                keys: vec!["model.name".into()], source: "user".into(), requires_restart: false,
            })),
            ("session_resumed", Event::SessionResumed(SessionResumed {
                thread_id: ThreadId::new(), rollout_path: "a.jsonl".into(),
                events_replayed: 1, drift: vec![], turns: 1,
                reconciled_incomplete_turn: false,
            })),
            ("unknown", Event::Unknown(UnknownEvent {
                name: "x".into(), payload: Value::Null,
            })),
        ]
    }
}
