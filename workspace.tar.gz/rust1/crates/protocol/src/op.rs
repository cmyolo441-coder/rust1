//! Operation catalogue: client → agent (`rustplan.txt` §9.1 `src/op.rs`, §10.1).
//!
//! An [`Op`] is the *only* way a surface (TUI, CLI, JSON-RPC app-server, ACP,
//! SDK) may ask the agent to do something. Ops are cheap, `Send + Sync`,
//! serialisable, and every one of them is either idempotent (replaying it is
//! harmless) or explicitly marked non-idempotent so that a resume path can
//! decide whether it is safe to re-drive.
//!
//! Forward compatibility rule (§10.2): clients and servers must tolerate ops
//! they do not understand. [`Op::Unknown`] captures the raw JSON so an older
//! agent can log-and-ignore instead of hard-failing a newer client.

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::ids::{OpId, RequestId, RunId, ThreadId, TurnId};
use crate::permission::Decision;
use crate::plan::TaskPlan;
use crate::{Mode, ModelId};

/// An operation submitted by a client to an agent thread actor.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "op", rename_all = "snake_case")]
pub enum Op {
    /// Start a new turn from a user prompt.
    Submit(SubmitOp),
    /// Inject user text into an in-flight turn at the next tool boundary.
    Steer(SteerOp),
    /// Cancel an in-flight turn (kills the whole cancel tree).
    Interrupt(InterruptOp),
    /// Answer a pending permission request.
    Approve(ApproveOp),
    /// Shorthand for `Approve { decision: Deny }`.
    Deny(DenyOp),
    /// Request compaction of the context window.
    Compact(CompactOp),
    /// Switch permission mode (audited).
    SetMode(SetModeOp),
    /// Switch the bound model mid-session (audited).
    SetModel(SetModelOp),
    /// Start a parallel subagent run from a validated task DAG.
    SpawnWorkers(SpawnWorkersOp),
    /// Kill switch for a parallel run, optionally one worker only.
    CancelWorkers(CancelWorkersOp),
    /// Persist state and stop the thread actor.
    Shutdown(ShutdownOp),
    /// An op this build does not understand. Preserved verbatim so it can be
    /// logged, echoed back, and ignored without breaking the connection.
    Unknown(UnknownOp),
}

impl Op {
    /// `true` when re-delivering this op after a crash/replay is harmless.
    ///
    /// `Submit`, `Steer`, `Approve` and `SpawnWorkers` mutate the world or the
    /// transcript and are therefore *not* idempotent; the rest are.
    #[must_use]
    pub const fn is_idempotent(&self) -> bool {
        !matches!(
            self,
            Op::Submit(_) | Op::Steer(_) | Op::Approve(_) | Op::Deny(_) | Op::SpawnWorkers(_)
        )
    }

    /// Stable name used in metrics labels and audit entries. Bounded set —
    /// never contains user data (§10.7 cardinality rule).
    #[must_use]
    pub const fn kind(&self) -> &'static str {
        match self {
            Op::Submit(_) => "submit",
            Op::Steer(_) => "steer",
            Op::Interrupt(_) => "interrupt",
            Op::Approve(_) => "approve",
            Op::Deny(_) => "deny",
            Op::Compact(_) => "compact",
            Op::SetMode(_) => "set_mode",
            Op::SetModel(_) => "set_model",
            Op::SpawnWorkers(_) => "spawn_workers",
            Op::CancelWorkers(_) => "cancel_workers",
            Op::Shutdown(_) => "shutdown",
            Op::Unknown(_) => "unknown",
        }
    }

    /// The thread this op targets, when the op carries one.
    #[must_use]
    pub fn thread_id(&self) -> Option<ThreadId> {
        match self {
            Op::Submit(o) => o.thread_id,
            Op::Steer(o) => Some(o.thread_id),
            Op::Interrupt(o) => Some(o.thread_id),
            Op::Approve(o) => Some(o.thread_id),
            Op::Deny(o) => Some(o.thread_id),
            Op::Compact(o) => Some(o.thread_id),
            Op::SetMode(o) => Some(o.thread_id),
            Op::SetModel(o) => Some(o.thread_id),
            Op::SpawnWorkers(o) => Some(o.thread_id),
            Op::CancelWorkers(o) => Some(o.thread_id),
            Op::Shutdown(o) => o.thread_id,
            Op::Unknown(_) => None,
        }
    }

    /// Envelope this op in a freshly minted [`OpEnvelope`].
    #[must_use]
    pub fn envelope(self) -> OpEnvelope {
        OpEnvelope::new(self)
    }
}

/// An op plus the routing/audit metadata every transport needs.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct OpEnvelope {
    /// Client-chosen id; the agent de-duplicates on it so a retried `Submit`
    /// cannot start two turns.
    pub id: OpId,
    /// Protocol version the client speaks (see [`crate::version_neg`]).
    pub protocol_version: u32,
    /// Milliseconds since unix epoch at the sender.
    pub sent_at_ms: u64,
    /// The operation itself.
    #[serde(flatten)]
    pub op: Op,
}

impl OpEnvelope {
    /// Wrap `op` with a fresh id and the current protocol version.
    #[must_use]
    pub fn new(op: Op) -> Self {
        Self {
            id: OpId::new(),
            protocol_version: crate::PROTOCOL_VERSION,
            sent_at_ms: crate::now_ms(),
            op,
        }
    }

    /// Parse a transport frame. Unknown op names degrade to [`Op::Unknown`]
    /// rather than failing, which is what makes the wire forward compatible.
    ///
    /// # Errors
    /// Only when the frame is not a JSON object at all.
    pub fn from_json(value: Value) -> Result<Self, serde_json::Error> {
        match serde_json::from_value::<Self>(value.clone()) {
            Ok(env) => Ok(env),
            Err(_) => {
                let name = value.get("op").and_then(Value::as_str).unwrap_or("<missing>");
                Ok(Self {
                    id: OpId::new(),
                    protocol_version: value
                        .get("protocol_version")
                        .and_then(Value::as_u64)
                        .map_or(crate::PROTOCOL_VERSION, |v| v as u32),
                    sent_at_ms: crate::now_ms(),
                    op: Op::Unknown(UnknownOp { name: name.to_owned(), payload: value }),
                })
            }
        }
    }
}

/// Payload for [`Op::Submit`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SubmitOp {
    /// Target thread; `None` means "the caller's current thread" and is
    /// resolved by the `ThreadManager`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub thread_id: Option<ThreadId>,
    /// The user prompt, verbatim (no client-side rewriting).
    pub prompt: String,
    /// Explicit `@file` / `@url` / image attachments resolved by the client.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub attachments: Vec<AttachmentRef>,
    /// Optional per-turn mode override (does *not* change the session mode).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mode: Option<Mode>,
    /// Optional per-turn model override.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<ModelId>,
    /// Free-form metadata echoed back on `TurnStarted` (e.g. CI job id).
    #[serde(default, skip_serializing_if = "serde_json::Value::is_null")]
    pub meta: Value,
}

impl SubmitOp {
    /// Minimal constructor.
    #[must_use]
    pub fn new(prompt: impl Into<String>) -> Self {
        Self {
            thread_id: None,
            prompt: prompt.into(),
            attachments: Vec::new(),
            mode: None,
            model: None,
            meta: Value::Null,
        }
    }

    /// Builder: attach a reference.
    #[must_use]
    pub fn with_attachment(mut self, a: AttachmentRef) -> Self {
        self.attachments.push(a);
        self
    }

    /// Builder: override mode for this turn only.
    #[must_use]
    pub fn with_mode(mut self, m: Mode) -> Self {
        self.mode = Some(m);
        self
    }
}

/// A client-resolved reference to out-of-band content.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum AttachmentRef {
    /// A file path inside the workspace (read lazily by the context engine).
    File {
        /// Workspace-relative or absolute path as typed by the user.
        path: String,
        /// Optional line window (`start` inclusive, `end` exclusive).
        #[serde(default, skip_serializing_if = "Option::is_none")]
        lines: Option<(usize, usize)>,
    },
    /// A directory to summarise via the repo map.
    Dir {
        /// Path as typed by the user.
        path: String,
    },
    /// A remote URL, fetched through `web_fetch` (SSRF-guarded).
    Url {
        /// Absolute URL.
        url: String,
    },
    /// An image already materialised into the blob store.
    Image {
        /// Blob store id.
        blob: String,
        /// MIME type, e.g. `image/png`.
        media_type: String,
    },
    /// A pasted blob that was too large for the prompt buffer.
    Paste {
        /// Blob store id.
        blob: String,
        /// Byte length of the original paste.
        bytes: u64,
    },
}

/// Payload for [`Op::Steer`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SteerOp {
    /// Thread that owns the turn.
    pub thread_id: ThreadId,
    /// Turn to steer; the agent ignores the op if the turn already finished.
    pub turn_id: TurnId,
    /// Text to inject at the next tool boundary.
    pub text: String,
    /// Interrupt priority: `High` injects before the *next* tool call even if
    /// one is already executing its approval step; `Normal` waits for a
    /// natural boundary.
    #[serde(default)]
    pub priority: SteerPriority,
}

impl SteerOp {
    /// Minimal constructor.
    #[must_use]
    pub fn new(thread_id: ThreadId, turn_id: TurnId, text: impl Into<String>) -> Self {
        Self { thread_id, turn_id, text: text.into(), priority: SteerPriority::Normal }
    }
}

/// How urgently a steering message should be injected.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SteerPriority {
    /// Wait for the next natural tool boundary.
    #[default]
    Normal,
    /// Jump the queue ahead of pending approvals.
    High,
}

/// Payload for [`Op::Interrupt`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InterruptOp {
    /// Thread that owns the turn.
    pub thread_id: ThreadId,
    /// Turn to cancel. `None` cancels whatever is currently running.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Reason surfaced in the audit log and the `TurnCancelled` event.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
}

impl InterruptOp {
    /// Minimal constructor.
    #[must_use]
    pub fn new(thread_id: ThreadId) -> Self {
        Self { thread_id, turn_id: None, reason: None }
    }
}

/// Payload for [`Op::Approve`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ApproveOp {
    /// Thread awaiting the decision.
    pub thread_id: ThreadId,
    /// Single-use request id from `Event::ToolApprovalNeeded`.
    pub request_id: RequestId,
    /// The decision itself.
    pub decision: Decision,
    /// If set, remember the decision for this session under the given pattern.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remember: Option<RememberScope>,
}

/// How long a remembered grant should live.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RememberScope {
    /// Until the thread exits.
    ThisTurn,
    /// Until the session ends (default for "always allow").
    ThisSession,
    /// Persisted to config until explicitly revoked.
    Persistent,
}

impl Default for RememberScope {
    fn default() -> Self {
        Self::ThisSession
    }
}

/// Payload for [`Op::Deny`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DenyOp {
    /// Thread awaiting the decision.
    pub thread_id: ThreadId,
    /// Single-use request id.
    pub request_id: RequestId,
    /// Optional human reason fed back to the model so it can course-correct.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
}

/// Payload for [`Op::Compact`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CompactOp {
    /// Thread to compact.
    pub thread_id: ThreadId,
    /// Turn whose window should be compacted; `None` = the latest.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub turn_id: Option<TurnId>,
    /// Optional focus hint handed to the summariser prompt.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub focus: Option<String>,
    /// Skip the cheap ladder stages and go straight to model summarisation.
    #[serde(default)]
    pub force_summarize: bool,
}

/// Payload for [`Op::SetMode`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SetModeOp {
    /// Thread to reconfigure.
    pub thread_id: ThreadId,
    /// New permission mode.
    pub mode: Mode,
}

/// Payload for [`Op::SetModel`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SetModelOp {
    /// Thread to reconfigure.
    pub thread_id: ThreadId,
    /// New model binding (`provider/model`).
    pub model: ModelId,
}

/// Payload for [`Op::SpawnWorkers`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SpawnWorkersOp {
    /// Owning thread (the parent turn awaits the run).
    pub thread_id: ThreadId,
    /// Client-supplied run id so retries cannot double-spawn.
    pub run_id: RunId,
    /// The validated task DAG (§7.3).
    pub plan: TaskPlan,
}

/// Payload for [`Op::CancelWorkers`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CancelWorkersOp {
    /// Owning thread.
    pub thread_id: ThreadId,
    /// Run to cancel.
    pub run_id: RunId,
    /// Restrict cancellation to one worker.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub worker_id: Option<crate::ids::WorkerId>,
    /// Reason for the audit log.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
}

/// Payload for [`Op::Shutdown`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ShutdownOp {
    /// `None` shuts down every thread in the process.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub thread_id: Option<ThreadId>,
    /// Flush the JSONL rollout and SQLite index before exiting.
    #[serde(default = "default_true")]
    pub flush: bool,
    /// Milliseconds to wait for in-flight turns before force-killing.
    #[serde(default = "default_grace_ms")]
    pub grace_ms: u64,
}

impl Default for ShutdownOp {
    fn default() -> Self {
        Self { thread_id: None, flush: true, grace_ms: default_grace_ms() }
    }
}

/// An op this build could not decode; kept so newer clients degrade safely.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct UnknownOp {
    /// The `op` discriminator string that was not recognised.
    pub name: String,
    /// The full raw payload.
    pub payload: Value,
}

const fn default_true() -> bool {
    true
}
const fn default_grace_ms() -> u64 {
    2_000
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ids::ThreadId;

    #[test]
    fn submit_serialises_with_a_stable_discriminator() {
        let op = Op::Submit(SubmitOp::new("fix the login bug"));
        let json = serde_json::to_value(&op).unwrap();
        assert_eq!(json["op"], "submit");
        assert_eq!(json["prompt"], "fix the login bug");
        // Optional fields must not appear when empty (cache-stable prefix).
        assert!(json.get("attachments").is_none(), "{json}");
    }

    #[test]
    fn every_op_roundtrips_through_json() {
        let tid = ThreadId::new();
        let ops = vec![
            Op::Submit(SubmitOp::new("hi")),
            Op::Interrupt(InterruptOp::new(tid)),
            Op::SetMode(SetModeOp { thread_id: tid, mode: Mode::Plan }),
            Op::Shutdown(ShutdownOp::default()),
        ];
        for op in ops {
            let v = serde_json::to_value(&op).unwrap();
            let back: Op = serde_json::from_value(v).unwrap();
            assert_eq!(op, back);
        }
    }

    #[test]
    fn unknown_op_is_preserved_not_rejected() {
        let frame = serde_json::json!({
            "op": "summon_daemon",
            "id": OpId::new().to_string(),
            "protocol_version": 999,
            "sent_at_ms": 1,
            "sigil": "xyz",
        });
        let env = OpEnvelope::from_json(frame).unwrap();
        match env.op {
            Op::Unknown(u) => {
                assert_eq!(u.name, "summon_daemon");
                assert_eq!(u.payload["sigil"], "xyz");
            }
            other => panic!("expected Unknown, got {other:?}"),
        }
        assert_eq!(env.protocol_version, 999);
    }

    #[test]
    fn idempotency_is_declared_per_op() {
        assert!(!Op::Submit(SubmitOp::new("x")).is_idempotent());
        assert!(Op::SetMode(SetModeOp { thread_id: ThreadId::new(), mode: Mode::Ask }).is_idempotent());
        assert!(Op::Shutdown(ShutdownOp::default()).is_idempotent());
    }

    #[test]
    fn op_kind_labels_are_a_bounded_set() {
        let kinds = [
            Op::Submit(SubmitOp::new("x")).kind(),
            Op::Interrupt(InterruptOp::new(ThreadId::new())).kind(),
            Op::Unknown(UnknownOp { name: "a".into(), payload: Value::Null }).kind(),
        ];
        assert!(kinds.contains(&"submit"));
        assert!(kinds.contains(&"interrupt"));
        assert!(kinds.contains(&"unknown"));
    }
}
