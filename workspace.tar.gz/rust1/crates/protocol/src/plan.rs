//! Task DAG wire types for parallel subagents (`rustplan.txt` §7.3).
//!
//! The planner (an LLM) *proposes* this structure; the supervisor (pure Rust,
//! no LLM) *validates and schedules* it. Keeping the schema in `protocol`
//! means the CLI, the server, the orchestrator and the TUI board all agree on
//! one shape, and the JSON the model must emit is generated from the same
//! source of truth as the code that consumes it.
//!
//! Validation lives in `orchestrator/src/dag.rs`, but the *cheap, purely
//! structural* checks (unknown deps, self deps, empty ids, budget sanity) live
//! here so that every surface can reject a bad plan before it ever reaches the
//! scheduler.

use serde::{Deserialize, Serialize};

use crate::ids::{RunId, TaskId};
use crate::model::ModelTier;

/// What a DAG node is for. Drives priority in the scheduler (§7.5):
/// `verify > review > implement > test > explore`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NodeKind {
    /// Read-only investigation; safest and cheapest, lowest priority.
    Explore,
    /// Write code.
    Implement,
    /// Write or run tests.
    Test,
    /// Read-only critique of another node's output.
    Review,
    /// Documentation.
    Doc,
    /// Repair a failed acceptance gate.
    Fix,
    /// Run the verification commands for a merged change.
    Verify,
}

impl NodeKind {
    /// Scheduler priority class; higher runs first (§7.5).
    ///
    /// Verification never starves — if it did, a whole parallel run could be
    /// wasted on unverified merges.
    #[must_use]
    pub const fn priority(self) -> u8 {
        match self {
            NodeKind::Verify => 6,
            NodeKind::Review => 5,
            NodeKind::Implement => 4,
            NodeKind::Fix => 4,
            NodeKind::Test => 3,
            NodeKind::Doc => 2,
            NodeKind::Explore => 1,
        }
    }

    /// True when the node declares a write set and therefore needs a lease.
    #[must_use]
    pub const fn writes(self) -> bool {
        matches!(self, NodeKind::Implement | NodeKind::Test | NodeKind::Doc | NodeKind::Fix)
    }

    /// True when the node must have at least one acceptance command (§7.3
    /// validation rule 6).
    #[must_use]
    pub const fn requires_acceptance(self) -> bool {
        matches!(self, NodeKind::Implement | NodeKind::Fix | NodeKind::Test)
    }

    /// Stable label for metrics.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            NodeKind::Explore => "explore",
            NodeKind::Implement => "implement",
            NodeKind::Test => "test",
            NodeKind::Review => "review",
            NodeKind::Doc => "doc",
            NodeKind::Fix => "fix",
            NodeKind::Verify => "verify",
        }
    }
}

impl std::fmt::Display for NodeKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// One node of the task DAG.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TaskNode {
    /// Short, stable, human-readable id (`n1`, `n2`, …). Must be unique in the
    /// plan and must not contain whitespace.
    pub id: String,
    /// What kind of work this is.
    pub kind: NodeKind,
    /// One-paragraph goal handed to the worker verbatim (§7.7).
    pub goal: String,
    /// Glob patterns the worker is allowed to write. Expanded into leases.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub write_set: Vec<String>,
    /// Glob patterns the worker needs to read; used to build its context slice.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub read_set: Vec<String>,
    /// Ids of nodes that must complete first.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub deps: Vec<String>,
    /// Commands whose success defines "done".
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub acceptance: Vec<String>,
    /// Token budget for this node's worker.
    #[serde(default = "default_budget")]
    pub budget_tokens: u64,
    /// Which model tier the worker should use.
    #[serde(default)]
    pub model_tier: ModelTier,
    /// Isolation level requested (§7.4). The supervisor may *raise* it, never
    /// lower it.
    #[serde(default)]
    pub isolation: IsolationLevel,
    /// Server-assigned once the plan is materialised.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub task_id: Option<TaskId>,
}

const fn default_budget() -> u64 {
    60_000
}

/// Process/context isolation level (§7.4). Default is `L2`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum IsolationLevel {
    /// Shared workspace, read-only.
    L0ReadOnly,
    /// Shared workspace, leased writes.
    L1Leased,
    /// Dedicated git worktree (default).
    L2Worktree,
    /// Worktree inside a container/VM, no network.
    L3Container,
}

impl Default for IsolationLevel {
    fn default() -> Self {
        Self::L2Worktree
    }
}

impl IsolationLevel {
    /// True when the worker gets its own worktree.
    #[must_use]
    pub const fn uses_worktree(self) -> bool {
        matches!(self, Self::L2Worktree | Self::L3Container)
    }

    /// True when the worker may write to the shared workspace.
    #[must_use]
    pub const fn may_write_shared(self) -> bool {
        matches!(self, Self::L1Leased)
    }

    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::L0ReadOnly => "L0",
            Self::L1Leased => "L1",
            Self::L2Worktree => "L2",
            Self::L3Container => "L3",
        }
    }
}

/// A complete parallel plan as proposed by the planner.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TaskPlan {
    /// Overall goal; every worker prompt includes one paragraph of it.
    pub goal: String,
    /// The nodes.
    pub nodes: Vec<TaskNode>,
    /// Run id, assigned by the client or generated on materialisation.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub run_id: Option<RunId>,
    /// Free-form constraints applied to every worker (no network, no deps…).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub constraints: Vec<String>,
}

/// Why a plan was rejected. Each variant carries the offending node ids so the
/// planner's retry prompt can be specific (§7.3: invalid = 1 retry, then
/// serial fallback).
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum PlanError {
    /// The plan has no nodes.
    #[error("plan has no nodes")]
    Empty,
    /// Two nodes share an id.
    #[error("duplicate node id `{0}`")]
    DuplicateId(String),
    /// A node depends on itself.
    #[error("node `{0}` depends on itself")]
    SelfDependency(String),
    /// A dependency names a node that does not exist.
    #[error("node `{node}` depends on unknown node `{dep}`")]
    UnknownDependency {
        /// The node with the bad edge.
        node: String,
        /// The missing id.
        dep: String,
    },
    /// The graph contains a cycle.
    #[error("plan contains a cycle: {0}")]
    Cycle(String),
    /// More nodes than the hard cap.
    #[error("plan has {found} nodes, hard cap is {cap}; decompose the task further")]
    TooManyNodes {
        /// Nodes in the plan.
        found: usize,
        /// Configured hard cap.
        cap: usize,
    },
    /// A node that writes has no acceptance command.
    #[error("node `{0}` ({1}) must declare at least one acceptance command")]
    MissingAcceptance(String, NodeKind),
    /// The summed budgets exceed the run budget by more than the planning
    /// overhead allowance.
    #[error("node budgets sum to {sum} tokens but the run budget is {budget} (allowance x1.2)")]
    BudgetExceeded {
        /// Sum of node budgets.
        sum: u64,
        /// Run budget.
        budget: u64,
    },
    /// A node id is malformed.
    #[error("node id `{0}` is empty or contains whitespace")]
    BadId(String),
}

impl TaskPlan {
    /// Structural validation (§7.3 rules 1, 3, 6, 7 plus id hygiene).
    ///
    /// Deliberately does *not* touch the filesystem: path containment (rule 5)
    /// needs the workspace root and lives in the orchestrator next to
    /// `path_guard`.
    ///
    /// # Errors
    /// The first [`PlanError`] found. Deterministic order so retries get the
    /// same message.
    pub fn validate(&self, caps: PlanCaps) -> Result<(), PlanError> {
        if self.nodes.is_empty() {
            return Err(PlanError::Empty);
        }
        if self.nodes.len() > caps.max_nodes {
            return Err(PlanError::TooManyNodes { found: self.nodes.len(), cap: caps.max_nodes });
        }

        // Ids.
        let mut seen = std::collections::BTreeSet::new();
        for n in &self.nodes {
            if n.id.is_empty() || n.id.split_whitespace().count() != 1 || n.id.chars().any(char::is_whitespace) {
                return Err(PlanError::BadId(n.id.clone()));
            }
            if !seen.insert(n.id.clone()) {
                return Err(PlanError::DuplicateId(n.id.clone()));
            }
        }

        // Edges.
        for n in &self.nodes {
            for d in &n.deps {
                if d == &n.id {
                    return Err(PlanError::SelfDependency(n.id.clone()));
                }
                if !seen.contains(d) {
                    return Err(PlanError::UnknownDependency { node: n.id.clone(), dep: d.clone() });
                }
            }
        }

        // Cycles (Kahn).
        if let Some(cycle) = self.find_cycle() {
            return Err(PlanError::Cycle(cycle));
        }

        // Acceptance.
        for n in &self.nodes {
            if n.kind.requires_acceptance() && n.acceptance.is_empty() {
                return Err(PlanError::MissingAcceptance(n.id.clone(), n.kind));
            }
        }

        // Budget.
        if let Some(run_budget) = caps.run_budget_tokens {
            let sum: u64 = self.nodes.iter().map(|n| n.budget_tokens).sum();
            let allowance = run_budget.saturating_mul(12) / 10;
            if sum > allowance {
                return Err(PlanError::BudgetExceeded { sum, budget: run_budget });
            }
        }
        Ok(())
    }

    /// Detect a cycle and return the ids involved, in order.
    #[must_use]
    pub fn find_cycle(&self) -> Option<String> {
        use std::collections::HashMap;
        let idx: HashMap<&str, usize> =
            self.nodes.iter().enumerate().map(|(i, n)| (n.id.as_str(), i)).collect();
        let n = self.nodes.len();
        let mut adj: Vec<Vec<usize>> = vec![Vec::new(); n];
        for (i, node) in self.nodes.iter().enumerate() {
            for d in &node.deps {
                if let Some(&j) = idx.get(d.as_str()) {
                    // Edge dep -> node (dep must run first).
                    adj[j].push(i);
                }
            }
        }
        // 0 = unvisited, 1 = on stack, 2 = done
        let mut state = vec![0u8; n];
        let mut stack: Vec<usize> = Vec::new();
        let mut cycle: Option<Vec<usize>> = None;

        fn dfs(
            u: usize,
            adj: &[Vec<usize>],
            state: &mut [u8],
            stack: &mut Vec<usize>,
            cycle: &mut Option<Vec<usize>>,
        ) {
            if cycle.is_some() {
                return;
            }
            state[u] = 1;
            stack.push(u);
            for &v in &adj[u] {
                match state[v] {
                    1 => {
                        let pos = stack.iter().position(|&x| x == v).unwrap_or(0);
                        *cycle = Some(stack[pos..].to_vec());
                        return;
                    }
                    0 => dfs(v, adj, state, stack, cycle),
                    _ => {}
                }
            }
            stack.pop();
            state[u] = 2;
        }

        for i in 0..n {
            if state[i] == 0 {
                dfs(i, &adj, &mut state, &mut stack, &mut cycle);
                if cycle.is_some() {
                    break;
                }
            }
        }
        cycle.map(|nodes| {
            let mut parts: Vec<String> = nodes.iter().map(|&i| self.nodes[i].id.clone()).collect();
            if let Some(first) = parts.first().cloned() {
                parts.push(first);
            }
            parts.join(" -> ")
        })
    }

    /// Topological order, deterministic (ties broken by declaration order).
    ///
    /// Returns `None` when the graph has a cycle.
    #[must_use]
    pub fn topo_order(&self) -> Option<Vec<String>> {
        use std::collections::{BTreeMap, BTreeSet};
        let ids: BTreeSet<&str> = self.nodes.iter().map(|n| n.id.as_str()).collect();
        let mut indeg: BTreeMap<&str, usize> = BTreeMap::new();
        for n in &self.nodes {
            indeg.entry(n.id.as_str()).or_insert(0);
            for d in &n.deps {
                if ids.contains(d.as_str()) {
                    *indeg.entry(n.id.as_str()).or_insert(0) += 1;
                }
            }
        }
        // Declaration-order queue so the result is reproducible.
        let mut ready: Vec<&str> = self
            .nodes
            .iter()
            .map(|n| n.id.as_str())
            .filter(|id| indeg.get(*id).copied().unwrap_or(0) == 0)
            .collect();
        let mut out = Vec::with_capacity(self.nodes.len());
        while let Some(id) = ready.first().copied() {
            ready.remove(0);
            out.push(id.to_owned());
            for n in &self.nodes {
                if n.deps.iter().any(|d| d == id) {
                    if let Some(c) = indeg.get_mut(n.id.as_str()) {
                        *c -= 1;
                        if *c == 0 {
                            ready.push(n.id.as_str());
                        }
                    }
                }
            }
            ready.sort_by_key(|x| self.nodes.iter().position(|n| &n.id == *x).unwrap_or(usize::MAX));
        }
        (out.len() == self.nodes.len()).then_some(out)
    }

    /// Sum of all node token budgets.
    #[must_use]
    pub fn total_budget(&self) -> u64 {
        self.nodes.iter().map(|n| n.budget_tokens).sum()
    }

    /// Longest dependency chain length (used for the board's progress bar).
    #[must_use]
    pub fn depth(&self) -> usize {
        let mut memo = std::collections::HashMap::<&str, usize>::new();
        fn depth_of<'a>(
            id: &'a str,
            nodes: &'a [TaskNode],
            memo: &mut std::collections::HashMap<&'a str, usize>,
            visiting: &mut Vec<&'a str>,
        ) -> usize {
            if let Some(&d) = memo.get(id) {
                return d;
            }
            if visiting.contains(&id) {
                return 0; // cycle guard
            }
            visiting.push(id);
            let node = nodes.iter().find(|n| n.id == id);
            let d = match node {
                Some(n) if n.deps.is_empty() => 1,
                Some(n) => 1 + n.deps.iter().map(|dep| depth_of(dep, nodes, memo, visiting)).max().unwrap_or(0),
                None => 0,
            };
            visiting.pop();
            memo.insert(id, d);
            d
        }
        self.nodes
            .iter()
            .map(|n| depth_of(&n.id, &self.nodes, &mut memo, &mut Vec::new()))
            .max()
            .unwrap_or(0)
    }
}

/// Limits applied when validating a plan.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PlanCaps {
    /// Maximum number of nodes (hard cap, §7.3 rule 3: default 6, hard 12).
    pub max_nodes: usize,
    /// Run-level token budget, if one is configured (rule 7).
    pub run_budget_tokens: Option<u64>,
}

impl Default for PlanCaps {
    fn default() -> Self {
        Self { max_nodes: 12, run_budget_tokens: None }
    }
}

/// The JSON Schema the planner model is given, generated from these types so
/// it can never drift (§9.1 `schema_export.rs`).
#[must_use]
pub fn planner_json_schema() -> serde_json::Value {
    serde_json::json!({
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "TaskPlan",
        "type": "object",
        "additionalProperties": false,
        "required": ["goal", "nodes"],
        "properties": {
            "goal": {"type": "string", "minLength": 1, "description": "One-sentence overall objective."},
            "constraints": {"type": "array", "items": {"type": "string"}},
            "nodes": {
                "type": "array", "minItems": 1, "maxItems": 12,
                "items": {
                    "type": "object",
                    "additionalProperties": false,
                    "required": ["id", "kind", "goal"],
                    "properties": {
                        "id": {"type": "string", "pattern": "^[a-zA-Z0-9_-]+$"},
                        "kind": {"enum": ["explore","implement","test","review","doc","fix","verify"]},
                        "goal": {"type": "string", "minLength": 1},
                        "write_set": {"type": "array", "items": {"type": "string"}},
                        "read_set": {"type": "array", "items": {"type": "string"}},
                        "deps": {"type": "array", "items": {"type": "string"}},
                        "acceptance": {"type": "array", "items": {"type": "string"}},
                        "budget_tokens": {"type": "integer", "minimum": 1000},
                        "model_tier": {"enum": ["cheap","balanced","strong"]},
                        "isolation": {"enum": ["l0_read_only","l1_leased","l2_worktree","l3_container"]}
                    }
                }
            }
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn node(id: &str, kind: NodeKind, deps: &[&str]) -> TaskNode {
        TaskNode {
            id: id.into(),
            kind,
            goal: format!("goal for {id}"),
            write_set: vec![],
            read_set: vec![],
            deps: deps.iter().map(|s| s.to_string()).collect(),
            acceptance: if kind.requires_acceptance() { vec!["cargo test".into()] } else { vec![] },
            budget_tokens: 10_000,
            model_tier: ModelTier::Balanced,
            isolation: IsolationLevel::default(),
            task_id: None,
        }
    }

    fn plan(nodes: Vec<TaskNode>) -> TaskPlan {
        TaskPlan { goal: "g".into(), nodes, run_id: None, constraints: vec![] }
    }

    #[test]
    fn a_valid_dag_passes() {
        let p = plan(vec![
            node("n1", NodeKind::Implement, &[]),
            node("n2", NodeKind::Test, &["n1"]),
            node("n3", NodeKind::Review, &["n1", "n2"]),
        ]);
        assert!(p.validate(PlanCaps::default()).is_ok());
    }

    #[test]
    fn empty_plan_is_rejected() {
        assert_eq!(plan(vec![]).validate(PlanCaps::default()), Err(PlanError::Empty));
    }

    #[test]
    fn duplicate_ids_are_rejected() {
        let p = plan(vec![node("n1", NodeKind::Explore, &[]), node("n1", NodeKind::Explore, &[])]);
        assert!(matches!(p.validate(PlanCaps::default()), Err(PlanError::DuplicateId(_))));
    }

    #[test]
    fn self_dependency_is_rejected() {
        let p = plan(vec![node("n1", NodeKind::Explore, &["n1"])]);
        assert!(matches!(p.validate(PlanCaps::default()), Err(PlanError::SelfDependency(_))));
    }

    #[test]
    fn unknown_dependency_is_rejected_with_both_ids() {
        let p = plan(vec![node("n1", NodeKind::Explore, &["nope"])]);
        match p.validate(PlanCaps::default()) {
            Err(PlanError::UnknownDependency { node, dep }) => {
                assert_eq!(node, "n1");
                assert_eq!(dep, "nope");
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn cycles_are_detected_and_named() {
        let p = plan(vec![
            node("a", NodeKind::Explore, &["c"]),
            node("b", NodeKind::Explore, &["a"]),
            node("c", NodeKind::Explore, &["b"]),
        ]);
        let err = p.validate(PlanCaps::default()).unwrap_err();
        match err {
            PlanError::Cycle(c) => assert!(c.contains("->"), "{c}"),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn node_cap_is_enforced() {
        let nodes: Vec<_> = (0..13).map(|i| node(&format!("n{i}"), NodeKind::Explore, &[])).collect();
        let err = plan(nodes).validate(PlanCaps::default()).unwrap_err();
        assert!(matches!(err, PlanError::TooManyNodes { found: 13, cap: 12 }));
    }

    #[test]
    fn writing_nodes_need_acceptance() {
        let mut n = node("n1", NodeKind::Implement, &[]);
        n.acceptance.clear();
        let err = plan(vec![n]).validate(PlanCaps::default()).unwrap_err();
        assert!(matches!(err, PlanError::MissingAcceptance(_, NodeKind::Implement)));
    }

    #[test]
    fn budget_allowance_is_twenty_percent() {
        let nodes = vec![node("a", NodeKind::Explore, &[]), node("b", NodeKind::Explore, &[])];
        let p = plan(nodes);
        // Each node defaults to 10k here; total 20k.
        let caps = PlanCaps { max_nodes: 12, run_budget_tokens: Some(15_000) };
        assert!(matches!(p.validate(caps), Err(PlanError::BudgetExceeded { .. })));
        let caps = PlanCaps { max_nodes: 12, run_budget_tokens: Some(17_000) };
        assert!(p.validate(caps).is_ok(), "17k * 1.2 = 20.4k >= 20k");
    }

    #[test]
    fn bad_ids_are_rejected() {
        let p = plan(vec![node("has space", NodeKind::Explore, &[])]);
        assert!(matches!(p.validate(PlanCaps::default()), Err(PlanError::BadId(_))));
    }

    #[test]
    fn topo_order_respects_dependencies_and_is_deterministic() {
        let p = plan(vec![
            node("c", NodeKind::Review, &["a", "b"]),
            node("a", NodeKind::Implement, &[]),
            node("b", NodeKind::Test, &["a"]),
        ]);
        let o1 = p.topo_order().unwrap();
        let o2 = p.topo_order().unwrap();
        assert_eq!(o1, o2);
        assert_eq!(o1.first().map(String::as_str), Some("a"));
        assert_eq!(o1.last().map(String::as_str), Some("c"));
        assert!(o1.iter().position(|x| x == "b") < o1.iter().position(|x| x == "c"));
    }

    #[test]
    fn topo_order_is_none_for_a_cycle() {
        let p = plan(vec![node("a", NodeKind::Explore, &["b"]), node("b", NodeKind::Explore, &["a"])]);
        assert!(p.topo_order().is_none());
    }

    #[test]
    fn depth_counts_the_longest_chain() {
        let p = plan(vec![
            node("a", NodeKind::Explore, &[]),
            node("b", NodeKind::Explore, &["a"]),
            node("c", NodeKind::Explore, &["b"]),
            node("d", NodeKind::Explore, &["a"]),
        ]);
        assert_eq!(p.depth(), 3);
    }

    #[test]
    fn priority_puts_verification_first() {
        assert!(NodeKind::Verify.priority() > NodeKind::Review.priority());
        assert!(NodeKind::Review.priority() > NodeKind::Implement.priority());
        assert!(NodeKind::Implement.priority() > NodeKind::Test.priority());
        assert!(NodeKind::Test.priority() > NodeKind::Explore.priority());
    }

    #[test]
    fn isolation_defaults_to_worktree() {
        assert_eq!(IsolationLevel::default(), IsolationLevel::L2Worktree);
        assert!(IsolationLevel::default().uses_worktree());
        assert!(!IsolationLevel::L0ReadOnly.uses_worktree());
    }

    #[test]
    fn planner_schema_is_valid_json_and_covers_every_kind() {
        let s = planner_json_schema();
        let kinds = s["properties"]["nodes"]["items"]["properties"]["kind"]["enum"].as_array().unwrap();
        for k in [
            NodeKind::Explore, NodeKind::Implement, NodeKind::Test, NodeKind::Review,
            NodeKind::Doc, NodeKind::Fix, NodeKind::Verify,
        ] {
            assert!(kinds.iter().any(|v| v.as_str() == Some(k.as_str())), "missing {:?}", k);
        }
    }
}
