//! Grapheme-safe truncation with informative markers
//! (`rustplan.txt` §9.4 `core/src/util/truncate.rs`, golden rule #7).
//!
//! Truncation is the single most common source of "the agent got dumber"
//! reports, because a model that does not know it is looking at a fragment
//! keeps reasoning as if it had the whole file. Every function here therefore
//! returns *both* the truncated text and a machine-usable marker describing
//! exactly what was dropped, and never splits a UTF-8 sequence or a grapheme
//! cluster (emoji, CJK, combining marks).
//!
//! The implementation lives in `protocol` rather than `core` because `tools`,
//! `context` and `tui` all need identical behaviour and must not depend on
//! each other to get it.

use serde::{Deserialize, Serialize};
use unicode_segmentation::UnicodeSegmentation;
use unicode_width::UnicodeWidthStr;

/// Result of a truncation operation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Truncated {
    /// The text that survived.
    pub text: String,
    /// True when anything was removed.
    pub truncated: bool,
    /// Human readable hint appended to tool output, e.g.
    /// `… [truncated: showing 2000 of 4312 lines]`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hint: Option<String>,
}

impl Truncated {
    /// Untruncated passthrough.
    #[must_use]
    pub fn whole(text: impl Into<String>) -> Self {
        Self { text: text.into(), truncated: false, hint: None }
    }
}

/// Truncate `text` to at most `max_bytes` bytes, cutting on a char boundary
/// and appending an ellipsis marker.
///
/// # Panics
/// Never. Invalid or oversized inputs degrade to an empty string plus hint.
#[must_use]
pub fn by_bytes(text: &str, max_bytes: usize) -> Truncated {
    const MARKER: &str = "…";
    if text.len() <= max_bytes {
        return Truncated::whole(text);
    }
    let budget = max_bytes.saturating_sub(MARKER.len());
    let cut = floor_char_boundary(text, budget);
    let mut out = String::with_capacity(cut + MARKER.len() + 32);
    out.push_str(&text[..cut]);
    out.push_str(MARKER);
    Truncated {
        text: out,
        truncated: true,
        hint: Some(format!("truncated to {max_bytes} bytes (original {})", text.len())),
    }
}

/// Keep the first `head` and last `tail` bytes, joined by an explicit elision
/// marker that states how much was dropped. This is the shape used for shell
/// output (§6.2.3: `tail_bias`, exit code never truncated).
#[must_use]
pub fn head_tail(text: &str, head: usize, tail: usize) -> String {
    if text.len() <= head.saturating_add(tail) {
        return text.to_owned();
    }
    let h = floor_char_boundary(text, head);
    let t = ceil_char_boundary(text, text.len().saturating_sub(tail));
    let dropped = t.saturating_sub(h);
    let mut out = String::with_capacity(h + (text.len() - t) + 64);
    out.push_str(&text[..h]);
    let _ = std::fmt::Write::write_fmt(
        &mut out,
        format_args!("\n… [{dropped} bytes elided] …\n"),
    );
    out.push_str(&text[t..]);
    out
}

/// Truncate by line count, keeping the first `max_lines`.
///
/// The hint follows the exact wording required by golden rule #7 so that the
/// model knows which `offset` to request next.
#[must_use]
pub fn lines(text: &str, max_lines: usize, total_hint: Option<usize>) -> Truncated {
    let total = total_hint.unwrap_or_else(|| text.lines().count());
    if total <= max_lines {
        return Truncated::whole(text);
    }
    let kept: Vec<&str> = text.lines().take(max_lines).collect();
    let body = kept.join("\n");
    Truncated {
        text: body,
        truncated: true,
        hint: Some(format!("showing lines 1-{max_lines} of {total}; use offset={max_lines}")),
    }
}

/// Truncate by line count keeping the *last* `max_lines` (tail bias), which
/// is what build logs and test runners want.
#[must_use]
pub fn tail_lines(text: &str, max_lines: usize) -> Truncated {
    let total = text.lines().count();
    if total <= max_lines {
        return Truncated::whole(text);
    }
    let skip = total - max_lines;
    let body: Vec<&str> = text.lines().skip(skip).collect();
    Truncated {
        text: body.join("\n"),
        truncated: true,
        hint: Some(format!("showing last {max_lines} of {total} lines")),
    }
}

/// Truncate to a display width (terminal columns), grapheme aware.
///
/// Wide characters (CJK, emoji) count as 2 columns; a combining mark counts as
/// 0. This is what the TUI needs to keep tables aligned.
#[must_use]
pub fn display_width(text: &str, max_cols: usize) -> Truncated {
    if text.width() <= max_cols {
        return Truncated::whole(text);
    }
    let mut out = String::new();
    let mut used = 0usize;
    // Reserve one column for the ellipsis.
    let budget = max_cols.saturating_sub(1);
    for g in text.graphemes(true) {
        let w = g.width();
        if used + w > budget {
            break;
        }
        out.push_str(g);
        used += w;
    }
    out.push('…');
    Truncated {
        text: out,
        truncated: true,
        hint: Some(format!("clipped to {max_cols} columns")),
    }
}

/// Count grapheme clusters, not chars and not bytes.
#[must_use]
pub fn grapheme_len(text: &str) -> usize {
    text.graphemes(true).count()
}

/// Largest `i <= limit` such that `text[..i]` is a char boundary.
#[must_use]
pub fn floor_char_boundary(text: &str, limit: usize) -> usize {
    if limit >= text.len() {
        return text.len();
    }
    let mut i = limit;
    while i > 0 && !text.is_char_boundary(i) {
        i -= 1;
    }
    i
}

/// Smallest `i >= limit` such that `text[..i]` is a char boundary.
#[must_use]
pub fn ceil_char_boundary(text: &str, limit: usize) -> usize {
    if limit >= text.len() {
        return text.len();
    }
    let mut i = limit;
    while i < text.len() && !text.is_char_boundary(i) {
        i += 1;
    }
    i
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn short_text_is_passed_through_untouched() {
        let t = by_bytes("hello", 100);
        assert!(!t.truncated);
        assert_eq!(t.text, "hello");
        assert!(t.hint.is_none());
    }

    #[test]
    fn byte_truncation_never_splits_utf8() {
        // 'é' is 2 bytes, 'あ' is 3, '🙂' is 4.
        for s in ["aéあ🙂b", "🙂🙂🙂🙂🙂", "日本語テキスト"] {
            for limit in 0..s.len() + 3 {
                let t = by_bytes(s, limit);
                assert!(t.text.is_char_boundary(t.text.len()), "bad boundary for {s} @ {limit}");
                assert!(t.text.chars().count() > 0 || limit == 0);
            }
        }
    }

    #[test]
    fn head_tail_reports_how_much_was_dropped() {
        let s = "a".repeat(100) + &"b".repeat(100);
        let out = head_tail(&s, 20, 20);
        assert!(out.starts_with("aaaa"));
        assert!(out.ends_with("bbbb"));
        assert!(out.contains("160 bytes elided"), "{out}");
        assert!(out.len() < s.len());
    }

    #[test]
    fn head_tail_is_a_noop_for_small_input() {
        assert_eq!(head_tail("short", 100, 100), "short");
    }

    #[test]
    fn line_truncation_hint_names_the_next_offset() {
        let s = (0..50).map(|i| format!("line {i}")).collect::<Vec<_>>().join("\n");
        let t = lines(&s, 10, None);
        assert!(t.truncated);
        assert_eq!(t.text.lines().count(), 10);
        assert_eq!(t.hint.as_deref(), Some("showing lines 1-10 of 50; use offset=10"));
    }

    #[test]
    fn tail_lines_keeps_the_end() {
        let s = (0..50).map(|i| format!("line {i}")).collect::<Vec<_>>().join("\n");
        let t = tail_lines(&s, 5);
        assert_eq!(t.text.lines().next(), Some("line 45"));
        assert_eq!(t.text.lines().count(), 5);
    }

    #[test]
    fn display_width_counts_cjk_as_two_columns() {
        assert_eq!("あ".width(), 2);
        let t = display_width("日本語のテキストです", 8);
        assert!(t.truncated);
        assert!(t.text.width() <= 8, "got {} cols", t.text.width());
    }

    #[test]
    fn grapheme_len_counts_emoji_with_skin_tone_as_one() {
        // Family emoji is a single grapheme cluster made of several code points.
        let family = "👨‍👩‍👧‍👦";
        assert_eq!(family.chars().count(), 7);
        assert_eq!(grapheme_len(family), 1);
    }

    #[test]
    fn char_boundary_helpers_are_safe_on_edges() {
        let s = "aあb";
        assert_eq!(floor_char_boundary(s, 0), 0);
        assert_eq!(floor_char_boundary(s, 2), 1);
        assert_eq!(floor_char_boundary(s, 100), s.len());
        assert_eq!(ceil_char_boundary(s, 2), 4);
        assert_eq!(ceil_char_boundary(s, 100), s.len());
    }
}
