//! Tool invocation contracts (`rustplan.txt` §9.1 `src/tool.rs`, §10.3).
//!
//! Three types carry the whole capability surface across the wire:
//! * [`ToolCall`]   — what the model asked for, with raw JSON arguments.
//! * [`ToolResult`] — what came back, already shaped for the next turn.
//! * [`ToolError`]  — a *model-actionable* failure. The golden rule is that a
//!   raw `io::Error` must never reach the model: it has no next step. Every
//!   error here carries a `hint` telling the model what to do differently.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::content::ContentPart;
use crate::ids::CallId;

/// Risk classification of a tool invocation, used by policy, the approval UX
/// and the parallel-tool router (§6.2.4).
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RiskClass {
    /// Reads only; safe to run in parallel and to auto-approve in `ask` mode.
    Read,
    /// Mutates in-workspace state (files, plan).
    Mutate,
    /// Mutates state outside the workspace or irreversibly (delete, move).
    Destructive,
    /// Executes an arbitrary process.
    Exec,
    /// Reaches the network.
    Network,
    /// Spawns another agent.
    Spawn,
    /// Talks to the user (`ask_user`); never auto-approved, never denied.
    Meta,
}

impl RiskClass {
    /// True when two calls of this class may run concurrently.
    ///
    /// Only [`RiskClass::Read`] and [`RiskClass::Meta`] qualify: everything
    /// else is serialised by `core/tools/router.rs` so that two edits to the
    /// same file can never interleave.
    #[must_use]
    pub const fn parallel_eligible(self) -> bool {
        matches!(self, Self::Read | Self::Meta)
    }

    /// True when `ask` mode should prompt the human before running.
    #[must_use]
    pub const fn prompts_in_ask_mode(self) -> bool {
        !matches!(self, Self::Read | Self::Meta)
    }

    /// Badge text for the approval overlay (§3.2).
    #[must_use]
    pub const fn badge(self) -> &'static str {
        match self {
            Self::Read => "read",
            Self::Mutate => "mutate",
            Self::Destructive => "destructive",
            Self::Exec => "exec",
            Self::Network => "network",
            Self::Spawn => "spawn",
            Self::Meta => "meta",
        }
    }
}

impl std::fmt::Display for RiskClass {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.badge())
    }
}

/// A tool invocation requested by the model.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolCall {
    /// Correlates the call with its result; provider-assigned when available.
    pub id: CallId,
    /// Tool name as registered (MCP tools are prefixed `mcp__server__tool`).
    pub name: String,
    /// Arguments exactly as the model produced them. Parsing/validation is a
    /// separate step so that a malformed-args error can be reported back with
    /// the raw text intact (§6.3.2 rule 3).
    #[serde(default = "default_args")]
    pub args: Value,
    /// Risk class resolved from the registry at parse time. Denormalised into
    /// the call so the policy engine does not need registry access.
    #[serde(default = "default_risk")]
    pub risk: RiskClass,
    /// Index within the turn, for order-preserving result merge.
    #[serde(default)]
    pub index: u32,
}

fn default_args() -> Value {
    Value::Object(serde_json::Map::new())
}
const fn default_risk() -> RiskClass {
    RiskClass::Read
}

impl ToolCall {
    /// Build a call with an object payload.
    #[must_use]
    pub fn new(id: CallId, name: impl Into<String>, args: Value, risk: RiskClass) -> Self {
        Self { id, name: name.into(), args, risk, index: 0 }
    }

    /// A short, redaction-safe preview of the arguments for approval prompts
    /// and audit entries. Bounded to 200 characters and single-line.
    #[must_use]
    pub fn args_preview(&self) -> String {
        let flat = match &self.args {
            Value::Object(map) => map
                .iter()
                .map(|(k, v)| {
                    let vs = match v {
                        Value::String(s) => s.clone(),
                        other => other.to_string(),
                    };
                    let vs = vs.replace('\n', "\\n");
                    let vs = crate::truncate::by_bytes(&vs, 60).text;
                    format!("{k}={vs}")
                })
                .collect::<Vec<_>>()
                .join(" "),
            other => other.to_string(),
        };
        crate::truncate::by_bytes(&flat, 200).text
    }

    /// Look up a string argument.
    #[must_use]
    pub fn arg_str(&self, key: &str) -> Option<&str> {
        self.args.get(key).and_then(Value::as_str)
    }

    /// Look up an integer argument with a default.
    #[must_use]
    pub fn arg_u64(&self, key: &str, default: u64) -> u64 {
        self.args.get(key).and_then(Value::as_u64).unwrap_or(default)
    }

    /// Look up a boolean argument with a default.
    #[must_use]
    pub fn arg_bool(&self, key: &str, default: bool) -> bool {
        self.args.get(key).and_then(Value::as_bool).unwrap_or(default)
    }

    /// Canonical hash of `(name, args)` used for loop detection
    /// (`core/agent/limits.rs`) and for the `tool_calls.args_hash` column.
    #[must_use]
    pub fn args_hash(&self) -> String {
        let canonical = canonical_json(&self.args);
        let mut h = blake3::Hasher::new();
        h.update(self.name.as_bytes());
        h.update(b"\0");
        h.update(canonical.as_bytes());
        h.update(b"\0");
        h.update(self.risk.badge().as_bytes());
        let digest = h.finalize();
        hex::encode(&digest.as_bytes()[..8])
    }
}

/// Deterministic JSON serialisation (sorted keys, no whitespace) so that
/// hashes are stable across map insertion orders.
#[must_use]
pub fn canonical_json(v: &Value) -> String {
    match v {
        Value::Object(map) => {
            let mut keys: Vec<&String> = map.keys().collect();
            keys.sort();
            let parts: Vec<String> =
                keys.iter().map(|k| format!("{}:{}", json_str(k), canonical_json(&map[*k]))).collect();
            format!("{{{}}}", parts.join(","))
        }
        Value::Array(items) => {
            let parts: Vec<String> = items.iter().map(canonical_json).collect();
            format!("[{}]", parts.join(","))
        }
        other => other.to_string(),
    }
}

fn json_str(s: &str) -> String {
    serde_json::to_string(s).unwrap_or_else(|_| format!("\"{s}\""))
}

mod hex {
    const DIGITS: &[u8; 16] = b"0123456789abcdef";
    pub fn encode(bytes: &[u8]) -> String {
        let mut s = String::with_capacity(bytes.len() * 2);
        for b in bytes {
            s.push(DIGITS[(b >> 4) as usize] as char);
            s.push(DIGITS[(b & 0x0f) as usize] as char);
        }
        s
    }
}

/// Outcome of a tool execution.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "status", rename_all = "snake_case")]
pub enum ToolResult {
    /// Success. `parts` is already shaped by `core/tools/result_policy.rs`.
    Ok {
        /// The call this result answers.
        call_id: CallId,
        /// Content blocks returned to the model.
        parts: Vec<ContentPart>,
        /// One-line summary for the collapsed tool card (§9.12
        /// `render/tool_card.rs`).
        summary: String,
        /// Structured extras the TUI can render without understanding the
        /// tool (kind, duration, cost).
        #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
        meta: BTreeMap<String, Value>,
        /// True when the result was truncated; the hint lives in the parts.
        #[serde(default)]
        truncated: bool,
        /// Wall time in milliseconds.
        #[serde(default)]
        duration_ms: u64,
    },
    /// Failure the model can act on.
    Err {
        /// The call this result answers.
        call_id: CallId,
        /// Typed error with a next-step hint.
        error: ToolError,
    },
    /// The call was never executed because policy or the user refused.
    Denied {
        /// The call this result answers.
        call_id: CallId,
        /// Human/model readable explanation from `policy::explain()`.
        reason: String,
        /// Which layer refused (policy, user, sandbox, budget).
        by: DeniedBy,
    },
}

/// Which layer refused a tool call.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DeniedBy {
    /// A deny rule matched.
    Policy,
    /// The human said no (or the mode forbids it).
    User,
    /// The OS sandbox could not be applied (fail-closed, golden rule #6).
    Sandbox,
    /// A budget or loop-detection limit was hit.
    Budget,
    /// A pre-tool hook returned "block".
    Hook,
}

impl ToolResult {
    /// Build a plain-text success result.
    #[must_use]
    pub fn ok_text(call_id: CallId, summary: impl Into<String>, text: impl Into<String>) -> Self {
        let text = text.into();
        let summary = summary.into();
        Self::Ok {
            call_id,
            parts: vec![ContentPart::text(text)],
            summary,
            meta: BTreeMap::new(),
            truncated: false,
            duration_ms: 0,
        }
    }

    /// Build a failure result.
    #[must_use]
    pub fn err(call_id: CallId, error: ToolError) -> Self {
        Self::Err { call_id, error }
    }

    /// Build a denial result.
    #[must_use]
    pub fn denied(call_id: CallId, by: DeniedBy, reason: impl Into<String>) -> Self {
        Self::Denied { call_id, by, reason: reason.into() }
    }

    /// True for [`ToolResult::Ok`].
    #[must_use]
    pub const fn is_ok(&self) -> bool {
        matches!(self, Self::Ok { .. })
    }

    /// Flatten the result into the single string a provider adapter needs.
    #[must_use]
    pub fn model_visible_text(&self) -> String {
        match self {
            Self::Ok { parts, .. } => parts
                .iter()
                .filter_map(|p| match p {
                    ContentPart::Text { text } => Some(text.as_str()),
                    ContentPart::Terminal(t) => Some(t.stripped.as_str()),
                    _ => None,
                })
                .collect::<Vec<_>>()
                .join("\n"),
            Self::Err { error, .. } => error.to_model_string(),
            Self::Denied { reason, by, .. } => format!("denied by {}: {reason}", by.as_str()),
        }
    }
}

impl DeniedBy {
    /// Stable label for metrics and audit.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Policy => "policy",
            Self::User => "user",
            Self::Sandbox => "sandbox",
            Self::Budget => "budget",
            Self::Hook => "hook",
        }
    }
}

/// Kind of tool failure. The taxonomy is deliberately coarse: it drives retry
/// decisions (`retryable`) and the model's next step (`hint`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ToolErrorKind {
    /// Arguments did not match the schema.
    InvalidArgs,
    /// Path escaped the workspace or was outside a granted root.
    PathDenied,
    /// File/dir does not exist.
    NotFound,
    /// File/dir already exists when it must not.
    AlreadyExists,
    /// Search/replace anchor did not match, or matched ambiguously.
    PatchMismatch,
    /// The process was killed by its deadline.
    Timeout,
    /// The process returned a non-zero exit code.
    NonZeroExit,
    /// A permission rule refused the call.
    PermissionDenied,
    /// The sandbox was unavailable or refused (fail-closed).
    SandboxUnavailable,
    /// Network unreachable, blocked by the egress allowlist, or SSRF-guarded.
    NetworkBlocked,
    /// Resource limit hit (memory, pids, output bytes).
    ResourceLimit,
    /// Budget/loop limit hit.
    BudgetExhausted,
    /// An internal bug; surfaced as `E3xxx` with a support hint.
    Internal,
    /// The tool is not enabled in this mode.
    ToolDisabled,
}

impl ToolErrorKind {
    /// Stable numeric code within the `E3xxx` tool family (§10.6).
    #[must_use]
    pub const fn code(self) -> u16 {
        match self {
            Self::InvalidArgs => 3001,
            Self::PathDenied => 3002,
            Self::NotFound => 3003,
            Self::AlreadyExists => 3004,
            Self::PatchMismatch => 3005,
            Self::Timeout => 3006,
            Self::NonZeroExit => 3007,
            Self::PermissionDenied => 3008,
            Self::SandboxUnavailable => 3401,
            Self::NetworkBlocked => 3402,
            Self::ResourceLimit => 3009,
            Self::BudgetExhausted => 3010,
            Self::Internal => 3999,
            Self::ToolDisabled => 3011,
        }
    }

    /// Default retryability. The scheduler and the retry policy both consult
    /// this; a specific error may override it.
    #[must_use]
    pub const fn retryable_by_default(self) -> bool {
        matches!(self, Self::Timeout | Self::ResourceLimit | Self::Internal | Self::NetworkBlocked)
    }
}

/// A model-actionable tool failure.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ToolError {
    /// Taxonomy entry.
    pub kind: ToolErrorKind,
    /// One-line message, already redacted.
    pub message: String,
    /// Whether the scheduler may retry.
    #[serde(default)]
    pub retryable: bool,
    /// What the model should do differently. Never empty in practice.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hint: Option<String>,
    /// Structured detail (candidate contexts for a patch mismatch, the exit
    /// code for a shell failure, …).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub detail: Option<Value>,
}

impl ToolError {
    /// Construct with the kind's default retryability.
    #[must_use]
    pub fn new(kind: ToolErrorKind, message: impl Into<String>) -> Self {
        Self {
            kind,
            message: message.into(),
            retryable: kind.retryable_by_default(),
            hint: None,
            detail: None,
        }
    }

    /// Builder: attach the next-step hint.
    #[must_use]
    pub fn with_hint(mut self, hint: impl Into<String>) -> Self {
        self.hint = Some(hint.into());
        self
    }

    /// Builder: attach structured detail.
    #[must_use]
    pub fn with_detail(mut self, detail: Value) -> Self {
        self.detail = Some(detail);
        self
    }

    /// Builder: override retryability.
    #[must_use]
    pub fn retryable(mut self, yes: bool) -> Self {
        self.retryable = yes;
        self
    }

    /// Render the string that goes back into the model's context.
    #[must_use]
    pub fn to_model_string(&self) -> String {
        let mut s = format!("error E{} ({}): {}", self.kind.code(), self.kind.as_str(), self.message);
        if let Some(h) = &self.hint {
            s.push_str("\nnext: ");
            s.push_str(h);
        }
        s
    }

    /// Error code string, e.g. `E3005`.
    #[must_use]
    pub fn code(&self) -> String {
        format!("E{}", self.kind.code())
    }
}

impl ToolErrorKind {
    /// Stable kebab label used in metrics and error strings.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::InvalidArgs => "invalid_args",
            Self::PathDenied => "path_denied",
            Self::NotFound => "not_found",
            Self::AlreadyExists => "already_exists",
            Self::PatchMismatch => "patch_mismatch",
            Self::Timeout => "timeout",
            Self::NonZeroExit => "non_zero_exit",
            Self::PermissionDenied => "permission_denied",
            Self::SandboxUnavailable => "sandbox_unavailable",
            Self::NetworkBlocked => "network_blocked",
            Self::ResourceLimit => "resource_limit",
            Self::BudgetExhausted => "budget_exhausted",
            Self::Internal => "internal",
            Self::ToolDisabled => "tool_disabled",
        }
    }
}

impl std::fmt::Display for ToolErrorKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Static description of a tool as advertised to the model.
///
/// Kept in `protocol` (not `tools`) because the server, the TUI's tool card
/// renderer and the SDK schema export all need it without depending on the
/// capability plane (§5.2 forbidden edges).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolDescriptor {
    /// Registered name.
    pub name: String,
    /// One-line description shown to the model.
    pub description: String,
    /// JSON Schema for the arguments.
    pub input_schema: Value,
    /// Risk class (mandatory: a tool without one does not compile).
    pub risk: RiskClass,
    /// Whether the schema is sent eagerly or only after `tool_search`.
    #[serde(default)]
    pub deferred: bool,
    /// Approximate token cost of the schema itself (§6.1.1).
    #[serde(default)]
    pub schema_tokens: u32,
    /// Provider-side parallel-tool eligibility, derived from `risk`.
    #[serde(default)]
    pub read_only: bool,
}

impl ToolDescriptor {
    /// Estimate the schema's token cost from its serialised size.
    ///
    /// Uses the same 3.6-bytes-per-token ratio as `model/src/token_count.rs`
    /// so that the ledger and the tool budget agree.
    #[must_use]
    pub fn measure_schema_tokens(&mut self) -> u32 {
        let bytes = serde_json::to_vec(self).map(|v| v.len()).unwrap_or(0);
        self.schema_tokens = ((bytes as f64) / 3.6).ceil() as u32;
        self.schema_tokens
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ids::CallId;

    fn call(name: &str, args: Value) -> ToolCall {
        ToolCall::new(CallId::new(), name, args, RiskClass::Exec)
    }

    #[test]
    fn args_preview_is_bounded_and_single_line() {
        let c = call("shell", serde_json::json!({"command": "a\n".repeat(500)}));
        let p = c.args_preview();
        assert!(!p.contains('\n'), "{p:?}");
        assert!(p.chars().count() <= 210, "len {}", p.chars().count());
    }

    #[test]
    fn args_hash_is_order_independent() {
        let a = call("edit", serde_json::json!({"path": "x", "old": "a", "new": "b"}));
        let b = call("edit", serde_json::json!({"new": "b", "old": "a", "path": "x"}));
        assert_eq!(a.args_hash(), b.args_hash());
        let c = call("edit", serde_json::json!({"new": "c", "old": "a", "path": "x"}));
        assert_ne!(a.args_hash(), c.args_hash());
    }

    #[test]
    fn canonical_json_sorts_keys() {
        let v = serde_json::json!({"b": 1, "a": {"d": 2, "c": [3, {"f": 4, "e": 5}]}});
        assert_eq!(canonical_json(&v), r#"{"a":{"c":[3,{"e":5,"f":4}],"d":2},"b":1}"#);
    }

    #[test]
    fn error_codes_are_unique_and_in_the_e3_family() {
        let kinds = [
            ToolErrorKind::InvalidArgs, ToolErrorKind::PathDenied, ToolErrorKind::NotFound,
            ToolErrorKind::AlreadyExists, ToolErrorKind::PatchMismatch, ToolErrorKind::Timeout,
            ToolErrorKind::NonZeroExit, ToolErrorKind::PermissionDenied,
            ToolErrorKind::SandboxUnavailable, ToolErrorKind::NetworkBlocked,
            ToolErrorKind::ResourceLimit, ToolErrorKind::BudgetExhausted,
            ToolErrorKind::Internal, ToolErrorKind::ToolDisabled,
        ];
        let mut codes: Vec<u16> = kinds.iter().map(|k| k.code()).collect();
        codes.sort_unstable();
        let before = codes.len();
        codes.dedup();
        assert_eq!(before, codes.len(), "duplicate error codes");
        assert!(codes.iter().all(|c| (3000..4000).contains(c)), "{codes:?}");
    }

    #[test]
    fn model_string_includes_code_and_next_step() {
        let e = ToolError::new(ToolErrorKind::PatchMismatch, "anchor not found")
            .with_hint("re-read the file and use the exact current text");
        let s = e.to_model_string();
        assert!(s.contains("E3005"), "{s}");
        assert!(s.contains("next: re-read"), "{s}");
    }

    #[test]
    fn only_read_and_meta_tools_run_in_parallel() {
        assert!(RiskClass::Read.parallel_eligible());
        assert!(RiskClass::Meta.parallel_eligible());
        for r in [RiskClass::Mutate, RiskClass::Destructive, RiskClass::Exec, RiskClass::Network, RiskClass::Spawn] {
            assert!(!r.parallel_eligible(), "{r} must be serial");
        }
    }

    #[test]
    fn result_flattens_to_model_visible_text() {
        let ok = ToolResult::ok_text(CallId::new(), "read 12 lines", "line1\nline2");
        assert_eq!(ok.model_visible_text(), "line1\nline2");
        let denied = ToolResult::denied(CallId::new(), DeniedBy::Policy, "deny rule #3");
        assert_eq!(denied.model_visible_text(), "denied by policy: deny rule #3");
    }

    #[test]
    fn tool_result_roundtrips_through_json() {
        let r = ToolResult::Ok {
            call_id: CallId::new(),
            parts: vec![ContentPart::text("hi")],
            summary: "s".into(),
            meta: BTreeMap::from([("kind".to_string(), Value::from("text"))]),
            truncated: true,
            duration_ms: 12,
        };
        let v = serde_json::to_value(&r).unwrap();
        assert_eq!(v["status"], "ok");
        let back: ToolResult = serde_json::from_value(v).unwrap();
        assert_eq!(r, back);
    }
}
