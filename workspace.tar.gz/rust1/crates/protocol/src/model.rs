//! Model identity and capability descriptors (`rustplan.txt` §9.1
//! `src/model.rs`, §6.3).
//!
//! "Adding a model must be a data change, not a code change." Everything the
//! harness needs to know about a model — context window, output cap, whether
//! it supports tools/parallel-tools/images/prompt-cache/reasoning, and its
//! price — lives in a [`ModelDescriptor`] that is loaded from JSON/TOML.
//! UI features are gated off this descriptor, never off a hard-coded name.

use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Serialize};

/// Parse error for a `provider/model` string.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[error("invalid model id `{0}`; expected `provider/model`, e.g. `anthropic/claude-sonnet-4-5`")]
pub struct InvalidModelId(pub String);

/// A resolved model reference: provider + model name.
///
/// Serialises as the compact `provider/model` string so config files and logs
/// stay readable.
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ModelId {
    /// Provider key (`anthropic`, `openai`, `gemini`, `ollama`, …).
    pub provider: String,
    /// Model name as the provider expects it.
    pub model: String,
}

impl ModelId {
    /// Construct from parts.
    #[must_use]
    pub fn new(provider: impl Into<String>, model: impl Into<String>) -> Self {
        Self { provider: provider.into(), model: model.into() }
    }

    /// Parse `provider/model`. A bare name is rejected: the ambiguity between
    /// "default provider" and "model literally named x" has caused real
    /// outages, so we require the explicit form.
    ///
    /// # Errors
    /// [`InvalidModelId`] when the string has no `/` or has an empty side.
    pub fn parse(s: &str) -> Result<Self, InvalidModelId> {
        let t = s.trim();
        let Some((provider, model)) = t.split_once('/') else {
            return Err(InvalidModelId(s.to_owned()));
        };
        if provider.is_empty() || model.is_empty() {
            return Err(InvalidModelId(s.to_owned()));
        }
        if model.contains('/') {
            // Some providers (OpenRouter, Bedrock inference profiles) allow
            // slashes in the model part; keep everything after the first.
            return Ok(Self { provider: provider.to_owned(), model: model.to_owned() });
        }
        Ok(Self { provider: provider.to_owned(), model: model.to_owned() })
    }
}

impl FromStr for ModelId {
    type Err = InvalidModelId;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        Self::parse(s)
    }
}

impl fmt::Display for ModelId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}/{}", self.provider, self.model)
    }
}

impl Serialize for ModelId {
    fn serialize<S: serde::Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.to_string())
    }
}

impl<'de> Deserialize<'de> for ModelId {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let raw = String::deserialize(d)?;
        Self::parse(&raw).map_err(serde::de::Error::custom)
    }
}

/// Which role a model is being used for. Role-based routing (§9.3
/// `gateway.rs`) lets the summariser run on a cheap model while the main
/// loop runs on a strong one.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ModelRole {
    /// The main conversational loop.
    Main,
    /// Compaction summarisation (§6.1.2 stage 4).
    Summarizer,
    /// Risk classification tie-breaker (§9.5 `classifier.rs`).
    Classifier,
    /// A parallel subagent worker (§7).
    Worker,
    /// Repo-map / embedding style auxiliary work.
    Auxiliary,
}

impl ModelRole {
    /// All roles.
    pub const ALL: [ModelRole; 5] = [
        ModelRole::Main,
        ModelRole::Summarizer,
        ModelRole::Classifier,
        ModelRole::Worker,
        ModelRole::Auxiliary,
    ];

    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            ModelRole::Main => "main",
            ModelRole::Summarizer => "summarizer",
            ModelRole::Classifier => "classifier",
            ModelRole::Worker => "worker",
            ModelRole::Auxiliary => "auxiliary",
        }
    }
}

impl fmt::Display for ModelRole {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Model tier requested by a planner node (§7.3 `model_tier`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ModelTier {
    /// Cheapest model that supports tools.
    Cheap,
    /// Default balanced model.
    Balanced,
    /// Strongest available model.
    Strong,
}

impl Default for ModelTier {
    fn default() -> Self {
        Self::Balanced
    }
}

/// Capability bitset. Stored as a plain struct of bools so that JSON Schema
/// export produces readable field names; `flags()` packs it for fast compares.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "snake_case")]
pub struct ModelCaps {
    /// Supports tool/function calling at all.
    pub tools: bool,
    /// Supports multiple tool calls in one assistant message.
    pub parallel_tools: bool,
    /// Accepts image inputs.
    pub images: bool,
    /// Supports provider-side prompt caching.
    pub prompt_cache: bool,
    /// Emits reasoning/thinking blocks.
    pub reasoning: bool,
    /// Supports streaming responses.
    pub streaming: bool,
    /// Supports a distinct system prompt (vs. a system message).
    pub system_prompt: bool,
    /// Requires the provider to be told the exact stop sequences.
    pub needs_stop_sequences: bool,
    /// Supports structured/JSON output mode.
    pub json_mode: bool,
    /// Supports a 1M+ token context window.
    pub long_context: bool,
}

impl ModelCaps {
    /// All capabilities enabled — used by the mock provider.
    #[must_use]
    pub const fn all() -> Self {
        Self {
            tools: true,
            parallel_tools: true,
            images: true,
            prompt_cache: true,
            reasoning: true,
            streaming: true,
            system_prompt: true,
            needs_stop_sequences: false,
            json_mode: true,
            long_context: true,
        }
    }

    /// No capabilities at all — the safe default for an unknown model.
    #[must_use]
    pub const fn none() -> Self {
        Self {
            tools: false,
            parallel_tools: false,
            images: false,
            prompt_cache: false,
            reasoning: false,
            streaming: false,
            system_prompt: false,
            needs_stop_sequences: false,
            json_mode: false,
            long_context: false,
        }
    }

    /// Pack into a bitset for cheap comparison and storage.
    #[must_use]
    pub const fn flags(self) -> u32 {
        let mut f = 0u32;
        if self.tools { f |= 1 << 0; }
        if self.parallel_tools { f |= 1 << 1; }
        if self.images { f |= 1 << 2; }
        if self.prompt_cache { f |= 1 << 3; }
        if self.reasoning { f |= 1 << 4; }
        if self.streaming { f |= 1 << 5; }
        if self.system_prompt { f |= 1 << 6; }
        if self.needs_stop_sequences { f |= 1 << 7; }
        if self.json_mode { f |= 1 << 8; }
        if self.long_context { f |= 1 << 9; }
        f
    }

    /// Unpack from [`ModelCaps::flags`].
    #[must_use]
    pub const fn from_flags(f: u32) -> Self {
        Self {
            tools: f & (1 << 0) != 0,
            parallel_tools: f & (1 << 1) != 0,
            images: f & (1 << 2) != 0,
            prompt_cache: f & (1 << 3) != 0,
            reasoning: f & (1 << 4) != 0,
            streaming: f & (1 << 5) != 0,
            system_prompt: f & (1 << 6) != 0,
            needs_stop_sequences: f & (1 << 7) != 0,
            json_mode: f & (1 << 8) != 0,
            long_context: f & (1 << 9) != 0,
        }
    }

    /// Capabilities lost when failing over from `self` to `other`. Surfaced to
    /// the user (§9.3 `failover.rs`: "failover ke baad … user ko explicit
    /// notice").
    #[must_use]
    pub fn lost_in(&self, other: ModelCaps) -> Vec<&'static str> {
        let mut out = Vec::new();
        if self.tools && !other.tools { out.push("tool calling"); }
        if self.parallel_tools && !other.parallel_tools { out.push("parallel tool calls"); }
        if self.images && !other.images { out.push("image input"); }
        if self.prompt_cache && !other.prompt_cache { out.push("prompt caching"); }
        if self.reasoning && !other.reasoning { out.push("extended thinking"); }
        if self.streaming && !other.streaming { out.push("streaming"); }
        out
    }
}

/// Per-million-token pricing in USD micros (1 USD = 1_000_000 micros).
///
/// Integer micros everywhere — floats are forbidden for money (§9.1
/// `usage.rs` acceptance).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "snake_case")]
pub struct Pricing {
    /// Input tokens, USD micros per million.
    pub input_per_mtok: u64,
    /// Output tokens, USD micros per million.
    pub output_per_mtok: u64,
    /// Cache read tokens, USD micros per million.
    pub cache_read_per_mtok: u64,
    /// Cache write tokens, USD micros per million.
    pub cache_write_per_mtok: u64,
    /// Reasoning tokens are billed as output by every provider today; kept
    /// separate so a future provider can price them differently.
    pub reasoning_per_mtok: u64,
}

impl Pricing {
    /// Free (local models).
    #[must_use]
    pub const fn free() -> Self {
        Self {
            input_per_mtok: 0,
            output_per_mtok: 0,
            cache_read_per_mtok: 0,
            cache_write_per_mtok: 0,
            reasoning_per_mtok: 0,
        }
    }
}

/// Full description of a model, loaded from data.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ModelDescriptor {
    /// Resolved identity.
    pub id: ModelId,
    /// Human readable name for pickers.
    pub display_name: String,
    /// Total context window in tokens.
    pub ctx_window: u32,
    /// Maximum output tokens the provider will generate.
    pub max_output: u32,
    /// Capabilities.
    pub caps: ModelCaps,
    /// Pricing.
    pub price: Pricing,
    /// Which tier this model belongs to, for role routing.
    #[serde(default)]
    pub tier: ModelTier,
    /// Date the descriptor was last verified against provider docs
    /// (`YYYY-MM-DD`). Stale descriptors trigger a warning, not a failure.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub verified_on: Option<String>,
    /// Provider-side quirks the adapter needs to know about.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub quirks: Vec<String>,
}

impl ModelDescriptor {
    /// Tokens reserved for the model's own reply (§6.1.1 `reserve_output`).
    ///
    /// Never more than a quarter of the window, so a small model still leaves
    /// room for history.
    #[must_use]
    pub fn reserve_output(&self) -> u32 {
        self.max_output.min(self.ctx_window / 4).max(1024)
    }

    /// Tokens available for everything we send (window minus output reserve
    /// minus the tokenizer safety margin).
    #[must_use]
    pub fn usable_input(&self) -> u32 {
        self.ctx_window
            .saturating_sub(self.reserve_output())
            .saturating_sub(self.safety_reserve())
    }

    /// Tokenizer estimation safety margin (§6.1.1: "hamesha underestimate
    /// karo"). 2% of the window, clamped to [1024, 4096].
    #[must_use]
    pub fn safety_reserve(&self) -> u32 {
        ((self.ctx_window / 50).clamp(1024, 4096)).max(512)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn model_id_parses_and_renders() {
        let m = ModelId::parse("anthropic/claude-sonnet-4-5").unwrap();
        assert_eq!(m.provider, "anthropic");
        assert_eq!(m.model, "claude-sonnet-4-5");
        assert_eq!(m.to_string(), "anthropic/claude-sonnet-4-5");
    }

    #[test]
    fn model_id_keeps_slashes_in_the_model_part() {
        let m = ModelId::parse("bedrock/us.anthropic.claude/v1:0").unwrap();
        assert_eq!(m.provider, "bedrock");
        assert_eq!(m.model, "us.anthropic.claude/v1:0");
    }

    #[test]
    fn model_id_rejects_bare_names_with_actionable_error() {
        let e = ModelId::parse("gpt-5").unwrap_err();
        assert!(e.to_string().contains("gpt-5"));
        assert!(e.to_string().contains("provider/model"));
        assert!(ModelId::parse("/x").is_err());
        assert!(ModelId::parse("x/").is_err());
    }

    #[test]
    fn model_id_serde_is_the_compact_string() {
        let m = ModelId::new("openai", "gpt-5");
        assert_eq!(serde_json::to_string(&m).unwrap(), "\"openai/gpt-5\"");
        let back: ModelId = serde_json::from_str("\"openai/gpt-5\"").unwrap();
        assert_eq!(back, m);
    }

    #[test]
    fn capability_flags_roundtrip() {
        for caps in [ModelCaps::all(), ModelCaps::none(), ModelCaps { tools: true, images: true, ..Default::default() }] {
            assert_eq!(ModelCaps::from_flags(caps.flags()), caps);
        }
    }

    #[test]
    fn capability_loss_is_reported_for_failover() {
        let strong = ModelCaps::all();
        let weak = ModelCaps { tools: true, streaming: true, ..ModelCaps::none() };
        let lost = strong.lost_in(weak);
        assert!(lost.contains(&"image input"));
        assert!(lost.contains(&"prompt caching"));
        assert!(!lost.contains(&"tool calling"));
    }

    #[test]
    fn reserves_leave_room_for_history() {
        let d = ModelDescriptor {
            id: ModelId::new("x", "y"),
            display_name: "Y".into(),
            ctx_window: 200_000,
            max_output: 64_000,
            caps: ModelCaps::all(),
            price: Pricing::free(),
            tier: ModelTier::Strong,
            verified_on: None,
            quirks: vec![],
        };
        assert_eq!(d.reserve_output(), 50_000, "capped at a quarter of the window");
        assert_eq!(d.safety_reserve(), 4000);
        assert_eq!(d.usable_input(), 200_000 - 50_000 - 4000);
    }

    #[test]
    fn tiny_models_still_get_a_minimum_reserve() {
        let d = ModelDescriptor {
            id: ModelId::new("ollama", "qwen3:1.7b"),
            display_name: "qwen".into(),
            ctx_window: 4096,
            max_output: 8192,
            caps: ModelCaps::none(),
            price: Pricing::free(),
            tier: ModelTier::Cheap,
            verified_on: None,
            quirks: vec![],
        };
        assert_eq!(d.reserve_output(), 1024);
        assert!(d.usable_input() > 0);
    }
}
