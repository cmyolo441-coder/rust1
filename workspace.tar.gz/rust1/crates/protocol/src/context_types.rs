//! Shared vocabulary for the context economy (`rustplan.txt` §6.1).
//!
//! The `context` crate owns the algorithms; this module owns the *names*, so
//! that events, metrics labels, the TUI's `/context` overlay and the SQLite
//! `usage`/`context` columns all agree on one bounded set of strings
//! (§10.7 cardinality rule: labels must never contain paths or prompts).

use serde::{Deserialize, Serialize};

/// A named region of the assembled prompt (§6.1.1 ledger).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SectionKind {
    /// Identity + hard rules. Never changes within a session.
    SystemCore,
    /// Tool JSON schemas. Stable per toolset.
    ToolsSchema,
    /// `AGENTS.md` hierarchy + rules. Stable per directory set.
    Memory,
    /// Repository map slice (§6.1.5).
    RepoMap,
    /// OS/shell/cwd/git snapshot. Changes rarely.
    Env,
    /// The compacted summary that replaced older history.
    CompactedHistory,
    /// Recent, uncompacted turns.
    History,
    /// Explicit `@file`/`@url` attachments.
    Attachments,
    /// Agent-maintained scratchpad that survives compaction (§9.6).
    Scratchpad,
    /// The current user prompt. Changes every turn.
    CurrentPrompt,
    /// Reserved space for the model's reply (not a real section, but the
    /// ledger accounts for it).
    OutputReserve,
    /// Tokenizer error margin (not a real section either).
    SafetyReserve,
}

impl SectionKind {
    /// Stable metric label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            SectionKind::SystemCore => "system_core",
            SectionKind::ToolsSchema => "tools_schema",
            SectionKind::Memory => "memory",
            SectionKind::RepoMap => "repo_map",
            SectionKind::Env => "env",
            SectionKind::CompactedHistory => "compacted_history",
            SectionKind::History => "history",
            SectionKind::Attachments => "attachments",
            SectionKind::Scratchpad => "scratchpad",
            SectionKind::CurrentPrompt => "current_prompt",
            SectionKind::OutputReserve => "output_reserve",
            SectionKind::SafetyReserve => "safety_reserve",
        }
    }

    /// All kinds, in **assembly order** (§6.1.3). This ordering is load
    /// bearing: everything before the cache boundary must be byte-stable.
    pub const ASSEMBLY_ORDER: [SectionKind; 10] = [
        SectionKind::SystemCore,
        SectionKind::ToolsSchema,
        SectionKind::Memory,
        SectionKind::RepoMap,
        SectionKind::Env,
        SectionKind::Scratchpad,
        SectionKind::CompactedHistory,
        SectionKind::History,
        SectionKind::Attachments,
        SectionKind::CurrentPrompt,
    ];

    /// True when the section belongs to the cache-stable prefix (§6.1.3).
    ///
    /// Placing a volatile section before a stable one is a 3–10× cost
    /// regression, so `context/sections.rs` refuses to build such an order
    /// and a snapshot test locks it.
    #[must_use]
    pub const fn is_cache_stable(self) -> bool {
        matches!(
            self,
            SectionKind::SystemCore | SectionKind::ToolsSchema | SectionKind::Memory
        )
    }

    /// Whether this section counts against the input budget.
    #[must_use]
    pub const fn counts_toward_input(self) -> bool {
        !matches!(self, SectionKind::OutputReserve | SectionKind::SafetyReserve)
    }

    /// Default token budget as a fraction of the usable window (§6.1.1).
    ///
    /// `history` gets whatever is left; these are the *reserves*.
    #[must_use]
    pub const fn default_fraction(self) -> f32 {
        match self {
            SectionKind::SystemCore => 0.020,
            SectionKind::ToolsSchema => 0.060,
            SectionKind::Memory => 0.030,
            SectionKind::RepoMap => 0.020,
            SectionKind::Env => 0.005,
            SectionKind::Scratchpad => 0.010,
            SectionKind::CompactedHistory => 0.050,
            SectionKind::History => 1.000, // remainder
            SectionKind::Attachments => 0.100,
            SectionKind::CurrentPrompt => 0.050,
            SectionKind::OutputReserve => 0.0,
            SectionKind::SafetyReserve => 0.0,
        }
    }
}

impl std::fmt::Display for SectionKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// The five-stage compaction ladder (§6.1.2), cheapest first.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CompactStage {
    /// Tighten tool-output caps and drop images. Free, lossy.
    BudgetReduce,
    /// Clip old oversized tool results to head+tail. Free, lossy.
    Snip,
    /// Remove duplicate reads/outputs. ~Free, lossy.
    Dedupe,
    /// Fold inactive segments into a stub + pointer. Free, **reversible**.
    Collapse,
    /// Ask a model for a structured summary with pinned facts. One call.
    Summarize,
    /// Move exploration into a subagent and keep only its summary. One call.
    SubagentIsolate,
}

impl CompactStage {
    /// All stages in ladder order.
    pub const LADDER: [CompactStage; 6] = [
        CompactStage::BudgetReduce,
        CompactStage::Snip,
        CompactStage::Dedupe,
        CompactStage::Collapse,
        CompactStage::Summarize,
        CompactStage::SubagentIsolate,
    ];

    /// Stable metric label (`compact_stage_tokens_saved{stage}`).
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            CompactStage::BudgetReduce => "budget_reduce",
            CompactStage::Snip => "snip",
            CompactStage::Dedupe => "dedupe",
            CompactStage::Collapse => "collapse",
            CompactStage::Summarize => "summarize",
            CompactStage::SubagentIsolate => "subagent_isolate",
        }
    }

    /// Whether the stage needs a model call.
    #[must_use]
    pub const fn needs_model(self) -> bool {
        matches!(self, CompactStage::Summarize | CompactStage::SubagentIsolate)
    }

    /// Whether the stage can be undone from the rollout.
    #[must_use]
    pub const fn reversible(self) -> bool {
        matches!(self, CompactStage::Collapse)
    }

    /// Rough wall-time cost in milliseconds, used to decide whether to run a
    /// stage pre-emptively or only when forced.
    #[must_use]
    pub const fn cost_ms(self) -> u64 {
        match self {
            CompactStage::BudgetReduce => 1,
            CompactStage::Snip => 5,
            CompactStage::Dedupe => 15,
            CompactStage::Collapse => 20,
            CompactStage::Summarize => 4_000,
            CompactStage::SubagentIsolate => 20_000,
        }
    }
}

impl std::fmt::Display for CompactStage {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Layers of the memory hierarchy (§6.1.4), highest precedence first.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MemoryLayer {
    /// `/etc/agent/AGENTS.md` — admin managed. 4 KB cap.
    Managed,
    /// `~/.config/agent/AGENTS.md`. 8 KB cap.
    User,
    /// `<repo>/AGENTS.md`. 16 KB cap.
    Project,
    /// `<repo>/AGENTS.local.md`, gitignored. 8 KB cap.
    Local,
    /// `<repo>/sub/AGENTS.md`, loaded lazily when that dir is read. 8 KB cap.
    Nested,
    /// `<repo>/.agent/rules/*.md`, glob scoped. 4 KB each.
    Rules,
    /// Agent-written notes that the user approved (§9.6 `memory/auto.rs`).
    Auto,
}

impl MemoryLayer {
    /// Byte cap for this layer (§6.1.4 table).
    #[must_use]
    pub const fn byte_cap(self) -> usize {
        match self {
            MemoryLayer::Managed => 4 * 1024,
            MemoryLayer::User => 8 * 1024,
            MemoryLayer::Project => 16 * 1024,
            MemoryLayer::Local => 8 * 1024,
            MemoryLayer::Nested => 8 * 1024,
            MemoryLayer::Rules => 4 * 1024,
            MemoryLayer::Auto => 4 * 1024,
        }
    }

    /// True when the layer is loaded eagerly at turn start.
    #[must_use]
    pub const fn is_eager(self) -> bool {
        matches!(
            self,
            MemoryLayer::Managed | MemoryLayer::User | MemoryLayer::Project | MemoryLayer::Local
        )
    }

    /// Precedence: higher wins a conflict (§9.6 `memory/conflicts.rs`).
    ///
    /// Project beats user beats managed for *instructions*, but the managed
    /// layer wins for *security* keys — that asymmetry is handled by
    /// `policy/managed.rs`, not here.
    #[must_use]
    pub const fn precedence(self) -> u8 {
        match self {
            MemoryLayer::Managed => 1,
            MemoryLayer::User => 2,
            MemoryLayer::Project => 3,
            MemoryLayer::Local => 4,
            MemoryLayer::Nested => 5,
            MemoryLayer::Rules => 6,
            MemoryLayer::Auto => 7,
        }
    }

    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            MemoryLayer::Managed => "managed",
            MemoryLayer::User => "user",
            MemoryLayer::Project => "project",
            MemoryLayer::Local => "local",
            MemoryLayer::Nested => "nested",
            MemoryLayer::Rules => "rules",
            MemoryLayer::Auto => "auto",
        }
    }
}

/// Where a piece of content came from, for the `/context` debug overlay.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Provenance {
    /// Layer.
    pub layer: MemoryLayer,
    /// Absolute path.
    pub path: String,
    /// Byte offset in the assembled prompt.
    #[serde(default)]
    pub offset: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn assembly_order_puts_stable_sections_before_volatile_ones() {
        let order = SectionKind::ASSEMBLY_ORDER;
        let stable_end = order.iter().position(|k| !k.is_cache_stable()).unwrap_or(order.len());
        for k in &order[stable_end..] {
            assert!(!k.is_cache_stable(), "{k:?} is stable but placed after the boundary");
        }
        assert!(stable_end >= 3, "expected system/tools/memory in the prefix");
        assert_eq!(*order.last().unwrap(), SectionKind::CurrentPrompt);
    }

    #[test]
    fn section_labels_are_unique() {
        let mut labels: Vec<&str> = SectionKind::ASSEMBLY_ORDER.iter().map(|k| k.as_str()).collect();
        labels.push(SectionKind::OutputReserve.as_str());
        labels.push(SectionKind::SafetyReserve.as_str());
        let n = labels.len();
        labels.sort_unstable();
        labels.dedup();
        assert_eq!(n, labels.len());
    }

    #[test]
    fn ladder_is_ordered_cheapest_first() {
        let mut costs: Vec<u64> = CompactStage::LADDER.iter().map(|s| s.cost_ms()).collect();
        let mut sorted = costs.clone();
        sorted.sort_unstable();
        assert_eq!(costs, sorted, "ladder must escalate");
        costs.dedup();
        assert_eq!(costs.len(), CompactStage::LADDER.len());
    }

    #[test]
    fn only_two_stages_need_a_model() {
        let model_stages: Vec<_> =
            CompactStage::LADDER.iter().copied().filter(|s| s.needs_model()).collect();
        assert_eq!(model_stages, vec![CompactStage::Summarize, CompactStage::SubagentIsolate]);
    }

    #[test]
    fn collapse_is_the_only_reversible_stage() {
        let rev: Vec<_> = CompactStage::LADDER.iter().copied().filter(|s| s.reversible()).collect();
        assert_eq!(rev, vec![CompactStage::Collapse]);
    }

    #[test]
    fn memory_caps_match_the_documented_table() {
        assert_eq!(MemoryLayer::Managed.byte_cap(), 4096);
        assert_eq!(MemoryLayer::User.byte_cap(), 8192);
        assert_eq!(MemoryLayer::Project.byte_cap(), 16384);
        assert_eq!(MemoryLayer::Local.byte_cap(), 8192);
        assert_eq!(MemoryLayer::Nested.byte_cap(), 8192);
        assert_eq!(MemoryLayer::Rules.byte_cap(), 4096);
    }

    #[test]
    fn nested_and_rules_are_lazy() {
        assert!(!MemoryLayer::Nested.is_eager());
        assert!(!MemoryLayer::Rules.is_eager());
        assert!(MemoryLayer::Project.is_eager());
    }

    #[test]
    fn precedence_is_strictly_increasing_with_specificity() {
        let layers = [
            MemoryLayer::Managed, MemoryLayer::User, MemoryLayer::Project,
            MemoryLayer::Local, MemoryLayer::Nested, MemoryLayer::Rules, MemoryLayer::Auto,
        ];
        for w in layers.windows(2) {
            assert!(w[0].precedence() < w[1].precedence(), "{:?} vs {:?}", w[0], w[1]);
        }
    }
}
