//! Error taxonomy and exit codes (`rustplan.txt` §10.6, §3.7).
//!
//! Every user-visible failure carries: a **stable code**, a one-line message,
//! and a **next action**. Support engineers search by code; CI scripts branch
//! on exit code. Both sets are frozen contracts — adding a code is fine,
//! renumbering one is a breaking change.

use serde::{Deserialize, Serialize};

/// The seven error families (§10.6).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ErrorClass {
    /// `E1xxx` — config.
    Config,
    /// `E2xxx` — provider/model.
    Provider,
    /// `E3xxx` — tool.
    Tool,
    /// `E4xxx` — sandbox.
    Sandbox,
    /// `E5xxx` — state/persistence.
    State,
    /// `E6xxx` — protocol/wire.
    Protocol,
    /// `E7xxx` — orchestration.
    Orchestration,
}

impl ErrorClass {
    /// First numeric code in the family.
    #[must_use]
    pub const fn base(self) -> u16 {
        match self {
            ErrorClass::Config => 1000,
            ErrorClass::Provider => 2000,
            ErrorClass::Tool => 3000,
            ErrorClass::Sandbox => 4000,
            ErrorClass::State => 5000,
            ErrorClass::Protocol => 6000,
            ErrorClass::Orchestration => 7000,
        }
    }

    /// Stable label.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            ErrorClass::Config => "config",
            ErrorClass::Provider => "provider",
            ErrorClass::Tool => "tool",
            ErrorClass::Sandbox => "sandbox",
            ErrorClass::State => "state",
            ErrorClass::Protocol => "protocol",
            ErrorClass::Orchestration => "orchestration",
        }
    }

    /// Derive the class from a numeric code.
    #[must_use]
    pub fn of_code(code: u16) -> Option<ErrorClass> {
        match code / 1000 {
            1 => Some(ErrorClass::Config),
            2 => Some(ErrorClass::Provider),
            3 => Some(ErrorClass::Tool),
            4 => Some(ErrorClass::Sandbox),
            5 => Some(ErrorClass::State),
            6 => Some(ErrorClass::Protocol),
            7 => Some(ErrorClass::Orchestration),
            _ => None,
        }
    }
}

/// A concrete, stable error code.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ErrorCode(u16);

impl ErrorCode {
    /// Build from a raw number. Only used by the catalogue below.
    const fn new(n: u16) -> Self {
        Self(n)
    }

    /// The numeric part, e.g. `1001`.
    #[must_use]
    pub const fn number(self) -> u16 {
        self.0
    }

    /// Which family this code belongs to.
    #[must_use]
    pub fn class(self) -> Option<ErrorClass> {
        ErrorClass::of_code(self.0)
    }

    /// Stable string form, e.g. `E1001`.
    #[must_use]
    pub fn code(self) -> String {
        format!("E{}", self.0)
    }
}

impl std::fmt::Display for ErrorCode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "E{}", self.0)
    }
}

/// The frozen catalogue. Grouped by family, numbered densely so gaps are
/// visible in review.
pub mod codes {
    use super::ErrorCode;

    // ── E1xxx config ────────────────────────────────────────────────────────
    /// Config file could not be read.
    pub const CONFIG_UNREADABLE: ErrorCode = ErrorCode::new(1001);
    /// Config file is not valid TOML.
    pub const CONFIG_PARSE: ErrorCode = ErrorCode::new(1002);
    /// Unknown config key (typo safety: this is an error, not a warning).
    pub const CONFIG_UNKNOWN_KEY: ErrorCode = ErrorCode::new(1003);
    /// Value has the wrong type or range.
    pub const CONFIG_INVALID_VALUE: ErrorCode = ErrorCode::new(1004);
    /// Two config layers contradict each other on a security key.
    pub const CONFIG_CONFLICT: ErrorCode = ErrorCode::new(1005);
    /// A managed (admin-locked) key was modified by a developer layer.
    pub const CONFIG_MANAGED_LOCKED: ErrorCode = ErrorCode::new(1006);
    /// Cross-field validation failed (e.g. `sandbox=false` + `mode=bypass`).
    pub const CONFIG_UNSAFE_COMBINATION: ErrorCode = ErrorCode::new(1007);
    /// A referenced file (`hooks/`, `skills/`) does not exist.
    pub const CONFIG_MISSING_FILE: ErrorCode = ErrorCode::new(1008);

    // ── E2xxx provider ──────────────────────────────────────────────────────
    /// No credential for the provider.
    pub const PROVIDER_UNAUTHENTICATED: ErrorCode = ErrorCode::new(2001);
    /// Credential expired and refresh failed.
    pub const PROVIDER_AUTH_EXPIRED: ErrorCode = ErrorCode::new(2002);
    /// Rate limited (429) after all retries.
    pub const PROVIDER_RATE_LIMITED: ErrorCode = ErrorCode::new(2003);
    /// Provider returned 5xx after all retries.
    pub const PROVIDER_UNAVAILABLE: ErrorCode = ErrorCode::new(2004);
    /// The model id does not exist / is not entitled.
    pub const PROVIDER_MODEL_NOT_FOUND: ErrorCode = ErrorCode::new(2005);
    /// The request was rejected as too long.
    pub const PROVIDER_CONTEXT_OVERFLOW: ErrorCode = ErrorCode::new(2006);
    /// The provider refused the content (safety filter).
    pub const PROVIDER_CONTENT_FILTERED: ErrorCode = ErrorCode::new(2007);
    /// The SSE stream broke mid-response.
    pub const PROVIDER_STREAM_INTERRUPTED: ErrorCode = ErrorCode::new(2008);
    /// The provider returned malformed JSON / an unknown event.
    pub const PROVIDER_BAD_RESPONSE: ErrorCode = ErrorCode::new(2009);
    /// Every model in the failover chain failed.
    pub const PROVIDER_FAILOVER_EXHAUSTED: ErrorCode = ErrorCode::new(2010);
    /// Network egress is blocked (no route / DNS / allowlist).
    pub const PROVIDER_NETWORK: ErrorCode = ErrorCode::new(2011);
    /// The provider's usage numbers disagree with our ledger beyond tolerance.
    pub const PROVIDER_USAGE_DRIFT: ErrorCode = ErrorCode::new(2012);

    // ── E3xxx tool ──────────────────────────────────────────────────────────
    /// Tool arguments did not match the schema.
    pub const TOOL_INVALID_ARGS: ErrorCode = ErrorCode::new(3001);
    /// Path outside the workspace or a granted root.
    pub const TOOL_PATH_DENIED: ErrorCode = ErrorCode::new(3002);
    /// File or directory does not exist.
    pub const TOOL_NOT_FOUND: ErrorCode = ErrorCode::new(3003);
    /// Target already exists.
    pub const TOOL_ALREADY_EXISTS: ErrorCode = ErrorCode::new(3004);
    /// Patch anchor did not match, or matched more than once.
    pub const TOOL_PATCH_MISMATCH: ErrorCode = ErrorCode::new(3005);
    /// Tool exceeded its deadline.
    pub const TOOL_TIMEOUT: ErrorCode = ErrorCode::new(3006);
    /// Command exited non-zero.
    pub const TOOL_NON_ZERO_EXIT: ErrorCode = ErrorCode::new(3007);
    /// A deny rule or the user refused the call.
    pub const TOOL_PERMISSION_DENIED: ErrorCode = ErrorCode::new(3008);
    /// Resource limit hit (memory, pids, output bytes).
    pub const TOOL_RESOURCE_LIMIT: ErrorCode = ErrorCode::new(3009);
    /// Budget or loop-detection limit hit.
    pub const TOOL_BUDGET_EXHAUSTED: ErrorCode = ErrorCode::new(3010);
    /// Tool is disabled in this mode / by config.
    pub const TOOL_DISABLED: ErrorCode = ErrorCode::new(3011);
    /// Tool name is not registered.
    pub const TOOL_UNKNOWN: ErrorCode = ErrorCode::new(3012);
    /// Internal tool bug.
    pub const TOOL_INTERNAL: ErrorCode = ErrorCode::new(3999);

    // ── E4xxx sandbox ───────────────────────────────────────────────────────
    /// No sandbox backend is available and `--no-sandbox` was not passed.
    pub const SANDBOX_UNAVAILABLE: ErrorCode = ErrorCode::new(4001);
    /// The sandbox refused a path.
    pub const SANDBOX_PATH_DENIED: ErrorCode = ErrorCode::new(4002);
    /// The sandbox refused network egress.
    pub const SANDBOX_NET_DENIED: ErrorCode = ErrorCode::new(4003);
    /// The backend failed to start the process.
    pub const SANDBOX_LAUNCH_FAILED: ErrorCode = ErrorCode::new(4004);
    /// A resource limit (cgroup/job object) was exceeded.
    pub const SANDBOX_RESOURCE_LIMIT: ErrorCode = ErrorCode::new(4005);
    /// The backend self-test failed at startup (fail-closed).
    pub const SANDBOX_SELF_TEST_FAILED: ErrorCode = ErrorCode::new(4006);

    // ── E5xxx state ─────────────────────────────────────────────────────────
    /// Disk full / quota exceeded.
    pub const STATE_DISK_FULL: ErrorCode = ErrorCode::new(5001);
    /// SQLite is locked by another process.
    pub const STATE_DB_LOCKED: ErrorCode = ErrorCode::new(5002);
    /// The rollout file is corrupt beyond the last checkpoint.
    pub const STATE_ROLLOUT_CORRUPT: ErrorCode = ErrorCode::new(5003);
    /// A migration failed.
    pub const STATE_MIGRATION_FAILED: ErrorCode = ErrorCode::new(5004);
    /// The session id does not exist.
    pub const STATE_SESSION_NOT_FOUND: ErrorCode = ErrorCode::new(5005);
    /// The audit chain failed verification.
    pub const STATE_AUDIT_TAMPERED: ErrorCode = ErrorCode::new(5006);
    /// Blob store entry missing.
    pub const STATE_BLOB_MISSING: ErrorCode = ErrorCode::new(5007);

    // ── E6xxx protocol ──────────────────────────────────────────────────────
    /// The peer speaks an unsupported protocol version.
    pub const PROTOCOL_VERSION_MISMATCH: ErrorCode = ErrorCode::new(6001);
    /// A frame could not be parsed.
    pub const PROTOCOL_BAD_FRAME: ErrorCode = ErrorCode::new(6002);
    /// A request arrived for an unknown method.
    pub const PROTOCOL_UNKNOWN_METHOD: ErrorCode = ErrorCode::new(6003);
    /// A response arrived with no matching request id.
    pub const PROTOCOL_ORPHAN_RESPONSE: ErrorCode = ErrorCode::new(6004);

    // ── E7xxx orchestration ─────────────────────────────────────────────────
    /// The task DAG has a cycle.
    pub const ORCH_CYCLE: ErrorCode = ErrorCode::new(7001);
    /// The plan exceeded the node cap.
    pub const ORCH_TOO_MANY_NODES: ErrorCode = ErrorCode::new(7002);
    /// The run budget was exhausted.
    pub const ORCH_BUDGET_EXHAUSTED: ErrorCode = ErrorCode::new(7003);
    /// A merge conflicted and the retry budget ran out.
    pub const ORCH_MERGE_CONFLICT: ErrorCode = ErrorCode::new(7004);
    /// A worker wrote outside its lease.
    pub const ORCH_LEASE_VIOLATION: ErrorCode = ErrorCode::new(7005);
    /// Two workers deadlocked on leases.
    pub const ORCH_LEASE_DEADLOCK: ErrorCode = ErrorCode::new(7006);
    /// A node was quarantined after repeated failures.
    pub const ORCH_QUARANTINED: ErrorCode = ErrorCode::new(7007);
    /// A verify gate failed twice for the same node.
    pub const ORCH_VERIFY_FAILED: ErrorCode = ErrorCode::new(7008);
}

/// Process exit codes (§3.7). A stable contract for CI.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ExitCode {
    /// Success.
    Ok = 0,
    /// Task/agent error.
    Error = 1,
    /// CLI usage error (bad flag, missing argument).
    Usage = 2,
    /// Policy denied; nothing executed.
    PolicyDenied = 3,
    /// Sandbox unavailable; fail-closed.
    SandboxUnavailable = 4,
    /// Provider or auth error.
    Provider = 5,
    /// Invalid input (bad prompt file, empty stdin).
    InvalidInput = 42,
    /// Turn or budget limit exceeded.
    BudgetExceeded = 53,
    /// Interrupted (SIGINT). Matches the shell convention `128 + 2`.
    Interrupted = 130,
}

impl ExitCode {
    /// The numeric value.
    #[must_use]
    pub const fn as_u8(self) -> u8 {
        self as u8
    }

    /// One-line explanation, printed by `agent exec --explain-exit`.
    #[must_use]
    pub const fn explain(self) -> &'static str {
        match self {
            ExitCode::Ok => "success",
            ExitCode::Error => "task or agent error",
            ExitCode::Usage => "invalid command line usage",
            ExitCode::PolicyDenied => "denied by policy; nothing was executed",
            ExitCode::SandboxUnavailable => "no sandbox backend available and --no-sandbox was not passed",
            ExitCode::Provider => "provider or authentication error",
            ExitCode::InvalidInput => "invalid input (unreadable prompt file, empty stdin)",
            ExitCode::BudgetExceeded => "turn, token or cost budget exceeded",
            ExitCode::Interrupted => "interrupted by signal",
        }
    }

    /// Map an error code onto the exit code a headless run should return.
    #[must_use]
    pub fn for_error(code: ErrorCode) -> ExitCode {
        match code.class() {
            Some(ErrorClass::Config) => ExitCode::Usage,
            Some(ErrorClass::Provider) => ExitCode::Provider,
            Some(ErrorClass::Tool) => match code {
                codes::TOOL_PERMISSION_DENIED => ExitCode::PolicyDenied,
                codes::TOOL_BUDGET_EXHAUSTED => ExitCode::BudgetExceeded,
                codes::TOOL_INVALID_ARGS | codes::TOOL_UNKNOWN => ExitCode::InvalidInput,
                _ => ExitCode::Error,
            },
            Some(ErrorClass::Sandbox) => ExitCode::SandboxUnavailable,
            Some(ErrorClass::State) => ExitCode::Error,
            Some(ErrorClass::Protocol) => ExitCode::Usage,
            Some(ErrorClass::Orchestration) => match code {
                codes::ORCH_BUDGET_EXHAUSTED => ExitCode::BudgetExceeded,
                _ => ExitCode::Error,
            },
            None => ExitCode::Error,
        }
    }
}

impl std::fmt::Display for ExitCode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.as_u8())
    }
}

/// A complete, user-visible error: code + message + next action (§10.6).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentFailure {
    /// Stable code.
    pub code: ErrorCode,
    /// One-line message. No paths or secrets unless already redacted.
    pub message: String,
    /// What the user should do next.
    pub remediation: String,
    /// Extra detail shown only with `--verbose`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
}

impl AgentFailure {
    /// Construct.
    #[must_use]
    pub fn new(code: ErrorCode, message: impl Into<String>, remediation: impl Into<String>) -> Self {
        Self { code, message: message.into(), remediation: remediation.into(), detail: None }
    }

    /// Builder: attach verbose detail.
    #[must_use]
    pub fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }

    /// The exit code a headless run should use.
    #[must_use]
    pub fn exit_code(&self) -> ExitCode {
        ExitCode::for_error(self.code)
    }

    /// Render the single line shown to the user.
    #[must_use]
    pub fn render(&self) -> String {
        format!("{} {}: {} → {}", self.code, self.code.class().map_or("error", |c| c.as_str()), self.message, self.remediation)
    }
}

impl std::fmt::Display for AgentFailure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.render())
    }
}

impl std::error::Error for AgentFailure {}

/// The whole catalogue, for `agent doctor --json` and the docs generator.
#[must_use]
pub fn catalogue() -> Vec<(ErrorCode, ErrorClass, &'static str)> {
    use codes::*;
    vec![
        (CONFIG_UNREADABLE, ErrorClass::Config, "config file could not be read"),
        (CONFIG_PARSE, ErrorClass::Config, "config file is not valid TOML"),
        (CONFIG_UNKNOWN_KEY, ErrorClass::Config, "unknown config key"),
        (CONFIG_INVALID_VALUE, ErrorClass::Config, "invalid config value"),
        (CONFIG_CONFLICT, ErrorClass::Config, "contradictory config layers"),
        (CONFIG_MANAGED_LOCKED, ErrorClass::Config, "managed key is admin-locked"),
        (CONFIG_UNSAFE_COMBINATION, ErrorClass::Config, "unsafe combination of settings"),
        (CONFIG_MISSING_FILE, ErrorClass::Config, "referenced file does not exist"),
        (PROVIDER_UNAUTHENTICATED, ErrorClass::Provider, "no credential for provider"),
        (PROVIDER_AUTH_EXPIRED, ErrorClass::Provider, "credential expired"),
        (PROVIDER_RATE_LIMITED, ErrorClass::Provider, "rate limited"),
        (PROVIDER_UNAVAILABLE, ErrorClass::Provider, "provider unavailable"),
        (PROVIDER_MODEL_NOT_FOUND, ErrorClass::Provider, "model not found"),
        (PROVIDER_CONTEXT_OVERFLOW, ErrorClass::Provider, "context overflow"),
        (PROVIDER_CONTENT_FILTERED, ErrorClass::Provider, "content filtered"),
        (PROVIDER_STREAM_INTERRUPTED, ErrorClass::Provider, "stream interrupted"),
        (PROVIDER_BAD_RESPONSE, ErrorClass::Provider, "malformed provider response"),
        (PROVIDER_FAILOVER_EXHAUSTED, ErrorClass::Provider, "all failover models failed"),
        (PROVIDER_NETWORK, ErrorClass::Provider, "network unreachable or blocked"),
        (PROVIDER_USAGE_DRIFT, ErrorClass::Provider, "token estimate drift too high"),
        (TOOL_INVALID_ARGS, ErrorClass::Tool, "invalid tool arguments"),
        (TOOL_PATH_DENIED, ErrorClass::Tool, "path outside allowed roots"),
        (TOOL_NOT_FOUND, ErrorClass::Tool, "not found"),
        (TOOL_ALREADY_EXISTS, ErrorClass::Tool, "already exists"),
        (TOOL_PATCH_MISMATCH, ErrorClass::Tool, "patch anchor mismatch"),
        (TOOL_TIMEOUT, ErrorClass::Tool, "timeout"),
        (TOOL_NON_ZERO_EXIT, ErrorClass::Tool, "non-zero exit"),
        (TOOL_PERMISSION_DENIED, ErrorClass::Tool, "permission denied"),
        (TOOL_RESOURCE_LIMIT, ErrorClass::Tool, "resource limit"),
        (TOOL_BUDGET_EXHAUSTED, ErrorClass::Tool, "budget exhausted"),
        (TOOL_DISABLED, ErrorClass::Tool, "tool disabled"),
        (TOOL_UNKNOWN, ErrorClass::Tool, "unknown tool"),
        (TOOL_INTERNAL, ErrorClass::Tool, "internal tool error"),
        (SANDBOX_UNAVAILABLE, ErrorClass::Sandbox, "no sandbox backend"),
        (SANDBOX_PATH_DENIED, ErrorClass::Sandbox, "sandbox denied path"),
        (SANDBOX_NET_DENIED, ErrorClass::Sandbox, "sandbox denied network"),
        (SANDBOX_LAUNCH_FAILED, ErrorClass::Sandbox, "sandbox launch failed"),
        (SANDBOX_RESOURCE_LIMIT, ErrorClass::Sandbox, "sandbox resource limit"),
        (SANDBOX_SELF_TEST_FAILED, ErrorClass::Sandbox, "sandbox self-test failed"),
        (STATE_DISK_FULL, ErrorClass::State, "disk full"),
        (STATE_DB_LOCKED, ErrorClass::State, "database locked"),
        (STATE_ROLLOUT_CORRUPT, ErrorClass::State, "rollout corrupt"),
        (STATE_MIGRATION_FAILED, ErrorClass::State, "migration failed"),
        (STATE_SESSION_NOT_FOUND, ErrorClass::State, "session not found"),
        (STATE_AUDIT_TAMPERED, ErrorClass::State, "audit chain tampered"),
        (STATE_BLOB_MISSING, ErrorClass::State, "blob missing"),
        (PROTOCOL_VERSION_MISMATCH, ErrorClass::Protocol, "protocol version mismatch"),
        (PROTOCOL_BAD_FRAME, ErrorClass::Protocol, "bad frame"),
        (PROTOCOL_UNKNOWN_METHOD, ErrorClass::Protocol, "unknown method"),
        (PROTOCOL_ORPHAN_RESPONSE, ErrorClass::Protocol, "orphan response"),
        (ORCH_CYCLE, ErrorClass::Orchestration, "task graph has a cycle"),
        (ORCH_TOO_MANY_NODES, ErrorClass::Orchestration, "too many nodes"),
        (ORCH_BUDGET_EXHAUSTED, ErrorClass::Orchestration, "run budget exhausted"),
        (ORCH_MERGE_CONFLICT, ErrorClass::Orchestration, "merge conflict"),
        (ORCH_LEASE_VIOLATION, ErrorClass::Orchestration, "lease violation"),
        (ORCH_LEASE_DEADLOCK, ErrorClass::Orchestration, "lease deadlock"),
        (ORCH_QUARANTINED, ErrorClass::Orchestration, "worker quarantined"),
        (ORCH_VERIFY_FAILED, ErrorClass::Orchestration, "verify gate failed"),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_code_lives_in_its_family_range() {
        for (code, class, _) in catalogue() {
            assert_eq!(code.class(), Some(class), "{code} misclassified");
            let n = code.number();
            assert!(n >= class.base() && n < class.base() + 1000, "{code} out of range");
        }
    }

    #[test]
    fn codes_are_unique() {
        let mut seen = std::collections::BTreeSet::new();
        for (code, _, _) in catalogue() {
            assert!(seen.insert(code.number()), "duplicate code {code}");
        }
        assert!(seen.len() >= 50, "catalogue shrank: {}", seen.len());
    }

    #[test]
    fn exit_codes_match_the_published_contract() {
        assert_eq!(ExitCode::Ok.as_u8(), 0);
        assert_eq!(ExitCode::Error.as_u8(), 1);
        assert_eq!(ExitCode::Usage.as_u8(), 2);
        assert_eq!(ExitCode::PolicyDenied.as_u8(), 3);
        assert_eq!(ExitCode::SandboxUnavailable.as_u8(), 4);
        assert_eq!(ExitCode::Provider.as_u8(), 5);
        assert_eq!(ExitCode::InvalidInput.as_u8(), 42);
        assert_eq!(ExitCode::BudgetExceeded.as_u8(), 53);
        assert_eq!(ExitCode::Interrupted.as_u8(), 130);
    }

    #[test]
    fn errors_map_to_the_right_exit_code() {
        assert_eq!(ExitCode::for_error(codes::TOOL_PERMISSION_DENIED), ExitCode::PolicyDenied);
        assert_eq!(ExitCode::for_error(codes::SANDBOX_UNAVAILABLE), ExitCode::SandboxUnavailable);
        assert_eq!(ExitCode::for_error(codes::PROVIDER_RATE_LIMITED), ExitCode::Provider);
        assert_eq!(ExitCode::for_error(codes::ORCH_BUDGET_EXHAUSTED), ExitCode::BudgetExceeded);
        assert_eq!(ExitCode::for_error(codes::CONFIG_UNKNOWN_KEY), ExitCode::Usage);
    }

    #[test]
    fn failures_always_carry_a_next_action() {
        for (_, _, msg) in catalogue() {
            assert!(!msg.is_empty());
        }
        let f = AgentFailure::new(codes::SANDBOX_UNAVAILABLE, "no backend", "install bubblewrap or pass --no-sandbox");
        assert!(!f.remediation.is_empty());
        assert!(f.render().contains("E4001"));
        assert!(f.render().contains("install bubblewrap"));
        assert_eq!(f.exit_code(), ExitCode::SandboxUnavailable);
    }

    #[test]
    fn code_string_form_is_stable() {
        assert_eq!(codes::TOOL_PATCH_MISMATCH.code(), "E3005");
        assert_eq!(codes::TOOL_PATCH_MISMATCH.to_string(), "E3005");
    }
}
