//! Protocol version negotiation (`rustplan.txt` §9.1 `src/version_neg.rs`).
//!
//! An old client talking to a new server (or the reverse) must **fail loudly
//! and usefully**, never silently misbehave. Three rules:
//!
//! 1. The wire is additive-only, so a server that speaks `N` also speaks every
//!    version `>= MIN_SUPPORTED` and `<= N`.
//! 2. A client below `MIN_SUPPORTED` is refused with an upgrade hint.
//! 3. A client above the server's version is *accepted* — the server ignores
//!    unknown ops and emits [`crate::event::Event::Unknown`] for unknown
//!    events — but the negotiated version is clamped to what the server can
//!    actually produce, and that clamping is reported back so the client can
//!    warn its user.

use serde::{Deserialize, Serialize};

use crate::error_code::codes::PROTOCOL_VERSION_MISMATCH;
use crate::error_code::{AgentFailure, ErrorCode};

/// Current wire version. Bumped on any *meaning* change; adding fields does
/// not bump it.
pub const VERSION: u32 = crate::PROTOCOL_VERSION;

/// Oldest version this build can still speak to.
pub const MIN_SUPPORTED: u32 = 1;

/// Outcome of a handshake.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Negotiation {
    /// Both sides speak exactly the same version.
    Exact,
    /// The peer is newer; we clamped down to [`VERSION`] and will ignore ops
    /// we do not understand.
    ClampedDown,
    /// The peer is older but still supported; we will avoid emitting fields it
    /// cannot parse.
    PeerOlder,
}

/// The handshake request a client sends first.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct HelloRequest {
    /// Highest version the client can speak.
    pub protocol_version: u32,
    /// Lowest version the client can accept.
    #[serde(default = "one")]
    pub min_version: u32,
    /// Client name, for logs and `agent server --clients`.
    #[serde(default)]
    pub client_name: ClientName,
}

/// Client identification in the handshake (kept out of the string field so the
/// cardinality rule of §10.7 holds).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ClientName {
    /// The built-in terminal UI.
    #[default]
    Tui,
    /// `agent exec` headless mode.
    Exec,
    /// The JSON-RPC app-server (IDE/SDK).
    AppServer,
    /// An editor speaking ACP.
    Acp,
    /// A third-party SDK.
    Sdk,
    /// Another agent calling us over MCP.
    Mcp,
}

const fn one() -> u32 {
    1
}

/// The handshake response.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct HelloResponse {
    /// Version both sides will actually use.
    pub protocol_version: u32,
    /// How it was derived.
    pub negotiation: Negotiation,
    /// Highest version this server speaks.
    pub server_max: u32,
    /// Lowest version this server accepts.
    pub server_min: u32,
    /// Server build version, for support.
    pub server_build: &'static str,
}

/// Error returned when the handshake cannot succeed.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[error("{failure}")]
pub struct Incompatible {
    /// The structured failure, with code and remediation.
    pub failure: AgentFailure,
}

impl Incompatible {
    /// The stable error code.
    #[must_use]
    pub fn code(&self) -> ErrorCode {
        self.failure.code
    }
}

impl HelloRequest {
    /// Build a request for the current version.
    #[must_use]
    pub fn new(client: ClientName) -> Self {
        Self { protocol_version: VERSION, min_version: MIN_SUPPORTED, client_name: client }
    }
}

/// Negotiate from the server side.
///
/// # Errors
/// [`Incompatible`] when the peer's range does not intersect ours. The error
/// always names both ranges so a support engineer can tell which side to
/// upgrade.
pub fn negotiate(req: &HelloRequest) -> Result<HelloResponse, Incompatible> {
    negotiate_with(req, VERSION, MIN_SUPPORTED)
}

/// Negotiate against an explicit server range. Exposed for tests and for the
/// app-server's compatibility mode.
///
/// # Errors
/// [`Incompatible`] when the ranges are disjoint.
pub fn negotiate_with(
    req: &HelloRequest,
    server_max: u32,
    server_min: u32,
) -> Result<HelloResponse, Incompatible> {
    let overlap_hi = req.protocol_version.min(server_max);
    let overlap_lo = req.min_version.max(server_min);

    if overlap_lo > overlap_hi {
        let (client_side, hint) = if req.protocol_version < server_min {
            (
                "client is too old",
                format!("upgrade the client to version {server_min} or newer (`agent update`)"),
            )
        } else {
            (
                "server is too old",
                format!("upgrade the server to version {} or newer, or pin the client to {server_max}", req.min_version),
            )
        };
        return Err(Incompatible {
            failure: AgentFailure::new(
                PROTOCOL_VERSION_MISMATCH,
                format!(
                    "protocol negotiation failed: {client_side}. client speaks {}..={}, server speaks {server_min}..={server_max}",
                    req.min_version, req.protocol_version
                ),
                hint,
            ),
        });
    }

    let negotiation = if overlap_hi == req.protocol_version && req.protocol_version == server_max {
        Negotiation::Exact
    } else if req.protocol_version > server_max {
        Negotiation::ClampedDown
    } else {
        Negotiation::PeerOlder
    };

    Ok(HelloResponse {
        protocol_version: overlap_hi,
        negotiation,
        server_max,
        server_min,
        server_build: crate::BUILD_VERSION,
    })
}

/// Migration shims: rewrite a payload from an older schema version into the
/// current one. Additive-only wire means most migrations are no-ops; the ones
/// that are not are listed here explicitly and tested.
///
/// # Errors
/// Returns the input unchanged when no migration applies; errors only when a
/// payload is structurally unusable.
pub fn migrate(schema_version: u32, mut value: serde_json::Value) -> Result<serde_json::Value, String> {
    let mut v = schema_version;
    while v < VERSION {
        match v {
            // v1 -> v2 (hypothetical): rename `Event::Usage` to
            // `usage_updated`. Kept as a worked example of the shape a shim
            // takes so the next author does not invent a new mechanism.
            1 => {
                if let Some(obj) = value.as_object_mut() {
                    if obj.get("type").and_then(serde_json::Value::as_str) == Some("usage") {
                        obj.insert("type".to_owned(), serde_json::Value::from("usage_updated"));
                    }
                }
            }
            _ => {}
        }
        v += 1;
    }
    Ok(value)
}

/// True when a schema version can be read by this build at all.
#[must_use]
pub const fn is_readable(schema_version: u32) -> bool {
    schema_version >= MIN_SUPPORTED
}

#[cfg(test)]
mod tests {
    use super::*;

    fn req(client_max: u32, client_min: u32) -> HelloRequest {
        HelloRequest { protocol_version: client_max, min_version: client_min, client_name: ClientName::Tui }
    }

    #[test]
    fn identical_versions_negotiate_exactly() {
        let r = negotiate(&req(VERSION, VERSION)).unwrap();
        assert_eq!(r.negotiation, Negotiation::Exact);
        assert_eq!(r.protocol_version, VERSION);
        assert_eq!(r.server_build, crate::BUILD_VERSION);
    }

    #[test]
    fn a_newer_client_is_clamped_down_not_rejected() {
        let r = negotiate(&req(VERSION + 5, VERSION)).unwrap();
        assert_eq!(r.negotiation, Negotiation::ClampedDown);
        assert_eq!(r.protocol_version, VERSION);
    }

    #[test]
    fn an_older_but_supported_client_still_connects() {
        let r = negotiate_with(&req(VERSION, MIN_SUPPORTED), VERSION + 3, MIN_SUPPORTED).unwrap();
        assert_eq!(r.negotiation, Negotiation::PeerOlder);
        assert_eq!(r.protocol_version, VERSION);
    }

    #[test]
    fn a_too_old_client_is_refused_with_an_upgrade_hint() {
        let e = negotiate_with(&req(1, 1), 9, 5).unwrap_err();
        assert_eq!(e.code(), PROTOCOL_VERSION_MISMATCH);
        let msg = e.to_string();
        assert!(msg.contains("client is too old"), "{msg}");
        assert!(msg.contains("1..=1"), "{msg}");
        assert!(msg.contains("5..=9"), "{msg}");
        assert!(e.failure.remediation.contains("agent update"));
    }

    #[test]
    fn a_too_old_server_is_refused_telling_the_user_to_upgrade_the_server() {
        let e = negotiate_with(&req(9, 7), 3, 1).unwrap_err();
        let msg = e.to_string();
        assert!(msg.contains("server is too old"), "{msg}");
        assert!(e.failure.remediation.contains("upgrade the server"), "{:?}", e.failure.remediation);
    }

    #[test]
    fn overlapping_ranges_pick_the_highest_common_version() {
        let r = negotiate_with(&req(8, 4), 6, 2).unwrap();
        assert_eq!(r.protocol_version, 6);
    }

    #[test]
    fn migration_is_a_noop_at_the_current_version() {
        let v = serde_json::json!({"type": "text_delta"});
        assert_eq!(migrate(VERSION, v.clone()).unwrap(), v);
    }

    #[test]
    fn readability_follows_the_minimum() {
        assert!(is_readable(MIN_SUPPORTED));
        assert!(is_readable(VERSION));
        assert!(!is_readable(0));
    }

    #[test]
    fn version_constants_are_consistent() {
        assert!(VERSION >= MIN_SUPPORTED);
        assert_eq!(VERSION, crate::PROTOCOL_VERSION);
    }
}
