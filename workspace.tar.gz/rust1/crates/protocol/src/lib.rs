//! # `agent-protocol` — wire contracts for the terminal AI agent
//!
//! This crate is the *only* thing every other crate is allowed to depend on,
//! and it contains **types and pure functions only**: no I/O, no async, no
//! global state, no provider knowledge (`rustplan.txt` §5.2).
//!
//! ```text
//! protocol  ← (everyone)      types only, zero logic
//! core      ← tui, cli, server
//! core      → model, context, tools, state, policy, exec
//! tools     → exec, sandbox, policy, index, git
//! tui       → protocol, core   ✗ tui never sees a `tools` type
//! server    → protocol, core   ✗ server never sees a `tui` type
//! ```
//!
//! ## What lives here
//!
//! | Module | Contract |
//! |---|---|
//! | [`op`] | client → agent operations (§10.1) |
//! | [`event`] | agent → client events, 35 in 6 families (§10.2) |
//! | [`message`] | provider-neutral conversation IR (§6.3.1) |
//! | [`content`] | content blocks: text, image, diff, terminal |
//! | [`tool`] | tool calls, results, model-actionable errors (§10.3) |
//! | [`permission`] | modes, decisions, approval requests (§3.2) |
//! | [`model`] | model ids, descriptors, capabilities, pricing |
//! | [`usage`] | token and cost accounting in integer micros |
//! | [`ids`] | ULID newtypes (sortable, type-safe) |
//! | [`config_types`] | the full serde config schema (§3.6) |
//! | [`error_code`] | the frozen `E1xxx`–`E7xxx` taxonomy (§10.6) |
//! | [`plan`] / [`worker`] | parallel subagent DAG + report protocol (§7) |
//! | [`context_types`] | section kinds, compaction ladder, memory layers (§6.1) |
//! | [`render_hint`] | the tools → UI bridge (golden rule from §4.1) |
//! | [`glob_match`] | path globs and argv patterns (§10.4) |
//! | [`truncate`] / [`ansi`] | grapheme-safe truncation, escape stripping |
//! | [`token_estimate`] | the shared token estimator (§6.1.1) |
//! | [`schema_export`] | JSON Schema + TS/Python stubs (§9.1) |
//! | [`acp_types`] | Agent Client Protocol mapping (§9.1) |
//! | [`version_neg`] | handshake and migration shims |
//!
//! ## Compatibility contract
//!
//! Wire types are **additive only**. A variant may gain a `#[serde(default)]`
//! field; it may never be renamed or removed. Clients must ignore unknown
//! variants — every catalogue enum has an `Unknown` member that preserves the
//! raw JSON so an older build can replay a newer rollout losslessly.
//!
//! ## Semver rule for `PROTOCOL_VERSION`
//!
//! * Additive field or new variant → **no bump**.
//! * Changed meaning, renamed field, removed variant → **bump**, plus a
//!   migration shim in [`version_neg::migrate`].

#![warn(missing_docs)]
#![forbid(unsafe_code)]

pub mod acp_types;
pub mod ansi;
pub mod config_types;
pub mod content;
pub mod context_types;
pub mod error_code;
pub mod event;
pub mod glob_match;
pub mod ids;
pub mod message;
pub mod model;
pub mod op;
pub mod permission;
pub mod plan;
pub mod render_hint;
pub mod schema_export;
pub mod token_estimate;
pub mod tool;
pub mod truncate;
pub mod usage;
pub mod version_neg;
pub mod worker;

pub use config_types::AgentConfig;
pub use content::ContentPart;
pub use error_code::{AgentFailure, ErrorCode, ExitCode};
pub use event::{Event, EventEnvelope, EventFamily};
pub use ids::{
    BlobId, CallId, EventId, OpId, ParseIdError, RequestId, RunId, SessionId, TaskId, ThreadId,
    TurnId, WorkerId,
};
pub use message::{Message, Role, StopReason};
pub use model::{ModelCaps, ModelDescriptor, ModelId, ModelRole, ModelTier, Pricing};
pub use op::{Op, OpEnvelope, SubmitOp};
pub use permission::{Decision, Mode, ModeDecision, PermissionRequest, SandboxStatus};
pub use plan::{IsolationLevel, NodeKind, TaskNode, TaskPlan};
pub use render_hint::{RenderHint, RenderKind};
pub use tool::{DeniedBy, RiskClass, ToolCall, ToolDescriptor, ToolError, ToolErrorKind, ToolResult};
pub use truncate::Truncated;
pub use usage::Usage;
pub use worker::{WorkerReport, WorkerState, WorkerStatus};

/// Version of the wire protocol this build speaks.
///
/// See the semver rule in the crate docs: additive changes do **not** bump
/// this.
pub const PROTOCOL_VERSION: u32 = 1;

/// Build version string, from `Cargo.toml`.
pub const BUILD_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Product name used in paths, prompts and the audit trail.
pub const PRODUCT: &str = "agent";

/// Milliseconds since the unix epoch, saturating at 0 on a clock before 1970.
///
/// A single clock accessor so that `core/src/clock.rs` can swap in a frozen
/// clock for deterministic tests without every call site knowing about it.
#[must_use]
pub fn now_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| u64::try_from(d.as_millis()).unwrap_or(u64::MAX))
        .unwrap_or(0)
}

/// ISO-8601 UTC timestamp with millisecond precision, as used in the JSONL
/// rollout (§10.5) and the audit chain.
#[must_use]
pub fn iso_now() -> String {
    iso_from_ms(now_ms())
}

/// ISO-8601 UTC timestamp for an explicit millisecond value.
///
/// # Panics
/// Never: out-of-range values clamp to the representable window.
#[must_use]
pub fn iso_from_ms(ms: u64) -> String {
    use chrono::{DateTime, TimeZone, Utc};
    let secs = i64::try_from(ms / 1000).unwrap_or(i64::MAX);
    let nanos = u32::try_from((ms % 1000) * 1_000_000).unwrap_or(0);
    Utc.timestamp_opt(secs, nanos)
        .single()
        .unwrap_or_else(|| DateTime::<Utc>::from_timestamp(0, 0).unwrap_or_default())
        .format("%Y-%m-%dT%H:%M:%S%.3fZ")
        .to_string()
}

/// The default on-disk layout (§3.5), resolved against the real home
/// directory. Returns `None` for a component when the platform has no home.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Layout {
    /// `~/.config/agent` — config.toml, AGENTS.md, hooks/, skills/, commands/
    pub config: std::path::PathBuf,
    /// `~/.local/share/agent` — sessions/*.jsonl, index.sqlite, blobs/, logs/
    pub data: std::path::PathBuf,
    /// `~/.cache/agent` — repo-map tags, schema cache, completions
    pub cache: std::path::PathBuf,
    /// `<repo>/.agent` — project config, rules/, commands/, agents/
    pub project: std::path::PathBuf,
}

impl Layout {
    /// Resolve the layout for a workspace at `cwd`, honouring the platform's
    /// XDG conventions where they exist.
    #[must_use]
    pub fn discover(cwd: &std::path::Path) -> Option<Self> {
        let home = home_dir()?;
        Some(Self::from_env(&home, cwd))
    }

    /// Pure resolution from explicit inputs. Split out from [`Layout::discover`]
    /// so the XDG precedence rules are unit-testable without mutating process
    /// environment (which is unsafe in a multithreaded test binary).
    #[must_use]
    pub fn from_env(home: &std::path::Path, cwd: &std::path::Path) -> Self {
        Self::resolve(
            home,
            cwd,
            std::env::var_os("XDG_CONFIG_HOME").map(std::path::PathBuf::from).as_deref(),
            std::env::var_os("XDG_DATA_HOME").map(std::path::PathBuf::from).as_deref(),
            std::env::var_os("XDG_CACHE_HOME").map(std::path::PathBuf::from).as_deref(),
        )
    }

    /// Fully pure resolution; `xdg_*` are the (possibly absent, possibly
    /// relative and therefore ignored) XDG base directories.
    #[must_use]
    pub fn resolve(
        home: &std::path::Path,
        cwd: &std::path::Path,
        xdg_config: Option<&std::path::Path>,
        xdg_data: Option<&std::path::Path>,
        xdg_cache: Option<&std::path::Path>,
    ) -> Self {
        let pick = |xdg: Option<&std::path::Path>, fallback: std::path::PathBuf| {
            xdg.filter(|p| p.is_absolute()).map_or(fallback, std::path::Path::to_path_buf).join(PRODUCT)
        };
        Self {
            config: pick(xdg_config, home.join(".config")),
            data: pick(xdg_data, home.join(".local").join("share")),
            cache: pick(xdg_cache, home.join(".cache")),
            project: cwd.join(format!(".{PRODUCT}")),
        }
    }

    /// Sessions directory.
    #[must_use]
    pub fn sessions(&self) -> std::path::PathBuf {
        self.data.join("sessions")
    }

    /// Blob store directory.
    #[must_use]
    pub fn blobs(&self) -> std::path::PathBuf {
        self.data.join("blobs")
    }

    /// Log directory.
    #[must_use]
    pub fn logs(&self) -> std::path::PathBuf {
        self.data.join("logs")
    }

    /// Audit chain directory.
    #[must_use]
    pub fn audit(&self) -> std::path::PathBuf {
        self.data.join("audit")
    }

    /// Worktree directory for parallel workers.
    #[must_use]
    pub fn worktrees(&self) -> std::path::PathBuf {
        self.data.join("worktrees")
    }

    /// SQLite index path.
    #[must_use]
    pub fn index_db(&self) -> std::path::PathBuf {
        self.data.join("index.sqlite")
    }
}

/// The user's home directory, without pulling in a dependency.
#[must_use]
pub fn home_dir() -> Option<std::path::PathBuf> {
    if let Some(h) = std::env::var_os("HOME").filter(|h| !h.is_empty()) {
        return Some(std::path::PathBuf::from(h));
    }
    if let Some(p) = std::env::var_os("USERPROFILE").filter(|p| !p.is_empty()) {
        return Some(std::path::PathBuf::from(p));
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_constants_are_exported() {
        assert!(PROTOCOL_VERSION >= 1);
        assert!(!BUILD_VERSION.is_empty());
        assert_eq!(version_neg::VERSION, PROTOCOL_VERSION);
    }

    #[test]
    fn now_ms_is_monotonic_enough_for_ids() {
        let a = now_ms();
        std::thread::sleep(std::time::Duration::from_millis(2));
        let b = now_ms();
        assert!(b >= a);
        assert!(a > 1_700_000_000_000, "clock looks wrong: {a}");
    }

    #[test]
    fn iso_timestamps_are_utc_and_millisecond_precision() {
        let s = iso_from_ms(1_761_800_000_000);
        assert!(s.ends_with('Z'), "{s}");
        assert_eq!(s.len(), 24, "{s}");
        assert!(s.contains('T'), "{s}");
        // Round-trip through chrono.
        let parsed = chrono::DateTime::parse_from_rfc3339(&s).unwrap();
        assert_eq!(parsed.timestamp_millis(), 1_761_800_000_000);
    }

    #[test]
    fn iso_now_is_parseable() {
        let s = iso_now();
        assert!(chrono::DateTime::parse_from_rfc3339(&s).is_ok(), "{s}");
    }

    #[test]
    fn layout_is_xdg_aware() {
        let l = Layout::discover(std::path::Path::new("/repo")).expect("HOME must be set in tests");
        assert!(l.config.ends_with("agent"), "{:?}", l.config);
        assert!(l.data.ends_with("agent"), "{:?}", l.data);
        assert_eq!(l.project, std::path::PathBuf::from("/repo/.agent"));
        assert!(l.sessions().ends_with("agent/sessions"));
        assert!(l.index_db().to_string_lossy().ends_with("index.sqlite"));
        assert!(l.worktrees().to_string_lossy().ends_with("worktrees"));
    }

    #[test]
    fn layout_honours_absolute_xdg_overrides() {
        let home = std::path::Path::new("/home/u");
        let cwd = std::path::Path::new("/repo");
        let l = Layout::resolve(
            home,
            cwd,
            Some(std::path::Path::new("/etc/xdg/conf")),
            Some(std::path::Path::new("/tmp/xdg-test")),
            None,
        );
        assert_eq!(l.config, std::path::PathBuf::from("/etc/xdg/conf/agent"));
        assert_eq!(l.data, std::path::PathBuf::from("/tmp/xdg-test/agent"));
        assert_eq!(l.cache, std::path::PathBuf::from("/home/u/.cache/agent"));
        assert_eq!(l.project, std::path::PathBuf::from("/repo/.agent"));
    }

    #[test]
    fn relative_xdg_values_are_ignored() {
        // A relative XDG_DATA_HOME is a misconfiguration; falling back to the
        // home-derived path is safer than writing into the cwd.
        let l = Layout::resolve(
            std::path::Path::new("/home/u"),
            std::path::Path::new("/repo"),
            None,
            Some(std::path::Path::new("relative/dir")),
            None,
        );
        assert_eq!(l.data, std::path::PathBuf::from("/home/u/.local/share/agent"));
    }
}
