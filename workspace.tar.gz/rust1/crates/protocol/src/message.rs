//! Provider-neutral message IR (`rustplan.txt` §9.1 `src/message.rs`, §6.3.1).
//!
//! Every provider adapter *only* translates to and from this representation.
//! Nothing provider-specific may appear here: no `cache_control`, no
//! `reasoning_effort`, no `stop_sequences`. That rule is what keeps one turn
//! loop working across Anthropic Messages, OpenAI Responses/Chat, Gemini
//! generateContent, Bedrock Converse and any OpenAI-compatible endpoint.
//!
//! The IR also owns **normalisation**: providers differ in whether they accept
//! two consecutive user messages, whether tool results must be their own
//! message, and whether an assistant message may be empty. [`normalize`] fixes
//! all of that once, so adapters stay thin.

use serde::{Deserialize, Serialize};

use crate::content::ContentPart;
use crate::ids::CallId;
use crate::tool::{ToolCall, ToolResult};

/// Who produced a message.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Role {
    /// The user (or the harness speaking on the user's behalf).
    User,
    /// The model.
    Assistant,
    /// A tool result being fed back. Providers that lack a `tool` role map
    /// this onto `user` with a `tool_result` content block.
    Tool,
    /// System instructions. Kept as a role so the assembler can move system
    /// content in and out of the message list per provider capability.
    System,
}

impl Role {
    /// True when the model may produce this role.
    #[must_use]
    pub const fn is_model_side(self) -> bool {
        matches!(self, Role::Assistant)
    }

    /// True when this role counts against the prompt (input) token budget.
    #[must_use]
    pub const fn is_prompt_side(self) -> bool {
        !matches!(self, Role::Assistant)
    }
}

impl std::fmt::Display for Role {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Role::User => "user",
            Role::Assistant => "assistant",
            Role::Tool => "tool",
            Role::System => "system",
        })
    }
}

/// One message in the conversation.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Message {
    /// Producer.
    pub role: Role,
    /// Content blocks in presentation order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub parts: Vec<ContentPart>,
    /// Tool calls requested by an assistant message. Stored separately from
    /// `parts` because providers place them in different fields.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tool_calls: Vec<ToolCall>,
    /// Why the assistant stopped (`stop`, `tool_use`, `length`, …). `None` for
    /// non-assistant messages.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stop_reason: Option<StopReason>,
    /// Model that produced this message, for multi-model sessions.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<crate::model::ModelId>,
    /// Per-message usage, when the provider reported it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub usage: Option<crate::usage::Usage>,
    /// Milliseconds since epoch. Used for retention/GC, not for ordering
    /// (ordering is the vec index — see §9.4 `session/history.rs`).
    #[serde(default)]
    pub ts_ms: u64,
    /// Set when compaction replaced this message's content. The parts are gone
    /// but the index is preserved so ids stay stable (golden rule: history is
    /// never rewritten).
    #[serde(default)]
    pub compacted: bool,
    /// Call ids this message answers (tool-role messages only). Kept outside
    /// `parts` so adapters can build the provider's `tool_call_id` field
    /// without walking content blocks.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tool_result_ids: Vec<CallId>,
}

/// Why a model stopped generating.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StopReason {
    /// Natural end of turn.
    Stop,
    /// The model wants to call tools.
    ToolUse,
    /// Output token cap reached — the turn must continue or be truncated.
    Length,
    /// Provider-side content filter.
    ContentFilter,
    /// The stream was interrupted (cancel, network).
    Interrupted,
    /// The provider did not say.
    Unknown,
}

impl StopReason {
    /// True when the turn should continue (tool execution or continuation).
    #[must_use]
    pub const fn continues_turn(self) -> bool {
        matches!(self, StopReason::ToolUse | StopReason::Length)
    }
}

impl Message {
    /// A user text message.
    #[must_use]
    pub fn user(text: impl Into<String>) -> Self {
        Self::new(Role::User, vec![ContentPart::text(text)])
    }

    /// An assistant text message.
    #[must_use]
    pub fn assistant(text: impl Into<String>) -> Self {
        Self { stop_reason: Some(StopReason::Stop), ..Self::new(Role::Assistant, vec![ContentPart::text(text)]) }
    }

    /// An assistant message that only requests tool calls.
    #[must_use]
    pub fn assistant_tool_calls(calls: Vec<ToolCall>) -> Self {
        Self {
            stop_reason: Some(StopReason::ToolUse),
            tool_calls: calls,
            ..Self::new(Role::Assistant, Vec::new())
        }
    }

    /// A system instruction message.
    #[must_use]
    pub fn system(text: impl Into<String>) -> Self {
        Self::new(Role::System, vec![ContentPart::text(text)])
    }

    /// Wrap a single tool result into a tool-role message.
    #[must_use]
    pub fn tool_result(result: ToolResult) -> Self {
        let call_id = match &result {
            ToolResult::Ok { call_id, .. }
            | ToolResult::Err { call_id, .. }
            | ToolResult::Denied { call_id, .. } => *call_id,
        };
        let part = ContentPart::ToolResult(result);
        let mut m = Self::new(Role::Tool, vec![part]);
        m.tool_result_ids.push(call_id);
        m
    }

    /// Generic constructor.
    #[must_use]
    pub fn new(role: Role, parts: Vec<ContentPart>) -> Self {
        Self {
            role,
            parts,
            tool_calls: Vec::new(),
            stop_reason: None,
            model: None,
            usage: None,
            ts_ms: crate::now_ms(),
            compacted: false,
            tool_result_ids: Vec::new(),
        }
    }

    /// All text in this message, concatenated.
    #[must_use]
    pub fn text(&self) -> String {
        self.parts
            .iter()
            .filter_map(|p| match p {
                ContentPart::Text { text } => Some(text.as_str()),
                _ => None,
            })
            .collect::<Vec<_>>()
            .join("\n")
    }

    /// True when the message carries nothing the model can read.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.parts.is_empty() && self.tool_calls.is_empty()
    }

    /// Rough token estimate for budgeting. Delegates to the shared estimator
    /// so the ledger and the assembler agree (§6.1.1 drift tracking).
    #[must_use]
    pub fn estimate_tokens(&self) -> u32 {
        let mut bytes = 0usize;
        for p in &self.parts {
            bytes += p.inline_bytes();
        }
        for c in &self.tool_calls {
            bytes += c.name.len() + c.args.to_string().len();
        }
        crate::token_estimate::from_bytes(bytes)
    }
}

/// Merge consecutive messages from the same role into one.
///
/// Providers disagree here: Anthropic tolerates consecutive user messages,
/// Gemini does not, and OpenAI Chat is fine with either but bills the extra
/// framing tokens. Normalising once in the IR means adapters never have to
/// think about it, and the cache-stable prefix stays byte-identical longer.
#[must_use]
pub fn normalize(messages: Vec<Message>) -> Vec<Message> {
    let mut out: Vec<Message> = Vec::with_capacity(messages.len());
    for m in messages {
        if m.is_empty() && !matches!(m.role, Role::Assistant) {
            continue; // drop empty user/tool noise
        }
        let can_merge = match out.last() {
            Some(prev) => {
                prev.role == m.role
                    && !matches!(m.role, Role::Assistant)
                    && prev.stop_reason.is_none()
                    && m.stop_reason.is_none()
                    && !prev.compacted
                    && !m.compacted
            }
            None => false,
        };
        if can_merge {
            let prev = out.last_mut().expect("checked non-empty above");
            // Two *distinct* messages are separate utterances: join them with a
            // newline so "hello" + "world" does not become "helloworld".
            // (Adjacent parts *within* one message are concatenated verbatim in
            // the second pass, which is what streaming deltas need.)
            if !prev.parts.is_empty() && !m.parts.is_empty() {
                prev.parts.push(ContentPart::text("\n"));
            }
            prev.parts.extend(m.parts);
            prev.tool_result_ids.extend(m.tool_result_ids);
        } else {
            out.push(m);
        }
    }

    // Second pass: fold adjacent Text parts inside a single message. This is
    // what keeps streaming deltas from exploding into hundreds of blocks.
    for m in &mut out {
        let mut folded: Vec<ContentPart> = Vec::with_capacity(m.parts.len());
        for p in m.parts.drain(..) {
            match (&mut folded.last_mut(), &p) {
                (Some(ContentPart::Text { text }), ContentPart::Text { text: more }) => {
                    text.push_str(more);
                }
                _ => folded.push(p),
            }
        }
        m.parts = folded;
    }
    out
}

/// Ensure every assistant `tool_use` is followed by a matching `tool_result`.
///
/// An unmatched tool call is a hard provider error (400) on Anthropic and
/// OpenAI alike. When a turn is cancelled mid-tool we would otherwise produce
/// exactly that on the next request, so the resume path calls this to inject a
/// synthetic "interrupted" result. Returns the number of stubs inserted.
pub fn repair_unmatched_tool_results(messages: &mut Vec<Message>) -> usize {
    let mut missing: Vec<CallId> = Vec::new();
    for (i, m) in messages.iter().enumerate() {
        if m.role != Role::Assistant {
            continue;
        }
        for call in &m.tool_calls {
            let answered = messages[i + 1..].iter().any(|later| {
                later.role == Role::Tool && later.tool_result_ids.contains(&call.id)
            });
            if !answered {
                missing.push(call.id);
            }
        }
    }
    let n = missing.len();
    if n == 0 {
        return 0;
    }
    // Insert one tool message carrying all the stubs, right after the last
    // assistant message that had a gap.
    let insert_at = messages
        .iter()
        .rposition(|m| m.role == Role::Assistant && m.tool_calls.iter().any(|c| missing.contains(&c.id)))
        .map_or(messages.len(), |i| i + 1);

    let mut stub = Message::new(
        Role::Tool,
        missing
            .iter()
            .map(|id| {
                ContentPart::ToolResult(ToolResult::Denied {
                    call_id: *id,
                    by: crate::tool::DeniedBy::User,
                    reason: "interrupted before the tool ran".to_owned(),
                })
            })
            .collect(),
    );
    stub.tool_result_ids = missing;
    messages.insert(insert_at, stub);
    n
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ids::CallId;
    use serde_json::json;

    #[test]
    fn consecutive_user_messages_merge() {
        let v = normalize(vec![
            Message::user("hello"),
            Message::user("world"),
            Message::assistant("hi"),
            Message::user("again"),
        ]);
        assert_eq!(v.len(), 3);
        assert_eq!(v[0].text(), "hello\nworld");
        assert_eq!(v[1].role, Role::Assistant);
        assert_eq!(v[2].text(), "again");
    }

    #[test]
    fn adjacent_text_parts_fold_inside_one_message() {
        let m = Message::new(
            Role::Assistant,
            vec![ContentPart::text("a"), ContentPart::text("b"), ContentPart::text("c")],
        );
        let v = normalize(vec![m]);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].parts.len(), 1);
        assert_eq!(v[0].text(), "abc");
    }

    #[test]
    fn assistant_messages_never_merge() {
        let mut a = Message::assistant("one");
        let mut b = Message::assistant("two");
        a.stop_reason = None;
        b.stop_reason = None;
        let v = normalize(vec![a, b]);
        assert_eq!(v.len(), 2, "merging assistants would lose stop_reason fidelity");
    }

    #[test]
    fn empty_user_messages_are_dropped() {
        let v = normalize(vec![Message::new(Role::User, vec![]), Message::user("real")]);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].text(), "real");
    }

    #[test]
    fn unmatched_tool_calls_get_a_stub_result() {
        let id = CallId::new();
        let call = ToolCall::new(id, "read_file", json!({"path": "a"}), crate::tool::RiskClass::Read);
        let mut msgs = vec![Message::user("go"), Message::assistant_tool_calls(vec![call])];
        let n = repair_unmatched_tool_results(&mut msgs);
        assert_eq!(n, 1);
        assert_eq!(msgs.len(), 3);
        assert_eq!(msgs[2].role, Role::Tool);
        assert_eq!(msgs[2].tool_result_ids, vec![id]);
        // Idempotent: a second pass finds nothing.
        assert_eq!(repair_unmatched_tool_results(&mut msgs), 0);
    }

    #[test]
    fn matched_tool_calls_are_left_alone() {
        let id = CallId::new();
        let call = ToolCall::new(id, "read_file", json!({}), crate::tool::RiskClass::Read);
        let mut msgs = vec![
            Message::user("go"),
            Message::assistant_tool_calls(vec![call]),
            Message::tool_result(ToolResult::ok_text(id, "ok", "contents")),
        ];
        assert_eq!(repair_unmatched_tool_results(&mut msgs), 0);
        assert_eq!(msgs.len(), 3);
    }

    #[test]
    fn tool_result_message_carries_its_call_id() {
        let id = CallId::new();
        let m = Message::tool_result(ToolResult::ok_text(id, "s", "t"));
        assert_eq!(m.role, Role::Tool);
        assert_eq!(m.tool_result_ids, vec![id]);
    }

    #[test]
    fn stop_reason_drives_turn_continuation() {
        assert!(StopReason::ToolUse.continues_turn());
        assert!(StopReason::Length.continues_turn());
        assert!(!StopReason::Stop.continues_turn());
        assert!(!StopReason::ContentFilter.continues_turn());
    }

    #[test]
    fn token_estimate_is_proportional_to_size() {
        let small = Message::user("hi");
        let big = Message::user("x".repeat(4000));
        assert!(big.estimate_tokens() > small.estimate_tokens() * 10);
    }

    #[test]
    fn message_serde_omits_empty_optional_fields() {
        let v = serde_json::to_value(Message::user("hi")).unwrap();
        assert_eq!(v["role"], "user");
        assert!(v.get("tool_calls").is_none(), "{v}");
        assert!(v.get("stop_reason").is_none(), "{v}");
    }
}
