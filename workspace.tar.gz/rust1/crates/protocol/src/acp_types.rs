//! Agent Client Protocol (ACP) mapping (`rustplan.txt` §9.1 `src/acp_types.rs`,
//! §9.14 `server/src/acp/*`).
//!
//! ACP is the editor↔agent protocol used by Zed and friends: JSON-RPC 2.0 over
//! stdio, with `session/new`, `session/prompt` and a `session/update`
//! notification stream. This module owns the *translation* between our IR
//! ([`crate::event::Event`]) and ACP payloads so that `server/src/acp/mod.rs`
//! is a thin router.
//!
//! Two rules matter:
//! * **Unknown fields are preserved** (`#[serde(flatten)]` extra maps) so a
//!   newer editor does not lose data round-tripping through us.
//! * **Nothing editor-specific leaks into `core`.** The mapping is one-way and
//!   lives here.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::content::{Diff, FileChange};
use crate::event::{Event, ToolCompleted, ToolDenied, ToolFailed, ToolRequested};
use crate::ids::{RequestId, ThreadId};
use crate::permission::{Decision, PermissionRequest};
use crate::tool::RiskClass;

/// ACP protocol version we implement.
pub const ACP_VERSION: u32 = 1;

/// Catch-all for fields we do not model yet.
pub type Extra = BTreeMap<String, Value>;

// ── session/update notifications ────────────────────────────────────────────

/// The `session/update` notification body.
///
/// Deserialisation is hand-written (see the `impl Deserialize` below) rather
/// than derived with `#[serde(other)]`, because serde cannot combine
/// `other` with `#[serde(flatten)]` inside a variant — and preserving unknown
/// fields is a hard requirement for editor interop.
#[derive(Debug, Clone, PartialEq, Serialize)]
#[serde(tag = "sessionUpdate", rename_all = "camelCase")]
pub enum SessionUpdate {
    /// A chunk of agent message text.
    AgentMessageChunk(ContentChunk),
    /// A chunk of agent thinking (only sent when the client opted in).
    AgentThoughtChunk(ContentChunk),
    /// A tool call was created / is in progress / finished.
    ToolCall(ToolCallUpdate),
    /// The plan changed.
    Plan(PlanUpdate),
    /// The set of available commands changed.
    AvailableCommandsUpdate(CommandsUpdate),
    /// A notification we do not model. Preserved so a newer editor's stream
    /// never breaks an older agent.
    Unknown,
}

impl<'de> Deserialize<'de> for SessionUpdate {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        // Decode through `serde_json::Value` and dispatch on the discriminator
        // by hand. Two reasons:
        //   1. serde cannot combine an internally tagged enum variant with
        //      `#[serde(flatten)]` inside it, and flattening is how we preserve
        //      fields a newer editor sends that we do not model yet;
        //   2. an unrecognised `sessionUpdate` must degrade to `Unknown`
        //      instead of failing the whole notification stream.
        let v = Value::deserialize(d)?;
        let tag = v.get("sessionUpdate").and_then(Value::as_str).unwrap_or("");
        let decoded = match tag {
            "agent_message_chunk" => serde_json::from_value(v).map(SessionUpdate::AgentMessageChunk),
            "agent_thought_chunk" => serde_json::from_value(v).map(SessionUpdate::AgentThoughtChunk),
            "tool_call" | "tool_call_update" => {
                serde_json::from_value(v).map(SessionUpdate::ToolCall)
            }
            "plan" => serde_json::from_value(v).map(SessionUpdate::Plan),
            "available_commands_update" => {
                serde_json::from_value(v).map(SessionUpdate::AvailableCommandsUpdate)
            }
            _ => return Ok(SessionUpdate::Unknown),
        };
        // A *known* tag whose payload we cannot parse is still `Unknown`
        // rather than an error: dropping one notification beats killing the
        // editor session.
        Ok(decoded.unwrap_or(SessionUpdate::Unknown))
    }
}

/// A content chunk.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ContentChunk {
    /// The session this chunk belongs to.
    pub session_id: String,
    /// Content blocks.
    pub content: Vec<AcpContent>,
    /// Unmodelled fields.
    #[serde(flatten)]
    pub extra: Extra,
}

/// ACP content block.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum AcpContent {
    /// Text.
    Text {
        /// The text.
        text: String,
        /// Optional annotations.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        annotations: Option<Value>,
    },
    /// An image, base64.
    Image {
        /// Base64 payload.
        data: String,
        /// MIME type.
        mime_type: String,
    },
    /// A resource link.
    ResourceLink {
        /// URI.
        uri: String,
        /// Display name.
        name: String,
        /// MIME type.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        mime_type: Option<String>,
    },
    /// An embedded resource.
    EmbeddedResource {
        /// The resource.
        resource: Value,
    },
}

impl AcpContent {
    /// Text payload if this is a text block.
    #[must_use]
    pub fn as_text(&self) -> Option<&str> {
        match self {
            AcpContent::Text { text, .. } => Some(text),
            _ => None,
        }
    }
}

/// Tool call status in ACP.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AcpToolStatus {
    /// Queued, not started.
    Pending,
    /// Running.
    InProgress,
    /// Finished successfully.
    Completed,
    /// Finished with an error.
    Failed,
}

/// What kind of tool call this is, so the editor can pick an icon.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AcpToolKind {
    /// Reads a file.
    Read,
    /// Edits a file.
    Edit,
    /// Deletes something.
    Delete,
    /// Moves/renames.
    Move,
    /// Searches.
    Search,
    /// Runs a command.
    Execute,
    /// Network access.
    Fetch,
    /// Switches the user's mental mode.
    SwitchMode,
    /// Something else.
    Other,
}

impl AcpToolKind {
    /// Map our risk class onto the ACP kind vocabulary.
    #[must_use]
    pub fn from_risk(risk: RiskClass) -> Self {
        match risk {
            RiskClass::Read => AcpToolKind::Read,
            RiskClass::Mutate => AcpToolKind::Edit,
            RiskClass::Destructive => AcpToolKind::Delete,
            RiskClass::Exec => AcpToolKind::Execute,
            RiskClass::Network => AcpToolKind::Fetch,
            RiskClass::Spawn | RiskClass::Meta => AcpToolKind::Other,
        }
    }
}

/// A `tool_call` update.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolCallUpdate {
    /// Session.
    pub session_id: String,
    /// Our call id, used as the ACP tool call id.
    pub tool_call_id: String,
    /// Human readable title.
    pub title: String,
    /// Kind.
    pub kind: AcpToolKind,
    /// Status.
    pub status: AcpToolStatus,
    /// Raw input, if the client asked for it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub raw_input: Option<Value>,
    /// Raw output.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub raw_output: Option<Value>,
    /// Structured content for editors that render it (diffs!).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub content: Vec<AcpContent>,
    /// File-system locations touched.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub locations: Vec<ToolLocation>,
    /// Unmodelled fields.
    #[serde(flatten)]
    pub extra: Extra,
}

/// A file location a tool touched.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolLocation {
    /// `file://` URI.
    pub path: String,
    /// First line (1-based), if known.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub line: Option<u64>,
}

/// A plan update.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PlanUpdate {
    /// Session.
    pub session_id: String,
    /// The entries.
    pub entries: Vec<PlanEntry>,
}

/// One plan entry.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PlanEntry {
    /// Text.
    pub content: String,
    /// Priority.
    #[serde(default)]
    pub priority: PlanPriority,
    /// Status.
    pub status: PlanEntryStatus,
}

/// Plan entry priority.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum PlanPriority {
    /// Nice to have.
    Low,
    /// Normal.
    #[default]
    Medium,
    /// Must happen.
    High,
}

/// Plan entry status.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum PlanEntryStatus {
    /// Not started.
    Pending,
    /// Running.
    InProgress,
    /// Done.
    Completed,
}

/// A `available_commands_update`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CommandsUpdate {
    /// Session.
    pub session_id: String,
    /// Available slash commands.
    pub available_commands: Vec<AcpCommand>,
}

/// One slash command advertised to the editor.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcpCommand {
    /// Name without the leading slash.
    pub name: String,
    /// One-line description.
    pub description: String,
    /// Argument hint.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input: Option<Value>,
}

// ── permission requests ─────────────────────────────────────────────────────

/// A `session/request_permission` request body.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcpPermissionRequest {
    /// Session.
    pub session_id: String,
    /// Tool call ids this decision applies to.
    pub tool_call: Vec<String>,
    /// Human readable options.
    pub options: Vec<AcpPermissionOption>,
    /// Unmodelled fields.
    #[serde(flatten)]
    pub extra: Extra,
}

/// One selectable option.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcpPermissionOption {
    /// Stable id echoed back in the response.
    pub option_id: String,
    /// Label.
    pub name: String,
    /// What choosing it means.
    pub kind: AcpOptionKind,
}

/// Semantics of an option.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AcpOptionKind {
    /// Allow this once.
    AllowOnce,
    /// Allow and remember.
    AllowAlways,
    /// Deny this once.
    RejectOnce,
    /// Deny and remember.
    RejectAlways,
}

/// The editor's answer.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcpPermissionResponse {
    /// The chosen option id, or `"cancelled"`/`"dismissed"`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub outcome: Option<AcpOutcome>,
    /// Unmodelled fields.
    #[serde(flatten)]
    pub extra: Extra,
}

/// Outcome wrapper.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "outcome", rename_all = "camelCase")]
pub enum AcpOutcome {
    /// An option was selected.
    Selected {
        /// The option id.
        option_id: String,
    },
    /// The user cancelled.
    Cancelled,
}

/// Build the ACP permission request for one of our [`PermissionRequest`]s.
///
/// The four options are always offered in the same order so editors can bind
/// keys positionally. The **default is reject-once** (§3.2: Enter = deny).
#[must_use]
pub fn to_acp_permission(session_id: &str, req: &PermissionRequest) -> AcpPermissionRequest {
    AcpPermissionRequest {
        session_id: session_id.to_owned(),
        tool_call: vec![req.request_id.to_string()],
        options: vec![
            AcpPermissionOption {
                option_id: "allow_once".into(),
                name: format!("Allow: {}", req.args_preview),
                kind: AcpOptionKind::AllowOnce,
            },
            AcpPermissionOption {
                option_id: "allow_always".into(),
                name: req
                    .remember_pattern
                    .clone()
                    .map_or_else(|| "Always allow this".to_owned(), |p| format!("Always allow `{p}`")),
                kind: AcpOptionKind::AllowAlways,
            },
            AcpPermissionOption {
                option_id: "reject_once".into(),
                name: "Deny once".into(),
                kind: AcpOptionKind::RejectOnce,
            },
            AcpPermissionOption {
                option_id: "reject_always".into(),
                name: "Deny and remember".into(),
                kind: AcpOptionKind::RejectAlways,
            },
        ],
        extra: {
            let mut m = BTreeMap::new();
            m.insert("risk".to_string(), Value::from(req.risk.badge()));
            if let Some(cwd) = &req.cwd {
                m.insert("cwd".to_string(), Value::from(cwd.clone()));
            }
            if let Some(rule) = &req.rule_hint {
                m.insert("ruleHint".to_string(), Value::from(rule.clone()));
            }
            m.insert("sandbox".to_string(), Value::from(req.sandbox.label()));
            m
        },
    }
}

/// Translate an editor's answer back into our [`Decision`].
#[must_use]
pub fn from_acp_permission(resp: &AcpPermissionResponse, req: &PermissionRequest) -> Decision {
    let Some(AcpOutcome::Selected { option_id }) = resp.outcome.as_ref() else {
        // Cancelled/dismissed defaults to deny, never allow (§3.2).
        return Decision::Deny { reason: "dismissed by the editor".to_owned() };
    };
    let pattern = req.remember_pattern.clone().unwrap_or_else(|| format!("{}(*)", req.tool));
    match option_id.as_str() {
        "allow_once" => Decision::Allow,
        "allow_always" => Decision::AllowAlways {
            pattern,
            scope: crate::op::RememberScope::ThisSession,
        },
        "reject_always" => Decision::DenyAlways {
            pattern,
            scope: crate::op::RememberScope::ThisSession,
        },
        _ => Decision::Deny { reason: "denied in the editor".to_owned() },
    }
}

// ── diffs ───────────────────────────────────────────────────────────────────

/// ACP's diff representation: one entry per file, with the full old/new text.
///
/// Editors render this natively, which is why §9.14 requires the mapping to be
/// lossless for `added`/`modified`/`deleted`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcpDiff {
    /// Entries.
    pub entries: Vec<AcpDiffEntry>,
}

/// One file in an [`AcpDiff`].
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcpDiffEntry {
    /// `file://` URI or absolute path.
    pub path: String,
    /// Full new text, when available.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub new_text: Option<String>,
    /// Full old text, when available.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub old_text: Option<String>,
    /// Unified diff, for editors that prefer it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub unified: Option<String>,
    /// What happened.
    pub change: AcpFileChange,
}

/// ACP change kind.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AcpFileChange {
    /// New file.
    Added,
    /// Modified.
    Modified,
    /// Deleted.
    Deleted,
    /// Renamed.
    Renamed,
}

impl AcpDiff {
    /// Build from our [`Diff`]. Text bodies are not carried by our diff type
    /// (only hunks), so `new_text`/`old_text` stay `None` and the unified text
    /// is forwarded when we have it.
    #[must_use]
    pub fn from_diff(diff: &Diff) -> Self {
        Self {
            entries: diff
                .files
                .iter()
                .map(|f| AcpDiffEntry {
                    path: f.path.clone(),
                    new_text: None,
                    old_text: None,
                    unified: diff.unified.clone(),
                    change: match f.change {
                        FileChange::Added => AcpFileChange::Added,
                        FileChange::Deleted => AcpFileChange::Deleted,
                        FileChange::Renamed => AcpFileChange::Renamed,
                        FileChange::Modified | FileChange::ModeChanged => AcpFileChange::Modified,
                    },
                })
                .collect(),
        }
    }
}

// ── event → notification translation ────────────────────────────────────────

/// Translate one of our events into zero or more ACP `session/update`
/// notifications.
///
/// Events with no ACP analogue (usage, cost, warnings, worker board traffic)
/// map to the empty vec: the editor does not need them and we must not invent
/// non-standard notifications.
#[must_use]
pub fn event_to_updates(session_id: &str, event: &Event) -> Vec<SessionUpdate> {
    let sid = session_id.to_owned();
    match event {
        Event::TextDelta(d) => vec![SessionUpdate::AgentMessageChunk(ContentChunk {
            session_id: sid,
            content: vec![AcpContent::Text { text: d.text.clone(), annotations: None }],
            extra: Extra::new(),
        })],
        Event::ThinkingDelta(d) if !d.redacted => vec![SessionUpdate::AgentThoughtChunk(
            ContentChunk {
                session_id: sid,
                content: vec![AcpContent::Text { text: d.text.clone(), annotations: None }],
                extra: Extra::new(),
            },
        )],
        Event::ToolRequested(ToolRequested { call, risk, .. }) => {
            vec![SessionUpdate::ToolCall(ToolCallUpdate {
                session_id: sid,
                tool_call_id: call.id.to_string(),
                title: format!("{} {}", call.name, call.args_preview()),
                kind: AcpToolKind::from_risk(*risk),
                status: AcpToolStatus::Pending,
                raw_input: Some(call.args.clone()),
                raw_output: None,
                content: vec![],
                locations: tool_locations(&call.args),
                extra: Extra::new(),
            })]
        }
        Event::ToolCompleted(ToolCompleted { result: crate::tool::ToolResult::Ok { call_id, parts, summary, .. }, name, .. }) => {
            vec![SessionUpdate::ToolCall(ToolCallUpdate {
                session_id: sid,
                tool_call_id: call_id.to_string(),
                title: summary.clone(),
                kind: AcpToolKind::Other,
                status: AcpToolStatus::Completed,
                raw_input: None,
                raw_output: None,
                content: parts_to_acp(parts),
                locations: vec![],
                extra: {
                    let mut m = Extra::new();
                    m.insert("tool".to_string(), Value::from(name.clone()));
                    m
                },
            })]
        }
        Event::ToolCompleted(ToolCompleted { result, .. }) => vec![SessionUpdate::ToolCall(
            ToolCallUpdate {
                session_id: sid,
                tool_call_id: result_id(result).to_string(),
                title: "tool call".to_string(),
                kind: AcpToolKind::Other,
                status: AcpToolStatus::Failed,
                raw_input: None,
                raw_output: Some(Value::from(result.model_visible_text())),
                content: vec![],
                locations: vec![],
                extra: Extra::new(),
            },
        )],
        Event::ToolFailed(ToolFailed { call_id, error, name, .. }) => {
            vec![SessionUpdate::ToolCall(ToolCallUpdate {
                session_id: sid,
                tool_call_id: call_id.to_string(),
                title: format!("{name} failed: {}", error.message),
                kind: AcpToolKind::Other,
                status: AcpToolStatus::Failed,
                raw_input: None,
                raw_output: Some(Value::from(error.to_model_string())),
                content: vec![],
                locations: vec![],
                extra: Extra::new(),
            })]
        }
        Event::ToolDenied(ToolDenied { call_id, reason, name, .. }) => {
            vec![SessionUpdate::ToolCall(ToolCallUpdate {
                session_id: sid,
                tool_call_id: call_id.to_string(),
                title: format!("{name} denied: {reason}"),
                kind: AcpToolKind::Other,
                status: AcpToolStatus::Failed,
                raw_input: None,
                raw_output: Some(Value::from(reason.clone())),
                content: vec![],
                locations: vec![],
                extra: Extra::new(),
            })]
        }
        _ => vec![],
    }
}

fn result_id(r: &crate::tool::ToolResult) -> RequestId {
    match r {
        crate::tool::ToolResult::Ok { call_id, .. }
        | crate::tool::ToolResult::Err { call_id, .. }
        | crate::tool::ToolResult::Denied { call_id, .. } => {
            // ACP ids are strings; reuse the call id bytes so the editor can
            // correlate. RequestId and CallId share the ULID representation.
            RequestId::from_ulid(*call_id.as_ulid())
        }
    }
}

fn parts_to_acp(parts: &[crate::content::ContentPart]) -> Vec<AcpContent> {
    parts
        .iter()
        .filter_map(|p| match p {
            crate::content::ContentPart::Text { text } => {
                Some(AcpContent::Text { text: text.clone(), annotations: None })
            }
            crate::content::ContentPart::Terminal(t) => {
                Some(AcpContent::Text { text: t.stripped.clone(), annotations: None })
            }
            crate::content::ContentPart::ResourceLink { uri, name, media_type, .. } => {
                Some(AcpContent::ResourceLink {
                    uri: uri.clone(),
                    name: name.clone(),
                    mime_type: media_type.clone(),
                })
            }
            _ => None,
        })
        .collect()
}

/// Extract `path`/`file_path` style arguments into ACP locations so the editor
/// can highlight the touched files.
fn tool_locations(args: &Value) -> Vec<ToolLocation> {
    let mut out = Vec::new();
    for key in ["path", "file_path", "file", "notebook_path"] {
        if let Some(p) = args.get(key).and_then(Value::as_str) {
            out.push(ToolLocation { path: to_file_uri(p), line: args.get("offset").and_then(Value::as_u64) });
        }
    }
    out
}

/// Convert a filesystem path into a `file://` URI.
#[must_use]
pub fn to_file_uri(path: &str) -> String {
    if path.starts_with("file://") {
        return path.to_owned();
    }
    let normalized = path.replace('\\', "/");
    if normalized.starts_with('/') {
        format!("file://{normalized}")
    } else {
        format!("file:///{normalized}")
    }
}

/// Convert a `file://` URI back to a path.
#[must_use]
pub fn from_file_uri(uri: &str) -> String {
    let Some(rest) = uri.strip_prefix("file://") else {
        return uri.to_owned();
    };
    let rest = rest.strip_prefix('/').unwrap_or(rest);
    if cfg!(windows) {
        rest.to_owned()
    } else {
        format!("/{rest}")
    }
}

/// The ACP session id we use for a thread: the thread id string. Editors treat
/// it as opaque.
#[must_use]
pub fn session_id_for(thread: ThreadId) -> String {
    thread.to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::event::{TextDelta, ThinkingDelta};
    use crate::ids::{CallId, TurnId};
    use crate::tool::{DeniedBy, ToolCall, ToolError, ToolErrorKind, ToolResult};

    #[test]
    fn text_deltas_become_agent_message_chunks() {
        let e = Event::TextDelta(TextDelta { turn_id: TurnId::new(), block: 0, text: "hi".into() });
        let u = event_to_updates("ses_1", &e);
        assert_eq!(u.len(), 1);
        match &u[0] {
            SessionUpdate::AgentMessageChunk(c) => {
                assert_eq!(c.session_id, "ses_1");
                assert_eq!(c.content[0].as_text(), Some("hi"));
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn redacted_thinking_is_never_forwarded() {
        let e = Event::ThinkingDelta(ThinkingDelta {
            turn_id: TurnId::new(),
            text: "secret reasoning".into(),
            redacted: true,
        });
        assert!(event_to_updates("s", &e).is_empty());
        let e2 = Event::ThinkingDelta(ThinkingDelta {
            turn_id: TurnId::new(),
            text: "visible".into(),
            redacted: false,
        });
        assert_eq!(event_to_updates("s", &e2).len(), 1);
    }

    #[test]
    fn tool_requests_become_pending_tool_calls_with_locations() {
        let id = CallId::new();
        let call = ToolCall::new(
            id,
            "read_file",
            serde_json::json!({"path": "/repo/src/a.rs", "offset": 10}),
            RiskClass::Read,
        );
        let e = Event::ToolRequested(ToolRequested {
            turn_id: TurnId::new(),
            call,
            risk: RiskClass::Read,
            index: 0,
        });
        let u = event_to_updates("s", &e);
        match &u[0] {
            SessionUpdate::ToolCall(t) => {
                assert_eq!(t.status, AcpToolStatus::Pending);
                assert_eq!(t.kind, AcpToolKind::Read);
                assert_eq!(t.locations.len(), 1);
                assert_eq!(t.locations[0].path, "file:///repo/src/a.rs");
                assert_eq!(t.locations[0].line, Some(10));
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn failures_map_to_a_failed_status_not_a_crash() {
        let id = CallId::new();
        let e = Event::ToolFailed(ToolFailed {
            turn_id: TurnId::new(),
            call_id: id,
            name: "shell".into(),
            error: ToolError::new(ToolErrorKind::Timeout, "killed after 120s"),
            duration_ms: 120_000,
        });
        match &event_to_updates("s", &e)[0] {
            SessionUpdate::ToolCall(t) => assert_eq!(t.status, AcpToolStatus::Failed),
            other => panic!("{other:?}"),
        }
        let d = Event::ToolDenied(ToolDenied {
            turn_id: TurnId::new(),
            call_id: id,
            name: "shell".into(),
            by: DeniedBy::Policy,
            reason: "deny rule".into(),
        });
        match &event_to_updates("s", &d)[0] {
            SessionUpdate::ToolCall(t) => {
                assert_eq!(t.status, AcpToolStatus::Failed);
                assert!(t.title.contains("denied"));
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn unmapped_events_produce_nothing() {
        let e = Event::UsageUpdated(crate::event::UsageUpdated {
            turn_id: TurnId::new(),
            delta: crate::usage::Usage::zero(),
            total: crate::usage::Usage::zero(),
            model: crate::model::ModelId::new("m", "n"),
        });
        assert!(event_to_updates("s", &e).is_empty());
    }

    #[test]
    fn permission_request_offers_four_options_with_deny_as_the_last_word() {
        let req = PermissionRequest {
            request_id: RequestId::new(),
            tool: "shell".into(),
            risk: RiskClass::Exec,
            args_preview: "command=rm -rf build".into(),
            args: Value::Null,
            paths: vec![],
            cwd: Some("/repo".into()),
            rule_hint: Some("deny rule #3".into()),
            sandbox: crate::permission::SandboxStatus::Enabled { backend: "bwrap".into() },
            scope: crate::permission::RequestScope::Once,
            remember_pattern: Some("shell(rm -rf build)".into()),
            raised_at_ms: 0,
        };
        let acp = to_acp_permission("s", &req);
        assert_eq!(acp.options.len(), 4);
        assert_eq!(acp.options[0].kind, AcpOptionKind::AllowOnce);
        assert!(acp.options[1].name.contains("shell(rm -rf build)"));
        assert_eq!(acp.extra["risk"], "exec");
        assert_eq!(acp.extra["sandbox"], "sandboxed (bwrap)");

        // A cancelled response must deny, never allow.
        let cancelled = AcpPermissionResponse { outcome: Some(AcpOutcome::Cancelled), extra: Extra::new() };
        assert!(from_acp_permission(&cancelled, &req).denies());

        let allow_always = AcpPermissionResponse {
            outcome: Some(AcpOutcome::Selected { option_id: "allow_always".into() }),
            extra: Extra::new(),
        };
        match from_acp_permission(&allow_always, &req) {
            Decision::AllowAlways { pattern, .. } => assert_eq!(pattern, "shell(rm -rf build)"),
            other => panic!("{other:?}"),
        }

        // An unknown option id falls through to deny.
        let weird = AcpPermissionResponse {
            outcome: Some(AcpOutcome::Selected { option_id: "maybe".into() }),
            extra: Extra::new(),
        };
        assert!(from_acp_permission(&weird, &req).denies());
    }

    #[test]
    fn file_uri_conversion_roundtrips() {
        assert_eq!(to_file_uri("/repo/a.rs"), "file:///repo/a.rs");
        assert_eq!(from_file_uri("file:///repo/a.rs"), "/repo/a.rs");
        assert_eq!(to_file_uri("file:///already"), "file:///already");
    }

    #[test]
    fn diff_mapping_preserves_change_kinds() {
        let d = Diff {
            files: vec![
                crate::content::DiffFile {
                    path: "a.rs".into(),
                    old_path: None,
                    change: FileChange::Modified,
                    hunks: vec![],
                    added: 1,
                    removed: 1,
                    binary: false,
                },
                crate::content::DiffFile {
                    path: "b.rs".into(),
                    old_path: Some("c.rs".into()),
                    change: FileChange::Renamed,
                    hunks: vec![],
                    added: 0,
                    removed: 0,
                    binary: false,
                },
            ],
            unified: Some("--- a\n+++ b\n".into()),
        };
        let a = AcpDiff::from_diff(&d);
        assert_eq!(a.entries.len(), 2);
        assert_eq!(a.entries[0].change, AcpFileChange::Modified);
        assert_eq!(a.entries[1].change, AcpFileChange::Renamed);
        assert_eq!(a.entries[0].unified.as_deref(), Some("--- a\n+++ b\n"));
    }

    #[test]
    fn unknown_notification_variants_survive_decoding() {
        let v = serde_json::json!({"sessionUpdate": "some_future_thing", "x": 1});
        let u: SessionUpdate = serde_json::from_value(v).unwrap();
        assert_eq!(u, SessionUpdate::Unknown);
    }

    #[test]
    fn extra_fields_are_preserved_on_a_tool_call_update() {
        let raw = serde_json::json!({
            "sessionUpdate": "tool_call",
            "sessionId": "s",
            "toolCallId": "t",
            "title": "x",
            "kind": "read",
            "status": "completed",
            "futureField": 42
        });
        let u: SessionUpdate = serde_json::from_value(raw).unwrap();
        match u {
            SessionUpdate::ToolCall(t) => {
                assert_eq!(t.extra.get("futureField"), Some(&Value::from(42)));
                assert_eq!(t.session_id, "s");
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn tool_result_ok_maps_to_completed() {
        let id = CallId::new();
        let e = Event::ToolCompleted(ToolCompleted {
            turn_id: TurnId::new(),
            result: ToolResult::ok_text(id, "read 3 lines", "a\nb\nc"),
            name: "read_file".into(),
            duration_ms: 2,
            render: None,
        });
        match &event_to_updates("s", &e)[0] {
            SessionUpdate::ToolCall(t) => {
                assert_eq!(t.status, AcpToolStatus::Completed);
                assert_eq!(t.tool_call_id, id.to_string());
                assert_eq!(t.content[0].as_text(), Some("a\nb\nc"));
            }
            other => panic!("{other:?}"),
        }
    }
}
