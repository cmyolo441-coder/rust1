//! Worker report and lifecycle types (`rustplan.txt` §7.8, §7.10).
//!
//! A worker returns **only** a [`WorkerReport`]. The parent turn never sees the
//! worker's transcript — that is the whole point of context isolation: a
//! 30-turn exploration that ends in "the flag lives in `src/cli.rs:42`" must
//! cost the parent ~200 tokens, not 40 000.
//!
//! The report is schema-validated *and* cross-checked against the node's
//! declared `write_set`: `files_changed ⊆ write_set`. A violation means the
//! worker escaped its lease, which is a hard failure (§7.8).

use serde::{Deserialize, Serialize};

use crate::ids::WorkerId;
use crate::usage::Usage;

/// Lifecycle state of a worker, mirrored on the board (§7.14).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WorkerState {
    /// Created, not yet scheduled.
    Queued,
    /// Waiting for a file lease (§7.6).
    WaitingLease,
    /// Waiting for budget headroom.
    WaitingBudget,
    /// Setting up its worktree.
    Preparing,
    /// Executing.
    Running,
    /// Running its acceptance commands.
    Verifying,
    /// Finished successfully.
    Done,
    /// Finished with caveats; the parent decides.
    Partial,
    /// Cannot proceed; blocked on something outside its scope.
    Blocked,
    /// Failed after retries.
    Failed,
    /// Cancelled by the user, the supervisor or a stalled lease.
    Cancelled,
    /// Excluded from the run after repeated failures (§7.9 step 4).
    Quarantined,
    /// Merged into the mainline.
    Merged,
}

impl WorkerState {
    /// True when the worker is occupying a concurrency slot.
    #[must_use]
    pub const fn is_active(self) -> bool {
        matches!(
            self,
            WorkerState::Preparing
                | WorkerState::Running
                | WorkerState::Verifying
                | WorkerState::WaitingLease
        )
    }

    /// True when the worker will not change state any more.
    #[must_use]
    pub const fn is_terminal(self) -> bool {
        matches!(
            self,
            WorkerState::Done
                | WorkerState::Partial
                | WorkerState::Blocked
                | WorkerState::Failed
                | WorkerState::Cancelled
                | WorkerState::Quarantined
                | WorkerState::Merged
        )
    }

    /// Colour token for the board card (§9.12 `render/board.rs`).
    #[must_use]
    pub const fn tone(self) -> &'static str {
        match self {
            WorkerState::Queued | WorkerState::WaitingLease | WorkerState::WaitingBudget => "muted",
            WorkerState::Preparing | WorkerState::Running | WorkerState::Verifying => "accent",
            WorkerState::Done | WorkerState::Merged => "success",
            WorkerState::Partial | WorkerState::Blocked => "warning",
            WorkerState::Failed | WorkerState::Cancelled | WorkerState::Quarantined => "danger",
        }
    }

    /// Single-character glyph for narrow boards.
    #[must_use]
    pub const fn glyph(self) -> char {
        match self {
            WorkerState::Queued => '·',
            WorkerState::WaitingLease => '⌛',
            WorkerState::WaitingBudget => '$',
            WorkerState::Preparing => '▷',
            WorkerState::Running => '▶',
            WorkerState::Verifying => '✓',
            WorkerState::Done => '✔',
            WorkerState::Merged => '⊕',
            WorkerState::Partial => '◐',
            WorkerState::Blocked => '⛔',
            WorkerState::Failed => '✖',
            WorkerState::Cancelled => '⊘',
            WorkerState::Quarantined => '☣',
        }
    }
}

/// Outcome a worker self-reports.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WorkerStatus {
    /// Acceptance met, work complete.
    Done,
    /// Some work done, acceptance not fully met.
    Partial,
    /// Cannot proceed without a decision or resource outside its scope.
    Blocked,
    /// Tried and failed.
    Failed,
}

/// One acceptance command and its result.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TestRun {
    /// The exact command.
    pub cmd: String,
    /// `pass` / `fail` / `error` / `skipped`.
    pub result: TestVerdict,
    /// Wall time.
    #[serde(default)]
    pub duration_ms: u64,
    /// Tail of the output, capped.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub evidence: Option<String>,
}

/// Verdict of one acceptance command.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TestVerdict {
    /// Passed.
    Pass,
    /// Failed (tests ran, some failed).
    Fail,
    /// Could not run (missing binary, timeout, infra).
    Error,
    /// Not applicable.
    Skipped,
}

impl TestVerdict {
    /// True when this verdict satisfies acceptance.
    #[must_use]
    pub const fn satisfies(self) -> bool {
        matches!(self, TestVerdict::Pass | TestVerdict::Skipped)
    }
}

/// Evidence attached to a report. Everything here is a *reference*, never a
/// blob: the raw transcript lives in a sidecar file so the parent's context
/// stays clean.
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
pub struct WorkerEvidence {
    /// Path to the worker's raw log (sidecar).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub log_ref: Option<String>,
    /// `2 files, +140 -3` style diffstat.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub diff_stat: Option<String>,
    /// Commit refs created in the worktree.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub commits: Vec<String>,
}

/// The structured return protocol (§7.8).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkerReport {
    /// DAG node this report answers.
    pub node_id: String,
    /// Self-reported outcome.
    pub status: WorkerStatus,
    /// 300–600 token summary. **This is the only thing the parent sees.**
    pub summary: String,
    /// Workspace-relative paths the worker changed.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub files_changed: Vec<String>,
    /// Commits created in the worker's worktree.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub commits: Vec<String>,
    /// Acceptance command results.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tests: Vec<TestRun>,
    /// True when every acceptance command passed.
    #[serde(default)]
    pub acceptance_met: bool,
    /// Self-assessed confidence 0..=1.
    #[serde(default)]
    pub confidence: f32,
    /// What stopped it, when `status` is `blocked`/`failed`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub blockers: Vec<String>,
    /// References to logs/diffstat.
    #[serde(default)]
    pub evidence: WorkerEvidence,
    /// Token and cost accounting for this worker.
    #[serde(default)]
    pub cost: Usage,
}

impl WorkerReport {
    /// A minimal successful report.
    #[must_use]
    pub fn done(node_id: impl Into<String>, summary: impl Into<String>) -> Self {
        Self {
            node_id: node_id.into(),
            status: WorkerStatus::Done,
            summary: summary.into(),
            files_changed: Vec::new(),
            commits: Vec::new(),
            tests: Vec::new(),
            acceptance_met: true,
            confidence: 1.0,
            blockers: Vec::new(),
            evidence: WorkerEvidence::default(),
            cost: Usage::zero(),
        }
    }

    /// A blocked report.
    #[must_use]
    pub fn blocked(node_id: impl Into<String>, summary: impl Into<String>, blockers: Vec<String>) -> Self {
        Self {
            node_id: node_id.into(),
            status: WorkerStatus::Blocked,
            summary: summary.into(),
            acceptance_met: false,
            confidence: 0.0,
            blockers,
            ..Self::done("", "")
        }
    }

    /// Validate the report against the node's declared write set.
    ///
    /// Returns the list of paths that violate the lease. A non-empty result
    /// means the report is **rejected** and the worker is quarantined (§7.8).
    ///
    /// `write_set` entries are globs; matching uses the shared glob engine so
    /// behaviour is identical to the lease check in the orchestrator.
    #[must_use]
    pub fn lease_violations(&self, write_set: &[String]) -> Vec<String> {
        self.files_changed
            .iter()
            .filter(|p| !crate::glob_match::matches_any(write_set, p))
            .cloned()
            .collect()
    }

    /// Recompute `acceptance_met` from the test results. The model's
    /// self-assessment is ignored: acceptance is evidence, not opinion
    /// (§9.4 `verify.rs`: "silent 'looks fine' kabhi nahi").
    pub fn reconcile_acceptance(&mut self) -> bool {
        self.acceptance_met = !self.tests.is_empty() && self.tests.iter().all(|t| t.result.satisfies());
        self.acceptance_met
    }

    /// True when the summary is inside the 300–600 token envelope.
    #[must_use]
    pub fn summary_within_budget(&self) -> bool {
        crate::token_estimate::estimate(&self.summary) <= 700
    }

    /// Token cost of the whole report as it will land in the parent context.
    #[must_use]
    pub fn parent_cost_tokens(&self) -> u32 {
        // Only the summary plus the file list goes to the parent.
        crate::token_estimate::estimate(&self.summary)
            + crate::token_estimate::estimate(&self.files_changed.join("\n"))
    }
}

/// Snapshot of a worker for the board and the SQLite `workers` table.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkerSnapshot {
    /// Worker id.
    pub worker_id: WorkerId,
    /// DAG node id.
    pub node_id: String,
    /// Current state.
    pub state: WorkerState,
    /// Progress 0..=100.
    pub percent: u8,
    /// Tokens used.
    pub tokens: u64,
    /// Cost, USD micros.
    pub cost_micros: u64,
    /// Worktree path, if any.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub worktree: Option<String>,
    /// Paths currently leased.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub leases: Vec<String>,
    /// Attempts so far (1 = first try).
    #[serde(default = "one")]
    pub attempt: u8,
}

const fn one() -> u8 {
    1
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lease_violations_flag_out_of_scope_writes() {
        let r = WorkerReport {
            files_changed: vec!["src/api/mod.rs".into(), "src/other/x.rs".into()],
            ..WorkerReport::done("n1", "did things")
        };
        let v = r.lease_violations(&["src/api/**".to_string()]);
        assert_eq!(v, vec!["src/other/x.rs".to_string()]);
    }

    #[test]
    fn empty_write_set_rejects_every_write() {
        let r = WorkerReport {
            files_changed: vec!["a.rs".into()],
            ..WorkerReport::done("n1", "s")
        };
        assert_eq!(r.lease_violations(&[]), vec!["a.rs".to_string()]);
    }

    #[test]
    fn acceptance_is_derived_from_evidence_not_opinion() {
        let mut r = WorkerReport::done("n1", "s");
        r.acceptance_met = true;
        // No tests recorded at all => not met.
        assert!(!r.reconcile_acceptance());

        r.tests.push(TestRun { cmd: "cargo test".into(), result: TestVerdict::Pass, duration_ms: 1, evidence: None });
        assert!(r.reconcile_acceptance());

        r.tests.push(TestRun { cmd: "cargo clippy".into(), result: TestVerdict::Fail, duration_ms: 1, evidence: None });
        assert!(!r.reconcile_acceptance());
    }

    #[test]
    fn skipped_acceptance_counts_as_met() {
        let mut r = WorkerReport::done("n1", "s");
        r.tests.push(TestRun { cmd: "n/a".into(), result: TestVerdict::Skipped, duration_ms: 0, evidence: None });
        assert!(r.reconcile_acceptance());
    }

    #[test]
    fn summary_budget_is_enforced() {
        assert!(WorkerReport::done("n1", "short summary").summary_within_budget());
        let long = "word ".repeat(2000);
        assert!(!WorkerReport::done("n1", long).summary_within_budget());
    }

    #[test]
    fn parent_only_pays_for_the_summary() {
        let mut r = WorkerReport::done("n1", "Added middleware.".to_string());
        r.evidence.log_ref = Some("worker-n1.log".into());
        r.tests.push(TestRun { cmd: "cargo test".into(), result: TestVerdict::Pass, duration_ms: 1, evidence: Some("x".repeat(5000)) });
        assert!(r.parent_cost_tokens() < 40, "got {}", r.parent_cost_tokens());
    }

    #[test]
    fn worker_states_partition_into_active_and_terminal() {
        let all = [
            WorkerState::Queued, WorkerState::WaitingLease, WorkerState::WaitingBudget,
            WorkerState::Preparing, WorkerState::Running, WorkerState::Verifying,
            WorkerState::Done, WorkerState::Partial, WorkerState::Blocked, WorkerState::Failed,
            WorkerState::Cancelled, WorkerState::Quarantined, WorkerState::Merged,
        ];
        for s in all {
            assert!(!(s.is_active() && s.is_terminal()), "{s:?} is both");
            assert!(!s.tone().is_empty());
            assert!(s.glyph() != '\0');
        }
        assert!(WorkerState::Running.is_active());
        assert!(WorkerState::Done.is_terminal());
        assert!(!WorkerState::Queued.is_active());
    }

    #[test]
    fn blocked_report_carries_blockers() {
        let r = WorkerReport::blocked("n2", "needs a decision", vec!["which crate owns this?".into()]);
        assert_eq!(r.status, WorkerStatus::Blocked);
        assert!(!r.acceptance_met);
        assert_eq!(r.blockers.len(), 1);
    }

    #[test]
    fn report_roundtrips_through_json() {
        let r = WorkerReport {
            files_changed: vec!["a.rs".into()],
            commits: vec!["worktree:3f9a1c2".into()],
            tests: vec![TestRun { cmd: "cargo test".into(), result: TestVerdict::Pass, duration_ms: 41, evidence: None }],
            confidence: 0.8,
            ..WorkerReport::done("n1", "Added TokenBucket middleware.")
        };
        let v = serde_json::to_value(&r).unwrap();
        assert_eq!(v["status"], "done");
        assert_eq!(v["node_id"], "n1");
        let back: WorkerReport = serde_json::from_value(v).unwrap();
        assert_eq!(back, r);
    }
}
