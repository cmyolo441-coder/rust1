//! Repository awareness: status, diff, worktrees, shadow-git checkpoints.
#![warn(missing_docs)]
