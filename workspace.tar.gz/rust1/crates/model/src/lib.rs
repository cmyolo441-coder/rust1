//! Model gateway: providers, SSE streaming, token/cost, cache, failover.
#![warn(missing_docs)]
