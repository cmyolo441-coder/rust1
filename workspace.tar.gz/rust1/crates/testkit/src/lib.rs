//! Deterministic fixtures, mock provider and golden-transcript helpers.
#![warn(missing_docs)]
