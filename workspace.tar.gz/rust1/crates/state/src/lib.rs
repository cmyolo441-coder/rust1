//! Durable truth: JSONL rollout, SQLite index, snapshots, resume, GC.
#![warn(missing_docs)]
