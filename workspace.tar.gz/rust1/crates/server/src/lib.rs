//! Headless surfaces: JSON-RPC app-server, WebSocket, ACP.
#![warn(missing_docs)]
