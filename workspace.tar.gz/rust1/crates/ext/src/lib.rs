//! Extensibility: skills, hooks, plugins, custom commands, profiles.
#![warn(missing_docs)]
