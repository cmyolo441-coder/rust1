//! Terminal UI: renderer, input, approvals, board, a11y.
#![warn(missing_docs)]
