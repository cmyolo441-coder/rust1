//! Entrypoints: subcommands, headless mode, doctor, auth, update.
#![warn(missing_docs)]
