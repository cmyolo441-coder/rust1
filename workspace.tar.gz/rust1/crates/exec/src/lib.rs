//! Process execution primitives: spawn, PTY, groups, env scrubbing, reaper.
#![warn(missing_docs)]
