//! Parallel subagents: DAG, leases, deterministic scheduler, merge gates.
#![warn(missing_docs)]
